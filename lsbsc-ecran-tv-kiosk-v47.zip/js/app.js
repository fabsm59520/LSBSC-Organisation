/* ==========================================================================
   LILLE SUD BASKETBALL SPORTING CLUB (LSBSC - SOUTH LILLE)
   Sélection de Format (TV 16:9 / Téléphone Allégé), Direct, Saisie & PIN
   ========================================================================== */

const DEFAULT_MATCHES = [{"id": 1, "wk": "w01", "wkLabel": "Week-end du 05 Sep. 2026", "wkShort": "05 Sep", "date": "SAM. 05 SEP.", "time": "18H00", "home": "SEQUEDIN OSM", "away": "U18 GARÇONS CADETS", "sh": 86, "sa": 55, "status": "finished", "cat": "U18M", "comp": "Amical", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "GÉRARD DEWAELE", "address": "RUE D'HALLENNES 59320 SEQUEDIN", "precision": ""}, {"id": 2, "wk": "w02", "wkLabel": "Week-end des 12 & 13 Sep. 2026", "wkShort": "12-13 Sep", "date": "SAM. 12 SEP.", "time": "15H30", "home": "U15 FILLES MINIMES", "away": "TOURCOING US F - 1", "sh": 27, "sa": 46, "status": "finished", "cat": "U15F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 3, "wk": "w02", "wkLabel": "Week-end des 12 & 13 Sep. 2026", "wkShort": "12-13 Sep", "date": "SAM. 12 SEP.", "time": "18H30", "home": "LILLE-EST BASKET - 1", "away": "U18 FILLES CADETTE", "sh": 66, "sa": 21, "status": "finished", "cat": "U18F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "GYMNASE LYCEE HOTELIER", "address": "31 RUE DE VAUCANSON 59800 LILLE", "precision": ""}, {"id": 4, "wk": "w02", "wkLabel": "Week-end des 12 & 13 Sep. 2026", "wkShort": "12-13 Sep", "date": "DIM. 13 SEP.", "time": "14H00", "home": "LOMME BASKET CLUB (LBC) - 1", "away": "U18 GARÇONS CADETS", "sh": 87, "sa": 45, "status": "finished", "cat": "U18M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PALAIS DES SPORTS", "address": "RUE LÉO LAGRANGE 59160 LOMME", "precision": ""}, {"id": 5, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "SAM. 19 SEP.", "time": "17H00", "home": "U13 FILLE BENJAMINES", "away": "BAILLEULOIS B C", "sh": 45, "sa": 27, "status": "finished", "cat": "U13F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 6, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "SAM. 19 SEP.", "time": "17H00", "home": "COMINOISE LL", "away": "U11 FILLES POUSSINES", "sh": 15, "sa": 27, "status": "finished", "cat": "U11F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE JEAN DEGROS", "address": "RUE DES SPORTS 59560 COMINES", "precision": ""}, {"id": 7, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "SAM. 19 SEP.", "time": "18H30", "home": "U18 FILLES CADETTE", "away": "WATTRELOS BC", "sh": 55, "sa": 44, "status": "finished", "cat": "U18F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 8, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "SAM. 19 SEP.", "time": "20H30", "home": "SENIORS MASCULINS 2", "away": "BAUVIN B C - 2", "sh": 50, "sa": 61, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 9, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "DIM. 20 SEP.", "time": "10H30", "home": "U18 GARÇONS CADETS", "away": "ORCHESIEN B C - 2", "sh": 60, "sa": 112, "status": "finished", "cat": "U18M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 10, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "DIM. 20 SEP.", "time": "11H00", "home": "ESTAIRES BC - 2", "away": "SENIORS MASCULINS 1", "sh": 35, "sa": 72, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE LES TULIPES", "address": "59940 ESTAIRES", "precision": ""}, {"id": 11, "wk": "w03", "wkLabel": "Week-end des 19 & 20 Sep. 2026", "wkShort": "19-20 Sep", "date": "DIM. 20 SEP.", "time": "14H00", "home": "LOMME BASKET CLUB (LBC)", "away": "U15 FILLES MINIMES", "sh": 44, "sa": 34, "status": "finished", "cat": "U15F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PALAIS DES SPORTS", "address": "RUE LÉO LAGRANGE 59160 LOMME", "precision": ""}, {"id": 12, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "SAM. 26 SEP.", "time": "17H00", "home": "U15 FILLES MINIMES", "away": "WASQUEHAL FEM B - 1", "sh": 11, "sa": 81, "status": "finished", "cat": "U15F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 13, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "SAM. 26 SEP.", "time": "17H00", "home": "LOMME BASKET CLUB (LBC)", "away": "U13 FILLE BENJAMINES", "sh": 31, "sa": 31, "status": "finished", "cat": "U13F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PALAIS DES SPORTS", "address": "RUE LÉO LAGRANGE 59160 LOMME", "precision": ""}, {"id": 14, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "SAM. 26 SEP.", "time": "18H30", "home": "U18 GARÇONS CADETS", "away": "WAMBRECHIES J - 1", "sh": 46, "sa": 86, "status": "finished", "cat": "U18M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 15, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "SAM. 26 SEP.", "time": "18H30", "home": "WAMBRECHIES J", "away": "U18 FILLES CADETTE", "sh": 40, "sa": 32, "status": "finished", "cat": "U18F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE JACQUES PREVOST", "address": "59118 WAMBRECHIES", "precision": ""}, {"id": 16, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "SAM. 26 SEP.", "time": "20H30", "home": "SENIORS MASCULINS 1", "away": "HELLEMMES LILLE BFC - 3", "sh": 62, "sa": 57, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 17, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "DIM. 27 SEP.", "time": "11H00", "home": "U9 MIXTE MINI-POUSSINS", "away": "CHAPELLE D'ARMENTIERES OSM", "sh": 6, "sa": 50, "status": "finished", "cat": "U9", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 18, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "DIM. 27 SEP.", "time": "15H00", "home": "HELLEMMES LILLE BFC - 2", "away": "SENIORS MASCULINS 2", "sh": 56, "sa": 39, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE LEO LAGRANGE", "address": "RUE FERDINAND BUISSON 59260 HELLEMMES", "precision": ""}, {"id": 19, "wk": "w04", "wkLabel": "Week-end des 26 & 27 Sep. 2026", "wkShort": "26-27 Sep", "date": "DIM. 27 SEP.", "time": "16H00", "home": "U11 FILLES POUSSINES", "away": "SPORTS OUVRIERS ARMENTIEROIS - 1", "sh": 35, "sa": 8, "status": "finished", "cat": "U11F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 20, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "SAM. 03 OCT.", "time": "14H00", "home": "RONCHIN BC - 1", "away": "U11 FILLES POUSSINES", "sh": 14, "sa": 36, "status": "finished", "cat": "U11F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "NIO/LOUCHART", "address": "RUE CHARLES SAINT-VENANT 59790 RONCHIN", "precision": ""}, {"id": 21, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "SAM. 03 OCT.", "time": "15H30", "home": "HEM S B B", "away": "U15 FILLES MINIMES", "sh": 48, "sa": 18, "status": "finished", "cat": "U15F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE DELCOURT", "address": "52 RUE JEAN JAURÈS 59510 HEM", "precision": ""}, {"id": 22, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "SAM. 03 OCT.", "time": "17H00", "home": "U18 FILLES CADETTE", "away": "MARCQ EN BAROEUL ASJ", "sh": 37, "sa": 70, "status": "finished", "cat": "U18F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 23, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "SAM. 03 OCT.", "time": "18H30", "home": "SENIORS MASCULINS 1", "away": "CHERENG ABC - 3", "sh": 103, "sa": 29, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 24, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "SAM. 03 OCT.", "time": "20H30", "home": "SENIORS MASCULINS 2", "away": "HEM S B B - 2", "sh": 67, "sa": 69, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 25, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "SAM. 03 OCT.", "time": "20H30", "home": "CROIX BASKET BALL - 1", "away": "U18 GARÇONS CADETS", "sh": 86, "sa": 65, "status": "finished", "cat": "U18M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE OMNISPORTS HENRI SEIGNEUR", "address": "59170 CROIX", "precision": ""}, {"id": 26, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "DIM. 04 OCT.", "time": "09H00", "home": "SAINT ANDRE US", "away": "U13 FILLE BENJAMINES", "sh": 19, "sa": 64, "status": "finished", "cat": "U13F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE SCHUMAN", "address": "59350 SAINT-ANDRÉ-LEZ-LILLE", "precision": ""}, {"id": 27, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "DIM. 04 OCT.", "time": "11H00", "home": "U9 MIXTE MINI-POUSSINS", "away": "LILLE-EST BASKET", "sh": 10, "sa": 10, "status": "finished", "cat": "U9", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 28, "wk": "w05", "wkLabel": "Week-end des 03 & 04 Oct. 2026", "wkShort": "03-04 Oct", "date": "MER. 07 OCT.", "time": "20H30", "home": "CTC PÉVÈLE TEMPLEUVE", "away": "U18 GARÇONS CADETS", "sh": 160, "sa": 38, "status": "finished", "cat": "U18M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE INTERCOMMUNALE", "address": "59242 TEMPLEUVE-EN-PÉVÈLE", "precision": ""}, {"id": 29, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "SAM. 10 OCT.", "time": "15H30", "home": "LOMME BASKET CLUB (LBC) - 2", "away": "U9 MIXTE MINI-POUSSINS", "sh": 2, "sa": 12, "status": "finished", "cat": "U9", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PALAIS DES SPORTS", "address": "RUE LÉO LAGRANGE 59160 LOMME", "precision": ""}, {"id": 30, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "SAM. 10 OCT.", "time": "17H00", "home": "COMINOISE LL", "away": "U15 FILLES MINIMES", "sh": 75, "sa": 31, "status": "finished", "cat": "U15F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE JEAN DEGROS", "address": "RUE DES SPORTS 59560 COMINES", "precision": ""}, {"id": 31, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "SAM. 10 OCT.", "time": "17H00", "home": "U13 FILLE BENJAMINES", "away": "SPORTS OUVRIERS ARMENTIEROIS - 2", "sh": 52, "sa": 17, "status": "finished", "cat": "U13F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 32, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "SAM. 10 OCT.", "time": "18H30", "home": "U18 FILLES CADETTE", "away": "LOOSSOIS BASKET CLUB", "sh": 61, "sa": 23, "status": "finished", "cat": "U18F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 33, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "SAM. 10 OCT.", "time": "20H30", "home": "BASKET CLUB LEZENNOIS", "away": "SENIORS MASCULINS 2", "sh": 75, "sa": 34, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "COMPLEXE PHILIPPE BERTHE", "address": "RUE DU CAMP FRANCAIS 59260 LEZENNES", "precision": ""}, {"id": 34, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "DIM. 11 OCT.", "time": "10H30", "home": "VILLENEUVE D'ASCQ ESB - 2", "away": "SENIORS MASCULINS 1", "sh": 47, "sa": 51, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "C.S. PALACIUM", "address": "59650 VILLENEUVE D'ASCQ", "precision": ""}, {"id": 35, "wk": "w06", "wkLabel": "Week-end des 10 & 11 Oct. 2026", "wkShort": "10-11 Oct", "date": "DIM. 11 OCT.", "time": "16H00", "home": "U11 FILLES POUSSINES", "away": "MARCQ EN BAROEUL ASJ", "sh": 34, "sa": 24, "status": "finished", "cat": "U11F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 36, "wk": "w07", "wkLabel": "Week-end des 17 & 18 Oct. 2026", "wkShort": "17-18 Oct", "date": "SAM. 17 OCT.", "time": "17H00", "home": "U9 MIXTE MINI-POUSSINS", "away": "SEQUEDIN OSM", "sh": 10, "sa": 21, "status": "finished", "cat": "U9", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 37, "wk": "w07", "wkLabel": "Week-end des 17 & 18 Oct. 2026", "wkShort": "17-18 Oct", "date": "SAM. 17 OCT.", "time": "20H30", "home": "SENIORS MASCULINS 1", "away": "TOURCOING IC - 3", "sh": 71, "sa": 64, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 38, "wk": "w07", "wkLabel": "Week-end des 17 & 18 Oct. 2026", "wkShort": "17-18 Oct", "date": "DIM. 18 OCT.", "time": "09H00", "home": "COMINOISE L L - 3", "away": "SENIORS MASCULINS 2", "sh": 113, "sa": 52, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE JEAN DEGROS", "address": "RUE DES SPORTS 59560 COMINES", "precision": ""}, {"id": 39, "wk": "w08", "wkLabel": "Week-end du 24 Oct. 2026", "wkShort": "24 Oct", "date": "SAM. 24 OCT.", "time": "14H00", "home": "COEUR DE FLANDRE BASKET BALL - 1", "away": "U9 MIXTE MINI-POUSSINS", "sh": 29, "sa": 9, "status": "finished", "cat": "U9", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PIERRE DE COUBERTIN", "address": "AVENUE DES FLANDRES 59190 HAZEBROUCK", "precision": ""}, {"id": 40, "wk": "w09", "wkLabel": "Week-end du 07 Nov. 2026", "wkShort": "07 Nov", "date": "SAM. 07 NOV.", "time": "18H30", "home": "BAUVIN B C - 2", "away": "SENIORS MASCULINS 2", "sh": 91, "sa": 46, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE PIERRE LEGRAIN", "address": "RUE F. POUILLE 59221 BAUVIN", "precision": ""}, {"id": 41, "wk": "w09", "wkLabel": "Week-end du 07 Nov. 2026", "wkShort": "07 Nov", "date": "SAM. 07 NOV.", "time": "20H30", "home": "SENIORS MASCULINS 1", "away": "ESTAIRES BC - 2", "sh": 76, "sa": 48, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 42, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "SAM. 14 NOV.", "time": "14H00", "home": "COEUR DE FLANDRE BASKET BALL - 2", "away": "U9 MIXTE MINI-POUSSINS", "sh": 6, "sa": 52, "status": "finished", "cat": "U9", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PIERRE DE COUBERTIN", "address": "AVENUE DES FLANDRES 59190 HAZEBROUCK", "precision": ""}, {"id": 43, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "SAM. 14 NOV.", "time": "17H00", "home": "U11 FILLES POUSSINES", "away": "BEUVRAGES ASM - 1", "sh": 22, "sa": 13, "status": "finished", "cat": "U11F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 44, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "SAM. 14 NOV.", "time": "18H30", "home": "U18 GARÇONS CADETS", "away": "GAYANT BASKET - 2", "sh": 53, "sa": 50, "status": "finished", "cat": "U18M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 45, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "SAM. 14 NOV.", "time": "20H30", "home": "HELLEMMES LILLE BFC - 3", "away": "SENIORS MASCULINS 1", "sh": 62, "sa": 65, "status": "finished", "cat": "SM1", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE LEO LAGRANGE", "address": "RUE FERDINAND BUISSON 59260 HELLEMMES", "precision": ""}, {"id": 46, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "SAM. 14 NOV.", "time": "20H30", "home": "SENIORS MASCULINS 2", "away": "HELLEMMES LILLE BFC - 2", "sh": 39, "sa": 82, "status": "finished", "cat": "SM2", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 47, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "SAM. 14 NOV.", "time": "20H30", "home": "LAMBERSART J F - 2", "away": "U18 FILLES CADETTE", "sh": 101, "sa": 38, "status": "finished", "cat": "U18F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "NORBERT SEGARD", "address": "RUE DU MARÉCHAL JUIN 59130 LAMBERSART", "precision": ""}, {"id": 48, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "DIM. 15 NOV.", "time": "10H30", "home": "U15 FILLES MINIMES", "away": "WORMHOUT AS - 1", "sh": 51, "sa": 35, "status": "finished", "cat": "U15F", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 49, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "DIM. 15 NOV.", "time": "15H30", "home": "U13 FILLE BENJAMINES", "away": "WATTIGNIES/TEMPLEMARS AS", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U13F", "comp": "Champ.", "period": "À venir", "fh": 2, "fa": 3, "liveTracking": true, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 50, "wk": "w10", "wkLabel": "Week-end des 14 & 15 Nov. 2026", "wkShort": "14-15 Nov", "date": "DIM. 15 NOV.", "time": "17H00", "home": "MINIMES GARCONS U15 M1", "away": "COEUR DE FLANDRE BASKET BALL - 2", "sh": 13, "sa": 57, "status": "finished", "cat": "U15M", "comp": "Champ.", "period": "Terminé", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 51, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "14H00", "home": "HOYMILLE ACS", "away": "U11 FILLES POUSSINES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U11F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "LAURENT THIRIONET", "address": "59492 HOYMILLE", "precision": ""}, {"id": 52, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "17H00", "home": "THUMERIES A G - 1", "away": "U13 FILLE BENJAMINES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U13F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE F. BEGHIN", "address": "59239 THUMERIES", "precision": ""}, {"id": 53, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "18H30", "home": "CHERENG ABC - 3", "away": "SENIORS MASCULINS 1", "sh": 0, "sa": 0, "status": "upcoming", "cat": "SM1", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "POLYVALENTE VICTOR PROVO", "address": "59152 CHÉRENG", "precision": ""}, {"id": 54, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "18H30", "home": "U18 FILLES CADETTE", "away": "VILLENEUVE D'ASCQ ESB - 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 55, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "18H30", "home": "SAINT POL SUR MER BC", "away": "U15 FILLES MINIMES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE CHRISTOPHE THOMAS", "address": "59430 SAINT-POL-SUR-MER", "precision": ""}, {"id": 56, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "20H30", "home": "HEM S B B - 2", "away": "SENIORS MASCULINS 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "SM2", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE DELCOURT", "address": "52 RUE JEAN JAURÈS 59510 HEM", "precision": ""}, {"id": 57, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "SAM. 21 NOV.", "time": "20H30", "home": "BASKET CLUB PEVELE", "away": "U18 GARÇONS CADETS", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE INTERCOMMUNALE", "address": "59242 TEMPLEUVE-EN-PÉVÈLE", "precision": ""}, {"id": 58, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "DIM. 22 NOV.", "time": "11H00", "home": "U9 MIXTE MINI-POUSSINS", "away": "PHALEMPIN B C", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U9", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 59, "wk": "w11", "wkLabel": "Week-end des 21 & 22 Nov. 2026", "wkShort": "21-22 Nov", "date": "DIM. 22 NOV.", "time": "14H00", "home": "BC BLARINGHEM", "away": "MINIMES GARCONS U15 M1", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE DES SPORTS", "address": "59173 BLARINGHEM", "precision": ""}, {"id": 60, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "SAM. 28 NOV.", "time": "15H30", "home": "SAINT POL SUR MER BC", "away": "U11 FILLES POUSSINES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U11F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE PAUL LANGEVIN", "address": "59430 SAINT-POL-SUR-MER", "precision": ""}, {"id": 61, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "SAM. 28 NOV.", "time": "17H00", "home": "U13 FILLE BENJAMINES", "away": "LEERS OSBB", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U13F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 62, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "SAM. 28 NOV.", "time": "18H30", "home": "SENIORS MASCULINS 1", "away": "VILLENEUVE D'ASCQ ESB - 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "SM1", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 63, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "SAM. 28 NOV.", "time": "20H30", "home": "SENIORS MASCULINS 2", "away": "BASKET CLUB LEZENNOIS", "sh": 0, "sa": 0, "status": "upcoming", "cat": "SM2", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 64, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "SAM. 28 NOV.", "time": "20H30", "home": "TOURCOING US F - 1", "away": "U18 FILLES CADETTE", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "PALAIS DES SPORTS", "address": "RUE DU CALVAIRE 59200 TOURCOING", "precision": ""}, {"id": 65, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "DIM. 29 NOV.", "time": "11H00", "home": "U9 MIXTE MINI-POUSSINS", "away": "BASKET CLUB BONDUES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U9", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 66, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "DIM. 29 NOV.", "time": "14H00", "home": "ESTAIRES BC - 1", "away": "U15 FILLES MINIMES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE LES TULIPES", "address": "59940 ESTAIRES", "precision": ""}, {"id": 67, "wk": "w12", "wkLabel": "Week-end des 28 & 29 Nov. 2026", "wkShort": "28-29 Nov", "date": "DIM. 29 NOV.", "time": "16H00", "home": "U18 GARÇONS CADETS", "away": "LAMBRES BASKET CLUB - 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 68, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "SAM. 05 DÉC.", "time": "10H30", "home": "RONCQ U S - 2", "away": "U9 MIXTE MINI-POUSSINS", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U9", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "JULES GILLES", "address": "RUE MAURICE THOREZ 59223 RONCQ", "precision": ""}, {"id": 69, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "SAM. 05 DÉC.", "time": "15H30", "home": "LILLE-EST BASKET", "away": "U13 FILLE BENJAMINES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U13F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "RAYMOND HERBAUX", "address": "RUE SAINT-GABRIEL 59800 LILLE", "precision": ""}, {"id": 70, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "SAM. 05 DÉC.", "time": "17H00", "home": "U11 FILLES POUSSINES", "away": "DUNKERQUE MALO BASKET CLUB - 1", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U11F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 71, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "SAM. 05 DÉC.", "time": "18H30", "home": "U18 FILLES CADETTE", "away": "RONCHIN BC - 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 72, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "SAM. 05 DÉC.", "time": "20H30", "home": "TOURCOING IC - 3", "away": "SENIORS MASCULINS 1", "sh": 0, "sa": 0, "status": "upcoming", "cat": "SM1", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "GUSTAVE DRON", "address": "RUE BEAU SÉJOUR 59200 TOURCOING", "precision": ""}, {"id": 73, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "SAM. 05 DÉC.", "time": "20H30", "home": "SENIORS MASCULINS 2", "away": "COMINOISE L L - 3", "sh": 0, "sa": 0, "status": "upcoming", "cat": "SM2", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 74, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "DIM. 06 DÉC.", "time": "09H00", "home": "STEENWERCK BC - 2", "away": "MINIMES GARCONS U15 M1", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "MAURICE DECLERCQ", "address": "RUE DE NIEPPE 59181 STEENWERCK", "precision": ""}, {"id": 75, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "DIM. 06 DÉC.", "time": "10H30", "home": "U15 FILLES MINIMES", "away": "BASKET CLUB BRAY DUNES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 76, "wk": "w13", "wkLabel": "Week-end des 05 & 06 Déc. 2026", "wkShort": "05-06 Déc", "date": "DIM. 06 DÉC.", "time": "17H00", "home": "FRETIN BC", "away": "U18 GARÇONS CADETS", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE DES SPORTS", "address": "59273 FRETIN", "precision": ""}, {"id": 77, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "SAM. 12 DÉC.", "time": "14H00", "home": "LILLE-EST BASKET", "away": "U11 FILLES POUSSINES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U11F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "RAYMOND HERBAUX", "address": "RUE SAINT-GABRIEL 59800 LILLE", "precision": ""}, {"id": 78, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "SAM. 12 DÉC.", "time": "17H00", "home": "U13 FILLE BENJAMINES", "away": "COMINOISE LL", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U13F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 79, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "SAM. 12 DÉC.", "time": "18H30", "home": "ANNOEULLIN B C", "away": "U18 GARÇONS CADETS", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE LÉO LAGRANGE", "address": "59112 ANNOEULLIN", "precision": ""}, {"id": 80, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "SAM. 12 DÉC.", "time": "18H30", "home": "U18 FILLES CADETTE", "away": "DOUAI BASKET FEMININ - 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U18F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 81, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "SAM. 12 DÉC.", "time": "18H30", "home": "MARCQ EN BAROEUL ASJ", "away": "U15 FILLES MINIMES", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15F", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "SALLE LAZARO", "address": "59700 MARCQ-EN-BAROEUL", "precision": ""}, {"id": 82, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "DIM. 13 DÉC.", "time": "11H00", "home": "U9 MIXTE MINI-POUSSINS", "away": "FRETIN BC - 2", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U9", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}, {"id": 83, "wk": "w14", "wkLabel": "Week-end des 12 & 13 Déc. 2026", "wkShort": "12-13 Déc", "date": "DIM. 13 DÉC.", "time": "16H00", "home": "MINIMES GARCONS U15 M1", "away": "CROIX BASKET BALL - 3", "sh": 0, "sa": 0, "status": "upcoming", "cat": "U15M", "comp": "Champ.", "period": "À venir", "fh": 0, "fa": 0, "liveTracking": false, "salle": "ANTOINE BLONDIN A 790M2", "address": "3 RUE FRANCOIS COPPÉE 59000 LILLE", "precision": ""}];

const FALLBACK_LOGO_B64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADwCAYAAABFcSteAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAEAAElEQVR42uz9d3wd13Utjq9zzszcfoF70XthB3uVKEoCqd6sZoGy5W4nsmM7cZyXPP9SQcjPyXsveSnPiZP4m5fYsS3bhGUVF3WJUBfFXsBeQKK3C9x+Z075/XFmLi4l2c+yZVvy4/jDj0yCIICZs2fvvfbaawEXr1/rpbq76ev/rPtN/uzidfH6f+0iSulAuHnDkiv+60eu+aff7ur8Q6AiAgBdXV3s4i369V8XH8KvKzi6uwnZ0iM/+/6r//y6S9r/c0lbxfrmquB1qxbW3eW3os8//PiTI93dnUZf34C8eLsuBsj/M1c3QHcoBbJlC/nCR6/9+pbVTb8fCjCRy+cllULUVoaqyssj7zWssif/7esvDF8Mkl/zm+ziLfhVl1UKhBD898/f9a218+Lvz+ZznNvcUFCQikBIIUxG2dCMmnz51Ox133ngsb3d3Z1GT08fv3j7LmaQ3/SegxCyxffn99708KaltXc6hZzDhTChCKRSUEoCSlFHOCIWoOGyUKgrVFbR98//1nf+Yia5GCC/2cGxfTslyz4r/+r377x/88r625183nGENJVSEFAgAKRUkEoBitCCw0XUx0MVsfKtVVW1L/zvf3327MUguRggv5HB8Wx3J2v77N+IP773Pf959aqG9/N81ilIL3MASikoqQAFEEKglAIAanMuy/zEXxGPvTdWWfX0l//l2cHuzk6jb+BikFwMkN+Q69nuTmNLTx//g9+68U9uWNP4eXCb57kwoSgEFAACIQSUkjo4Sj5XSZBsLif9jAcqy8ru9IXKnvjXZ14Y7urqYv39/eri3b0YIO/q695715q/97cv809v3fxfblzX9j9CpuQOVwbcQFBKQUoFIQQIIdApBFAKEEJACAlKKbGdgoj4aKgiXvHejON/5PGnnpq4GCS/ovR/8Rb8ci4PefrY7Zff+94tHf9aHQZPZTiTRBApJYRU4EJBCAkhFDjnAHTg6OAQ4FxAcA5JKIR0RCRUxoZTZv9XHjh0+cDAgRkdVLgYJL/E6yKl4Zdwbe/qYj09ffyeW6/c8p4rl365rswQaVsywyDEMCgYNUAJAYEEIEGIBKU6gyg11144goNDQUGCUsZmkjO8Nmx3/NatSx8ghCi1vYtefMldDJB3Webopu/73vfE6tVLWrasad3eWmVa6XyBGJQQRQAlAOlmCAKAUgpCCCglkEpAKukGioJlGPCZJiilEFJBghjjE2O8NY4tf/apu79KtvaK7u7ui2XyxQB595SsS5cuJVIp8wPXLf/e2vnllelsTkCBCs41hEsAQgkIIWCUQgoJzgWklGCUgVEGQgEQ3Z9wh8NxHDiOAyUlTDNgTEwN8/m17Lf/y4fv/GxPTw/v7u40Lt76i036O/56trvbuOWznxV/9unbv3zDhtbbeCHLFWEGIYDS/QKUUhBSutCuhCMkpJSgVFdLjsPBuQDnHAXbBlcKhACEAHqOyCEB4uTTsr6u5oa6+sYn//Yfnzx3sWm/mEHe2aVVZ6expaeHf+qeG++5Zm3bpwnPckfAgJLFLloqCSn176SUkAAYY6CUQkqlswQkFHQfQhh1Sy+dSaQQACHwGYxwLgnPjrNlLRXfbmxsjG/f3uHmp4vXxQB5B/YdX3zuOX7nLZ2Lr9vQ/G/lAS5zNmeEzmUNpRRIyfn1eg/vYwBAGQVjzA0a5kK/AKMUlmXB5zd1WSYBSimdmJoUYSPd8jvv3fIvhPTIbRf7kYsB8g7uO4zrN7Z/o6OlLJAv2IoZjCg3H3iXcptv7xcXAh55UUD/nnMO4eiyixDqBo+ClBK2bcPhHLbtIF+wYRgGGx0d5G3VZtcf/84HP3GxH7nYg7wDs0en8dnP/o3440/f/ifXrm3+oJ1NchDDUCgppaSCrn+IOxyUUG4fokNM5xZ3VOh+JgGXOlAE14287kGkhoIJAaUMlFDi8KSqqqi6RrL4d776789MA6B9fX0X+5GLGeTXe3V1dbH77nuOf/CO61Z2rpm3zYIjpKIMUIAbCBrCnSunvB4EVKNYuvnWA0E9NJSwuYAtBaQUbhARjXC5JRhlrDh5l5BkejqtDD4TunxNy78QQtTSpUsv9iIXA+TXf23v6oJSCpetrv9frZUGy+XyIACBO+zTh5holq6bDQAN8yo3YByHw+ECUgFCCnDh9iRKgRAKSimYQUGomz0kihlJSv3LNHxseOgcb6og1/7Bx9//ga1bt4rtF1d2LwbIrzU4tm9nZOtW8eef/+BnNy2vuzqfzXDKGIM74/AApbnB+FzF49HaBZQukxgDoQqMMVgmg8EMnXlKsg8zGCyfBWYYxeZdB5wOIMpMmhg5L5e1x/7usstW13d1dCh0X3y+FwPk13ApBdLV1SU3blxRvW5BvMevbCmVpCDum13NUdfnDvMcWgWlQJQ31yghLXIJ23HAuaO5WO7E3etDbJvDdmwIIQAoMKZLNMEVhAQdHh2XPpmquuXSVdtIT4/cvnT7xVLrYoD8Gq7e7ZQQom7atPy/Lm6KxjPZnFQKVMkSLhVxG3Slm3HiDgI9BEsK4TbfejCo+w8OKXQD7gWWjicFJaEHjLqnB0BAiH58QjrgXMCyfOzs2ZOiodL3sY+/99bVXV1d8qI6ysUA+RWjVqDo6pI3bdnSsm5hzaekPSMlwJQkbpbQvYYH3zLKYDA2h1Apd2uQEFBGYRgGLMOAaRowTAOmYYASWsw+Req71JR44j423YOIYulGKWD5DMIlV9SeNVYubvoSIUR1dXVdfGgXA+RXd21bup0QQtS1l7f9+bzaQCiXlVJJRSQEiPtWJ4Tq8km6OJOSOkDcRl3CDRK4h59r9EpJQAoJ23aQy9nI5wrI5wqaCq+jy81AunxjjLiDRcOdxktQahnnzp0V1eXqxk+9/87r777YsP9C18Wh0lvKHt0UXV1yy2Vr5y1qitxj55NSEsb0Foec6yWkglASUigXedJTEU0bISDC5WQJCSGFJr1LjWjZDodUsthfMIMWeVpCSCgQN0MJCAEo5fYoUkBwBaIICvks0hNDWNJe+98U8FTX9g51kYRyMYP8CrLHUkIIUTdvXv6FBQ2RABdSMqbbC5095n5RpinsuhTSC1GOEHr4p+YQLUqp23MAhsFAmQvtMqrLLsNwkSxAQbgBIVxCo+5blFKghMKyDBCm4AsG2fDosKgtN9d94n1d1xLSIy9mkYsB8kvvPejdW8U1l62uX9pa8SGRzygJwlwCSZFGotErN2CoS0ZkFITqX4wZRYIio252cOkkRU5WyfJUsamX0m03XKo8Y24AmTAMozhTEZxDSoVMJo/c7DjWLKr7fQDAxV7kYoC87iJdXV2ss7PTwNvAct28uZsqBVxz+dLfbq/3+3O5goAEkV6vIecacCm1SolyB4SaqAiYlILCGxoKiOLwULk0eOH+fZQ06QqOLcAdCenCwoAOPB0UDmzbgeAa6QJhoASw/H42OHheVkXptR/Yesf6rVu3ircR0aL/r7xcf0N/SEUAqN7eXtHX18fxi+9tk6uuuo8DCLbXxz9BuQ1FQAl0U60PtZybdSgFqfTeuZcBvD1zUYJwEUqg4O17MJ11oOFh4S5SCSEglYBQEtylohCi3J11Dko1Jd6Dhak7pLQsC3nHltRJ0nULGz8D6Mn/23RvJQDZ3d1Nf9Nh5N+EACHuQ/KyBAGIAhDbcMVNN2/YeEPX2rVrg3Mfe+vX9u1dVCmFz338tusWNISbcvmsAEClC71602590JUurSgtllLeFxZSFhm8+qy536nyFE0oiOHR3QmYCwMzQ/87c8Gmg4wxfTalm71QbPYd2IUCoAg7f34AFSF657Jly2ro1q3iF3/mRMXjDY0tLYtae3p6ZG9vr7gYIO/Qyw0M5T4k5b3NVq+/Zt09H/v/HVqx+tofrlqzZfvGDVd/1kWhfq63XRf0m3f5woYPR0NQXBKlSojQsoSZq4gWg9MolnSn3gAMBrgNOCEE3PGm5HMSP9LLPlK4Wlm4oAfRAejNQPSQUQoF4W4gevMSjWpJKKXI6MQkD/lE5I6r1t6h8At4j7j39pLOmze3L7vySLCqo3/pmlueXLzqyg9j7VrzN7UaeVf9UN3d3bSzs9vo6upi3d3d1A2MqsuuunNLS8f6WrcRVXWNre9rnr+i3rLCWWaYIhA0twKg27Zt+3nedpRu3SqWtbXV1JQZW3LZLIGAhnZLUCsALrmQufuxBN4wXEjpzju4RrMcDrefL85E3E5krgehTH+elMXE5w0ii2gZKKRQRRKklySZaei9d0qhoEgqMaZaa2J3A8C2bfi5VBk7xzsIAMRClR+IxRvCyghYCMSuaWlb8fX3tq7aBOD/NrV/VwLN74Y5COns7GQ7duwQhBDp1r8AgMu3dP1O+7wlXyTMX7GwrfmFr23duhkAlKDKLjhKKMcQnDMQUg2AuJ9P3kpP0t3dSXt6+uSdN2+8srk6XO4UEgLUZCAcSlHApa8TQty3v941l67WlVASwqWfGIbhDhI5BFdw7AKEULp8khKO1H9Xub2NcMsx7/x7Q0KldNZQSgefh2oRQooZi7nwsWFYdGx0lLQsabnstttuayWk52x3dzft6el5S4GyeTNkXx9QXh5fPDLrKEAozhU3LT9tb65NAkBHR8dPuK/dFLhPApJ0dm5mfX19FzzHixnk5w6MbgOA6uvr44QQtXztpcuvu+mj3Tff+pH3tbUtW9E2f+VX6lo6KkADvKm++fJ7tt6zCQCy2eQpO58njDJPpC3SVt1W+fN8E9u27ZAAsLCtbGs0AKVp6AqEMN0Qk7nDK5QsljhSSS3UUIJGeQfe+0UpK/YRxcaduINAqZt37/Mcx5krrRwBpQgImft8zjkczotZiLtkRwqQyWSSh1jeumJx842/6HMPhSOGkJJAKUIJDEDSSCSU+emf1SMBRQGiXNBEQilyMUB+zr5i+/btTAdGDw8Gg7Wd13d96r33fO7pSzbdsadpwbpt1XUt316/4fLHo+UVsPNZ6QgbjDIViUTuAAAOZ1xKDgJKhACEUuWR2ooqt0x7Kw+GUkLk4sX1FeVh49pcJkOEYlTBnY6XDPxACBShxfLK41rNDQ9178A5L/YsHpFRlvQZ3r9JKC1mC48+731MN+0EhKjiDrsW2SKgZA4coIRAEUDYgiRnJhAJszt00G97y2/vnm3bFABwqQy99OWBExTpdIr+tPO1YdPNKzduvufowpXX93WsufYz5eWtLSBElZRd71gBvHdYgOi+YuvWraKysrLuhls+9Kfvff/vH1y+ovOf2xasvaqisslQUvLJ8UkVDJbXCik19CMJUskMUQphAMTO27ZQHCCKSCUBwlBREXnLUG93dydVAK5es+z6hni4rOBwAULI3KYsuUBwmnj/c5sP7lHVhSwGBnFHCBredUkqck7txPt86iYnKaQeAIo5YqKUoqh8wjnXX0fz7Es0f6VWZhQShBA6Oj6JkJ9tXLx4cV1JqfmWLylApLvlqEAglUQqlX7zl912Tbdvrm/+08r6BQvMYNWVVqThH5df2nmoq+vDdwHAvffea7rllguyvLMMTH/dPQjp7Oxmmzdvk8AO2tOzhV92xQ3X1dQv+JzlC11a19AWJ6YFxaVIzsxgbPQ8HRkeNJjKSwrIhgrGQBQUUZhJJjGTmM0TQhREPsmUJvNJ11YgbFlv+ZvbvHkzenr6sKKjeU00SJFKQhmEQFcYc9Nv5fKvFJS7a47i3rkQc5uEmpmrYVruHl4hJBzOIdy3so4YN6tAl1GWxdypOjxFEy36wOUFWUcqBeJlJ7epp5TAME0yNT0lFixm4as3rr306NGjD27v6qJbfw6IVqm5Fs7bj0+np9702fZqWNmMxSrXnxpNSy7yUhYs3tDQFmZkdh2AB7761a86zQtXtBk8nent7R2/2KS/7n739fXwvr4eAJAt89etbl+4/gf1zQstoQA7XxCMCzo7O8N27XwJ+fQMhFPgPpMZ8Vil+w7Uh3J2NoWRkdGgUipQVd34QcsKwOZceUkmFA7/HAGyTQA9ZtAk1yjhgHNQQtQFUj2yeJjdCbnABeu13hxkLgPMyTJorpYuiQjV8xBBZBGmFVLoqQ4hUIoUh5FenyKFi2gpBUaZ3lIs4Xp5qiiEEORyBcULabTUlF8B4MGqjo63lkEodUssoQUplJsNpcLUVPrNEEfS09OjVq9e3cIMs0EoSQmhBCBEOo4ywsFjANTlV3V9gSP0pWx6NrGictmPZqfP/sPAyQP7UJwU/b8ZIN7DMa67+Z4/8AdrbwgaTpoStbCyus1Kzs5gcmIMtfWNjFI/QBjsQgHSySEWCRnpzOSpVGqaMoO1EaWUaRqGP1aLRRVVH6mfv/a6eEVDI1cSUgpDOwpQ+H2Rt5S6u7tBCSFy6bx5tZVh/7JC3gEhlBCCkqZbQp9sV6VEzmUOQigILnzDzyFRCkUM2FVOVG6JpYqaJoBBGQRUcatQupCvV9oxRuHRdL2yyhOK0JlNJwjKKKQASc6OozzSuh4A2bwNEj1v4Xm535gQknoBSHWgquT4uASAnpJ/b8eOHRSArKmpX+0PhEyHTwgCxSgBGCWkvr7+2NrFi+vqalv/++C0DTCnklq+jyzpqN360dvvaO/5m57Rnwdte9cGSFdXFxsf7yDV1f0K6EJv71Zx03s+8Xcdqzd9ZmbWAbOnURYC9h3co4aHj38zlUy+dONt9/yz5fMpBQK/FYDBfLna2uBXmBm8bypNr1FCfF9IU5SVlRmUloMQg1TVm422zaXt5Ck1TEgCSRml2XSyEgD6+/t/xjdnJwX65HWXL9xQWxWkgmeFgmJecy6Vct2hShtrAiKJ3l6Sojj486Dg4uFmFFQCSkhQxjQiJfVmodeT6KDwuF0eB0t/6xrRciFfd9CoGb0EIBRCiuKchbnMYMvno+lUChVRtriiYlGYkJ7UW4W8ATAuHMvjj0GTLUcrrcKw28qX/FubAfQhEon7KTUhOFcErkC3VJiZmM7XtXW8vyxahRPDxx2pHMZtyGisljU0Nbxjxg+/koaIEALNi+rhvb29Yvv2LgUAscr6TjCfsHnWHhkf4+NjI3J44KB9aM8Tn1y+uPI/87kMJwpEKSGDoSAJh4KnfvToI3/0yCMvpYiNY/lcRilIgxClKDOglKDnz57EiaMHqeQSSkiAQFFmwhGqBgDGx8d/pgDZjM0a1vQblwX9JhFSqAvo7LRUBZG6Day3P+5Oyd3p+JwWVsnMRL+N4Qi9A8IdLftjF+zi/+fCa97lBbYIlHpfn8C0GExTM3pNw4BpaNEH6nb5QkoUbI4Cd8jY5LSiTMbvvuWKee5L6y08f4V4HCHB7QruCmlrqgzJPnztSz8R5mXMUB4aB1AQ6AA+P3qeMhaozOULSklJFEAoIYZwHDk0PST/b2AOcAG96F0bIMRL/xs23nTzje/52J/fcMMdd7goCjiXOdvmjCjJhFCsUMiqWJT9E0ByJwaS8wghTCnPT4Oi4Di+j3zkI34AxDRpQSqd7DOpvDqyb5d8qe8Hzzz642/feubsgf8CSDBqCKqYYpTCtMzAW+o/XCg0XhZYC+FAShCPSuvteHjlkyiKK8xlF0CTEQFAen0LUFyjlRJuBiLuHrrmXXm/KNFrurqUMsCYMedCVSypdJB5E3rb1irwDnfAOYeSElQRUFBYhgXbdiRVnNZVh5e7g723dMDa25eWAUZEKglCNW2fQJKtPT/5oDJ3PdhFwkEIiOQOkqmJXCGbRyFf0FieAiihUFKwkwcO0NeXbCUlKtFzlQvpRe+mACGa79NNAYX58+dHb+v6nUfXXHrdD8ur59+3bOna73/io5+4Vv9NYRqMwqSGblCFYP4g+z6gCBepnJRSaFE1SRhhgET80KFDYQAqJ7OEKIAyQzo8T48f2//nu156+OqZsWM/CJj+VwV3QKm2qaGEwu/3X5AZftaruabcJJJDuEGhtwC1yohHV9d0dloUUSCEaMjV/btKek28cKkmDgq2Ddu1NvAO0BzjVwBEaLIiY3C4gG07KBQc2AXu0t8FJNdKKFKh5BC6MkHUAEAhAJeuAhQcR+UyszAMbHiL5TEFANOMNxnM8EkhFQEhlDBASvT+Xz5f88wklFKKEFAhHL70yjVnsrm833acYpHHGIOCnD117Fj2jSWbd2uJmjevY/6yZes3dgBWb2+vACHvjgDxyIO6seqR3d3bSHl5y7y6hkU3WMFymcnm84z5lGEEP6nnBI5+eVBASEiHS9i2qAOgEqMTOQiRJ4yCMgJQAsOgZZVhDUepvCSQACVKmZYPFTV15/XbpYuZTFZTyqCUVBL67Wy6AfIzxgehlEgAMSnEfEUUiI42ALrWpwZ1F5vgCimqOfRJCHeqLotlF6R+kzrCm4cQGJTCIFQ3Aq7Yg5RaYpSAgnnDkKIYo1640lmGAa6er553zE3wPYs3L4VLKHAlwKVAKpWESdGuB4Zvje4RDcaCIARKSkmoHoRyx3FFwN78kBLDoEpJSEf3LURREEX4v27bVnC4JE6RYKm7JsMyz7/S3z/9+v7IyxTXbnnPVSs2vOeAL7bkJd8lt+5fs27LvVDql1ZuvU0B0k2VUsQlD5bfcMMH1re2rm7p6emRphlaBEKE4LYklJjJZJoopRp0ieXMEqLctVOl3ObPBIBCIcEBFDzEh1IGwzThLy8HACSTk3Ccgjt7UIBCVJcgvYITpEAUiFfjgMDvD72lN6ZSwIqFTUuDfqvatm0FpYgnAyq8ssqR4I6EEO5arRTgJZNxTSeZyyxeMy+kPqwSCorqYZsQczKjXhaS0HMTlDTu3n6Inpx7aBeF6U7XPbE5BeFmDgWDMZjMACWMZjJJZLOp+fpL9LylgaE/HFFK6b14RaAIZZCggwB4Z/dfGOjqoq9bPQAv5COl9Br9NCR27NhGAKmkFIBnLEQIpBDkzRBeV51F1TfN+3xlTWvAVszhLLzYCjf96y23feTvf1nllvF2ZI3e3h5BSA86O2//VG3jvD8uq6hvNqJV6erqyo/DYoIZPkagOAFBvsBBpGIAoKTKeLYAlFJQyWBSyzsgEgRqzgLAAJg3dAUmJyeVwwsuMqKggLx3VwXEOOc2fJakCpAggM+y3jKmvqQuboQCBriQSipFlFRFl6jiUM/1ENSlFikCtUXY1R0Memom3rPX5Eb9twkunMzrA+4uTHF1wYKVt9LrNf3eZqHHApbuX2CUgrqyp0RIEEpBQYlTyIKYTuXatbdU7N79w8m3dFh0JQzTYBBcEgippEJTS0tLa19Pz1kAxXIrEJhmAAQxfFndb0ko4rIHpMRXvtKjlLpBaSVK3aAw08QcM/OC0CV33323qKqqClumf10hn1VE2Uwo5UgaolXVsWXvyBKrq2s76+3tFc3NC9pvf+/vPLZkzeZ/rmpa3GwEwjJW0RSurWv/dlV55L5CwQaUYgSE2AUbuXw+6h4tv3KHbIQxUGbAcife6XRaKQlZyj9izIRbKGFiYjRFCEkyRhmlFMLO3gZXrd6AP08UFaZpwrRMpZQCUfJnHqV7e3fxilBNMGBAKar065oU7dP0gZ076B7MSz1Raa9Rd/V1DdPQ+liEwDAYTMb0wZClTF9S7EE8ZMujqOhDM6f27tgcjiOKm4WeIITNebHnoO735CHElFEiBAeBjDc3B2u9gd7Pel8ikYiCsJXgDphh0LydwcRMrjUQX/rq0jXX/XjJ0k09q5auuwwAe+yxLxcAKDtfiBTnJjpNQAquenuh4XBCipw0QIE7efr6/NHd3U2UUljUtqiZMFabKxQIUYQqBcpMyWwnl7vwyb0DAkTvY2wVay+97p5Lr7jjleaFq683LIs7uawiUFQKoWxBWThYsZhzB0qCKKKIbXPYtlMGwGTECFJCQd09CsooqDLdBxZinDuGlBJEKf0xxsBYyL13mSlF6JQjJBxuO+FQ+Xs6OlZ/TvcnOWIXChgdHcTE8AC4KKhsLlvxs/5shzs0FBwKBxf7TAYhhe5migabKBGR9hqEuUWmYokFqRMNARwh4HBeMl3XU2+uFGyHo1CwUShoDSzbsYu2bIZB51QWqaeU4ulv4QKROkL03MOFDt35CYGE0l9faCUUgwBNNfG3/Myz2YxZXREiJgQc7kCBEkcpZQQrqlmo9kajvPUvVFnriysvve3A2g3X/UOwqqXW7/NdIqSC4A6UcHRJBcwAEIoQoqTSrC4llOZbGufc/ugNgeuPRpWQgOBcL2ESBdMwwQU33lEZxJtwXn/jB3uWrd7yraqmBVWZVFLs2fmSMTU1SaiW9iepVEpNJRJSCy5rlMKRAkqKEAAfZVR5NA1N0GOwZcF9chlIKZRXU1NCYFBmzKZmIx44IqXDGWMwDAvRaJmqrqr9IACkUqnhY/27RicHzwpSSDmzU5PEtnnwZ4Z43U6+oixATOZCrVQ3yVKqokutN+GGUu5u+uuoTYoUg8UbFuo9EaEV3aUq0kWoq3CiG3CzSGNHqaeIcHV/iQShCl6jLMkc1AxXAghuADGiwKgmP1ICcO4IgwFjIyNLSybeP/Xq6NV7HqdOnRxwCimxYmGLLPcxSZwCFHcI547iXAgJJgQNKWmUdVjl7b933ZXX/q9YeVmjLThAFCWUajVJy5yGBg8qCPHYAFRRShHwB87r72vbm3xfluafKa0LRgBFCYHB2JSuaH5yG9DZ2W38PAIebyXyCPT+N+np6RGXd976sdaFa/7CCob48OAAPX5oH5sYH0JtXTMoNWCZFrgQJJPlRYRDEQ1lut1uCS3DLUUIgxKyyv16tpSy4A4DQBgTlt/PkineAuAQNIDFMqlZjJ4/Q0KWj5TV1PsAGMeOvZS6obVroKEm2lDIp4MziQmRz6eedSfpP3MvEvAZFnVRMLiHzfsfdR1qhRRa0kddGBx6wj0nB6QIoBSFUFzrWUlVJFIWvUNKDT5VKX1EFWkmjDJNelSAZenMa3ATDndK2MK6D/FmJJRRMFq0dVMmI4iGAyHNNwP6+n76fehBj9S9Zu/R6qrKf2prWfJ7i1tqMJvK8JlMgSRzOVrgnHGuex1CiCOIQapragNQeeRyeehZqqmYwWAYLAudAOLQYARRoIoQoOAU3hAYHvuB5zNRKIBzoaSURLpqk8FA6BgAHD58mLzZ3IQQIl73hqf4GSksP0sGIV1dej8DgOzo+DQBQGJVLZ/2h6PyzOmTZM8rL9CZ6TEIaUMIR6Mc0AzXfD4LpfQiD1HEpeq5qI6ULnqBYpCA0JgXIEqKgiaQKzDDhN/nQzgc8Lkfl2dPnxg9dmifFPkZwYjDDYNWzZ8fDwJAKj27zeGpJ02r8Fd5nlnzg0cffAYAeSsiA4TQCKFMS366jF2vPpZCe5pLpcBLhoDex4X0SjJXwV1jNhAS7huTFDcOS5epitnE8yuk7EJKlLuz7hn0FPKFYmkmSmBe7rlSlVgxeFnOYBTRSEi8Fdy7t7dXdnd300cf+8EfnTzV/1fZzMR00A+jImqxpspy0lpVJurKfCJiEkUcm/JsijlOLjCTTAQd23Z7DwklKYSHVRAWUQComrPFzmUy9CfPU1QloQxCSTXnLw+k0ykBADve5IVOCFGXdXb99ror7v6blWuv+uRawERPj3SzyS+aQbopIffJ3t6toiZUUx2qqfD39Gw5F402xkORioXccSgkVUIBgucQLwsA0tE1IiQUYRDcAaAl1vQgSNMNKrTSTbE58xpay/R5J6IgpLAJM2FaFggBTNNCTbjGO+DKYoXZppomygt5HzMEpmcm9548OZ12S8AnX3wRT77uhv1M2WPz0qXKHaw1Cl0+6SfhKZC4ZjdSSXB5IYTp1n5vCJi5rCBcftWFNPUiE1d4CvGkWKZRSoszFcIYTMtw0S8C7W5IwYiCzTlAAQoGyTk0QsQAMtejSKXgMyn8lvVWy2vV09OjANhPPPXDP+nquul/O7z8VscRdzFqXhr0ByMBy4d4xAebB4VQlGVmx4VyRLigcnC4IJQZymAERNqOnpFggTswJiBQRFFwIYa6urrY6dMjxWxQpAcZrNUwTUDZUrdyGlFOJBL6TbTjQqi+t7dX3HTTXd21Leu2HT19HlwRGJffee+6/Mjv9vX1vVTcbPsp67/0pw/9eqRSyrz6+q09V773I/1LVl1zdMPGGz7e3r7wkkAwEBWSy0AgSgzmR8BvopCbQnJm3EVoXI6SS6VQam6FVEEFqpe0xg3GpOCO3lsg7sTb5/e+WU4JG0gnZ3H21HFVyM6qgN+nlFLeZiB1Cpn7UrNDg5bP3gOS+YPRsXNbAcienh7laTZ1d3YbrpLHzw7zdnVJt7CrR1E7V8t9ao8OB467y1HKkZrjXM1NxTnn4I4DO1+AY9ua/lEC65bwcdxpsi6bPJNP7jFyCXG3COf6mznrBC0EwR0Bp+BohMvlcmkHKy1Rqkm5QDDggyPtqp+XKaHLrR+Pfrf3/q8+9PB3r5OY7OB24hNSzD5MZGoqEiBWbcxICTH5L1yiTtpJ6Se2S6lhoIxl57W2Xh/yB+oohaSEUAoCRiVi5WVHe3t7RXv7NXJuprLZLXkDS0zTV6Jsr7F2QolLlixGCOnt7RWxWKwsHq/7fUJ9Iscdx5YGd4yyNTTU8tz6S67/M1d06aeKTbxpBuns7DR6e3t5Y2PH/NUbNn+9rnnRZcw0MUlnEM3M/p9QFSYBA0qBSCJh+kxAmRgbn0ST0DptWnbTgOP2GoxSGIwRpZQilJpDp8+ai1aJvMbFPcRHgTJS/GYHB04Nz0xPC58BYTEiBXcMUBUHgJGREfbyy0+/tmjRoo5jx45lXvcW8N52+up7aweAUqIABA3TbNENIaHFUpBqZIgCUNI9rd4MojgN51BKFvWrlPJsEIhbmin33WQW5XsoozCZvhdEEUgyF2ieV6FyuVuEiNJDogMHerCoXHs2ShmImvMrEcozClWwTAbp5Mp+zgDxZJZIZ2cn27x5s+zp6RkE8O8A/v1DH7q9Ij2b2zQynjv5zDOP9d903Z2JcLiizIhHBJeEcyXh5LKp+rqW9QF/gCRmZ4SUiioolsxklJ2d/ouVKzcWDvdu/XE/YJfOVILBgJ8SpiWTpASBvjf+SGgcAKqrq1VptRCNVseUYr5cLs+gHGoQRbgQQlA/DYbrv3jpFbdvzoyeure3t/d0Z2en0dfXJ17/IjXeGBzdRl9fD1+y4vJLlizb+IPaunlVBVHgyikw02LI5TkCplWpFMAMi1BG4bMsUBqCaVqwbVvj8EpqCRy3gpIufUIIDodzef3tH//D8sraZXqzzqH5bEZGowSc8+riSZXJU3UVjYw7glkmkMtNpw2/ehQAqaurE0A3PXasJ+UF9Zv9gL/IFQ4FlHKV2qk7ECQgoEpBQOoErYjmaWmvg6LMqJf+54TeSJECIqXegjRNA55TlHaUkrAFh1S82ItIqcCooTOTSzfRvC8AjIKDQ/E5TS0FrclFZHEtqwhNCyVBhYJpMADE9wveHtXX18f7dIdPOjs7WXV1tfrGN3qnADziNchXXnbVB8rLQl82gmwNJRarqCiHbZs/2LN3MFBhmlDJHOyCDSsQINm8DRu0gwUaHjQuuaV/jcp+l4jBrzz22JcndWhT2/NyJEQPQqEUqLLzr2sNAPQgEgn7Hdv2KUOAKApQBkopo5qpxC1/zdWhOt/O1WWV9/b1Pfv9kpJLvWmAuFNxvnbjtV3z5q/9WlXdvODk+IjgkhuxWAxjgwOYmZ2BFH4VbxRECQEKAr/lA2V+GJTBsQs6g7jiAUopcMcpIlbU9JO6ukYSLq/8ZN7RYmijQ4PEgK18ZkQRymwvUHH2a38zEgwsqq2rWh0IBh46N5j41o+/89ARAKRkkYYAgKuW8fZc7u3xW36XBTFnrSa9/8oLPc9V6e+lzhTeAZ0z1cEcG1gBUrqlUZEar5Evh8vinEQ/LXJBC+XtrwupG3Hv8xV0ivPYBTowhFva0uIw0+fzgShE38ZxgSq5/6Srq4t2dHQoooUZXgKw9qMf/egap5C9bno2k/rWt775tYULly6OZ2ZkQ3U1nGFHpTIZYvh8gGFIBxQG8XcAkR475/vkwiXRLxw/suu7FjXbHEdBKqkp0a6CZSFfeF2F3E96ewGL+MtBCFVQikERoThM6gd3HKKEMDhhgpnRCn/E98DGy2/5+5dfIF8A4JTebOPC4OgVay/pvHzxkku/HatuYSNDZ+X+Xa+y6rp6DJ49hcT4MAp2FrmsQea7ewqUUJiWDwY3YTAG2y64UpoEhmEUa3MlFSzLRH1zK2BQZBwuiJR06MwAyc1Oo6m2QjlOjhTs7KvFymhgII+BgQ+9CWyn3nic8XbHB4hrSiOkBAV1115fh1iVBMkctcRVRnQpNHPDQW+nW5b0ZRSMajjYcJtuIYiGiItBR0pWfGXJGq9HfHR5TK6Pup6pAECpqJ279qsITMuc+4be/kuVIoXezOxrX/vaHgB7AOD++7sY0HskVlb91+WRyi/Mb67iE9NJkkjlWb5gU2IyKMZkQRHJAhX1lAW+seX6effFK2JNyWxWI+6EFpWDnHzuAnjXa+qJRdooNeBwIZUUjBHAYBTZ2TTSqSTi1fWMBfyK06AMhoK/f/X1WxeZJHnHJZdc4ngluhcgZPv27ZJUVkYampd/vayigZ04dkic7D/IsukJDGQSCIXCUNKB35Dw+Qm4Y0OpoOvAasCkFgzGwLnt4vt6j0ErAWpCFGPav4IQIDk9xUbOD8KAg3hZwOFO3pyeGj0+Ovnq/weA9PX1CJc6T3p6emR3d7cBQHq7JL/sJRYvCCgzQIkovvaV11cQVbKbUTr7mNPNpYxecDi92QalBFQB0gXHHEEB5QpbS7gAB4FhuLvnLqglpXjdtB4l5MY5jpa3djsX7p4Kid7PZ1TzoX4Vl5fpXaCE7tixA319vQLopjt39fwpNRCrqWy4tzoWQVkkpNJZWybSGZrJZyiYSZllSdAA6urb2ii1kcykdJ9GKRhlVCqp8vnsm8qqhEKBGCMUUgild/wBH6Xgjo1CNoV0YgxWLkJCZWU0yy3RUNV07Xs2Nkc/8bnPTXgvYsODxAghYsWlN2yOVzW157IZMT42wdLJBJQSiJURpJLnYFkBgHCcOTOBxau2gEBPuAkIGNNbbQU7DwIJSgDDtCCUQmp2BtGKKgGqaGJqmowNnYd0sogEA8JnmdRvUdOxk6dTueQtu3ePZEt3kb1I7unp4fgVXzobaD4UhduEE1Xif15iX6CBbZ08KQWULIFrVdG/wytzNMadh6PCGOILkZ05g/aycW2ZoHTp5DXhRTsE/U1oZRQPJnaDRcv+6JmRVLrRJ4SAukGhF7O8DMNAiJH5Vd5L93mWRGWPcg/hJy+/tLM3VlH5BcsKXROPhFgkaCKTs0Uinae5gk2VlDAY4dlsluWynNiKQnKuYBhESpGprm447lZAF1QTfiukAALti0oA6A3Q+a01OGUnIBUHkwXkUjOAFaaWFUsY5eXyDU36uLtZ1lTTsMoXCCmnIJQ/EALnHOVhA7XVZWhobAY1Aji0/0U4dg6KuDV1cYHfADUMZLMpSAVwIgCi4DMNTI+cBVcOswsCdjopghaULxAwAn6T+fyQpo//e87O/Mlzzz01DuDXvqhfDBDlNcVemeiJQqNY7nii0bonUMUhnYZkaRFNl1CQ0Coj4AqgAlxSpK3lOJeIY2QyiwAjiJlnIQQt2Q9RRe/DUpdcAo0SKqpNSlSxBKUQXKEIsM2pdQEEMJgBZlgwLHP2131/CSHKfRk+BeCpO2+9c4uk/DNCsNvLwkEWDflgO4oPT84SJzdjyHwGjq1QkASUmZCKK0ZhSDnT/sADD+zyWoXx8fG5KQbRkknSZTpwx0YgKNDWFMVMBpCSqXg8LLIFGFMjA6E9e7KiFIK/oA41LCtICCVamAwQwkFZvAZLVl2NJetuQG3bWixacS22dN4CAwxcOC43iMJxbAQCIcxfsEy/5QoOpG2jLBpGJCTyMn3+xwE5k2mpj7NYedgIBaFCEfVgwC82/p9//+pvPfjgg+NuGv71B4d7uLIFhwjpqoqU9B6v30s3mEv/ECUeISAlSuzC7RcEhLsOKwocOVWN0Xw1zg0OwZYmjszWIWNX6O0xSQDFQAnTdm5MwbQoLJ8J0zJBGdN7Ja6FtOepXqrYeMFsBtqb3TItMMNEWTQ68k54CfX0aBqLgiLff+T7z/Y+cP9dPpreCJm8X4pUOhwkxuqOBmaxwpOzszOZgEkh7Rwoo8QgFNOpvDU0RZ/YuOmmP1u/fn1Fb2+vSKcXEb2jRIlSxL1PHBACmUwGp8ZsFGQIVXEL9dUBUl9Zbixqi+dM4mz7h3/4h5nSuZlxYQMs8lLoKbhBGVauuQTLVq2GUAzZZAKEUNjKgp1TiEiX+kAJpBSglg+XXH4bWLACgkrMJqYBJycr4zHi8JnEQ4989+b169cvFTL7V/F49Bw11Nf+/Wv/sasEIJDvlMzhlkUym7cFEC7uJsytzl4oFSrVnDTPXDPtHVjXR1AADAqEURAiwXkAOXMpjp+agG1nYBoWxjMUA8F5mGflwWQGwn1MwoVxKZHFr+UxihWZ2wHxpvKEsWJmN0xWFFhQSsJk3gIXyeIdcvX29goCgq6uLtbR0aF6enpeA/CBm2++uT2Tmb01k/MX2trwtZMn0nurqqoWxElQDU7MMJ8/QBxHgsOKBSzfFynxf6qzs/pLm/u++q+7ASnUbbZQAoB+0RCm1xWEokjKgDQUo0xMnMgWJnrSo+mXHnvyB2dK+6a5AHEHkPlsjrvbDGhpaUYoEkDe5gDhWiiZMhgmw3QqixpX1kZygYrKStRUx8ChxcuyiQTGhs+iOhaRpmUaUpGX3FR6GHjt1lKEw/2G3kkmLEpKSQkheUroaShV7y73Ma+MoZRcoLgu3KGuRyzRpZnLV4Uudwgh4FJBSAKiJDK0DsPpACYmh0CpWUTLzk+biFU3Iy4PQrrCbB4bR7obivqPNVAglSbvFOVOpYRU7tRcAeB6SEsZAWEEAZ8PBAaS6fQ7TgvXQ7+6u7tpf38/6e3tPQ3g74us4o5Vf1ZWVtMbj5Zz2y6o6XSOEGaBmZYqcCUJDTcQFv7Ko5tuu3tJ+uxnRJ7PVyXkTepqJ1NCoEDoRFbKilBt82RyZv2TT/7gfncGKH7iHCSXy0gpBChjoH4GqYBMKo3x8TG0ts8vwrqFQgHc1uWVZRIEK+IogIERiunxcUyODiIWCQqiFM3nZ1Bwpv+qp6dHrV271mxvb5fj4x1k82a8gzLGG56Uy/4QSbi0D3hNuoseeQ26FLIICVPvEBPlvrGJi0wRKEgI6Le4LQ2kzQU4NZzQ234mA5EKJgWSuTzOZSoRCtXCJ4egqAnifr1i3+MRIdUbanoYjLmDWg/dUkWypRKAzx+AAMVYYuYdq65einx5dPzq6mrV29v7vVAo+ne1VH2+ujyCcDDAE8ksSxXyhFo+ZlCispwI04h3xmKBvZWxELK5LAQJGMQVE7csC9MT4/D7AjBDQTqddsxIKPa5TZ23Zvr6ev7UHTjz1wWITiGSqGkJJakrWTk9MY4De16BaQXQ2tYOISQMZri6sgUQCBBD24Zl02kMDZwFVTZi0SA3CIxgAChw+4Pff+iJ3W4GcXbv3q1nHH14x1+5gqTCnYCjhBWrvECRpEgv93oMPdvQPcQcFKvbPZMSSCKQpvNwftbA5NQkDEbnPg8ShEgMJfKoDLSjXk3puZWay1YuTVyv07o+iFqRSBah3iK663qWeEKOXAhYPh+zhQKlxrG3Sv//NQWKfN1M5Q+uuKKzP6pq/ns4WFbh94URzXExPZtmuYIihmUZeQURidWaZkBhZiIFYRlzSUERwM5KLgtUKQUzGABXVNTU1N8O4E/7nnuOv4Gs6HFYUonpgVRikmYzOXXuzBlxeP9ranZ6UnBuKyk0rYIZFJQZSM1MQnAhhSRydGgIAyePwM+4LA8HpN+iRjiMIcOXe8/27du/1dXVxd6x2eKnoVggOV3S0OLJKx0MCvdt7qpyaCp7cRruuBZp7oqsIyAcBwXHj1k1DyfODUPv+hFQ6HVjUBMGMyCEwLm0hQxt0aWX60VFQEoo7XrWRAmFxRh8pgGTMY26FSOFFCf/yh2WBINBYgsJYlnTumzpUO+W5+E19M8/3/dvQo2tcuzZ/w2ZzccjJmupicvaeEhS4aCQKzAQW+bTGZW3C5AEMJi+Jz6TIuAzqEUhQyZX+eSMErZCMBTOleAzFwZIb2+vVEoRi8nD6cTpY/nEeROFSRYNWCQeDbCK8iCBUhBKgTED4WAIqZkJDJ85SqfOn6KF1JSorYjy8nCQBnySGkb+W8n0wPr/+I9v/NCb0ONdeTFHCAmb28rhc9I6xY7DXaDysopHFCSEgujlJM80Xb/BlUTaaMfpcY50Jg3DtFw8QEAJB0oI7TgFhalEAWO8AZJGYVACSq2iqBzRKjBFtIpLR2d1N1iF8FxwRXGYqNdxCULBALJ5rvr7+9+VnoK9vb2iq6uLPfZY3+DDP9j+OcZyl0iRfcQwOK2NR+iC5mpeU+bjMp+nhUKWKCWg9FKbAoBo0JxpaQo9F4sFaDzkJ8vaalVNlLKp8aHjAHDllVcabwgQQKuH7Nr1/Pn1a+Praiv4bT6W+89gAJnKCuM7lfGyf2eMQiglpZNHrDwiY9EgQkbyqaCVOdBQHWURv2H4ffYpahTu+Nb9X/vggw8+PvJuDY4d7maaLVRSSM2w5W5Z5YkmcIdDSe4upyt3r34uw1BC3e06L5wECohjnDfhzOCoJ/zsCqQQgBh6EEgUCDWgIHAuKTCrmmBzDqkEbGFDClVcLtM+hEXHBGhTG6ZFIUwTpsncNQLiolpK+gNBMMMaeeHEiYHSQey7LUhczhd74IEHDvQ+8I3bhEy9J5sdP2AQ21i+oNFoqjZmsvmkDPot2JlZKAXCBZfprO23rOCL1TH2pXhlcKa60s/qq4wXpkfO/y/N4Ngs3wTxfwPLAgCwcmVZ+aWbPnkdsSr/h83Nlmw2iYnBc6Sy3M8hCoblz330G9/61v3XXnXDbZWVlSqRPP7kY4/tTHqwLd4B8vU/z9XV1WV1dHTI8VN7PvLezrZ/k7mEcBRh8CzWPBkfgeLiklTa58N2xNwmn5oz3uRCYca3ETvPUgwODcK0LEh3+QpEI2FC5GAaFFwwUCYhucK8uiia2QEExBi4okUNqVIH3OIA03OygiqWWkWvEhAo4cg733MLHclXnvnA7/3/5pUMxBTepVcJEioBmDdce9uHo2Xl5VxOPjidIK/Eyxsrp5JZTOU58fv9EI5EWciHkKWeCFqJfxFC7Pn+978/8JP+/TfdBwmHw1XzFq7f0tq6+APMV31rlmtcfWJkFD6LgIIRM8BgE3EAgPPkM499r+RwsXe7d3Zvb68NAB++5cphBQolCpCS6sUpoblRSgr3vy7U6yqYmIyBUOrK9Xj5mSNHm3E+FcXI+FmYlgW43QcgISQHEXnc09kCnk/iyf3TmHWCIERgdMZGVc08+JwpUOrutruUeVnc9dDvNkaIuwOvh2PKnaxToiCVgGUoFQwGlJ0Vw4QQE3rfgrybn5XX27rnznnsyYf/j/ex9Zd0/n+VFfJPKisidmYkYeWzefgDAcxkCsJRgeuEKl+bnj7/OwAGftJLnZVGYl9fH1avv+6GFWuv/VFDa8cnIrHqRXlHC8eMDJwlimcRDfkdkxCjYCcf3/6d+/9XV1cXq6qqYq2trXRgYED19/fLd+/t7qZAn7rxxns2LV52+aci8cbfrYxXVdsFG4SAmEzBIHq2IYSGcgW0HpUnEGcLvQkouQBXHFQBNsKYYmuw99QE7EIahBqAYiBKQlAF4XB85JomdF1WjWxyEsSewVRGICdMFAoFMH8F/IYNw54A3H0yrRPsZTBtLCrBdE+kGIg7GIRSUBRQNAx/uJHaZp06Nearraybd1tNVey5gYHTk/CWRt7Fl4vGkc7OTuP6669n7e3t5Py504eD/uD7osFYrCzi445doMlUGobPT7kQosBpyOeLdNXVNlmPP/bgcy5iRt40g/T3LyUAZH3rwr+oqV/UmM+kbC4EE1yw8aEBWFQgGg1wn2GYPl9uaHRw5NOuyIAC8K7OGHMvCdCeHkgrHLu3oXX9h5PJWTzdb8NHW6mFFKJGEvFADvFgDtEgQKmAsL0WgmrdWWlrgQcwEKHh1zRpxZFzOUxOTSIYsADhQABghCKXyeHGlXHctqkOxAogWDkPldEJrOQ5vHSeoAADg+PTKGtqhs8YAxNp2FzAYAx+nwlHAPlCAUoBAZ8OXEfYEITBMCthBOtAfHWwjRiG8hJ7X0nTmdS40XnpitV2VfDe55576vPd3d3vSpTxzYa8JUtcFMBITU3N5pkU+2YkXH1JfWVcBn0ZjE6nqCSUIRBUGWnIQKjhTzZtvvPSxPjRG/v7DzulMVIMkO3buyQhQNAXZo7MS0qJMT01QadGh1Adj8AyLO63DMOyCsdBxa1PP/306W3btr0zuFNv80Uoy6XSWT6TykpFYGlxszCoCsFUNgI0jXJjBrVlBdSXFxD2O1qs2hbgXIEEarFs9ZWorqzE1PQYBgemkUiegaokmMwbKEDBJARCAHVlJu66qglQCjzUhEBtHP6hMbQYQ5jK5rB/lMDhHAPTQbBwK9pCA2hpng/BApjOA+F4LZrbFmAmMYm+H30bBqUIVM4DCTYhK8IYTTuYHMsglZ9E3mVa27ZUBVvIUCQo8Jt7SQC0r6/vJOaj89bF773PMKP/tTwaQCTo46PTKWM2kyaBcIRmFXNqKlquaqguu7K/nzxV2iYUA2Tbtm0EgErPTpnMitCJ0SEbTtJoro2DSKVi8aChSO6Z6cSZrt7eJ6bd2cZv5A02YCkQalAoTgmFIHO73TbzIa98GM9EcCQxiwidRV0gi4ZYAbGIg5BJMTE9i52HhrHl2g6s2HIVVioHy48dxM7nn8e+/gEcHhYYz/pQcARuurIJzTUhDCckFi5dgHPTR1HV1A5WWYacfRAjKYnzMxSMT2PLhuVYtmALJtICiQLF+hWrUFNbjfHhMRw6fBpW9SbkZQRDaYmxkQySqUlwzsEMAp/JYBmG3goRCgallEqC3/BLdqOb9py8r/DIyQe+cMetXS8yQr8SjpY3xMrL+eR0gg2MTBBhRGmwvlJUhVkZAIyPz/mmlJRYWpzLyU08nJ0WK1urY1ZdVQNmk0n4AgYIs//pR4/+0x/098P+TWjE3+xa6sr9SIiIlNzF9DiIAhyhh31EFBDyAzWxIGoqGlAWbYcJjszUOUxmRyF8BUQsiUP7X8TJ0ydx3ZYrcdk1N6J99eWIN84Hfejb8KndOD46DVoVw5bVdZhNc7BoHcpqG0COHEW8Io6IVY3E2AgWVQyjPhbCp+66BG0LFmBoWoDSDG68bCOyyRQe6n0I33voAQBlqG1ajkRqDE4hixgjiMcpbK6QyTtI5xXykroDdgMgCv5A8Dc+QnqgFew7OzvZg4/0PnLTTTfttEz6D8FQfGt7Uw0qYxF+6NiQzGdSVsaQtgv0v7HE8rDlp556qOczn/nM93OzMx8fGszc5AuwPLPUl/7+77+y3V1qp7+JweEiIdr5yi4stu0ChJOnilmw7QIsg6NjXiXWr16AZR0tqK+vQrQsCsPUJjLpmRQmh89i6OxRTJw7hanMGYykChgcGkX/ntewcOVqVNY2YPMt78f4+DQITqAsLOHkZiCDVahrWgQQCr9hIhCLoaKiCkNnTyJ44jguXdOGjg1XIi0YeHII69avx5lTp3HySD9mJkawckET5rXNhz8YATOqwJhegw5GyhEIhuBIYCaZw/hkEmdHEth7ZBBCCFTEYryrq4uNjIz8pgeK6uvr4+6LfRTA3b/90U88n8oYf1lVURe56vLl6D96aPjksalX9CykT/ykOYjX3Hh9hek24NLlwah3O9rxU++iUmTbtm1k9/7EnkB83spkckZSKmlLrYVV8yvQ1FQJ02DIZvIACAJBH6LRMtQ01KGhuQWWFYBUEmNnTuDMod0YOX8OMIPwR+NoaZ+PxvY2lFfW4KXnnsFTjz4GHyTa6yNYuHIdFq65HIFwGXa+8BwCfh9q6xtwcM9rePSh72PpqnX40Kc+hd27dqKhpg6DZ89g+MwJ+A0gEAwARhCJdA6CEFTV1KC2rh7hUBCKc2SyWeSyWTiOAyElTJMineL8/HDCOH3mxHe7v/hn71Pucve2bdtYf3+/+k19AXpn3lvjXrBgQfvKpavviVdXZDOZ5PZvfetbg6+fBZKfNHzp719Kenu3CkII7rrrLvYbftMAgHo6rje8594jNbXzFjPiyFiI0rYmHxgEZhIp5Aq54k0LRULao5ww1DXUYdmKFZi/ZCn8wTAK+SyO7d+L44cPQREK0+dHVXUNVm7YAEoNfO+794NKwIcc1l1+JdoWrwQIxa6XX0BlLIaKmhqcPn4cTz/1LOYvWYxVK5djenoKFghOHT2A6ngUkXgNMjZw4swZVNbUYsmiBQgGAxgbHsb5s2cwOjaJZDqDXCYD7tgwLAOhUAiRSFRZph9DE+OpJ5/dcc/jjz/+NLS/iveioNu2bcNvCLL1k6qFNzvTb1Df/L+l1lJu6G/yVbwxN91w7Qc//rFP/fuqFStYJOKnjJmw7TRyeQeFbBbp5CwyqSScfAGZbA6J5CzyjgPbdkCVRGtrCzZsuhw1jS0AgBNHDuPA3j1aRzeTQ01DA6696SY8/dQTyMwmYRGBSzuvRnlVDQBg7ysvoKm1FZHyGIYHzmLnq6/B8vsQDYYQ9vuQy0yhqW0e4vVtsG0H+/fsQl1DPRbMm4/piQns370LQyNjsB0HVNpglMA0Tfj9PgQCQQjCwIWCwwUCwRDSuQIy+dyZqcnJ6cGhkad27dn3w927X33hJx2Y37SXYndnN3WFG990/eKdVHuSboCgu/snepl3dPSqnh68rWWeV17cfvsNLZ2XXduz6crLP7xgwTzYjq0MwyTBUAiBwJxzAucOkjMzmBgewdjoMJKpJJxsHvl8HolkEnYhj7bWZlx6+RWobmoBIRQH976GV195BZFgGOl0GqvWrEF1bTUO7z+ISMiPDVdeBdPnh5IKe3e+hMVLl8EfDmNi8BxefullpJNpVFbGYTGKBR0daJq/CEoCr77Qh5qaKtQ3NuL0sWM4uHcPpmZmYUEh5DcRiJQhEIlCEoK8a8jjsyxUVFWhsrIKkWBQUYOBEEIK+TxmZ9M41H8Ep88N/PDV/fu/8Ehvb3+pgMbPV86AAPqZllpwewxyj038Ti3ff10B4omLkc2bgc2bt0nGqPQE0X5qyBMCISUBQHZs20Z3YAeAzfLnvMHEHZKx3/vMp/ZeunbdkqmpCZFOzjJwDmYY8Pn9KK+sRmNzK5YsX4a6hqbiJ48OD6O//xAmxsagOIeTz4NSinQmjaaGBqxevwE1TU0QUuGZJx7F7HQC4UAIk5NTuKzzcowODSPgN7F20xUAMeDYNg7ueQ0r1qyDYfkwNTaI555+FkoC5fEytC9YgNYFSwAAB3bvhN/nQ1v7PJw+cRyvvvAc8vksGKEIhcOob25BrLIGYxMTOH/+HJpbWjB/fjuikTIkpqcxOngO42MTGB0bRmJ6RnJHwPRbsrKqmjY1t9BXd+48971Hfrhq8eLFyZ+RV6ef6fg4WfqZatXVtV2+Tr/sZ3pZ9W7dSg93jJMdO4pLUr9WTt+vMkDI9u1dtAtdIFu3vlk/w5a0tjau7qiPhUxfkPgMAyCMCKIEcoIXzPzxMzPTLx3ePQig8IbAoQTiO99l2w7/E3ED5qe+9VySm9HT02P/7qc/uTWbTH73+PFjtm0XrELBRi5vI2BZqK6twILGJpTFymFGyrBo4RKs33QpWlvnwzAt5LIZ7Nu1C8ePHYfDHQRMA5FwBInpacQrYli6aiVa2ufj7KkT2L9nD+rr6jE4OATTF0CsPIpQwIfVl20CZRZSyRkc3PUaLttyNUAopieG8eKzz0EIgYVLFmHxshWghoUTR/sxfO4sLr/ySoyPjGLnKy9h+NwgfH4LDU3NWLpqFSpqanD8SD+Gzg1h2cqVaGxuwuDQIPa/thPDJ47h5NlT2HXgCM4PDkEqIBaPIVoWQcgfUqFAQK5eu5oBZtsf9/Sc7e7utnp6epzXH9RugKKzk27bsVm6hqCvuyoiXbeuq4+YNJJ38sFCQVRSIinAIKTgjBoJX8Ca8YWqM4/v2TM9qN1t33BA/6Kz0+j/NQXLLz1Auru76balS8nrgqLidz9+54qwhUsWtNYsM6mq547daFlWa1UsbAYsA4zMWSArKAhFMTWbFals5jyEmjZM/8TIdGbk9Nnzz50dTR340bOvHoCWjSwGzHe+cxfr7Z3bdfau7du3s63u97N62bKNH7znfV8PWNa8kyePIxT001QqhfPnz2Pg3DmMTU2DEYKl81uxYvFCsHAZiBnEsmXLcMnGTWhobYeTz2Lf7l04cuI4pJTwMwPRSARnBwYQi5Vj2bKlKIvHsWf3TixZ1IFcLo8jx06gvq4WAZNh3aYrYAXDGDhzEof37cVNd3QBSmFyfBhPP/o4ymJluPLqaxAMR5FKzuLB73wbnVdeDtNnof/gYZw/fx7xeAXmL1yA+UuWwxcMYu9rr+D4kcO46pprEYpGcWT/AZw8uA9nThzGjpd34tmdBxAwGDasW43FHUtRV18HSQ0IIZFIJGRrawuOnTz5nX/+56/+AYAxQgj+4i/+gvb09Kjuzk72xqCIlX3szg3rTVJYW1MVXmNn8/XZXL7dZ5m1lkEpF0KzjoUomnZKV4ETlIpUOjejQPojZeXjjjJyk1OJVyUN7ez90RP7vRciIQTfvesutvVXGCjklxcYoEuXdpGtW/XhrK6urvn0+6+6qiLmu7MiGuxsrIpWBXwMfpMB0oHj2Cg4DhxHQmr1NJ10lYQklFACWIZBLMunLY0pgZAEOUdgaiaHVDp/YixReO7sUPKFXQfPvvbi/v2HL4BvN29m/dXV6tOf/jTZsmULv+ryyzuWLl1+X0tr851XdF5JmpqaVHksTjjnSKdmMTUxhomxUZw53o8Xn38ez7y0EwYUtly6FhW1jUjlFRoa67B23Vp0LF0Oy2fixPFjmJycRiqTRqFQQCIxi+HBQTQ3N2H+gvlIJ2dQU12L1WvX4bHHnwAhBH6isOnqqxAtr8DOl1/AyOAguj70cQjuYGTwDJ547HGsXrseq9ZdAkIIvvedbyKfTmHJkiU4dOggxobHsGTZMlxy+eWorqsHQLF/z2vY+eLzuOLKK2H5fNi/ey+mhs/h7Ikj+M+HHsXQRAK3X3MFtt59N+oamjA6OY2xqQSCwQAqK+IIhUKYTiSUEIIc6T82dOrMwL/c/537/x7ABQqGN23Z2LKsPb45wHCHgtzAIOuknYNjO8gWcrBtx92PB4T2s5YgnnyrAgj0ahmjMAyGgGXCZ5kgzISAAUGCsB11POvIpxNp/r3eR599DgD/KSjUuyJAvLqeA8BHuq5bu2Fp02dr44Gb6yrDVT7GIbiAbRdcQUACpUAUFNENsyLKlep3TeuLol8KREmlg0Y7z2syN2NgoUAAlFng0oeR8aRI5/m+I6dGXtx9Yrz3qReLqAwA4Pd+7zPvXdDa/h9XXHFlZNmqVYoZhudHcMHlODZGR4Zw/sRRnDp0AA8++hh2vLQTLQ31WLNyDQzLQDASwvz2+VizejVCoSAmp6bBDAMj4+M4deosjp04CctgaGlpgN/vA6TCxz/2cRw9fhwvvvAi7FwWN918I2JV1ejbsQPCLuDDv30vnEIB/Qf24bnnX8Q9H/4oausbsfvVl9D7rfuxYMF8TM/OYP+BA6itqcEf/NEfob65HQBw+uRR/PiRh9HW1AQF4NSpM0hNjOHAkYN4+IkdqK+uwB//3idxw61dkJYfJ44dRyo5g4p4DNFoBAYzEQyFEC4rg2X6xPTMDDtx4hR2PNe379HHn/yUPTNz7pZrV9waNthdgucuNakTzqbTSOfyyObyEopIjXsQQigllOjXW9Hxwd1RAVVgkK41HJSUEii6GhPPMZ4FAwHi9wfBqQ+cBA5OzeYf+NpDT/09gNlfxQiCvN3l1H333SeVUtiy5bJ577lswZ8sqIt+pL4qwGzbhlMoCB0VhDLGXOUQ17K4KO7sKpeLuZ9ZFn37XHUOLXV4oYefkpJAK+z4/QHm91kQgmEiUcCpkdkXTpwd+e5TLx869Pk/+sKWqsqqv9i4aRPa5i/g6XTSeObJJ3Hy6FE4hQIYo4hXVWPN2nVYumIFTJ8fw8PncOzQISQnRvHDH/wQ33/0KVRUxrF66XKEo2GYpolIJIra2hqEQiE0NjagoaEOJ06exncfeAipVAatLU2IREKYHB/HzTfdiKs2b8G//8d/4Pix4+jsvAJ1TU146cUXwQjwW/f+NoQQeOxHP8apMwPo+dJfYnx8FP/77/4OyuEIhyM4deYM+o8ewef+4PP4wIc+BgA4uG83HnngAVAQCMExmZhCeiaBg4f7sfPgUaxa2IYv/8Pf4JLNNyCZTuO5px6HUgINdfUYPH8ep06fRjqZge1wMNNAS1Mzrr7uGlXf1CROnTptPPaDH8rU8OE0c8ajyWQGieQsOBfCNCwogBJGvKVIKNA5O2rXQNQzkNCWD9pyDUqLSejlMW046h1N/ZilpAaVBiQNBEI0GC5HShinpmacv/r6w898DYDY3tX1Syu72NsXHJ1GT8/XBYDQfZ9/37b3bGz/t5XzKjb6mEMLTp5zIQmllOr3ipaz9lyndGCQC8TYvMCQbt3qBY/2PFcl8jvu7SSUAJRKSWje5iqdyyjbyYmgj5L2xkhLY13NTR++9798tLGlrTMWK8fy1WvV7td2sr/+0n/D/ldexcTQCM6dG8DgwBmcOXkSRw4dxNnTpxCJhFFfXw/GKMYmJhGPlSNoEBw9NYDhsXGEAkH4AwFwKTA5NY2R0VEcP3kcuXwe69evRzQS0QZChCKVSkJIgb379mHR4oUIBUN4bfdeZNJpKACnT51CJp1GS2MjpiYn8OSTz2BJRwcWLVqEr/zjP2Lg7ACiZVEoRjE8PIxlK1fgj77wp5gYH8N37/8mHti+Hdl8DjZ3kE6mMDOVwCu792L/sVNoqavCV7789+i8+b0QUuLZx3+IQiaHtuZm7Nu7H6++8hpOnDiJ0bFRzCQSmJlO4Nix49i3Zw9ZvGQJXbpqlaysKKOGZfn6Dx7l4+NDyvQFicEYVcrLDXOK61Jq/xRKAea5WFMKRfSaGAHceYxewSiKbXu284SAMQJKiTZAppQUuC1T6YTwEaeyobrs1o1rVlxfWVE18MUfPHqSeLvN78QAeba72/hYz9d5182Xr/3Dj13/o8uW1b23zC/9eTvPtbsa07ogrogBIZ5bkrzA2+/1VgJzM0pX7qZEPVAprYXraeUK6UrtQAKKEKrVnqmjJJmdtUXHlXfKeON8HD18WF5z0y3kaP9h8pfd3SBCwbYLeGXPHuw/dhynBocwPDaO2XQa6VQaw+fPI5VMIhqKaMV6g2LRosXIpdM4duo0CoLrZtvnQy6fRTabxcT4JF7duQunTp3GdVdfhc7OK7Fs+TII7iCZSmFwcBj79+3D8mXLkM5mMTwyBCiFqalppJMphIIhDA+P4tz581i7Zg2+ef/9eOaZZxCLlaOiqgrlkQga6+tx8y0345WXX8L/+KsvYfeu11AWK0fA7wejDD6/H3sPHMC+/qOoKIvir//H/8Rt7/sghOB49JEHMDkyhnnz2/H0M8/ioR/8GC/t2o3Dx0/gyMlTOHbqDBKzSdTV1oE7Dl595RWsWbuWNLS0qUw6hyWLO9jZ08epnZshXuaXruKKBlXcs+76d1A3UKRnHuTphQk3gJh+zlKiaC/BmBbiVl5ecNX3KGU0Z3M5m5iQYZ9qmtdY+6FlCxdUvrL/6NOEQHR3g/b1vX2ZhL0dwbGlp4d/8v3XffjWzqUPLqoL1GezaZ53BFEKzFM+h2s+ozWU55TR53aqXZsxoVwZHf1m8Xa6izKfrs6sKtF78hSrKHX/7eL+FkOhkEf78qtpzqqj3/rPr5G7tr6PhiJR8lc93cim05icnsaPn+1DMpdDLFaGsrJyMMPE0OgYTg8MwDAY8ukMhkZG4Ng2pqYmMX/RQqzfsB7SsWEXCrjnng/gxvfcgsrKKtQ3NKB9/nysX78BV3ReicaWFvj8ATBKEYvFkC84KDgCuUwGDrcxb948EAIkphKQnKNQsMFMA6lUCu1tbbAsCyOjo2hqbsbSjg7U1dTCYAbiVVU4c/YM9u3bAy44mpqaUFtVg5raGixon4fKqkqkMhk0NTTgvvvuw133fBBKCvzw4e9j92u7sHDBAuzeswdf+9b92H/0GChlKI+VobqmRn/N8XGcOTeA1tZW5NIZjI6N4JrrbiD5bIYE/D7MW7wEB159FibTAoOavafmdIuhM727mg8uAc51iawF5wlMg4ART2DPE7qjOrBAAEUg4Gkgq+KOPSEgBjVoKp2R2dS0XNhae+kl69ZuevbVAw/09cF2t2PVr70H8YLjS3/wod9dvSD+v+MBAduRQlLCiOTwEAvv7U8YLb5eXh8gxXzh3mjPElkbw3jeGigqgUg1FyRFH3GplaY4AIMwSGEjVNmC8vlb0Pu9h7GsYzF+67O/j2eefhJf/uv/iZraenz7ge/DME0sWbQABp0Te8vk8hgeHsVUIoGrrtyEjvnzkcnnYTsFLJy/ADffdBOi5RFMz6Sxat16MMN803tUKORQKBSQz6QwPDSMvXv34szAAAzTQDgQhM+yUF5ehsOH+nHu7Fk43EE4FMKqVatw9TVXIxyNIpVKY2ZmBlwIZDMZ2LaNZDqFRGIG2ayW2A34fIiXlSNWEUc0EkE4HEYyk8H6Sy5FKFKGoXNn8dijP8KTTzyJtqZmhEJBfO/hh3Gw/yhaW1sRCfhhmAYCgQD8fh+S6QwO9fcjXhbD9VddhenEBL74l3+JhYsW4/GHH8S6Devx497/g2d/3AtfIFjUKy6qolMdBEqpooaXUtq70usvmCvJKpSrD+Z6LWqQxjUGYgSMusIYrh40c1OScnXJlODOisWLzSQpf+XvvvHoHZOTk6MuJC1/bRmku7vT+FjP1/kf/datn9qyuvGfQiwnsgVJqEm0BWaJzJ8ukojXds0pj+u6qijTqQ+8KPYk2qmp1AxzLgV77kylaus6Er0/lyDUgBGdj4cefQ6F2QRuuf121De14Ov/8X/AAJwdHMTRkyexdtUKVFfGYWjvPnCHa1lVnx+5fAHHT55EU309opEwphOzGBwcwt5du2FzBzfeepv2QRGi+LOpEkVFwzBhWT74/AFYpgHLMkEoUMjbyOVySM4mkc/nEY/FkEomwR2O9RvWo3PzZlDDgOHzwTQtRKNRBIPasMh2bNi2AwKFYCCIcDiE8rJyxGIxlMdiiFdWIhaLI1oWxaFDh/DA9u148PsP4PnnnwclFBXl5dh74ACef+U1xOJxVMTK4DMNGKYJ0zQQ8PtRGY+DMYZTZwewbMkShEIBQCqsv+xKnDh6CD946BGs37ARh/bvRCFfAKGkWA17skTKFbUgrmmPYVJQSvSfQbs9EarnIQS0aEAkpdSUfYO6zT0FVwRSKFfDT6ObSimYBoVlGez8yAhvrSlvvnTd6qsef2HP/Tt27LB7enp+4Z7k5xIP6+7sNHp6+viH79hy6+Urm/7ZRFZkbEkpARGOLqq0Rzdx06IulRzHgeMIcC41/ZrzYqNO4Fkd02Ji00YvXsbRioWcS9iO0GVKvoBc3kbB5q43uXswpfb/M31lOHZsEGeP7AMTBdRW1yKdSmFiZAzt7e04M3AOjbW1iIZDSGeyEK44NDUMKBBIJRAOhUAoxQs7d4IRhqb6RsRjccxmMqhpaAYzLPeBMlBa+ouW2J8RmKaFcLQM9Q0NmD9vHhrr61FTVYWq6kooAOl0BjW1NdiyZQuuvf46RMvL0dzajpa2BWhum4/KmhqEgkEYrmuVYTCUl5WhpqoSDXX1aGluQmNTI2rraxGPx+EPBRCvqMD89nacPn0Kp06cQm1NPVqaW8ClwKu79sIwLdetV4IwBsoYGKU6Q6WSqK6qQjAQwNjEOBbMn4+BgXOA4mhpasS5k0ewZ+draGxuh+PwojC026PP2dB5pqZEK8FAKN2XUJ05pEIxyyjos2CY2nlLSKlF8LgrkuFWJFK5hqZUgwLckTBMv7Hn4H6nzEit+W+f//iDhBB0d3ezX7RKom89c3TT+57r4zdsWTvvmkvmf6M6BJnnihgGI1DKlf2XrjSNh1QpUKoueNN7hjBSKdfjwimWUm5XdkEJJYQsSn1KriCFglRaMd12BPIFB3lbe4Jz7oBzYHwyiV2vvITzJ04BCmAmw/DQeQQCFqprqpCaTaOxqQHRaASFfAGJ6QRmZ2eRSmeQSeeQzzkoFLS/+dDIKI6ePImJ8VH4A3587r/8IW5/710XQNQ/hWOkH6zQ8qF+y4dAwI9oNIKGujrMa2tBTW0NYrFyrF67Co2t7Whun49wWflcmSmkLtWyORRyORClELB8iITCKI9GEQ1HEI6E4fcHYJgmDNOEhEJdYyN6vngfbr7lRuRzGSQmJ/Hk089iMpEAd2w4XCKZyiKVziKTzmBmZhbJZAoO54jHY6iMV2J0YhLtbe2QSsDJ5+Gz/HByGRx6bSfSiRkYJnVt4aRbJmsLOMYYGNM6XQXOYXOpexEh4XAJ29EvOy/bUkphWtprxeESXHlqIEpbRyit4SKF0kr5Qrnmpfog+3xhc9fuXU57jXXNts994n/29PTw7du3/0IKksZb7VmWLu0nSrX4b7tiyXcX1fmjqUxOGBRMKa1hS5RWPJdC6EkPY9oliaiiyaTXgxQPj3QbMEgIXiLlqbwGjQLQkppeGXUh0uXNTxSE29QTZYDJJJqboojX346G+nIkpiYxm8sjFNJliVIc7S0tmN/egnwuj4mpSWSzeWSzNrL5ApKpJGzbxmc/87u47rprUFMZx9T0FDZcchkqqqouqLl/6k0jBIVcFplUEtlMBjOJBHLpDAgh+mCHQ3A4x9joOCqq6xEKR+cgbQI4dg7J2QRGh4cxOjyMdCajVU1Ms5h1iasfrA08KSg1QCmD7XDEK6vw+f/6BWx65VUc2LcHN956MyYTs/j617+O3Xv3gzIGLoFoyI9oJIjy8ihq66rR1qaz7HRiBvGKCvh9ltYYlhIKDsanhpHNm2BM2zdQ5qo4ei9C4qIoirpOwRp1ZJTAZMQV3VZF6olGrbQouBBSv1iZHqIwbX6t0S7P9QveudFBRKEgmd/cu+dlvmHjVX947/tve3Hr1q0PuXMS8UsPkO7uTrZ1ay//w4/d/CfL2mJr09mCoygxhTubUFT3ExQEyk23pXbJ3lCv1P2oNEhKbY71L3FBqUVcDB0MRfVyTw/XG72CAkRSMAjYvjI0LFiP2oYmlIcJzp44CRoMweECoXAYjFJUVMSxbPlSzMwk4QgO25mCVAWkM2lASfRu/w5uvuUW5NIzmJ6cwrz581BRVXWB2+xPyxyEEBQKBZw42o/jx44hmUoim83CKdgIBYOIRiIIBIOI+4LIZbLabMeTL6UUdi6DofNncfjgQZw4dgL5fB6W5UMg6AcziG6qRaBocTDXA2jrA8aYbg0IxYaNl6G+rgoGoSiLxXDHzTfgvr/87/iP//w2TEM7V1VUxNBYX4vm5ia0t8/Hrl37IaWC3+93IVcH6XQSK1euxJ6dzwLgUMpw1R49o1Di2kJoJJK6OsWetyMhcINMPzfK9OxcCh08VMNU7gyFFJ/znGiVLAYUyJxFne5JGBLJDB05d0RdumrZV776VNVTXdu3Z90vrn5pAdLd3U23bdsmDu66on3d4povyHxeOA43CABFGQjhYIrqG0VU0QucFKE/uJlA9wdF5KkkUOa8xL0bqbd/ldRSnp5ZpZbDvXCoSIjrrgQGSiRyKEdSzkddXQWuvH4zhk+fwq5XX0VNUxuUVDBMC9GyMkxPJ1BX3YD6+nqMTk4gmUpBKoVMOo0v/+1fY9P6NfiXf/hbDA8NoaqqCjfffhtildUl/oMomde8eTZxHEerMiqJqakpjI6NI5fLoaqiAoZJEYuXIRQMgTsO0qlU8X5l07PY+9pOvPLyy5hJJBAIBBAIBMG5QD6fRzan91B8lh8sx0ANBsMywbihi37CIFy/FyKELoEYxdNPPYXUTAqLFi3E3/31/0A2W0Dvgw+htjqGqoo42lpa0NzShqrqGnAh0d7WCkYZQsEQ0qkZjAyfw3U3b0UgEMSLO34Ag81V69r1SrlmoW52Ix5uRVxBbVnSoyndM2qaFhSlMNyXqxASTskw2ft3PLjHCwp9dkTxOfgCIXrk+Elx07zFdX/9yQ99kRDy+VKC6i8FxfrMZ6rpsmVb5UdvveQfV7bF1mYKeUmJHvHoIJj7gZWrPqhKZhel2aM0i8xZKWt0igsFLnRzptXUS4eCnlHmXNbwEC3vY0o54KQcU2opqmN+bLlxM+paFsDhNg7t2wdQilQqhXhlHGNjEzhy7Dg2X3E5CraNkZFRpFMpTCdm0NTQiDveczP+9V//BQcPHkJ5eTk2X7UF1bW1WvvW9ScsDQrPjba0tAIAy7JQU1ePNveg5XI5BINBcO4gkZiBwRhi5VGMj0+CmgaaW1oxMz2BvmefxjNPPoXyWBw33ngTli1fjkAggEgkhIp4BSLhCEjRglpqa2TDK7E8oMCFQ7mNfD4LQhnsXA7PP/cCdr62G5ASa9etxcM/+CGCgQDaWluwaOECtC9YgGy+gIce+gHec/NNYITA5/fBZzCkpiawcOU6tMxfiNmxEYwNDWj7BngOvsQVzaZuI61LX1kSGKV+j17ZDOpZmriOwYpo9JNSTU0puc+6tNRB5ynqG3r5yz1LlNi5Wbm0Y9kGQsIP/PkXvzgBrZOl3vYA0RpYvfLWay5bd9Wa5i8bsCWXipGSwzG3m6tP7oW1+dwPIt0hoEch0Qfea2QJhFSAG2BeUIkS+I9L7fkn3DeiUtDZRXJACgiUYZivhIEsrrnhSrR2rIZwbDz4yI9wYN9eWKYJfyiE8bFhNDY04MePP4nKqhgioTDOnTuHfD6HQoEjk07jyOHDAAg2bFiPq67agsbWFkgpUMgXoKSCaVlukOBCusSblFmZTAr79+3BwJkzmJmaRl1dLTZu3IhMNotjx47BMgwkZhJQUiEY8OP5vj4cO3oMt91+B26+9RZMTU/jhRdewKnTp1BTXYX5CxbC5/Mhk8mCcweO7Whk0IXEQQgYZQABhBRwHBtSSDgFGz7Lh7JoFEJwHD54EIeP9OPEmXMIBPxoaapHY0M9ymIVeHbHczhx4gR+6xMfw95de7CkYzHOnz6Ng4ePoK61Fe0LOlBXW4+RcycxOjYCZhi6dyyi/G5BJKRGCF394CKjwm26QXRTr6HeOQsJXT65Kw/FccBcxtZGqgChynUV1tN7Xa0YZGJ8UnUsbDQq6ttjazdteWDHZz5De15nFf22BMjhbdtoT2+v/K07Nv7N4sbI8nTBFhSEqpKqTkrPEkwjULJoU1YyvyhSS4qWSSXzD1XMCKXZZm5gqGtqUlrKuHWoEIAUBTiqDONYi6nxSVx75UKs2XIT8pk0vvov/4If/uBHSMzMIBaJwrB8GBkdRiQYhGUYeOHFnRBSIpfP6oPGJRYuXIC7u+7Epk2XYWnHUlRWVQKEIJNKw7YLMEwDvkAQ5k8YEJZmESEEElMTOH3yBHbufA2jo2MYGh5GOBzGlVdcgXPnzuPk6TPI5fIgAKbGJ7B77x503X03lq1cjYcf/D6+9a37cf78efj9AaxYsQq19fXgUiCdScN2HEghYHMOLjgUANM0wAwTUkkUsjlk0xk4dgGWaYEyBn/AhwXz52PD+rWYSSTw8mu7wAyK2ppqhMIhHD12Ao888iN85MMfgkEUEtPTKC+L49WXXsTzu/bi5ImTWLxwPhYsW4GAP4Bjh3Yjk80UM4Zy/WS850S9jEpKnrcbSNQdIKuin7lGvhjVjbmERkEZnQMhiucHCqU0LKWoO4+SUGCkkEuqhYuWLJnh/t4PfOlLE291yv6zBAjp+V6vvHzVqqotaxv+zmfygJCCuhiF2xe4JVXRToaUMHFLSyxveu4ycHWHoZ1bS2Dh0ul4MbjcQJNCFeknXkARJeEIP2bNtTh0ehqXLA3ghq4PAITib//6v+PHP/oxQsGgnr5CIRoOwc7bmE5MY/WK5UjOJnHwcD+yuQKam5vwud/7XXz84x/DgkULkcumEQyH4fP5MDs9jcmJcYSjEZSVxxEOl/3ERt2zRXBsG8lUAsFgCAsWLUFLczMcx0Ymk8Pw0AiEzVFTV4uz585hbHwcBcfByOgYli9bhrraGgwODYILiSWLFqGpqQHRaBl8PguxWEy/TISAYRr66zGGaCSCWCyGcCQKKxAApVRP4FMpTI5PgHOOsli5/r6FQLSsDEuWLMaq1aswO5PA8NAwTp85h2MnTuLmG29Ax5LF6Hu2D3XVtRg8N4Cde/eDg2ImkcDxY0ewfOVKzFu8FOnpCZw6dhDUMEDc1WnPK16DB0oPEwmKNtnF+PGqCyWLL0OU8rkYBQV1YWQFQqnLvHDnVsQtJV1GMIF2szUMg6RSSbFy+SKzrKpx9kdP7Hhm27bN7Otf75NvW4B0d3cbfTv61AdvXff+jrb43Y5tSwBU4vWWZG75pHT/UKShuz7j2v+CgAsFUSQXquL0VUoUA2MO9XJ7EMB1TuJFrB0gxWzEBUHeWo5dAwzNoQTu+ejdiDW04x//19/gxz96FLFYHD6/DwbTaIthUMTKy2FzgdTsLJrq6xANh6AUcOMNN+Da665FuLwM+XweuWwGkWgZlJQ4c/oEfIEAWubNR3m8GoZhvAFmLr4eCIEUNkaGBjA6PIzaukZYvgBi8TgUJGZnZ1BXV4twJISpqWn4fAFw7mBwaAiXXbEJtbU1SKUzWL5yNZatWI3m5iaMjgxBCIna2lpks1kI7qCisgqUUjgOR3msHHUNDaiorkFZeQzBYBg+XwB+v6aR5PI5TE9MIBQOIRSNuAeQgXOOylgFwsEQDuzdD0YorrhsE2qrqrD7tV2IxeLIZbM4fKQfeaEQDkXgs0yMTUxg4OwZbLxsE2rrG3Cmfw8mpiZhGAYoaLEfoISAlfQH3lCQFm3tUNLQu0Nilw5PaIkXigvv6vWGOW4GSs8iFCi0BYVpMhQcB+GAReobmqvuf/DJf/7a13bInp6et6/E2rFjh+rp6VFbr133z1VltL5gc6VAqFcyFT27i1bdLlYtS3oIhZIMozMOl3OUEVX6/12kSkqpm3Sh5tArLzAw16QLKZA32nFoqhqJ4dP47Q9fhaWXXo3vfPMb+NY3vonqykqEIiFUV1di/rx5aG5p1oM3JVBTXQtm+mALiabmFtx252246pprkElncGj/foQCAYAQhKNRTE+MY3jwHJatXof6plYwZryhlCIl9TWUxPD5ATz04Pdw7sw5rF1/SRFynUlMYzaRwPz589CxbCmi0SgKhTzq6+txyYYNaGlpBjMMXN55FULhCIRUMEwT05PjMBnDsuXLcfLUKbz00stYsGAB8oUC8vk8GhobUVFdhUhZOXy+AAzDLFJdAqEQQuEQUrOzSKeSqKqt1Y2wVHjx+ReRSqUwf+EC1DfUo7a2BkpJJBIJ1NbUgDscg0ODcKSEaVkoi0ZRVl4OSgkGzp5FMpnEVdfeCOXkcOTgnmIRXKq+plFG6TbYerZVytuaqzq8Xk4Wq4S5LONythiFZWjGgjtCceFkAkVdeVV4xkVAPpdVyxYvqY61rvjR9ddfP9TV1cV+VvNS4/+2NksIkVuvv3RNTcy3JpfLQ0jFvDkHcX35pII7LUexSSvOJ7y3hPTQCdcuzOtR1Fw6hptmvdqSUqpV04Uoobq7KzdEAopCkBgmnHYcOX4Sd29pwcbr3oOdr76K+//jP1BZWQlfKIDq6kos7ehAY1MTysvLUXBszMwkYBoWKioqEauoQmV1FRiR2PvaLjz44ENoaW1GS2MjDKaVTSbHx1FdU4+mlnlFiFcp7TbFBQfnjveqA+cckxPjeO7ZZ/HKyzvx0Y9+DD6/X8sG2TZy6TSCPj/qa2sQi8URDkXACwWcOnUKjBHMJhLoWLZCu1BJ7XMuhYQjBLgQYIaJBfMX4pmnn8ETTzyB1qYmZLMZtLa0QDoO7HwWMP0gVE+yQRgYNVBWXoG6xgYc6z8MKSQMZrrPCPj+ww9hw7r1uHzTJnR2duL80CAmx8aRmNQ7LstXLEfYpeQkZqYhJYHPsqCkxAt9fVi8aBE2Xn499r78LA4f7QczLaji0huZqxBcM1KiaMkczCvHSjKBy+EibA7AoZQBzDsrwj13FEUjeZBiUHq9rWUxMjk7LQRP03m1gbsAvPbpT3eQ3t63ZQ7SSYE+uaC58qpYxDQy2RynhBjaGBHgJUMpoRQ4L22+UYTvpJIuS5cUexZPwgcAuOCQriGNV1J55u9w0RBvakrcJp5z/TbJ+dpx8EQSdTHgzq6bMTaewN/85X9DKBSG4fOhurIKK5Yvx4KFC9DU3IpoLOaiT2aRP+UUsjiwdy+efeopnD59BomZBC7buBGFfAG+cBDMYHAEx7yOpVBK4uypY7ALNvL5PPK5HOx8HtMzCSSTSVAQGIaBwZFhHD16BNffdAM2dW7W/CTuYGJsBOfPDiCfz8M0LASCIZg+jnAkAs45UskUfH4/4pWVRfqFlAIz0+MYGRpGyh00trTPwx133I7nd/Rh3/79iJRFcfL4CfCjR8EMA2XRMvhDQYQjYQT8ATBmIFJWpstNnw9ccJimD9l8FksWL8bzz/Th5ZdexqlTJ7Hp8k1Yv34d2lvaMDUxidnZWf29GPotPj4+jqHzQwgG/FBEYWRwCN/r7UV7cws2br4eR4/3gwsBKFk8wFJK10hUZw6pd9J1UEh1wS6QV2JRqifquu/QU3jdtNNiINCSUpt6MxQlQRnAmObUOYUcGR8bRHV0/rUAvrB58zYB9PziAbJt6WdUD/rQUBPeoJTmN3m4mwat5t4ApSzdIkm3BJLz0qOGbfWbhblvYkJIcfGpdG4yd8Pmts3g2hqDC2SNepycCmHg3DF88v2r0bBgGbb9yZ8iny+AmRZqK2O4+qrNWLh4CWoaGhAqaaqVFJgcG8WJY0exZ/ce9B8+jHQqDWaYaGpsgs+0wIWDkGXB9PlgmD4ox8H0xBj27XwNx44fL/KNOOdIpfSCFRcc1GAYGRsDdxxcsuEyBEMRZNJJnDt5Evv378XhI0dQHo1iZmYGtY0NoIQgm81ianIS6XQa2XwOa9etR6VhAlBITE1h58sv4cDefeDcwfKODlTV1WLVmjV45aVX8Mqu19DW0oqJsXHYBVuXIJaFYDAIv98PKSXKolGsv/RSNDc3g+oGFsygsB0Hlmmhra0NR48dxez0LB763kPY89oerN+wHqtWrUJdY30xewnBUVVTg1h5DCeOn4Bj23DyNqYmJ/HIjx/FB++6CW0t7Th68gT8fj/gMiK8GZmU0jUfnXMfnTs3bplK3YUpr3QiVD9zd/ZBCUrGBtIdK8whqaoE6SSUghKTDg2ex6KVCzvWrr1sHiHklCszq36RACH07rtFXV1dUNiFddmcgbwtKKUXNuevH4q9gUbiTUGIV3bNkRa93yuCC4aGXvl14dchc9iQEpDUh1nRimNnx1ERVbjlxk786OEfYt++fSjYDmricdxy6y1YvWYdyiurwJiGY7PpWZwfGMCxI/04euQIBs6fRyqd1nwhaqAiHkNDQz38Ph+Y4TFzDUgh8cSPH0dZRRxnT57E4NAwmMEQCIZhWRYkCExfABa0RzpA4TgSmWQKmdkEDh3cjxf6nsPxEycwk5pFWaQMtTU1qKqphGX5ceb0aQwND6MyXoGTZ07j4e9/H5du3IiCbWN4eAgvvfgSzg0MgAB4beerWLJ8OSxfADPT0yjkCijk8iBSs50LmSwooZieSMDhBQiHIxaLAQDOnDiBfKGAles2QCoFRhkcx0FrawuGhoaQzxcQDAYxeG4Qg0ND2LdvHy7bdBlWrF6NisoqcMFh2wUEQiEEgnoRbHxiAtHycpw7P4jT58ex/rKr0H/siMvkdUtlNxMw18PRXTgv7vXM9XBev+FmBdcmm7jWc9qH3u1NiOZokZLzR4pQsFuKQcHyGWRyKiE2BInvqktXLN29+6VTvb1bNcHv5w2Q7m6Qnh6lrr9yeUU4FGzJFwpQAJEuUxPqjWnxQkTH5TgXS645V1jdZ8xFTynhTLjZw0M8iFtmaUIj9UgoyNM6DE1STE9P44PvWYF0Jo9vff0/MZXMoLmhDh//6Iew5pKNiJbHAQCp2QQOH9iPfbt348zpM5ieTsB2OAgjsKgutxYvXoRFixZifHxUs2INE5RROPkCDGZgz959sKX2HzQMH1LTs0imBuAIiUxGkw9rqyrR3FCPpvpGjI+N4MW+Ppw7cwrHjx9H/9GjmE0mNc1fKBw+dBgVFXFwLvDKK6/ALtjI5fNghGL/nn3Ip7NwBMfM7AxGR0aQL+QBQnDg4CG8+sKLqKmthZ3LorqiEvlsDmfPncf54VHkcnmUxcoRi0RhGQzBYBBIpnDgwEE4hQLWrFsHShmkEDANA5QQRCIRLF68CEODQxgfn4Dls6AIcPbMAEaHR3Hk8BFcetlGLF7WgXi8EtlACD6fD0G/Dw7nePKZPgSDAex6bR+2bOxAPB5HKpmCZZolU3M9wxBSFsvl0mm6V4ZRSgGXskIphckMcKn1hAFNgCVzyydzVQUAg5VM470tRQrMpjKKKBvz2quXAHikqqqD/EIlVn9/FwF6EeDOEssAAaSkhFJd+pA3IDgXBIbuFODt2F7AupXqApdWfaNIMRAEFyW1t+5lDIO6VB9Ne+eKImFXYGgqi0jQxIpl83H//d/B8ZOnUd9Yi9/+rY9hw8ZNCEbKwB0bRw7ux8svPI+j/UeRmJlFwbEhQXQDTiiCoQCWLu3AZZs2gSggk8kg4Pe5AcKQz6YQjURQV1+H/Yf6MXBuCI7DkbcdOFz/qq2uQjKVwukzZ3G2thbz2lpQVxnDxPgYxsfGkUqnAKEQMH1QpoVQKATBBQ4f6AeXApxz+N3eIBgIIJ3OYGxiEpQQ5LJZWMxENBgGZQxKAE899Qxqq6uQzedwbnAQo+OTSCTTiMWiaGqoQWI2gxNnzumKnRI01FajuaEBkXAQbS0t4NwGNUztp26Y8Pv9WLhwISpicZw7dx7HT52A5BogcBwHB/YfwPDgEBYfWoS1GzZg2ao18Pl8IACuuMJELp/HQ4/8EATAqqXzsXDhMrz4Uh9M0yqW5UppirpSmhajQC5YndZDxpL+E3CDaU7EAZijnUhX4cZjBftM/bHiqAAaKjYohZ3PEjufRSQYXQoAmzcv/cVQrE93dJBeAGWx6A1BP0hyhgvKDKpcYtgbyytSjNxSqnZpAOlGSv9g1K1BS+V9vLeJEAK2PcdqdZy5BSrDUHBUFMMzFqZSCTTEwjiw8zk8//JOKGri7jtvxYZLNyIYKUMhn8Ozjz+KvmefRWI6gVQ6i3Q2B0c44FyCUWDJ4gW45rrrsG79Bpw8cRwDp84gGonAsCwYlgVGGFLpWczMTKOtrQXzFswHQDE8Moqnn30OO3e9hubmBvzt//xvePW11/DN+7cjmytgf/9RnAn5sWLxYjTW1oA7NoLBEELBqFuLc+TzNqZnZmAYDI2NjairqUVlZSUyuRz27duPdDoLbjsAJMLhCKBCoIyCMgM+auD8+SE8/cLLGJuYhmlQ+H0Wbrp2C+7puh1f/+Z38G/f/B5am5tw3TVbsKXzCgSDAYyPjWtoPJNDuNwHZuogYYxBKoHB4SGsWbcW5fEY+vv7MTs7C4dzGMzExNQUkq++hhPHT2LTmbO45uabUV5ZC0qAG6+/BucGBrB3zz4cP3kKsXiVBm+gACGLLGNd9hjFl50XLITRIotCCeIStt0XK2PFCb3UUBiYaWhbbCkhiS6nDEaLAgVK6FG2InpAKRSQTaUQDlU0ugQq9TagWEBZ2FDcFrAdCYhCcZ/YUxfRO+L6B/fYuqV9CCE6E2AOm3IbdafYVBGXR+NNyIE5kttcqUU1gdGWyMhyTKQ5IDhSGYJX9w0hmVK45dorseW66xGMxpDPZfDg9u/i1RdfQjabx8TkFKZnky5szGEwissv24i77t6KVWvXY2JsBD/+8Y/RVNeAsmgUpruCSg0Lls+PtgULsWL9BpSXlwNQyKbSCPhNHDl2BI7DcejAIQRMA2tXLsPREyeRz9tIJlN46bXdWLdqOaoqKkCh87/DHWQKBaRyeeQ5x6LFC9FQV4uKeBzRaAQVhIL5TOzdsx+njp2CzQvwW36YJoPPZ8FnASOTE3h1916cHxxGZUUMftPAgnktiAZMHNp/AEeOnQAhCuvXrsSnf+deVNfUwB+KgIBgZmYKPr8fhmnBtCwYpj4GdqGAwcHzWLBoIa67/joQAMdPnsD4hGY5+wIWpBCQIoEnHn8S6UwWt3XdhbKKGigJ3HrTNRg7P4bnXj2Jhc0BbSjEBRhlILRE+0zO9ZWUsuKfeagONfRZElJpwqMuYEDhEh+hULC1xTtjFNQ9I4ILUEaghC5eFAAipZvlBUmnkwjFjGpoYyj+tgSIcJwyIQwIqTVVqQuxCSGKtSVcqrlweHHwR9kcWqSzg7u4D+LuKqs5arsL7+ICCvMcBV5IAcE9XSWGpIggLyj8lh+OIjiTKseS+Rbec+Nm1Da1IZ/LoPf+b+KVF16CY3MMjY5jajYJLgUYBariMdx++3tw8223o66hGenZWdz/jW9g6Pwgmuoa9ENlBgzLQjAYQDgURC0zQF1i4vjYCDIzCXQsWYRVy5fizMAQHn/mOcTLgqBSoKW2GmNT05hJzqJgC7z42m60N7eguaUJSul1Y3/Ah8b6ej2faWxEKjULwhhq6xuhCOALBOAUbDj5AianJlGwCyCGRqeGRkbw2v4DyOZtmJaFUMCHxtpqRINBnDlzFidPD2BobByxsihWLluKfCaDoaFBzFu8DKblQ1Vtg4ssMRimBcMyi6RCy/LhxRdfwuVXXoEt114NR3FkshkIBSRmEsgbFsJBXfa80PccKAVuu/t9CJfH0drShptv3IS//8+9MINxmL5y2LlpaAIDuVDSicxRTDz4F9BkVSkkBBQY1W2sdBfqvBkYK5m4KyXguGu8nvicN6X3BAaJfuGSfD6LoOD1iLUHCSGz+Bn8T35igGzeBokeIGc7S6UyQRmIN7n0QCXBRbHZgjur0Aefuv3FXMMEpXlDXnnloRWOw4uZwpP68ZCyIi3aVbJQSoArA+mCiXQ6CylsKFAEfQrvvX49FqxYAyUFHvj2t/Fi3/MgoBgcGcHE9AyoYcIyKFqbGnH33XfhmhtuQihajkIugwe++23s3bUHls+CbduwHcfj8miRhSKConF9RghOHDsBzjluuPZqPPrE05iZTSGbyYESCTtvIzGbRr7ggBKKgu1gdHICv/2pT2DlimUYGR5Beawc8coqBPx+FPI5HDuahc05Kqqr9WYmIaiuqsLCxQuxGAsRCvjR2NyEWCyOf/jyP2FyehbhUBBcUqQyHOOTs5iZzcMwjSIN43d/55NYs3o1Xnz+Ray9ZF3JGI2AUv3omWG4g0gBqRQikTCOHDuOZ55+Fnfc9V5cf8P1EEJg56u7EAqGMZWYhmPboFAIBUN45qlnEK+qwpbrb0a0ohorOxZhWdsRDEzl0BIog5ObBAEtsrg9pIl5elre4hTRbF/qLl5RV/5HSQWumfCgjIK4rGCPPs8oAWX694J7C3ueyqkWhaDu2bJtG6GAn2+4ZKPa+djpn2kj9CdnkG36P5bBNOpSFGlTRREFnSk8aR5VIsXjFHclvB2J4tTcXXz6/5P33+F2Xdd5Lv7OOddau569Ty/oAFEIkGBvEiWCRSxqlmUZlCxXuduJnOuSOPndOCDixLac2HLkKtqWbTVbhHqlSEoiKFEUC9gBEL2funtdbc55/1hrH4Cyk6jaN797HlEPH5TDc/bZY805xvi+90Nb4tS/nhyVLHOwEmm7XZ5YkG7nlTCE1qPeU4RBC0dZ/MBwzdYc2y/dwtDENF/+wuf5ykMPkcvmmF9YZKFWQymHfMbhoovWs/OHfohX3nILhdIwOoq4/zOf5tGvfpUgCpCug9GaIAwuePHENw0fIF8o4noulcVFxkdHeetb3sxzL+znwOEj1Gp1jBUUhkpMOQpHKRqNJlIK1q9bx9joCAjYtGUbruvR6bQTiXs2S7ffR0iFl83iehkcz6NULlHI58gqBUYzMTnGyhUrEt7vqlUYK8jmskRhQLvXJysEa1fO8Eu/9DNcfeXlPLL36wRhyFCpDMsmrwv2BGnfF8cxFouX8QD4xqNf58qrr2LDxs3c+dpktPq1rz+GchyanS6QgCgcKfn8Jz/Npk1bWLlmNY3KODdfu46/+dxRtCpidIgxHli7rLWSUqQykNRPLiRGW5QjcByVaPlsgnESQiY4JqPRcdL7hunOTEiDsQopxfL7xUElokhzfq9irE0UHclDWYyOjX5vHYU25acKAVJYojAmiiwJFk4ghFl+o58nmdgLAAws43sGMg0TG7Q9b1tNphuDIxh0nC4LnUTNaTBIK/FNhl5kcZWDUJK81+MVl61ixZZLOHP8BJ/62MdwlUO73WWuUkEbKGQ9Lt12MW9721u55pU3kskViAKfj37kw3ziYx+nNDREFEWUPZdYJ269OE4g2wmx5OUvk5fJMDYxwdmzZzFhgOO43P2WNzE7O8dLh48lPUanS7W2xLVXXc3f79lDs9ni8a8/ihCvYN3GzWSyeay1FIfKyQQml6XebBIEPl42g0njAhzXoZDPMzIyDNbw9a99nePHjlPM57j1phuJdEzf7zM1OYUUgpHRETasXUuhmOdrX3uMdq/LlZdfzsjYaOLv/ia19YA4E8ch1sS4joujFK1Wi89+6lP84r/5N6xev4E3velNuI7D5774II7n0Ox0yOXyTI6OUKnW2PP3/8C/+fe/QWlsBRs3rmfV+AnCMIfFTTfq540K+gI3qSMlUgkclSwPtbZEWiMwuE4iLjUkN48UR7fsE0lUvIOd2aBfTQibApBWEsUWlUYtDLR7te+l5bYXREJbCSJZ8g9Gr1KKZVPTeaKevKAwxD/yoafrk2VNzoB7JZLSThWdIi1ESaxZ3p/E1hJGPh0j8UOTAB4iWDvhse3SLeSGxvjCh/6CdrNFNpdndmmRdreH4zhsWLeKH337j3DNK2/EyeSI45CPfPiDfOAD7+fyyy4nDkNm5+cRCPq9Ph3Xo9Nu4/d7ZPo5crlC0kymAOY4jphesYJatcrpEyfp9bocOnSIbCbLujWrsDa5E4+OjRDHETe/6ga6rSb5bIbLr7yGfAplGDxMcvkCpXKZdquF1hq/16PTadHv98i6LoVikeHRUSYmp6jWmkgJN15/LeXSENdddy1ff+wxut0uhUKBfrfHgYMvEUYh2UyWiy5az8pVq/C8bPpwsss/GyEEVmt0HOOHIVEYk83lMBYc1+OpJ5/ia3sf5rY7X8/06rW8/o1voFpr8o3Hv0EgJUvVKvlsYr566skneerrj3HdK17J5MxKNq+d4KVjCyjP+0cmOpuObh1H4giJHtgd4igpBKkQqJTbm2zeE+xD8nMn1WglbxuLk2wFSUPul+df2uoEJijBxBalHOLYcvTxI+c9vN9xgdwD7Abfj/wwUARBiEw5RkLI5d5gMK1K9iM6nUJ9E8wtXeokV6cLx7rJ0WqtQbnnf3hJUenk7moTaYpNZR1hqAgjjbGaIAy5aMUYq9dt4OTxkzz91FPkc3lqzSZLtQbGwoqJcXbufAvbr7kaJ5MDLF/47Ke57yP/wI6bb2bDuvXs+chHyOcKGGMJAp92W1KtVBkdH8dxHOIowvU8pEru0kHgE4UBYyMj1KtVaqfrVBsN+n6fKAyZmppi2yWXMjExjhQi+Zy1BbZddS35Yimxnl7gaVdKMTI6lsjEhaDXadPrdomiiEIuTyFfIF8oojI5Lr3icq49sJ/52Tm2b9/Ohos2MDw6whOPP8n+/S8QBBHFoSLl4TIT4+MU84XzJEutkYmBfFnfFsZBAqILfKyFXD7PUKmE1dALfL7wmc9y5ZVXMzo5zdSq1bzt7rdQq1Y4cvIUraBFpV5naChRE3z2M5/jymuvZWRyBZs2zHBqrk234SFt8DL/uFJq+T0Tp+Y6rZNTIZGGDNAMKTYqZR1IkfD7X2a2Sq+xhnSRaBIaoxDnt/GkhJVMNku379va0fvtt4oV/Z9iOe6552EJkPGyB7W2WG0t0kFItewK0zpZcJ2nH5I2tOJlBqnB7w98IoP5t5QW5YByL1RyJsrfOEp4WckUy2JTWX1fJ02vsRalNOtXlCmUx/jaI3vpdRL420KlRhjFDOWyvP6uO7j+FTeSK5YB2PulB/nUJz7Bm970Jt761reyd+8jWAvZbI4gDOl2e3S7XRYWFliaX6BeqVCvLFJbWqC+tEijWqFZrVGrVDh79izVapVmq83C/ALNap1169Zx5113ccMrb+SSK66kNDqKH8WgVBpw80//YDK5HKOjY2ANoe+jozhpWqVM9EomuUeXhkdYu3Y1bsajVquTyxfYeul23vLWu7n7bW9jfHyMSqXC/MIC1WqVSqVKu9XC9/v4/W56lUpe/zDw8Xvd5Pf7QYpKDXG9DMMpp/jAiwf47Kc+lUo28qzbtJGdO3+YQjZLPp+j3mrRaHUYKpU5euQwLz7/POXxKVbOjDNSLmDxMCmpZfAwHQDlMIOUKZDKJnQTOfB52DQ2YXDt0Mt8zoFJSkqFFYIoXbQOZEsixR8NAHVCCByJyReKeF7mCNBJw1vtd33Fiq3t23ScNljwLE8jBmrceICLPO8FSTanevk4XwbAxcmvOY7AXGDBNCZKxrhGpJIDmZ6A55XB1kBs3OQ4FYrhfMyKFWPUmx2effppspkMzU6beqtNLpvhlddeyU07bmJ0YgopJIcOvsBDDzzAW9/2Nl796pv4oz/6Iw4fPsT05FRyl9WGTq+PlIqlpSXyxQJBFJLPJwzdhB+l6bY7VCoVTp0+zfzcPPV6HUcpbtqxg9tf9zpGJyaXJ4hBEGCwhFqmyoJ/XCI2RZRG2qDjkDiKsNosu++0iRMckDGYWDM8Nk6+OESn16XeqDMyNcXI5BSvnlnF5OQ07/2LP2dufo7ZtE/LZDLkCwmVMY4CXCcDQhD4Pu1anaWFJaJYo2JDo9EgjELyuTyrV65kYW6OBx58gFe+6kY2br0U4+W44uoree0dt/Hhj34cjWWpWqU8VEJYyVcf3ssV2y9hZGyCseE8p61MLLODXcfAOy5YRvYkY1l5QeaLXt6rmVSN4TrpqSKSi1ayO7sA+bSM/jHLAsYBo8ukvXA2m2Op0fLTl1x+TwrED40WIplCRFGUzs/leSPLBXjN5DRJnvoyHbEtY3lIqll6alkJnDwY7DLXFpXuTZabrfMGqsE42Y9Sp6GGoZxlbGKcEydOsriwQLFQZKlaxe8HbF63hjtuv5VV6zcgXZdatcJzzzzN297+I2zZto173/tevvzgg+Sz2cTTEYcopej7IUr2qVarOJ5HECTivUzGw3FcgiCg2WyytFRhfn6ORr1Br+9z2eXbufXOOxmdmCKKIsIoxOiIoaEhhool6tUqlaUF1ly0+R8dIcKK5QeCSTfDQiWAZp2ahgZQijgK6LRbhFFIoVjEGJP0SrkCQki2bL+c17/xDfztX/01rVYbd34BVzlkvQwSQWGoiOO4WGvp93osLS5SqVZxlKLT71Ft1AmDgCAMKJdGufaG63nggQf40oMPctGWrUjl4OUK3HHXHTz3wgs88czz1NtNOt02+UKBlw4cZHGpQrk8wlDeQ0iFjUFbkxSETbxEpFggIZPN+WAKJa1IJ6MMYtqSftMOYhbO97JGnBfCSpIBkrbnr2ADRpc1FuU6NpcvEvTlkcQIeI8cdCzfoRYrybHu9+O9rR6/bqJYJNgW0rGauaDRfPn9cqDetHoA9kq0VDadZsgLbJRaa6IoWtZeJWYYu6zHSlS/GkyMwSW0gtjoRH6RVRTyRZ45eJQ4jgnCiHqzSy6f4VXXXcXmi7dSGBkljkJOnTjKjTfdxPDwCH/8h+/mwS8+gOdlcFIOb5QuB2Md0/cDPFextLRIEPrkc3mUI0EqoiCg3/NpNBo0m038vo/nOlx2xRVMTK+g1WrQbjawRqNcB9d1kgeF0YmK9Z9AaFkGEQ/6ggfKeQHfgOiijUUqRb/v02g0mZqcQghBv5+IGh3lkC+UuOFVr+Zrj3yVw4cO0el0qCxVOO64xHHM5OQkrpuQEPt+n6VKhV6ng5vxqCzUaLd7RHEyODly5Cg/+Y6f4siRIzzxxBO8eW6OyZWrwHEZnZjktltu5vDR41QbbaqNBqtnZqjXqhw5cpRLN64hl00cjTqS53dygmWnYPIAlckS+YKx83k9FSm8IdmmxwOTlEkk8ViBFElTr0h2JEZcIKIVMkm7MpqRoSyuV6DaqB9LrLLf5RRrEPDes8UXYxNbZaWSUqWMhOQLiJe5qun0SYKSKsHNpE7AhOadbM9NejoIBsiHpACy2ezL1LuD++TgNFJSoK2i2zM2CrUwRhOFPhnHQxs4duwYruMkTN2+z7WXbuaqK7dTGp9ASUW90WDzli2EYcgfvOv3eeyrj1LI5xGOApMsnqw2SZ8jJH7cp1zMEfgBTdOk3+mlW3S7DG3r9/uYOOHRDpWHuHjrVnrdFqePH8Najes6FEvDuK5HLptlamKC4fLwPwmZM0YT62gZwC3Sh4OSMiHN63iZGCOVw/qNm3hh/0EM4GY8ojAkDJPeotVosHrdOq6+9lqOHj6CjjT9Xp9KrYrBUm82ll/vKIrpdhJQXRBGzC8sorVOwoKMod1sc/LECd75znfyW//xP/Lss09zx8pVICRONsf2y7azdfNFPPHsi7T73XSvpTl48CBXbNuSGKpkspd4OcxDLme5LMtOxGBSNaBKqqRXGshNJCiTqnzT5lulWFpjINLR8nBIXQjSSCmO4yNl4WvFidn68wBL363ldvfu3Rbg6NmznY1j482SUiOxNWlAzQVampSpa4xBRxaIE31MqqWKo/NLv0HvspxKZOLlaZbjqOUJGBf8v+u69PqG2aWWrtQj1SmESJEHa8jnMrS6PebnFxBCslSt4yjBDVdexsq168mXRhKzUHmYWq3CX/zxe3j80UcZKg0lJ4cxqefDIQzbCCxuJku302Z8rIyDRxzGxJFmMCFdHjAIheu6hGHIypWrGBku88xTT9LrdRkaKlEeLjFULuO6GUZGR4l6XYbK5X+SxjiYMCVviOQ1ch0Hz3HphX2UoxLNlEpOo7Hxce68805iHVMoJBFv/V4Ha6FZqyCxXHJJIjnvdrroWOP3fZqNJmEQ4LpeKs1InuiFfI7Tp88yOztPqVhAeoYosORyOR584AHuuOtO3vKWt/Clhx7k1tvvxPEyCOUyPDbO9ddezaGjx6g2OnR7PbKZLCeOnyCIIzKZLI1mjO0YXSw7wnW1HEjQL3w/8HK3T2qXNSmOVi5zmpeXt/ICDttywljSl7gpsG4AUidZStqJ8WlVaYa9Rx8/sh9gZ5Jp+F3R3e199+1U+/btq2jh7XU9j1hHJopTQFm61VRK4XkerufiOM4y3e7CCVeyiIqXKYOO4yzDwGza2wRBeD5NShtCnSwS55Z8Dh6r6EpTq57ItiJsZNKTJeN51OsN+p0uQRix1GiwfsUMV1x+KcWRMTw3i5SSdqvB37//73jy8ccpFIsJh1YqPNdjqDiE52SSCAVhyXguXT8gimNcVyUZ7TomjuIE3KwN1jgomcVzsziOy5pVqzl06DDP7HsaISSu5zIxOU2pNEo+V2Dz1m3EBnK5wjc16eI8qFvrVJ6QvC5OCqUzJrn6ZXL59PXNEIYRF228iGtueAWjk9OUR0ZRaX8URzFPPf44+UyW9RvWL7+J4jDC9326vWRK1+326PcTD0ur2eTw4aP0+j6hHySFlE4K2802H/voR/mZn/9Zsm6GQ/tfWP7as7kC27ZtZdP69Qig2e6SyWZZXFikUW/iuS7G8XTXeKpWj2S7K4yQClcJlDxP+BcMbLdcQD4xiS134GlPdXyJKSnRa4VRAh5USiZXWZGoMyIdExmNlQIrJFlHmhUzK2n29f4XXth71lo7CL767uIP9u9fFAD1dviYFQ42tjZBzifOtTiO8QOfft+n3/MJw+DljXqK57xQ5RtFyQ8qimO0TgrMcdQF6M6EVO4oxZnFPsfPtLRxCirMlj8e5zPbjZUHPc9FSmkcx6Pd7mCMpt3r0+91ufKSi5leuRKvWEg0OqHPF7/wOR7Z+zCu6+I53nJxlIpFMl4m5cWC5zpYYTBaJk/arEqaZWMT1pPRCbAciRIujswyVBjCy2b45Gc+Q6PeYLhQZHrFSsYmppeXUceOHU8ciOlG/mU4Vq0JfJ8wCIjiJDNFWIujFGEYJqeJ5+G4HjbdnfS6Xb7y5a8kX7OXoVgqMz45hee5dJpNXnjuBQ4fOszUxCTKUcvi0iiKiYJo2U8fRUn/Nzu7wFKlRjHr0e/5VJcaZByHjOuRyWZ4+Etf5tiRo/zoT/44J48dT/GyAieTZXJqhssvvYRiLkun08FYBvkiOuNlUd7Q/TZf+JHAyZ/r+lI2mrGJ0hNiIAfhgqbapNeqwQrDJtnQyZ8fDIZStKqwEGkIQo3VBlfKZJeUIldBoGPNUCFj8yNj1JvRQwAP33PPt4zc/V/jyXffbADOds3nu7HUynGU46jEz6ySK4bjOMsTrQEEYeDyutAzkhSKumDLnlwxklCdeFlMFgSJ/2GxFnBuvquzxYLqidzff+nrT73l0Uf3nTZGH0zZSEZKSafdJtaaSr1BMZ9j25aNFMojZLNFAJ5/5mke+PwXMJEmm8nhOk4y9sznybhZ+r2IVqdLbCMy2SyrVq/EcxWtZpdYR7iecx52ZlNt1jL8TpPL5Tl5+hwvvHAQRzmMTUwwObXiZXDrD3/wQ5w9c5Z+r7N8xVz+R1j67Rb9Xi/N/vAxsabTSWLXMp7H+NgY+WJ5eXq4tLTEBz/4Qebn55Zz+4qlYSanprHA7Owc+57ah46Txt0OdlFxjI7iZUypsYZuu0mtWkNrzcz0JEJCp9cH7TCUL1DIFfD7fd77J3/GzMwMay9aR7vZSMSASpEtFLj44k3MTE0k5Ho/+frbrbY1EnRs/L2PP/MP3TC7Ixbu8SgWst7CGNxUwKiXkU423ZVjJVKo85O9lMiZ5oYny+WUwjgQz2qTMJ2TRbRdHiZZa1gxMSk7cZZjs5XPAfzZt9h//G/HvLvZbXbtQu7e/eCLl/7Ua58sKXFDr+9rN6GALT8F41hf4DvWy04wq5NFj0lzCGV6MiSTLHu+qVLyAsGZpe9bTsy2tZfNya51n/vyN7I/sWPHTc7evXuNUu7RwRgsNpp2u4sfRFQqdTauXcmKmWncXBEvk6VWmeeLX/gC1Uo1TWdy8DyPbCaD43h0Oz61eoNas05sNROTE9x+++2cO7vImVPnqC42mZwcQwiVBIOm0oZ0NEKkQ+Iwpnn8NBLBJZduY2btWlzXu0DsaDl75jRDuTz1SoUgjlmaW2CpspQAE1QyadEmaf51egIvLiyyMDdHsVik3Wyw+dLtbNq6jUw2z+zsLPVGI4kGSFsZKSXl4XG2bNvGzONPcvjoMbr97rK/xmIxWhMLgUoTpeIwpNdqUW+0KBeLvOKGG3jwoS+zuFCj3w/JF3Lk81mGhsoc2H+Aj+35KD/20z9Jvx8tU2mUl2VyappNGzbwxLMv0Ol0yHmKWq0uMo5DqOPMzp071Z49e45t3rz5zWvKmUcI/KF+4NpCRiYDnwsBcNai0Qgjlwdfg7W3koO5rk1hEAKhUmavEFjO55AMSI4Ca1av3SDbHfPSe//6vY+nsAb9PSmQC9E/LV/93eR46YYgCBLu7gURW8tGmPRcPE8uOY+xN9aihFkulAvv3+l3mKh6HclSo4eJtaBQEO1I/CrsjWFHFvBRXi9BxRj8MKbXj+h2ezTaLdatuZbyyDBOJoPWEU8//jgHDuxPHXMOrqPIZjyU8ui0fSrVCou1JVCJ1/2OO+5k85YtTEyOc+bsHOfOLjHkZXAyOUJt0sJIvk5tDX4c0e1FNFsdNqxZyVXXXE02Vzy/2EyLRCnJ0ROnOHX8FEePPcTRo8doptIUozWl4hClUgmpJH7fp9tu0+l08KOQQqHAyRMnefgrj3DR5k285YffwnPPPU8/SH7vQtqLcBxWrFnHNddcwwc//JHU3KRxXHk+C9JYYmlQ2uK3feYXqoRhxMzMBGvWrObSSy/h0OFjLNaX8DyPoXKOkbIhjEK+8PnP88pX3cjmSy5Pr9ACx3HJ5QpsWLcGLDSaTbITo3R7fZz8EFaI/J49e/Q777or88f33//85FWX/MVoPvub3U4/zrrKEUZjLxx/X+AxWs5JEQP1uEkhczbNdEtHvctEeZYbfGwieC0XsmZser187nT3I0D88MP3ON+qWepbimDbvXuvBnjxyNynmr5qSSGkNsZeCGsYNOQXBm0qqXAdJ/VyJMb75cKwyekzoJFjB8lQliCyLDV6ujhUlEZ4X33iiSe+smvXLgk3xwDC6KJMzCnEMQS+T6VWJwr7bFy7ilxhCKkUi+fO8cRjj9Pr9HAdFyUlnuvhKpd+L6JabzJXWcA3mm6/x9q1a7jpllsQjsNQMcdQMUej0+XcmQV0GCRUciNSbVgSBxdpS6ffo9VqceWVVzK9YuU/inQAuOqqq3jm+Rf42qPfoFFtsLhU4dTZWYbKI6xYuWr52rS4sES33cH3A7xcjrXr17Nq1Rpml6pU6nUqC4t85hOf4qMf+wQ333xzEmpjz6duYS1uNse2y7ZTLBRoNprLcuyX6+Y0JopYWqoxv1BlqFjA932Uo7jztXeRKeSodxvMLc7Ta2sKmQLjo2N0uz3u++CHCXud85HMUqIch5npGcqFPJV6HUjG0z0/wtrkIfx8v68BUe2bvzZS+SCUHwsrZJoWNfATkQbLpON3daHaNy0IIZJdm1Rime65jIoikTtJ5RDHhg3r1qqmr8IvP/HSB5MFId9W8u23kt9m77tvp/rqvn1z9b74ZLYwLEwcaQaGeEcl9lTHuUDm/o8pJ8nTRuE6ahk7ucxiXQbGWbr9CB1Z62WHMErsAcTDDz+8/HUqx+sm2TCKKLb0+n0qzRYjpTJrVs7gZnPoWHNo/36OHT2GSHMyHMfBdV38QNNoNFioztOPQ4wx9Lpd3vrWuykMlchmsoyUSzgSvIzLqWqDpfkqShuko1DKSfspBzfjIoQkn/W4eMtmpJtJ78riZf76H/qhH+KiDet434c/yLMHDvLxz32O+x/+Ch//zGfQxjI8NoqbyxHomF4YgusyPDzCyOgon/7iF/n45z/Hns98lgPHjvOXf/d+Zlas4ud+9ueIoui8vWDgALWWsYkJVq9ZTRgEiUXX9cikk0apBI6xdFpdzs4vEGJwPJdWu41wXbZedhkXb96CHwRU2xUzX1mg103MUWPDI+zbt4/HvvbVl2N2HMX42DDTk+MsVpfo9fuEYUin28cKpRNIws1mF4iDBw8e0cZ5JpNVQofWiHSAo1KnoJOuCJbfS8ZidWqiUhea8uzyYNgM8mMSyUEiQTGaYs7V6zddIs4str74mc/sOWqt/bajob+lgMP9+/dYQBw6u/TbrcgJhZQyCAIbhFEqKDy/ER9YcbVJDVHGEmubTEzipF+J4vhlOxGZ+oqNMTQ7AY7rKCMFfeM9Dtibb755+ZvScdgfPCl6oabX7RBGMD46zshwGVyHbrvNsWPHaHc7y1QL1/GwRtBp91msLtLpd1COx7mz53j1q17BK2+8MZ2cJHP1bMZltFxEOJIzlRqdVhcTRjSaTSrVKku1JdqtFmEQMDE2xsoVM4kdwGosSZCo73dp1JYol8v8zV//JZs3b+TDH9tDq9NBeS5zi4vsP/QS+VyOfDbLULFIoVggX8gzMjLCydOnefHwIZzUp/Lxz3yGkckp3nvvnzFUzCXj5zhMtvTp1UJaQz6TZdWqVUTGslCpcvbcLHMLi8wuLFKt1ug3W8wtLNH2QybHRxHCJPR7Y1Fuhltv3YFyHAJj5Hxt3iwsVdCBoFwugxQ89MCDdOuVZf2TlIpsPsea1Svo93q0Om2w1nb9CNfJLKWMZ/nwjh0SEKGV+zKuByZJRJfim1ZDySx3mWbysiRca9K9mz6PCRLyAsKUSC0JhnWrV4tQjpjnTy39DsCeu+/+thNvv6UC2b0bs3PnTvnA3m8crbbNHxaHRqUUVg/stIPI32X/+ECLNdj+puREo81y0KQQ4oLohPMoe20MjusKjdC+HzYGX8DycinqCysErufQ6fWpNnykW2L1yhmyXgZroF6tcurUabQ2KSjZSXVWAZX6EvVWEzeTED7Gx0d505t+gFw+jxAQ9H063Q7lcomtWzYxOjxEYA1nlypUl5boddv4sU/f71Gr1pifnWNpaZH77/8CLz73HP12m6DbIex3aVSWqFeWmD17Bqsj/tvv/Ff+4F2/y003voKxUgmAYydOnHfnpadcxnPxPI8Tp06DhWI+z2vveA2//zu/zT3/97+n26jTqjcIOl38djMB6UUB6IjZ06f51Mc/wVNPP8V8dZGlxQqxMSCTN5EJAmYXayy120xMjJLPZVizZg2u4+D3fQCuvPJyNq5bE/thdMwoI88unTG1eoeMyjM9Mcmhlw7xja9/HSFSZS4C5bjMTE/iOhla3Q5xFNP1I5TrBIOf3eTkpAVsFAePSZkY1e2FRMULCk4KucwrSDOPB+brRNErVGqgShRagw26VAITWwoZqS++5Co5Xwvu+6u/+qtv3Hfffd9RkOe3nFG4Z88es2vXLnnvvff+9o/eftnbi/n86p4fGCmFTJpwk0hMJMvcrAH6XroSoRNZQTLGBcdN434jTUScvkkUcRRbx8kJlNM41+5Vk2kadkcqngniiGwYII1mrhpjAodieYpVK6ZRjoeODXOzs1SWFpMwyNRbrrWm2Wqz1KjiZD1836fTbvLrv/JLbN9+GblCMVXfJpKNbDbL2jVrOHLyNGGkWWgmhqeVM1Noz8FaQaRjysM1bnrVK9m8ZQt79nyUft/nx370bZw9e45VK1YShUHiLqxUqNZrrF21gl//lXdy6swZ/vZDH+L5516g2+uTyWUSgaMx5LI5/DBg37PP8prbbuU3f+PXCYM+Z06c5OknnmDrxRfjCEkYhOR7OfY9+STbLt3Oxz/5Sc6cO8dtt9zGD/7Am2jVW+RzebK5bBKTDDSWqpxsdSkPl8koycTkJCtWrOT0qdNEYSJ0Xb9xo77jtptFp9/7H+cWFn9QYW89M39OFwt5NTw8SrvT5f7P3891N1xPvjiU+FuUw2i5RHl4nF4/Jowjer7EdQcJAjcz4OFKRxyz0iIk8rzylmWPzDerxcVAJo9ZZvEmQt1Uzi4v7LEMRmu77fLL6cqR8OvP7t9lrRX33HPPtx3g+W0VCGAPHDgg5+bmenPty375orGxz5reGW2skiKN+xLiApeWSIRog/zswRZ6EOsc60TXFIURjqPIpGQN0mmEULI4XhKlWaheKFwSVsuBs0xbBe4QmWxMIVvACkkQRSwuLNDr9ZBCLG/4+72Qar2ONonv+tjBg+x88w/wgz/wekZGRpBSoXVEo16l2Wgu84J9v4+nJMMjw5yr18kqh7GVU8nkRToMl4ZYs2olt732tdx0223Mzy9Sr1b48pce5o47b2fPR/6Bq668itnZ2QTZmc1i0vv2b7zznfz27/93Pvm5z/LmN7ye0tAQUghiY/js/fezafMm/u/f/Hc8/JUvc/rkSbKZRHkslaJSr/Po17/Gb/zGv+XzX/wiazZs4I0/+EMMD5fJ54ucPLif4VIp5UclfUe31uLk3AJO3mOsXOLM3Dm2X3YZnusAhlqtiokjlJcTr7rp1fLQkSO/furc0mula+5v9eqr5peWzFBpjZyamODUyZPse/JJbr79NQiSUfJwqUQ+X8YPuvj9Pr3QRVrdH5THAXYCe7CGEVdKNMZKIZeDmEh1aOd5zue5z1JciBgV5xPLTBrDlmr7jNZMTo7ozdte4Tx1rPF7H/jIBw6/8S1vVLt37/7+x0Dv2bNHp5nTn/uFnXd9ZMXw9Fsri2fijJdzLGZZg6djQ2yixJp7gXtwsFVPJAHJCDSTSXRBiKQZc1xH+LG2pYyXmSypKeDErl27ePjhh1PZRLdjbUrRHkS6SQfluoSRJuj3aDSaRFEEQuCq5Gnf7HRodFtkcjlOnznD5PQ4P/+zP002VyBfSkSEcRCyOD/P4uIi4xPjVCsVGs0GDh4rV6/kULvN/rOnmei1yeWzIAU9P+Tpp55iZnKUmbXrmJmZZmpijHt++x4W5ua49dZbicOQVquJ47hkc3kWlxap1WpUlirs/k//N//5v/wuH9rzMW645hqwmmcPHGRkdIR/+2v/Fx/6u7+j1mwwOjLC2NgY9VqdxcVFLr54Czt/eCfFfIF3/d7vEafj8zAIOPHSC3zxC/dzbmGBKIpBa0SsExCd67BmcoJOp0vfD/ADnzj16MzOzRL6PbJFT27YvEnfcMP1a5vt7o98/qGHfmL1zMzD87V5PTUxyshIFukovvH1b3DDK16RxlTEFPJZhstDLCxFHD4xi8lKJiZHnx4cIIsPJ8qMXCZ7V9bVhFIOHCLLAsMLcbMXoJqXT5QBESeJ0kijMrTFSIWQlqzn6OuueZUz2zDP/oePfeI/W2ulEMLwHX443+5fuHvPHmN37ZKbPvShn3/DDVuvHBue2txoL2mlPKXjOFFWpgIypVSSbW0scWq8Vya5C1sBSay6uABrb5NxXqR1Puc6Rd9eCTz+8MMPy717bzawlyiIH5HZME7StbFCCuG6Lq7rEYYxnU6XTqeD1gZHOTjKIQxDGs0mUkl6fp+FhTn+3b/9VdatXUeuNITjJqdXp9Pi4MGDdDodhoaGOHr0CEGnT1d3mZgcZe3UBGEUYWNNRjhIx6EvI5598UXmFuY4fuYMb3z9axkfG0MKwepVqwj8AGM0GzZsII417XbiO3ccl/mFRR66/wH+27t+jz+79y/5+Oc/jzWGu+66g1/7lX/NfR/+e5ZqFYqFIUQaEzE+MUEul6XVbKEch1qtxpP7nqQ8PEyjVuf9H/57tl18Mf1OB2EFhUyOjBC0O23ypQJD5TJCGJZqFYyOqVQWKZeKCCFYWlikXq0yUxzGzRbUdddfGy/ML/zW088991Rs9AddKX9sfmFJl0ur1XBpiMOHD3PqxElmVs2gjaWQz7Nu1Qznqj77Di1yycXTmKhlB/LytAchn3PXC6FRjkxNT4Y4lfoLIVAMcgjtMjJqYJ01Vqcb9WTci4yTRa4BwtBeedUrIb+2//hTz/yYOHAgvOeee74lY9R31aR/81Xrnt27OXr0aOuZo0uv76iRueHhUSVMpB1XoZTAcxWuIxHGvAzklXgvklGkMTaRwacj3lgboliTdQUSIxxh8Bz5+vNTrERdnMkMLcZx0IviQGgdJx4KBFK6hGGUSDZ8H200Kh3L9vo+3X4fpRzOnjvLhg3reP3tt6M8h0KpvGxXPHPyBIcOvkSsNY1anWqlStTrMjU6wmVbtzA+XGJ6fJTpiTHynoMb+Ix7GW667nr+43/8j/zBu/87O265mVarRaVa5cy5s3zhgS+Ckpw6dYpnnnkmIcREEXEU43ku83PzfPXLX+KP//C/MzRUoFjM8Yf/7V08+Y1vMDc/RyaTwRqTnATAgZcOUq3VCMKAPR//KM12i1OnT9Pz+2y/6gp+49/9Br91zy5e85rXkFeCIgZXGsrDQ4yODTM8VOCK7ZcyPFTA9PsszS0wPzsHQKVSZfbsmeTlEJLRySl5+2232ptfdePvP/v8C39kFX6tWRXdTkCpOESv1+PFF19cJvc7nsf46CihlkTkpBCg4/hYUh8Ps2fPHs3oaCnrcENCwLcq1vHLXIE2jeeL40FAzqD5lkmvkTQrpP4pBCrdgfr20u3b9fSGK9WjTx/8V3/2V+/f/5927XK+3bHu96JA2A1m586dau83vnH08ZfOvCGQY9VCaUwFfhhrbYijhJ/qupJsRuG5MrVcnn9KuK5CeRLlShzXSYR8AjJK4LpSxqFPPuPdcsMNN6zcvXu32blzpwQIw4a2NpG9mmRAnsZ6OQRRRLfXXfZGOMpJRsfNFrExdHs96rUad95+G+NjY2Sy2eVYhG67xbP7nmZpaSmFQ4TYbg/R6TM1McamLRvp+D3arSbFXBbpCGqL85x87hnifod6fYnpsTGmxya46VWvZsdNNzFSGuanf/wncJFMT8+wffv2pHh1okHSxpAr5Jidm+X0iZMMl4cZyhc49MKLnDx5EjebTT36yVWy2+2y6aKNrF6xkrHRUd75y/8aE2ne+sN384rrb2D1qlVs37qVA888w8FnnmHu8FEqJ08R+yHZXB7fD9Fas3nzRkaHijhBSNDtUq/Xk9ep1ebE8WNYnYgkvVxBjk2Om9tvu2XLdVddvrbn9/42wJfVWk07MoPnuRw+dDj1sxusUMgUPJFxXWF0SGm4MA+wZcsWAYgb16++Ku/JiVBHxnHEy/qPZU7XAEVr0xi+dGsvU4RpsjhL4dZYhNbmkk2XmI3bXu08c3j+1999771/85WkOGK+yw/nO/2Le/bs0anG5mnP826/ZuPU50bG1Mzc/LlYSldlPCls2lAh0oWSGfjSLUbHy8coViCVSrMgBLmMEL7fjscmx/OjraF3AP9lZGREAnpp6Vg4s25FIFQOYeIED2RjQgNGR/T6mjh92iql0FFMs9MCR1Ct1JkYH+Pqyy4nNprsQH5uDccOH+KpJ54kCEOGy2Vsq0u/2UZEMdNTE+QLBUysaXRbFLJ5bBDgN1scmTtH/ol95EdH2ffCc5SLQ2zdejFHjh1j27ZtnDpxgmwui+dmaLfb9Pt9oijRWw3YTsZYZs+cwVWKlu9zYP/+1GWZmIgGvv0ojInCACEF+1/cT7vT5dbbbuGP/scfseOmHVSqFZ544glKxSGeeGIfR+bOsbZYInYcyhkXP/CJ4gyFQp6R4WG8KMbp9onDEByJH4QcOniQeqXK6NRMgl/N5di8aZO9/prrfvavPvDBey7evOkXK42aWBlMJ3C++QUatfpyipgQDkaAcjOYONDnzp298E1qJ0eKP+lIK5SwGoyUVrI87BXnRQGDiI3BrsyaNA9dyIToLg1hGJF1pL7isivV+JpLeeyFE7/2rj/5s3d/Zdcu55bvQXF8xyfINxfJlx557JmHHj/y6rYYfmTNmoudjOsK3/e11okPJNYapSCTcZLrl6vwHCf5j5tkui3T+2ZsLK4EHYZSiciOlQu/MDExUZyZmdFgxdLSUk/HcUVHPmHk21iHiYQ+TGLZ/H4/5Qgnm3s/jAjjGKylXq1x5WWXMzoygqNc3ExmOTvksa9+jTOnzzJUKlN0XXQlWahl8zk2b95MGEY0m02EVSzNnmP22Wc5OTdLUxv8wwdx/T6bN29m6yXbmJycRACuSsJpjDb0e3366YY5iqJEjiMkSijy2TynTp2k3+vR63Q5e+oshWyerPJwROrQvMBj3e/1yKRUEQmUS0XyhTxr1q3niquv5pJtlxC125xqtagGPkGtgen7CAStdodMNsvE5CTScXBaXdwgSlo6Yzhx4jSnThw7D8nzsiqbzXHRhvV3aK27IB/uBX3ZbLV0Ppuj3WmzsDCP0QZjIEFZWeMoJRxHzb/5en0cEPfee2909fbt20dL2R+P+x0rJY4xJmWEpruPC5A/A4XAcsx2SmqHZfiHmR4d0a++8TZVnN669Pihc2/+XhfHd10gFxbJvv37j737bz9xy8mG+Q/eyJr+5ORqZbSwQRBpK7BCJjggR0lclRApBkI+Rw3ifdNoBAuug9R+22xcPb7qmu3bf2X37t3mvvv2SM7ngiazb5ncW7t+jNEJoXwwDXEdlyAMMQZ8P0DHMZds3YLrOAyVSyjHxRrDSy+8wJNPPIGXScaf4VKdRrVGTwhyU+Ns2noxjUaDIA4pSgenUqfV9znl+0xkcowHIc0zZ7h4/Xq2b9tKuVTm9ltvBW1Yv3YdSiakwn6/nxRwFOMIRS6TZWhoiNHhEc4cPUGrWieMY+aPnWCqUGJieIRcNpsMdIwljqLEa9FJtFBr166l0Why+x13MDIyzIZ1q7n88suh3WBLt8OU63K82aTf7yNbHTwl8QMfoSQrV62CfI4wChCtPkUng+M61BpNjh56CR0FICSul0EqpTdtvEjdddstr2512u81UtNot63reug4ZmmpQhRFxNrS64dYA47jYIjEww/vXb6tbFw19idDjlE6Co1J0pQST8ggLsOCuqAolke6giQ6XEMYxSbnqHj7tkvlldfdrpqMPPSxvftu+B9/fu8nd32Pi+O7umJ9c5HsAnlPoiX+vVdcc81nr9m88j8VRod2yrij/H4d3w+0UlhHKWmFFUJKHIkwVizLnJUCKxPIUFZZ22tW7coVK6L1K6b+/dZ16z509913n0r8MtJY6XKeoGSptXpYA1GKxU+OZkEYRiAF7U6H0ZFhpibG8TyPYqkMJH3EVx76EkuVJWZmVkLPp31ujr6SdJTLpRdvZvW6NTz2+ONIK6DdplFb4kSnyziSCSU5FGoaX/kqufEJTp46gxAQRhGRTqZWnV6PwPeJghBhIJ/JksvnKQwNUchkWDx5kke/+lX80EcKwZNPP8mYl2H1xRfj5XN02h36fp84SqZ0Ceo/pt1uMzIyQr1RJ1/Mg4WoH1L7xpPk/R4TuTx+q0Ol32W60cDL59Gxpt1osWnLZkQhh69jektLFGYmGS6VqdXqvHTwEPWlRcZXrMZKiZBSlIZKrF2z9nUf+/Rnf/7aq6+OOr2uK6ywrlKiVq0yPT1FHGt6vQCLwXUUJtb1v9uLBuyOG665eaygbmpV5kMtrWOttcp1xUDqbwZqY5UuDG2SZGyssTa2Rklh87mCWjGzWk7PrJWBzB195kT1d//wL/7yfQD33bdT3X3397Y4vmcFMmjcdwvBrh07nN1797742FNP3f2Gu17zqjXDxZ/LZvNvHMpHI0L72CihDxodkeDoEpGZSP3tGRQglDSecN28rNb6+FEc+0JkBktVIUQzySaJE9a3ENSbXWKdTIgGGiFSWolUgn6/z+oVMxRyefL5PMp1MJHPc/ue4umnn6ZQKJIRkva5OZr9Hn4hTxwF/OAPvolisUSlVsfVhqBe52SzTVlHvHFiiJWOA7kCXWtRL+0n2rCRRZ04BbU1RGGEDgKUEWQKRYaKRUrFIRwpCBstDj/3PI89tY9qt0NZKBwpCYKIB776MJecPc3GbZcwumIGXRqi2/fp9bp0u53EXBYG9Hq9NLVXkZOSQq1KcPglIifLuOqwbbjE890OtU6Tld0SsbQcO3aCt/3oWymPjXGiVscVmqGlCsOb1tMPAo4fP8mp48cZX7E6OfVdVyopyeUy1wNtKcTzoQ6vDsPYOo4r2q0WvW6XMIzp9kKEENZ1XYYKueNABDCUz2xxVJasV/bisEcQxkCkkRZprVWWhHeWZocnrlJX5QsFMTQ0rMoj48hMCaty+042or/9nff87d9BtZ1uycXdd39ni8B/tgJZLpS9e+NdIO9JQg6/Bnzt2m3XTm/bMnlz1indlnXL10oRr3dEXFKglE2OWoMgFoJYKmKrolioOS3VC7PV3qOnzsx/4sSJE4fToYAWUoQqPXoFibS+1e3jBxqMTiHNKew4jVQwsWF6chIhJNlsDmti6ktNnnz8cYIwZMX0DEGlRnN+kW4+y7lmnVt2vJqbbtmRgOKWKjh+QK1Wpx1G7ChkWKskeU+SLXg4hSJBq8XSkWMUp2fQxSJaCCLPUh4qkfEyOEqi4pjW7ALnjh/j+PHjHJifp4lhLF9gPJtFRhGuFERhzIvHj3PmzDnWrlnN6k0bKU1PkR0ewVhLqGOsEegoIuO4OGFAeOYM/tGjEEfMWsFax2WbBzWd5VSlSWmohM24nD53lpHxcV7zmtt413PPUx4bp7FQYWjFDKPDI5ybPcf+F17kyutvQDguypHCYu3wUHly+6ZNU8aYxyz2aj/0TRzH0g8i/F6PXldTb7eXgRbZXEKK37lzpzp16tQHsnkbl0vTt4o43J61ZoNrdMa1MZ4wSGFJAkEkeC7S9cDJIhx3nkx2fzUyjy7MdR74uw/f++jgvXbffTtVan6yfJ8+nO/HJ90NZvfu3ezatUtecuCAuHvPnvknD/APwD8AXH/rrVNrx8cnCHobi5kyDooY0Ghavh8VSpMHvnTwmYW5fft6F/LVBigihRRRSggfML/bvT6dbkTWUxdYf5MGcACmmxgfI5vJ4HpuIok/eIgDBw9SHCrhaktzbpFKHNB0c8Sx4e0/fDdDwyOcPn2GXquFDHwq3S6jCjZkXRwBQnlYHIz0cKQDC/N0zs2ix8ZxJycxhRwBlmrjNJ3FKpWzcywtLNDr9zASZjyXNVIhpKKQy6OLLrVeB2Og7HkQRpw8cZSlM2cojo5SmpkmUxpiaLiMl8mg+y7B3AKN2TlUo0ZOCM5EBuUqLip4FK3hokKOI5Umc7U6o9PTzC8s0O50ed3rXsuHP/JRKo0mGSkpnZ1j7OKN5HI5DuzfT3VhnolVqwGL60hTLg2pdevXbz5+7tyz+UxuOWw1iiKCXkCnbai1O8lDSymy2cHbaydPPHF36wl4L8k/YueP//hq025fUszn8sb3rygNFXJIaPe7eihTeibS2jdR9uQzJ0+e2PfQQ00u2KZ/5CMfUXfffbe5++49mu/zh/P9/OQXLGnEjh071L+anLRv/ege/fiXv7zwOCwAL/6v/v6uXbskDz8suXmv2b2bZSaQESIZaKRLSKwhCEKWmh02TDopCMLBERKpkrwJIcWyJ11KQa/V4dlnnqHZarFyaga/2mCxVicoFDk3N8utN76SK6+4HICzZ85AGGDDiKbf5+Kcx2iK67eOg5YgohgdaVQ6Ou1U6xzZ/yJBqUQ3DJmYmuLUoSM0W3VyjsNwxmNYORSUpJTPorTG9Dv0hGTUCuZQ1KMYKQW5TA5jNbXKPKeqS6zasJEzZ88yWSxQqdUZDg2XTo+Rz2Q46wd4Q2VWhj2mVY6o22FcCUY9l8VWm6mZaTr1BgsLS2zYtJE3vPZO/sefv5fRlSupVquUOzOMlkc4NzfHkZcOMbFyRaLETuBVFPPFbd1ud99IcQijtVAq0T9FfkS10aXXC3Ec93wW+gUPuMF74O49e/SeD3zgNHA6/b2P/S8307t2yXtAHjhwwO7Zs8fcfffd3/fC+GcpkAu/x71798Z7L3ixdu3a9TIj1IWS6G3bttndu3fbtMAMe7/pky1jSRNOlxVJwMrcUp2NU5MoLMpJnsqOTEJxlJR4jpfKpAXVSpXjx0+Q8TwcKWhW6jSFpmM1fuDzxje8nuJwGYTg3Jkz5AwstFoIa1njZcgrMFIRG4tMgyWNjlFCUsxkkNJhrtvlrTvfgi4VCcOYj578M0YzecquQ1EKcq5L0XUoOA5ePksU9NNwYM02B5p4LGrNmUCzIBxKOY+g22Jm43q2bt3ED9xyK7/3+/+NztlFzrYShE9xfJJp7bMhn6fdDrDKoYxkZTbLuXqDTqdDaXiIpcVFNm69hNe+7k4+/NGPUev75ByX1nyF4c1rqTViXnj+ea57xQ2YJIci9e4426rV6udWjE8QxXGaQ5BMo2YXKwRBkEh3rEUJ53/2HhC7du0SBw4cEIuLi+LmxFGV/rGHB//j5ptvNrt377Zi8D74F/hw+Jf5sCmYznybV7d0r6e/6UtPvNHnlhpgV5JJoxLiOIHYaZ08iTNelji2+IHP4lKFpaVFCtkc1o+oN5vE+RwLc3Ns27iJKy+/Aum5BL0+S3PzKN9nqdWi5AhWOeBIAUoSYyGOkTJRCbgYSqkEe8J1WDx0mKvf/AYe/erXGfUDLp+ZxsYxWJN4P5RE6pjIxEnEQqxRwkUIwxqrUW6WtrWcDi1HraBnBEcOHeWaK7fTqS0yUmviFvMJ08vJENdrbJ4aBR0mmFbp4NqQyUxyFW22OwzHmrlz5wDB5s2buflVN7LnE59ics1aqpUaQ6unyWWzvPTSQaqVCk5yCoskaUzPJFNnizZaKJuoJHRsOTm7iLYGB7PMuPrf/PwBkuff3r3/6A/t/Sd+7Z/7Q/J/0Mculh9WCSlFJwwlYcF1XCqtLp1eSFYlhiNtIhwl0UYjU5tsFGna7TYL83P4fkA+lyNqd2nqCN9a2o0WN15/HaMTo3hZj1qtSqteRYQBQRizwnUYcRJ5t0lx+4mOLE4wQdJSchVTWZfNI8Oce/5Fjh88xPzJU6wvFlmb85jOOEx6DsPW4EY+IvbJYslZQ05BURkKElwpyGAYsYarcvBDIzleNz2KbdapVJp845Fv0Gk06fd6TBTKlDNZ4ozLE4sNDlXrRHGUFDJQVpIhx6Hb6+NZmJufBSBbKHL7bbciBLStpqUDevUG+UKBpaUqZ0+fwVhLFIUioRXa0Xa73cTadhpFYDOOQ7fjM7tUw8t4y1vwAQ/t/+QP5/+kL/b8CZIWhhCpiC0hyYdByMmlDpfMuDhCJU2kPE/v03GM7we0O20qlQoCSyaTYanTJVSCRqtFvpDjkku2JuwvN8PsuVmCVoeo72NtzCo3R0am8V/KIeNlEke1MCBV4o3QmjCOcQRE3S5P73uak6fOMuH3kR1JNxVn9nSU0lIEmpRUKSxZASUhKbiCkrZkhaAoHQpxyLW5In1jOX7kCCfbfcLSEKVMjuFum0LYo5wvclJGvNToku/3uajgMuMqpmLNiKuoBj5ZpahX60SBj3Jdtm3byrrVq5lbqpIdHaG2VGXt9CSxjjl16hQrV60kCMPkNZfkk+0dOoGZKzLSYaHSptpu4XoOOtSJQNX17P9fF8gOcG7eAQf2YvekO8//N1RIEqaTMluRy4JFKwRHZqtsnZgi50n80OI6MuXQJtSLKAxpN9t02l2ElHhI+mGI9hTdVpvVK1cyPjaeMr4U8+fOooyh3w8Q1jDpKLKA9CROxiO2gnoQUAl8GhH0jEA4AqtchOfSzxVZPHSCaq+NVx4hVyrjp9t+ZS1eSjwMg5C+Tpx4gdVENiYOJQ6SnJKMqZAVjmBVYCnkihw7foqcgHVDRYyS1Ho9imGfjUow7LgcKRQ5FGn2tgKmJWx0BWOeZKHvIy10W23q1SqTK2YYGR1h+6WX8NInP83MxCi9oI8NI5SUzM7OJgrpfpDgdAT55Eu3BmFxXUEGyfPzFfwgIOdliEkCOuNIZwG2bdv//5ZCEbtAXLJzp9i5Z48R320+yF6IB9dAAfwnkA+D3Jvecv6lvkudYvSTkyNJG0IKXEeZ0/NLZnHNkCy7ruyFfTwv4WEZncAiAj+kXqsnzaTjIi34VidZHFHEqpmZBCUTx9jYZ2lxjqznUOv1UVIwlFP0heScL5jv96j5mkA4WE+Rz2YoenlK2SzjhQyuABv4bA4D+q4gJxVDNsTBJysEjknm/8aJsa4BHLSRRNZglYsvXZaswZcus0HE/thy2lhkoCl7DmuCgI2hT8cVVCZHeXHRMNdss7FcZHvGYcVYkdmu5Gg34uFej04oaFtDL4jQYcjiwjyTK1YileSiizYk2CUdEzsZwl4fJRW1Wo1Op0MYBMRRhN8LJIDjOFYKRc51CSPJobNzy64+KaTQWtNudacBsfs//2fzL1kQDyfvWyPB7AbLnj3f9QkiAPnmNTPvkMrNNK188aGTJ5/cDb1BYew6Xyz6n/tkMVoLoTyEq3CUi7XWBEHPishXcRzKI+eWuHx10UphhXAzZDOZhILSS0BtrXaLKArxXJfYWgI0cRhjganJSVSaSdJrtmi2OzjFIY53O1SN5JP1IKH+SUMu41LOZFidLTBVyDHmWUpKkSUia5Jrlt/tI6SkrQPQFs9IlLYINCIFdZPSVBJNnsWTYE1MUYas8Vz6jqQbGA75IYXxceIoYF0QskFaQHNRNstKz+HF0WGe7fSpLtS4bHyIUeVSKma4KOdxpgNf9H2aQD8McR2HamUJAD8IGRkuUy4N0e330eUsQRCiMopet0er1SYMAqsAbFwBQqWkqxzFUK7I6YWaPjW3YF3HUWn8EXHyQBoFPKwNeJlH8Pveq8pLQLwV9O5U8ZWOC/JXl8sXXzc9fVEzn3/iw888c+p/93X9owLZCWoP6Osnhy+5OuP+5aiEitZsX7/yVNOKw9WY+57q2ft3186dHRTLfaDuPi89+749DWC3mZm5Oi8dudFgDUaaMOxKqQM5nLUUy+KY37cfPHRu7pZNE+tvygppAmllLpNJSOXtFiYMCW1AGEeJ1BxLDPSDENd1KZWGEEKidUSr1SQKQoaLQ7hCElmLNLC14LIuP8SwK8g5CktIHASYrsaXIFyFdj1io3FSPmzOUcm/G0tMjBKCSKc+bJF4HRLCi0AkMwC6wrK/F/Nou001stwwXGL7sMfzfY8jZ04ykfcouoq5epWxQo510mWxmOfAXJtys8fm0TIaibJ9LlaWSsFlrgc5LJmMR61aBSDSMflMlrHRUSqNBvGwILIxruMRhRG1ao1ev2ddY3GlfBbouo7jZrIeBcezL1XOqH57CS9XxMmqWDiOSOpesBE4+s90WuwEeV9SDIP3obpyePiS9UrdOF5w3jCVyW5XOlp1yfSIeHps4n0888zPfGXXDnXL7r3xt1wg29JqkoFVrjFxFsEERk4psTY0Zm1bmdvX5uJGa/WqZ5pCfuzBKPrI3XNzlUHlHgCxZwDo/Z4XCHbt2vJIvaMnre7J4aInswVLzlNPjpUKf33F5pEP/+Z/e187M7np/ZdXxl9YPZnPRRJbKORFHIe02zWUjunrMOkxpEUoiXIdoihKlotKEYVhEiUQG+IoZtxzGZYC4cIbRrKscUCLPnEssEYRC4cgJbhYLCYyeMYirMHKBDvkSomOwoTCYTShMQmlw4LCElmDtkn3K5VkIXb4ejfgaKBZk/f40bLL+pwg02lTc3Kc9Fy6WlMIfYJYMx9H5JVkC4JmucTTzTbDuT6jjsLqmFgYhLVkAU+A57o0GnXAoKMQsJSGy8wuLqIFaAGuEERxTLPVJOj0iLodtI6OAMOu52aGsp41USBl1v7uRFlNRXHvp6IgdvoBtOo1I9dP6NfetZE/vv/7WiJiB6hHIN6TfNlcM1a6doubfcuwY99UtGyaznoq5ymKrkdWuXFOSZF18xfQVvZ++z1Iy/dbgc4Z7biewbE60sZqa/Na2PVCDFvCWzpC3TLtiV3VNWs+cFDG9+4+OXso8S0g7gb5PW7sLcDcXLW7bdOapdHRcsfzeLBczO55z71//VVjLH8P3HXXXZn777//+NHKRQ+smxx+05CLHimVHWFEQu3w2+Ck+BhjcTMenpfBWJPO+2P8fo9uu4ORIvGSZLLnQ/F0hBYCLS1WJm7EnCvJyzTvW2ukBVKFaoKsiUAnk504SnH+xiafzkLfJC2dKxQdleOpXp+n2h1KGY8fmBriUgccqwkAHfYYijR55YGKyHse7UBjQkvgCEpWcG1e8cWuw/ONLreVc9g4IhTQMiaF0goc5eD3+5igh+8H9IOQXC6HiSKMFDiZTMozS0jzNghFp9mi4/cOr5ic3JbLeHLI9WzH909/6GN7/n8AP/j61/9Zrxf9Uq/jv6EfzE8tnlOlj77nPfzx5td9X1YUu0DuhnhvwtrN3zk1cfcaz/nJMWl2TAohXJssXa0N46xbFn2jRT+M8IaFCnq9GrAMA/m2C8QxJquEdESSYYVQSGMhtBajscJisja267ETq4X5tWktfvmydesePCO9PxfHD3+BtJp/OLmyfS8KxQKcOvVc4+0/cNVVv/Oe91UvpFWkQkZzf8qAPTy78JGN4yM/uH5lRuSyWRylmF+s0G/WkaViisa3qYjQSYASShLrmHanS7PdTlBAcYTOZMm6Lg1jCYUgIpkuCQGRsfT9KHFDplFjJjVZW2swjpsolS2JR18med4mvZDGRuMohS89ng81j1drxMrlhrEy1+cUxdjHRIa+lIg4OaXyroMlph9qVA4cJ9kOqcgSCSjZmCuKGR6rhcz7mpXS0I40fpQUrHIcrJBEOqbX7tDv9mm3O1idMIetsXiOm2rZDJEfIvp9mq02J09VWyPF0tZyoYArhKj1+/8DEHfddZf3yc99bh/ws3/zN38z/PD99199dv6MYNNrwwt/ft+r/uLupL8wUBp9/aTz46s895dmlNhSEMtpVHFktTQWYUKcbr/PcLFAbK3phgFG2/53NebNFFwHjBRWIGSSS5gkARkSCpFVGoGwwiqr9YwV2RX4b1xpgzeuWb/6S2eFePfDx0/fv+d7Xyj87h//zdLv/vHfsGvHLufA5AG7Z88evWdAzdu7V1tAzD7z8WeHCwdL2VUXF0rKlErDslqrUmvWWVXI05EyAQ24DkomSU5Wa6IwptfvU63UKQ4Vk22861IeKnB20dCNIZZJZLRDkqwaY4itJNIWjU04s6k0IwoCPMdB6AR7FmtNrAUWDcqgpceR0LCv12cxFmwfKfHKoRxlv4f2O/giAW9LK9BWo60gin36UYBUEJuYMIhxFFgpUNIhDCNWew6n8zn2d30mSy6x1fRNEseczeeI45iMBb/v02l3qDcaCRnTWnSURlhoTdYtYrW2Ua0ql2p1/9Cp+Wfv3HHZxeVcxizUa+f2L9b+eteuXWL37t3hrl275IEDB8Q73vGOBvClgbjwe1UYAyEswOby1PrL8+anZ6T66XFHrPBMhNVoIyVWoIy1jotCCIOT5j36QYiT+OVxXXc6UbjczO6938EVy1ikRGKMsSLxPy6PVmUKEBYkKSbaSMdgrau1mYgQZcfcNiPlbevWrX3qrOe85yEn85E9Bw6EFwwBvtuGXiTS+n/SIGMFOxzYG56u1d717Onc316xKmsmh4tUmgFzzS4z5Q6Z4XJieRaCXNZLYsqMptPp0mw0yReWsEAcGYTrMDk6yrPHjlGJDes9B2MNwtjE1CMS6b2SchBdgSbJO5Ek/vsAkRDslU3k7DicjC3P9EJmA826UoFbywXWaZ+4WSWyAlwn6WmsQRpBbBLqfzUSdPwIJ58gOjNeIqsxgLAapCUTBFycdflKV3OmJyg40DEaByiNjNAPQ8rSod/r02g0aLfaBH5wHsiWYkXzmQI67NOsVMRcvdVfs2aNyBpxnWusrMXxrzz00EPNkZERRaLgXkZYDSAbe/Z8V4rbQeNtB4335RPlK7Y62V+cctSPTklRzEpLFBvtx0k7mUSt2uV1gLQgRAJ9UK5D2O9jdIznufI7OkEODBSzIB0n8UMHOk69wmIZs5Oev6RkH6SwIhZCGWkRsdZj0opRGV4zbaP3T/nBr9fXr//vz7ju/XsOH64MCgXgOzxV/jd/fq8GZMZWP3p8yfmPyo5dZGNhMtlhudC3NJtNcvkiUgmiMKSYzyGlII4N/X6fdqtNLp9DqmTB2AtDpqaSSLWFWBMJkRSHNUgkZsCWlQkDbJAFHhuDkwa7JPneBqsVJxE82/U51deMZV1+YOUEa6RGdxZpWEFGKKxiuU+R1uLKNM3VkSyEGkfHlFRCcllOxrVgtQEhCU3MqFIMOx4nA5+NUtGKYxwpmZiZpmKTjMdqpcLiwgLddpd+v58uX1km1OfyGcJKVVQabVPxdem6q7b9fXP2+Oxso/E7H/78/Z8ceHS++efz3RTGhcOewQ3k6qnR6zYr599OKvHmlY6jMtLSj2zciY1SNsnWsSTRz4m9YYAyTUAPQWywRBQzWRRi+ZT8zq9YNjG/CilxcVMQQpLyE5kUA0kKRMZihEzv2gaEVSYRFZqyMbYo5OV97AdWivhc9aL17zuos3+95+TBU4P/1n2g/hTE3vPTr+9Bv7JTLizs6a5ZOfwfTjejPUoVTSanWfKh2o9ZWW+QHcrQ6/bI5XI4ShJHEe1uB3RM2O3RTqmPzU6HFWvXkJMOrUjTw1IQCo1FJ8cqQklCksRfkabHWikJjMGzFisFFat4sRdwuB9Qzua4ZarMJge8fpNuHIJw0xmlQS1n9SgQlhibyGeEYCEKKTqSogNhHKMBRymMSZi1xhhiCyrWjHuSpS5UY01fa0qZPMXxMeZqVVzP5dSZ09QrVeI4ottLbMsqTZRVykPpmNaZWWZbvi2Njqk1a6b+294zRx978PP39wDxXZ4Qg9uA2AliG4h7koIY3C4Kt0+Pvm5cOj87JdQdKz2BsJoojuI2UnlKOhkDsRkoKiCMdZJ8lephIBmE5F0PISxhGDHqepy/+X2HTbqrHEdJlbhiZZqWYm1yxbKcDyu5IJlUCJsSFdKcQmFlbJPk+LyO7AbDyjXS/Na09d+5bfXMJ5aU88lHxiYfuvsCY1S6sXfYsYOH2cvkXuxg9Lz7fOF8CwW0RwPyHT976OPv/0DhGavGr1Ro3Q16ai5WlJpN8vlJemFAuThEMVdgwdRod9pYP0C3O/RTgeNCtcbGDRuZGR5hoVmnFltyjoTUO63SH4UxFmNUMj5ORGMo6bBo4MVewLFeSF65vGpyjIs9SSbsEfQC2kJglEry9+xApjBI4TIYILYSIw2BViwEMZuy7vJT3lXJdS5MtVxxCubTaPJS0jeGE/0Y31g2T07iDZcIZs+hteHc6bP0Wx3iKKTf97EWXEcl/UfGI6rUWKosxf38iDMzM/a3f/ie93xJCMH/5OT4X16J0802B9JiAPjPEFuwey5QE102MnXpRV78w2NS/PiUqzYMCdA6ohOis8KRrhKONJZIa1ylUFYsM4sHV38p0phrklO11+9TKuRxXYlvDJmsY76rMa/rqbGsVELZOBZaG2sTrl0SuyZSDKRJjvb0+x+EMQ7Yqkmug0AKIZOcHGudODSrEMOTQryjYcN3bK4unu6uW/dgQ9ov74/tV06vf8fS7r27Y75HUufduzEXX9z72SBoPI4qCmGlPVXviYlhmGo2EWqYXDbLxPAwJ86epdbs0O12yadps7JUpN3pQCHHtk2bOP3415kNDZOug0Qke5NYJ+o9KbAiadID4dDWhsNhxOFuRE5KXjk6wkUZQSEK6HZCImFBSiLEMv7IDADgMsnFICV9CCuQ1nLOCLQVrHIlkUlOKmUFcfoAM2mRxanS2BXQsYbZlBV2xVVXoGVCI+x3u4nFuFbD9wM63S5CQLGQT6ZrWtOZO2vq2lWTM5Pzr75q7a+v37graZa/RRh0knG5fCLY3d/8B66+2l137NyKTVl17bgMtrnWvGFY2ssnlOspE2O00bEAJRzlCaFCExFryDsOnnAJBwyClGlgpUCksRqD7EaZPPBtHIZGoHVGKUcqL/cdXbHSBpq2U3j2WL40v9JzpjO9Dq7fhUibyFprpJTa2uQmcUHk98DyN0gfTX49vZ9b0BJhsCqOtVVYM4YVU3G0RijnZzpC/MwWVKt/8n2L/srJR9xcfqEW64Wl0H8yGp5YzJXLkQP9Bx97rAGE36oqZQC323rxVX8eRME7lXLjVrfvnMtnGWp3EsfhVJLwmjnoUG20OFetIKRDuevjOQpHOZyr17jkmqv5ypPf4GTfZ23WY8J1CAFtDS4SB0FfCk5HgiN9n9kgxLOCy4tZNhcyFE1E5Ic0LQlwmwRYYbEvQ/2bFME5eNhECITQKKE43o8oSxh1k6kZMgkoSnbwyV9KHlQCoxyiOKalYypRxIyX4epX3MChs7Pkczma1Sq9+XnatRrtXoduv08hm6FYyCMRxIsLdn62ajIbtziT06Wf/rlf3137Nk8Odu/GjFx9dflS8vl+Y9axrZaXj+3Fk9nM5XkdzGTmztxZKrCyiM3nRMIQiHWMjmwcSCldKZREEFmTRvm5GGPwdUxGOUghk2ZcgrFxGiQ0YGphhdYGo3GGCsoZKqtmtqga5RFmg87T3+kexAA8ce7cWXHVliu2OOVXFrrd28pB7w2lbnet22xAt4M0aKOS3FEtQFiRaJgGEWzLQYzpSSLAaCjmc0wMl0XW9VSsNTqKjI5DE0ZaGG1KBl1S2cJGIQVRxqFTzOILHVVrtWhJqPiHbrzpaDufuenBBx/sfSvXrT179pid7FSrXrvqN7/w+Udu6vbjy4UV+kwrVivzHsVajU61ytTUFBnPpd71OT23xFCpiBfGiHyGwtgIJ8+c5dbt21k/s4oDs2c54wcUlcJaQ2gFi9qyFGlOBjG1UFOQksvzeTbmXIoiJgj7tK1FpSyvhCabcos5H6GWZC4lpWIHKiEBHlCxirO+z+U5D2UNIRZtBW4yJkCnxSq1xjoesZA0goh2nEQ+X3rxxQyvmObcs8+wYnKSuFKlU1lisV7nbLWONoJSscjwSJmwUmXhxGktZtY4uVLuPX/wP/7kC7t27HB279kTf6uN9mevvlqNNGq/NVOv/lJJ1byctI4q5h3XWC8vLZ7xyCLIOALHU1o6nhVOVhrXEUZrx/d9Gp0WJo5xpUOok+um50g85RIbmwQvWIujQFoXA4TE1kShVko57sioMlMrODdUrgXZ0pf18NBnjnXbz33igx98DhC79+6Nv2M17+Of+fLC4/AJ4BP8+o/95tsPd15THhr7sUK/87pSs5ZXzQbCmhipFAghUsm5SX3ipDHIqSOVCE0JyYh06fe7KeVdSqMcmc9kkDa2wiprBcb3fWwUkgm16ge+G/iR6w5PUBofuyInGdm1Y0cw1+mImX37BoK0/1mh2D3ssbyb/m2vetUPnTzX/kZMeaIfRuZoB3lpTtA8eYzJ7VcyXipR6yyx0GixvpAj6nfR1Sr5oSKVOKBuNNff+EpeuO8fOOSHeG6GUBvOhJrFOOnPVrgerx5ymfYkjgRjQrrGJB5tm4C7EXYZ1jwIzh4UyWCeKcUFl3eb4P2PBDECWJEVRBaSmb8gJLH92mSvh5WK2HNphjGnOl361jCG4pbX3cWJuXl04JMLQsJ6k2qtymKnw1Kjg0AyOjpKTipq585pUyo7k6tmnrz6VdnfuOON96lv0Qsur776akWxaL16ODI9NvFbowuncRptMsIBCRnlGqkcI10HJ6NkLuOJoVxWCQSelwEB/dASkaHXNHTSvsJVyRU20jHGOuRcRWgjtE2jtG1sTay1cZTjrFnv9Mano3ik9KVwZMXfPa/llx/8iz9YfJlu6buVuw/m2dsWF8XuP/hg98PwKeBTP/6zP7u5u7T0i16l+qMjtcqk06qitdZSudIihD2fg7x8r9YkG1ptLX2t6XV7RNYSC5kCijVT69YLhRFRvSrLw8Pkclk63T6q2bYitjQyOWtdyTPV2tSH9u49e+E3+5GdO9We9MT4J4plcNU6vn37tT8S9Hufjch7p+uhLbueGGtV6S0sML1imsOzS/Rjw2yrxXCpiGw1yC/lGR4d4YWDB3n1q29g/SOPcGBhgbNRk6KTZdSRbMu6THmKEanJItCxIZLpjFKI8wWQkszN+fCwAbY5rYa0n0v/3VqDg6WBw7F+l4uyDnkB/iDbbzkjPN3UG5BZj1g5nOs1ORdFKG24cttlbLzyCj7y0Y+yslBAV2vMzp5hqV6j4YeEcXJUTQyX6cyfM6DU9LaLa2Nr177lF37hv0a7ds38z2IExE6Q23bsEPfs3asFmH379pl9wHU3vfKSMbcQDbeKcjSXlQXXxdEWDyGlK2XWyxBEIWEYLud+tHotcpl88onl4AGSxPWhDa5KcmasNfTiwaMFa4JQx7mcI1etccKJFY1oZs1fzuUKf/dXf/T7+5enpTt3qv2Li4LE626+nenCt7a0+ablz50///MzK8/MvSPfrP38cKO21m1UETrWxnHkck4wligtEhlqVo+NMV4u060tYiVI10MJqIchd/z7XQStNo/+4bvISOgGIaNbL6E8OcHp5/djHce6k5NiNghPna5W3yfGJg7sD7svPfbYU/sv/OFZEPfs2KEOTE7aCwvm6quvdvft2xe98trrf6rRyb6v2zdGqVit93qMZkBMTfP5Rx7DcQpsmSqyLueRFVDO5ChPTjGH4aobX0F8Zp4/uPevaFjN1YUhrioP4cYBQRgQ6mRy5TpJPDJKYkTSMA8mXeg0iDKdgmEvuFIhkMIuZy0Za8lI2B/AmW7IbWM5ciLZRblCIIWDTcNSTRqk6pUK1CLL40s1TkQBk06G3/6d3+ZUq8GJp59hbbHAmZMnOVlZBCmYj+DoYg+E5pbLNlnVbNqZbZcFaqT8Q3987733f3PfsQskO3bIe/buvVA5C8CGbdvWXOd512X73atXDBV+bqPnjhXDvnWkFTrwibwhrrz7rXSrVQ587tOMlUt0+j38IGB8ZCQB54UhGouVDsdOn6YbgVHJyiF1NeIpibBYEwY68DJObtU6/OlVC+2h4t+c9bw/33PvvachIaLsSdBT35GK49uKYBu8SMu8q3vvnQN+5zU//5t/uv7cS7+QqS/9q5F6bY3TrCQaCOmoOCnwRCohLdbzEhGfAKkckAKNwfMyRAj61hJnPMqOpBNErLzhVVx0/Q3sP7ybq266UZSHS+h/+NDaSWN302myQRh709WX7l8K4s/7Q0Nf/fRS/XFx9OgSF9wtB0+Oh/futTt27HBmSuoLq9thvO9E4PZCaY/4VsyIDiuyWcpDRaqtmAgPWSygwx71sE9v7iz54VGe+vpjvO51r+P2V7yCz3zta8wFfRZ7kmGliKwg1JaM0AgNVuiURE7aQgu0NUmxWDWAmi8/piQiKaZ09ZfkqljqOBzr99g6lGVICQItkyIygljoJIBGa3pRBK5DLzS8VG8yG0dIY7n7rW8jv2KKg1/+EmuyHieOHeFsrQEyYmJ8lKMnu0TaUsp7tOYqZtu2NSo77O39w3vvvf++++5Td999t9m5E7Vt8fwpwd69ZjdAee3w7ZP6spFO/zWTpdIdozrYulI4pdBEbNm8iY233sb+T3xMdE4eIzYxFQ8yl16OPXcOPwppdLuUS0M4jkO92aJcLKKkJNIa4XjpHihCWok2JLwzaWyv39fKyznu+s2Onp5eaI9P/ckzmcx77//jP15Kfub3qf3b9g+IKN8fy+3/fDJxnne1a8cOtfvedzWB37/jV3/1r1YeOvhLxfrIvy406tM0lnBiE0vlKitTbrfjMrhrKEeCUkRxonCVKmky+2FMxyp8KwiikG4YEmdzFNZdRGnVSjreJ42tzBmv2RCTK6bVa9/8w5eeeenQpYeef+7fbR8vV5tTNxxqRHzuVL/7zBdarcfu3rOnMdAF2b17+ak33HjbkK2760RXH7Vl1Y0Fs8ZFLbUoulnabsiZWo9SKc/qrEdgu7SCmOz8PMJzeeyxJ/mBt/8w52bneOrEMZ7rdNlWKJCzEFqDiS1GJuNZAKEkVtq0QCQ6TUwSiYU1vV2JNO1SECMwQiC0JpQOL3Rjio5iXUbha5PsmqwlNjEDgJ4xlsBAHFvmgoAjYUisNTdffR0/8KNv4wMf+Bsy7TbHT1dZ6rQwaKZHR5jrKxZaPo5ywUqsY2SveZr8sHMZTBX2/+mfBgLsnj1o2MtuIbjpqqu2r9fR68s2un1Mm0vzgskrbnw1qy+9gkPf+BqLT+3TjdBYs3Gryl58iZCje2m/tJ9SqYiwEHR7YA3lcpmw36fWaDFaLpJ1XdrdPvmslwxuHRfhOOgwxFEKa2Pb8Xs6ky04mQ2bnP7MqnpzePS9p4PgPZ9IHtbs2rHDYe9ec/ee7w0767uFNth0CpAUyrvfXQP+6yt+7Mf+ckuj9UuFxuSvjFQXR219CWHiWCAVrisG1O44jtLMwsGMOLmVRQa6kaYXaVAOSkmkMFgTEgY+sdHScZTsW0tuaMyOX7/D9lTG6C8/JIaznbGClK9cOzT8yu0z41ylxPxS9qKvVEz8wL5Tc9+4/E132QlR+e3Tx6qUHSE2iAbHdZGezXCy7SOsi5txiOKII+ca5FYVyUtFJEK6QYAX+AT79rFq1TS/+M5f5Pd/579zeGkOjWWdk2VIOhiR+N9FGCa5J2lwqXDUINl4mUdMSjWXUqRsWkNswFqNQnKkH1PxA24s51FGE1qQWLTRiV8l1RvFAvpCseTHvOT36MUxl65ex3/47V3sfeTLLL14AL/dohn4aGEYKefxnSFeOLFIhCXvuqwYdsi5PTE319MzK6ZW/MTOq39+957Pv5tVq3I7jH/bKiuuGUbcPl1buG5tPutkpKHZblG+8pV2890/pqNsRoyHPTm37xnlxwG92CcOujg2EQj2ej1MKZ+8DlISRCHD5RJ+FFGtNxjKFSgW8ugoxFhQQiG9LNLvW6v7Wjo5p7RxveOvWFFvjE2893gY/9mn3ve+M+mtxtm9e7f+302l/rkL5B8Vyn07d8q7P/jBxcdg986f+Im/ikZHfyVTm/iFcq1S1rVFhONYYbVQKnlDcL6fT5x0dpATkowtpRAgnQSCIBPom7Fp5ooVGKNF0OuIvh/LGIfAYLudtpmYmrGvfcfPyM65uenO0tyPLCwt/sidlzTiuN/XUuuMbzzqUksd91glI86ZMi3hIaxEmhDhSLp+xAtn61w8mcOTFusK/EiD7vHVT3+O0Z94O7/0b36R333XuznbrmOMYI3nUs44yWg7jiFKgoJkLHE06cAvCaAUJhnrGmFwlEFZlSz54giJYM5ITvZ9Lsq6ZExELxwsZZN+IzQGiyIWlghLJYajgU8rjlk9PM49v/+7vHT0MI9+6tPg92hpH+1APuPhlkZ47nSdTi+mmHGZKVuG3Q46jNEGuXRizq6fybzrHeumLx2WzvVb1118yczUNBMzq8gOD/HSQw/GzdMnRCXQsrRmlfAxTq/dJDcyQXGkhPR7oBVCuXT6PZRwyGazVOI4icdzFbHVVBoNxkdH8ZRDo9GkaLLksi5xoDEC/DiyobCiuH6zE86srgdTU+8952X/5P3vfve5wfX57j17zO7d33uy+/eyQJYLJQ1rT06U97//HPCbd771J/98dbn0C0659DOiUJywnaq1wgolFbG1SfaDWV51JTogKVAiXafIVEUsVTI+TuUdOhl1JH4OLDo2yKwSUjrKeFn8XA6xcZ1dccUlerVQwjYazmd+53ecuLJoLykPiw6GVlbQ0RFn+22O+UUWtEsHgdHJlKjZCzm6FLNlKkc+q4kdQRxDP+iz5/0f5M1v/xF+9Vf+Ne9+z59wrl3Hx7DaWgpZD0c5iDhGxAasQYQRXhrLDINE10TDFsWGWCWvg9aGjjDsD2FSSaatwQ8TGUlqyk2k6clZQsfCfBgxZzTtKGJteZzf+8Pfp1Kr8pE/eS8mbGNci5NxKGUcSkPDPHW6zelam+F8hrUlmFAB2dhSiATDxhNTXUH+yCm3NFT66df+1M/hrVpp1FDeREIJjZRrpOM8+d4/oe84FKdXYB1FHGiKExPkxsZxZxeSwE0pMEJSabaYmBhNFrNhhIOgVBxKIuAadUZKJUZHSnTbXZx0ohVra83MGmFHR2rtyam/PBE5f/qRP/3zM4Or1O69e/Xde76/fN7vFxfr5Vevj/zdSeA/3PnmH33Piv78o5PSWRcgTBhG0jpOaiCSaSBwUhSuFHgipX2LJAVkcAVL+/5EsyRk6iGPkzeN0WgTAxZHKeZOnRNfe3G/s37bVoaLRVuLLMr3hdFLhCaJhVsxNsrWtWu4odbhnK8561sWbIYzXUM9tszWfTwbc+naIbKeIYgskYRer8MH/vKv+MG7d/Lrv/ZO/vy9f83h+XP0rGXMxIxnc2QdBxHpJIrZGiKdjDTl4IqVMrassFgRIS10hOKwiSlZhxlr8UOdvAzLYxiNRhBbQw/LfBxzzlh6ccSWsQnu+S+7WZg7xwf/4i/ARmSHHFxPUsw5DBXK7DvRYKnWYXsxz6VlhykV4ZosE6OjTK1ey+j69azeupWjhw7brz3yiObijbLe7sn5F16Si5UFrnvFq6CQpxsLuo5LaWKcZqfLwkKFizetx5mYIg6fTWQvgJvJ4HgZGu0e/ZxMR92Wfq/PSLFIP4ro9HpIY8llskmoq42M43nCWbv6yLHh0i170hNj164dzj2792rxPb5K/XMXyMsKxYJ4z113ef/mEx+au+K6ax5xsmq9slYL6cggTt7pyRw8EVpklCLrufSCaDkT2y679BJTkk2LRCYoEIxOM9NTOkhy73cJWk2e+ocPc2SkjMkWhGjUGHM9HKlQaHQhw6t/5mcorlhNb3Gefr3C4jPPcuLFA/SKWWbbltk+NA2otqE45mJkSGwMZCXGt3z4Ax/ktjtv51d/5V/xkY9+gq89vY9ZHdPRlrLnkpdJ5JwwGmkMMuX5Jukx6WBaJjbgvnSY1RE5JNNCE2lDJATSDPbrghBB1xi61lLTmrqOiYDrN23il375F3n2qSf5/Cc+QWHIZXSiQM4TFB2PMenQOttk3XyNG4pZtq2bRLdb5KZmuPYH34IcGcXJZ8F1sVaw9NTToqe1Q2zxlyrc/8fvgYkxbthxMwJBJ4qIikMMD49yul7jpRPH2bZlE6MbNiCVTEJbEcSxRomEIxbGSTIxInFW1hoNhkpDFEolOq0OPT8gm/WQsbDKdWSn2zm852/++tx9u3Z5O3fvjsTuvfHuf0aCzj8LWVGA3ZVaYa0SQmuDNhapBAKDEjJVVCSapNhYuq0OQRgihEpeaJ2Msa0waUxXsmYz1ib3eGMwqThNJRt6tNV4Xo4Vw6PQquPXG2SyWYxOTp8g8JnZspWRDZuod1rk16yjvHUbU5dcSeev38eLX3uY297wA6A1p154AWMiVFfQFg6LcUhTOXSygr7j8sADD3H23Cw/+JY3sXHLZj7/wIOcqS7SiCMKrkNJKnJS4UqR6HRNcioKm+iphJV0BTSMJi8UI8Li6zRYyFqMFETWElpNz1iaRtNKFdVTo2PctWMHV15zBZ/79Cd48alnmBwpMJX3KDZ9sgZGHE3OzbJ+ZjWvue6VDK9dw+rtV/DsVx6m1m5T3r6dc6dPU4gs9TMn2fvhD7N4/Bgjmzaljh1NPgoYHZtESkkc+URRRGl0nGK5yJln93Hw2Wewd7yG0oqVyEw+CSI1YIym2++QtRlkpog2yQ5bZrIIR9LxI6IwJl8o0Ot2MUYny0BASZndBXJnMof4ZwfQ/XOjRy2xxTpJU67jGEg0XGEQ0G+2mVy3kTt//TfQ3RaPf+KT6MhHpNmFSSMvsGGIMVHK6JXLd3IhRAIbFxYhFWEUMrJimtf/2v9Fd3GB5z7/RepnTuO4Mr25CaxIZOSNapVPv+9vuXj7pVx9+x1c+vrX8vz+F1n56lcxsWolZ373Xcw9+wQbr38FN7x6B/u/9nWOHNqPlytgpCLI5ajtP8jj8wvceOutbHr7D/OFrz7KMweP0gj6NIjIIikIleTECFA2FSdagW8sHSx5KcmgqVhLlA4vIqvRQGghTCWhGUexIpdn84pp3vjaO8gj+dJ776W3MMt15WEKQUzWCi69/hUMl4b50gMPceu//knGN25EZLJoo2k127QaS5zdv5+//S9n8MYm2fnjP85io0nvpUOMOIKsVMRBRK5U5s5f/mVKq1ZjjeXk8/shjplYswpr4aKJGSZvuoVep4saG4dCAev7IC0yk4HCEENr17BQqWOjEDE2zNU/+wuUpyaZe/wbvPipj6NNTDFbII5jrIkTcr9B/2cw9/wLcaT/5di8NpnfO66HH8foXpenv3g/17/97ZS3bGaoNMzzj+9DCIXrZTBpPrZ0FOPr19M6HtFtVhgSYDFYa/C8pAG2qVxciETy4U2vYMX2yzh55BizRw6nc/bkuhaR8GVVZJl97Ov0D7yI0OBkMmgliXwfP4yQuQxSQHZiivFXv5oJbXn68FHe9tM/hd9q0zp7ln6zQX+pyrE9/0BpdIzbC0WuWr+KSr9LPdLU/YB+pIltAlazFoyS+EbjGEPeCqzQKCtwEHiQpr9m8ARkpaDgKrI6YtLLMJ7zyNuQ+ic+ydFqhYvXreeS23+SuZMn+fqXH+byt/0IO37mp9j3lS+zEEWI0TH6QnD8649y6pmnqZ86A7UqWSJOHDnERTffiVQSx5EUi1l0HKPjmCiOUMUiK6+5hm6rSxCFXHTZJbzwxfuZXrUKX8es3LQeIQTtdpfhfIHi+ARGCIIwYvOdt7PttXcyMjXJwd/azfED+7nu9tfAzGoCR2KEZHp8gl7k0/J7FDPZJC0XC3KQr/Av8/EvUiDiAjl3YpMUZLMZZp94jE8fPUph1RTDU6uYPX6E/MQYY5UavWaLxRMnmd68mZt/4eex3R4vPvglzp0+lUQb5LIYG9NthURRnEAVlMfpEy/ytQcf4tLt2zl16jTK9VJJeXIiqZRuki8NcfUrb6R++BB73/tniEKe0tAQrucl+wmTJEzqWBN3u/jWkB0dZfjiLcROhrVuBqKY2G8z98RTPPr+DxGHZ8hlc6xwFNMSMiumyOTzBL5PHEagYwK/h5IK6yqCOCYIk3t7MZtFSIj7PorkWql1hFAOF197E4VVK/CGhsiXylQOHGDvxz/OxFXXcsXbfwz9xS/gPP0sW258JfVqjSce+BJRkOSz51zFS1/4HJUX9pPJemRzeZxslnI+xnOcdD+T5JInN6tkTB33enzmQx/hbKvBj//iL5AbGyfK5iiPT+Aqh8e/9DAPfPlLvOaNb+DWHTcxuWEds3NnkRKc4VGCXp9Thw4zEvR56pOfpH7oEK6JkFFAVK8y7jmUC0N0ZRcd6TQcTPIvjYP+lzlBROpZkKlv23HJegaUQ36oiK7UWTp6nEzY5+CnP8FT9z+ADgKe+cxnCLVm6qKNTK5dy/ill3D4pYPEQcDayy6j/Ku/Ru30KQ59ZS+hHyZps70Os48+iv/cPjJeluFsJtlgS3Bch8bsWWqLC4yvXMmd7/xX9Ot1Zvc9zZOf/BihEKAc7PLDLJWFOAkJxZESqw39TpOnX3iOcrHMyMppVt50E5dX6jzxyT1oKYlNTLvn8+qdd7P2yqvpdbuJfzwOac2e5amPf5x+dRHhZoh8n1e97SdYefFWpKd44fOf49hXHyabzdOzhh0//Q5WXXtdIpIXliCM2Lb1Up578SCNXptu0KPW7rD5FTcytW4t+598isqRQxRyOUw6ch4eHiW/dRMTazZw9sB+rB/gaIsxMdYkvm4hBSaymDhVGPd6nHrkYRr5AliItcXL58mXS0R+QP3re7EvvEDlku2EN/iMjYxy4KuP8Ohfvw8bBVSPHke3GxSEZcjNEJ88inEdcsKSNxHN0CeIY8q5AlYZor5PEjVpxP/nCsTagXfagko4tIGOufbHf4a1N9+E7fpgDf35WWqnjnPsyX3MvfAiIuhz4B/+nse1Jr9iJdlckc6ZM7z4pQe46OZbGb/0MjbsuJkglBw78BxCwMToBFdfdw1xdYFevYlj9bJPxfUcgsoSe//8Xja99i7GVq2iNDrBpje8EeFIvrrn48ubfrvcIQpQCaDBSoFVConkqU9/jsbp09z0trcx9YNvQo+NEjmKIWExJKPoWCnCXDaRkXguUkhWrb8IJzfEg3/6HhwMslRm5orLsaUSwnOY2rKNE489RqBjsqtWs+LyK2k0mrz4tW9w6swJbrjlFsSKlfTjmCHpooTCKw+z9eb1BCbk6GOP4sURViQx0YE2XH33W8kP5Rkqj/P53/5tWieOIYUkjhPpi1CpI1SkhBMESMXEyhk2bbwYz/VoBwHZ4WGmNqwjqNbIt9rcsGYljX1P8OnD++mfPs2kEIRPP4FFMzY+ycSlr2RowzrKk9NkSmXIFjCdBi/c9w9kqlWEtLT6HYZyuRS4Bwjh/n/winW+Z7dCEkYxxvUY27KZ0FiOnjzBM088wZrVq9m8bTt33fEGTj2yl8fu/Yv/p70zj5Kruu/85977llq6qvdN+w4SICQE2MJGEh7ADg4YJ0jGNs7ES+wkjjPZk3Myk0aJkzOTxD4ZExtjJ/GGF9SAHRBGGGPUILMJEBJSa99aLXVLvVZ3rW+5d/54r6pb2M4kM/EC6p9OHUnV3dX9qu/v/bbv7/uledkyWpct43hvL7kzZ2iUAbvu+wa7dzxF/ZxFtF20nDNnBzjb18dIXx9zL1nGnMV/TGUyz+ldO3nl2w8gRYyBCiGRTFAeOMmTn7kLnW1k0Zo1vO2/vo+6ZcuR2fqoYIyjvNZRJ61a3PvxSjHC0JFIkBAaN4xogLwgRAYGHDBxeRkGGtdNsO+5F3hy61YuWXMFN7z7VlRjI6RSVMaHaZy9CKuujrJXRuCQmdWBTLl4hTxSSPxQY+mQVx7dSm7gDJWDh1COzdCpfmZffjl5r8zi5ctxEy6Dx44zfGAf9UmHc7raItekWluolIqc2fUi+dwIUglCz0w1OkS0vqqkiGhIAx+VruOm3/8Dsq3taAEv73iG/ESe3m3bGDm4n1J+EktatJaL5MZHaV+wkLSb4PSh/azceBtLbrgRzwhGB8/yysFD5EuHWPdfriezeAk0tTB+4iTzZnUQhj5aBxGg1cST4AvKQWRES1PlpDKA5dh45Qr58XHmLF5MUhsGfriD3sEhtre0sObGt7Fw+QrGkkmybe1c+r47WDKZQ5Y8ihOjDB3YT9+uXZzc+SwHnvgebl0G5Qc89sUvs+qdv0TzvDk0tncyb+217H7sUWQhj7QVuckCc695C+veczu7Hn2Mp77xTUoNGRwjmTCGijSEJqKRjA5NdVZj4uUmEcNFojutEgJLRCyKEEEltBAIEc88MCgpMbkcuYOHmGhowLIdwjCiNfUDQ+PcOYiki8n7hMbgtjSTamimkMtFuig6RAhBS0OWNqFJKklhbJiMiJ5XBrAV0rEYOnSUIDdBOp1Ch9EQ1bZtnn7wQU7v3ImaHCMZBLhOAlEpgQlq8yRtTKT1aCsSyQTYFkFJcuZQL4eeepq+HU+TCjz23/s1UokE6WyKwNcMB5q3fvRjzF69mokjx9j5yd0saWin7KQoDZ/lqXs+x+DpM7Rf+SYsN8Hw4cMUTp3GdmxGxkdJJpIoCcRQJCOt6H56552GzZsvAAfRceiOWQARAulYuH6Zp770JVZMjDFnyUX8/j98htLoMP1HjtK7axff+e538cdzdKxcyWR+gtAPOXj4IBjDwqvXcs2Gt7Hm5Elevm8Lxw4eRCYcJvfv5ZF9e7AbG5m1fBmt7e2IIMRSFiUtCLSgVK5gmppZeOMNkEpgpCI0euqwhWFE3iBjNSshIsYRLbCMARNEApe1pagY6GyiHZjqZofR0c0gDAKaZnWy+srVdC5bWmOD8eOhWsOs2Vi2zYkzAzQ1NrCwo4Ps3Nn0HTlEOp7zGMvmHR/9TZRtk8xkyB89xIN3fQZ0EDmtAN8PmH/pCvY3NxNOTEAkE4GF5PQru5k4eJiW5iyW6yBExEIvhUAoRTKVxDcGR1gor8LBHc9w9tQJJk+dpDg4AMUySWmzaM1qlrzlzchA8/x9XyMlLSY0VBqaKQJlY5CWQ8UrQxBgWQ5v/42PUtfSDMkUFWOwkzaWa+MkXGzXppQv4FgWiiq0/eergvYz/+aBFMaAsYTAKJC2QIYaN5OifnY7Lz30CFvH7iXZ2MicJRdx5XUb2PiOGzn0g+1s/dSnIr4jKbETLmd2vcyBbdtw21q49tc/zCVvXstVH/kgg3/7KYLRca589y24jsNQ3ynO9p/iyO5d1KGZkAJtpUikUpzd18vB555l2dq3cPV73kcQVCiUKygpqYRejZml7HtM5CuUyl4MdQlra7HEhxIiulEh41lMPOcwka4MEkHFqzBrxcVcfMUVlPwKOgzZ/+JLlHM5rFSSbEcntm2zf89eFi5awJJFi2hauBS5vYeJoSFOHj7M4ssuRSVTGB1QCjQdV15Ny/KVTBRL2I5D/+AASduhbc5sLl7/NnZ2fx1V1xhFBh3S3DmX1sYmll95Fa6l2fWtryMxoEP8YoGBU6cIwoCkEujBfl782j8jtSRpQ8p1KTsOY4kUl3zgA6RaWpk4fhxpOfh+NKUJfR+kQNoRRi7wfTQRwrl/ZJj9T/ZQ0iG/cvt7yc6eT+PSRfR9//vMntVJJpvBr5QxgYlYcIy5sFIsX0nXF0KEfhhKHWLZUmiBKJe1XH3jO9iwfDkHe57i2e8+yu6HHsK1LRrbW2lcsYKGufMgBKEUZa/Cmrdew2xbcHLPPly/jOeVCNNZwkyWusZmrvzQRyjliyw1AZYweOeGGNy3j1N7dnNm/2HKlSLKcnjhq1+l72AvTYuW0NzZSX1zG6/sfIHc0Dm8yRzCllz1y7cwb9FCEm3tBF4ZKSMK0dpuedxankJXRmBHaaKFKQQRJZCyGB4apn+yj1QmQ3t7B47loMKQTEMT9Z2dBL5H7tQZxlNJjNY0zZlLIplCVIp8757PM2v5paAkI/k8N/7qr9LUkCWfSCAqHmk3Qd+J4wyfG+Zd77qFizas59ALzzF6+hSu4+BrzXV3vJdEXRqZbWR8/15CI0mmE+SPHeP+T24mf/YcyguRLS3MmTeH0b4TFD0PW9jRzEn7+EJQrHjIcoHQL0cdDKXQQZQagsBIhR9LdgshCCoFnv3KVykWSyxZv45kfYZKpYKemCSbzVAo5HXatowrhPEDXxspVWhbF8YcpLetLZIv0OLR3S0ttzZnGhJpr4TrFRHlIhQnzOP/8JlwwY03igWrrhC3//mfS+2VCaSFZUtCz6JsQqRrR/gs38dqbWfpe+9g5XslWkUPW9mUdEg2XUcuN44f+Jw8coxXn3+Biy67lPkrV/Pma9dR6Otjz4MPM3B4L05Y4fSTO9jzyKMEjoPKZAkKeVq1ZOdDD7Ouo53Oyy5j3upVlAtFjJRYlovRkWCnADLNrRT7zyBir5BSRb5So0CKhHocx+Hwrt08fO9XWfXWt3D7xz/B0isu59WH7qe+rY26xiyFfIE7PvgBlGORy0+Q7Wgj0dgEw2epq1Qo7n2RydwEQwF477wJW1o4RuAHPhXt06QSbPveY6x989W0d7TzplvezbHPfJr+I0do6pjFRLHIiSOHGD55kuFXXqGczyGFQleKeKPDJNJ1vOmOO5i7+koS6QSP//3/RJ/qw3cgCEO8ICLRlpYVLYPFDxGGVFuExhgsxyKM6DhRSpHMNnDbH/4R2ZYmQstmsPegOffiD7V/9KDJ1KVUUUuZUxZhqo7xFkUxlaiMlMvdAN2bNkl+OrozvxgOEq/rivufe+Grb33nO3cs6Zi1pk4HK5xKZZ0bBBcn/XCWzI1bLz65nV0927HdBJnW9rBxdqdJZrPyXP+gKA0PiUx9Gum6OBp2PPCvnNj9Mu2LF9Mwew51Tc3khocZOX2K2R0tSKWwLIUulzn91BPknnmaJy2Xd3z8t1l0ycVc+Zsf4tm77mIyN86m//4HjJ4+zbnDh+jfv59xv0JYKDD2ym4e/V9/T8fVV5Nua6dt9izS6TQv73gKGYY4iSShCbn+ox+iVCiglUJ7kea5jmcnVb6wSCxH4oYh9WWP+mIFqSKGRt8Y6mfNjtq/vo9qqCMMDSI0JOqzpNrayJeL3PZHf4IEnn2gmyWpNA0NDfhak3BELO2maMwmqRsZ5uUnnuSX7ngfLUsWs2DBXHbe9w0OPPM05wbOUh4aoj7lMm/+fJZc+zayre04tsuBHz7NsaEhWlatwjTWMzk5SWCiCKCQcV2lo/a3khgtEEJSyheoVMqYVBo3mcR1EuRGR7AN+BMFxs4MMnpuQJuRUbP3B0+YkdN9imJBpNN1ypo1nwHHZRxxuuw6ewtGvDipzUsHz43seWbbtqOA+GnD2n9hsFgGhHjkkWM74Fjt2Y0b625vbriksT5ztTtv7nrL868ojU8szI+Mqf7jx5DFAgnfo1WJcOBAr3GefUY2z18kbeOTHjnL5MgIp71nIlJpCSlClBUtLSGiVKgjm6UewcBknoQwhL5GJ1KEHZ2U83lobaW+o5OWK9ew0vPQuUmG+04yfOwwA3tf5di/dlNULla6DmFJgrFRsk0t7Hqyh5b5C0k21FHX1IJlWwRehSN7dyNhSkvdRNxVFb/CrCWL2XDrrbQtXIgJfIQ0hNKifs5cLNuh79AeHr9vCzLh8isf+SCzFiygfd58Bs6cJrV4MYHns+G//QEqaRGEmtJkjpG+47TMmU9ueIyzR4/S4doMPPMUDw+cYmxwCKswRjaoMHn0MAsWX8SSm29m0ZrLybZ2QCJFYELCYpG+/j4m+vsplyokjIkdONqnN0LUwKCOjFYRQkKkbdO66nJmLV5K86WXkWhtpu+lnex74H7Tagt96olt5vj2bZZjOdJyXajPopvb0QvSZ8ZT9Tsng6BnwmLHFydLvXzp3sJrZmYiIpS6QGoQAaYLZO/GjWLFihXiTtBi8+b8t+B5osddLFni3r5u7Yr0nLZL3HzlhlQYXi698iXaq1i58RGe+cpXqAgQ5UrYYCVRtpSJhBOtvFuSYiEf4ZmkoBL6mCCgnC9Rl0yQcRMkbAeUQGIohz4+hiAICH2f3ESOrfd/m1mdnVy8ehVLVl/B8ltv5eIfPscLD9xPWMojZRKnYy5jQ0P03P2PkE7hNDWSbGgm095OKTdK6egRWhOJqCOGhUTi2g6WbTPvkuUsu+pKvDCIlrJGx9DKYu5FF5F0EwwdOgyHD+C7DrnBsyxduZL5q1by/He38sJDD7H8mmsolUuUCwV0qczBp36AHhxkrFzma3/xZzA+Rn3CQXkepb17SNkWFd+QWbCMGzbeRsPihZTLFfoOH+bIY9/HwhAWiwwcPIieyGFbDkEQRHg2KXEsm4I2FPP5aE3aslAiUuRybBe3tZ2rf/2D5EfGzeneXj2871UzfviwtKSUTkenEg2N5NwEhXTquOc4h7xUosdXiR1bTkzuHt1298R5DtHVJe8E2dvba1as6DbTRZIumEHhZtBVKd64s13j37qkrc1s6u6ufOvIkV3ALuBegFve//6LZiUSa1KzZl8vJnJvDkZHlydzOeWXivj5PMILjKNECEYmbUecPXFMjA8M0rJwPk2trTR1zsEbGaBUjAvKmBq/EhpKfljTWU86LmKgn4M7nuTV7nt5++/+AYuvuYbOt13HspExXtjydZZesYa3fugjTJ7qpzB0jqH+4wyfOsPw2QFGXjiOqZRJ2SpifbckQaWMC7zyxPc5cuoU6UwdiVSSVDpFpVhk57ZtJCxJ/5EDnD7Tz+DevcxqyhIAR5/cTnFkmNyJk2SUYOc37+XFRx6m7IeYchnbhDQITcayCUaHsS0LS9ooI1FS4KYy+IHHRMrlrR/+EKnODkqFEk984Qv07d6FkoKklLhS0Og4BI7DZKAJdACxFELgh9iJNC0LF7L0qqsY7z/JCz3beeprX8aubzKlsVHtDw8j8zmVTDhKZurRl1xKLp0Z8tzkM9pN/GDcZscX8pVevvKV8vSzsGXjRrVvxQpBrC8Ss5D8XJ3ixw+1f7FMdHV1ie3bt8uPt7WZ93R3h+fF2PXrrU2LFl3i5PPXWpXyTYlScW2qVGxoKJdRExMor0SlXAr95laz7Pob1cLVK0Vrpp7y4DnO7D9A42WXIhsacVybbffcw8ihw9z+N3+DLwzKGLJ2gtLQOU4d2k/T0otItbQibJvDPU/x/D/dQ11nB+lVq6jvnMucJYuYPWcOBAF4FSw/oDSeY/z0KXY+8ACV4gT1rZ34hRIj46OUSiV8EbGxCwmh55FxXVJ1dUxUKpQDDzvU1NturE9iKPoeQcUj29xES/tsRF0ap76expZWsk2N2OkEdqA5uetFTuzaDUrVOOiElJQ9j0JTC+/5sz9HOBaOsnjyHz5F7ugRhONiaQOBDybAVg7HFfzy7/0JcxcuRAcab+gsmcZ6RDpDcSzHq9++Tw8//6wObEeOhchEYyOJ9nbC5uYKDdmdeek8Pxb4PzhYGNq5o3vb0E+KEN3/j1xVFwbc/f9Sq8RqRbrK8V7l4gLY1N0dbOnp2Q3sBv7xTTff3D6vpWlpLgx/KVnxbnSLpcud4qStRsd48VvfZPfWR3TnRRfrOatXyjlXrhJ2XUYIqaLDUy7FGoXgWBaThQkeefxhrrnuOhbfdBPFyQkKE0WM1vSdPI60LNR4joHHvkevV6Ht8lW86+OfwAjIT+Z59eWXmT17Nk3z5lFKpBBCsv53f48QgZiY4Lt3/W+aZs1mzc2/THEiB2HI/qd3MNC7lwbHpmH+Qi5evw6pXCr5PC8+/B2yjsuSm9axeO01JFvbcZJJjIF8qYKwFOm6uqit3FjP8VderdU+ETt8WNvzBxPpE2JwLQUmpFwpIUJJ66L5XLJhHd7Zs5x6dBvKUghLkRseIp8bM7ufe14PHuw14dCAZUsh04uXSJqbSWay57xk+ulJ23mkXzk9D95997HXU4R4vTrIj6Zl5xOAia6uLsH27TKmkTz7PJwFdgB/fuPGO5bUpzPXNbR0rnW80g1OvjBn6NRJebp3D09rSDY1h9m2FjyvLPMHD4nOuXNw61yksrDLJfq3P872A3u55Y//FDvhMj4ywv2fuxtrdIhON5r+t9XX0VxS1FlOtP0mwJQr7Oq+n0PGB9fFKZdonzWXohQIJ4GTrmNMWWTqs2QuuQxZKKAcxZsuXsGOz9/D0ZdfoOXqa5h7/fVUvIDy8BDjD3TTsXA+V9zxaxQrHvn8JNu/8U0GDh9mbHQUN52ipaWVUrFEOiiRFCERAjRWp5LRRqaoCo8QMTtOTBbwA4PV3MxV77yZy97+dnypeO7uz9JuSfZ3329eMlqP9PXhlYoqW59R2VmdWJevppzOHB11nSc8x3pkr5V+esfdd49NL6rvvPNOVY0QP6/u0wXnID8pwsQ6IrUa5i97eoLvdd97hEi//outv72xbsNE09qmztk3JANvgxkbvTTI5ZPDx46hipM0Gm2Cs2fD57Z0q9aLlws34TCvqYXS8RPsevhhrrn9vcyaP5cNa65g39aHsd10RE+kw3ijMaxyIKKUYk4mTdavoAUEsVKsEpGUmw4jKEgYBlQqJbxyGeGDSris+9hHyf3dGJPjOUqlSqzV7uGFIYHlUiqWCXSAKXsMvvAcHe0tXH3deqSbhESCxo42GhIJdvzLFyJgo7RjQuto70UqhUw4CKEQElbd8i6amhqo65xDJQjZ88NnzIEnvmc43KuzaVdOnjkug2yjartsBX62sWjqMy+PSfGDc5bz3XuP9b3Ctm2V86JEzHkbF9UBbxCz3iDXYV7LHbt9/Xr58bY2s+lz3flueJzowXs+9rEFmXLxBqtSvskultYWSoX2ZC5nHXqqh92PP0bSZEFV6wAAErZJREFUcUlpj8a0y8knHqdp/lyWXrWWazZuxDt9mjP7d6NcF4XEMyaiK4qoViLZ5zBAYrAshQpUTc9RWJHgZm0f3VIoW6CDSB5C12dZ/5u/xaGXd6N1iLQUluPE6Z+OSS0kUkpCqbj4+htZtm4DE2Pj1Lc0RQyLo2OgbESsm2DFtY6WEr+YZ/jECVoXzKdYKeO2tHD4+DFOP/Y9zh08QDgxLjpamkX68tWyXN+IztSdNen6pycy7kMjjvPUv/z1p05Of8O7utZbvb1t50eJ/yTRoxkH+Vl0yXp6qvVLLbrc2dMTinvuOQF8Efji/PXvarhmVsfl6bbW1dmliz/RXs4vLJw6QXE8J0I/xDUeL331Xl55cgcdSxaTamkGYaMQ6EiZESUEtuNEDIcikhsmNLXpuZma/kTT9ZixXRiwHJdTgyd5ddcubnnXu0m2d3DF29vwggBpWUglsS0ZR6joNUMd6X889fVvcv9XvsSiK9ey6Td+g0oYYElNEPix8A4RFxcCR0oy5RLbP383bmMjXqnM5MQ4vl8mka6jacECsgvemgvT6cNDjrt1zDc/3NGXe+nVr33hR1Knai2xeXNPwAVg1gVwjbXosplpzOQbNmixefP4yUigrudjt938Jy1Njpj0HH0KKRxtk/STOCUf3X+Is0cPkJWSZluhQ4HQGmUElfwkw/39ZDo6cN2I/REjCHUkvmfJiH9ZG0MYBlHnKgbuaV/T4CQ4sPUx6gLNdbfdRrESoKoURzoinLOUhe26eKUibsLh4quuwhGaTFMT7WuuxkqlcAsF9ux4hsLkJAkr0uqT8fQ+FAbXVqArjI0O4Lk25ZYEjW1tLF6yMBTN89XuvtHHv/z5f954XoG9ZaMC2LdvhXmjpU4zDvJvRxcTVbIRr9l7rt/wL7PTpnP03Ek9MDgkhbSoSE3RMRhH4jRkcbSkFBrGAk2qEuL6IQlLYQ2d5ZFP/x12SztJW6FLBZSSEXJWRJQ3oR+SyCSwY+4vW9kkUkmUUuhimoX1SQ5s3Yrtulx7663o0CAtGxmEOK7LxMgg5/qOk21tQ6XTrPvwhwg8j3KxyNjQEDsffojju3cxfnA/jZaNjyBQEm0pfFtScSxKrsJ3FKESBDKiPs2XJnHPnVKLXRXOb2j81Zs2bPjwd7dv/2cpJddee621aVP3BecQr5c5yE/NukDeGeEXzHXXXXvNwvrU3y3MimsmC8P6QP+gNEJgGRURUBMrNhEL2hhBEMPYbSNR2pAMBU4QokoVjOdThySjFa4xKKOpYKBjNqq9jXQySf9zz5FpqGfJ9Tdi1WWpjIxyaOu3yWjDuYrHwuuvZ84llxJqTWlkiN4HHkR5ZXQ2i9PRjsEhP5mjkp9El8qImE0SS+DWJfAthWdLPFtSsQSBJWoM8kCk1Q4oE7H8hmHAso5mM3/+IoZ1Rh8dnPxi9yPbPlkqlU7HvLfhjINcOCbjqKHef8vb/7qzIfEnnalAnB0aDHv7zyopIryRiHdstaiSZEc7IUZETOoYgZZV0UxJKEGaSIlWhAY7jFIbNwBX+6hKSOBVMEFIQjkoHVL2NKESWNpQb9kIJbG0Ie97FG0VYbc0ZC0LW0WI77LxqSDwlUJbCu0ohGMR2DJSs4oro+rOPSJKEao6PT8irhpXNkHgs6i1kQVz56Ea5tA3Wj778r7DH3lix7Nb/6OinTMO8vq+VrN27dr5K+e1fXVxS2Kd5Y+ak4Nn9bHBYSUshYWqCdyAQOiILFrHKNzawau9oKgN4IypyqZVKYVMpLgqo808KeNoFEbyBRKJjIm4o1oDUAK7JsFmCInYFE1MhCclhLK64hsP/ww16empxa143hE7CTFBdvTvWEgUHbGXEIEpQy+ksyHNRfPnBg2tc61hL8lLB4//4X0PPfrpC9lJ1IUSOQxw38UXN795ceczy9usy4v5Qb/3ZL8aHBmXtuOAkITxgLd6pxVSxGK9VXk0U7unVGWbq3ofJj5/1dVbS8jYEWK5gliXUAtDKMAXkYahJw2hgtCWBAo8JfAVeFLgCU0ooyVejUaLmLIz1gSXtbAYtYBFHBWEFHGEiDmP4+uQVfI9ItzZeQfBUkwWy+QmJ6WtK7oxZevZs2e/o76xPbnl2995vKurS/ZEtduMg7zh6o7169V1J0/qd1yx+L+vXJC5+fjpE17vqTNOxTckXCdONKakmKsCPxGiOzr5Itp+ig/ZeU3c6BD+mHA8/fVEnN+J2p8pZ6pGo+or1xwUUXOG6DlRYx0xVVXb+HtHnhwp7UafI+Ofe+onmfJpMbXMFT8AlLIoBpozY5OiODks2uqUTqUz1xYq4lvf3LJl+EJ0EnkhXGR1m9GxgtV7Dh3QR08PSSMslBRoE6Ik8UPE2h0GiLT/dEyXM/0Qg556TkyLKNP+ff7hE7WPCynO8yQxTe+59hox24shYhcx014znkmc54ZCgYj0hYm6sZEa0Y9zDqbVIFXW/NoDjVTRJmTfaFH88OU9pjGlzZuuuuS6C+m8XLBt3knfHUxgS8e1I8ENExKzXdeoeVSc14dGoGLhHl0jzzZT50SYKQFnEZW7GBNLMkfFfC0No6oXb37kgP+456pfEzUNqpRBsVyblHHtEUsgx5RE8YsgkFP69MJMc+o4Baz+31CLmtX00AiBNGFEt2ODch0Rqgahdf6l2p3hAuzqvOFtxYpuA4iiZ3/aruvwbcexCbzQFk50CKsdHymxbRtLqRoNjozPhZQCpap3exPTkMabdkagNSYIwlAZbaxY9Gfq8EcRR0oZ65ao2kPEW3rnuUb1e8monoi2+qJYIIkpUKWMCBRCbYyOZYWEOi86KfOj0cnIKktkVJxXc0MTE0yYuBbTgeetWrVWjXrmq3d/+es7t2zcqDb/fyrGztQgv6DW04Pp6uqSX/zKV84uWbx4d2tj023KVKzJ8oRvNMIYIfS0u3CVGrWa9yspa2zx1RMXN5+MCX2N0CbhKNnS0Cjr6+pEpVwh0GaaKNBUx0u8JrWpVQXitb3FqZ8DM518DgIjsC3BnNYmEo4rpDAiCHwdmDA01dom8ojzxeNrRYiYXpDUTBttQt/TrrL01Ve81Z4MEzv/pfuRjZN/+IfhpZ/73AVXoF9obV6q7cp3/9LbbpjdnP6CrIwvyOXOkZssmCAMw+huLqSMuXiliLRLjDH4xoA2OgwjOV7XdVRdKkkqWYfl1FHy8QKsV8r5scvK+XNJL4xwWtVuUpUeaHodUXUYGadN0+ua1348qrkjwZ3AgC20WbrsUjFaEn0EFVsJv1OZCqVinmKpRMnztTE6BriLuL6X8cuLaovYRNEt+ryE41rtLe20zV5KUbvfufve7g9NTEyMaRMJT884yAXkJPXz5zfc9qaVv5Vy+KA03lIRlql4JQLPIwh8tAmjrpOMDqitbCzbRlouUiYIjDRGquOVQD0zWfCe7D83tmPHzp2Hbl2/8sGELL07X6iEQgpV601F7DfRvCSmK5VS1JhnjTGRPqmpFQjRx+PV4CpvrowPt0QHl152pdU76P/m/c/13fvOy5rXt9Ynbkg5Yr0J/cW2DLOEHr5fIfC9mPM2JDRgtKldl+s4JNwUdiqDUMkQlfrhwFjps19/4DtbziugLlATF+JFd3V1yWn5tPOBjbeuzbjiCiX0VUabyywlbBHXo6aqwhtSdlynt1QJj1YCtbdQUa92P9R9GPCnFdzi9utX30VY+HihUAmEFNb0TpeMYR5VskARD+6mIkqUTpnp7d4aF7Ce1uIFof3gyiuusvomrA994d77vzT9+q699u2dC1qt1WnXnq/DYLVSYqUibJDCEBqatKFRSSZtyx7SRgbKcfdWArPj3Fj5ie6HHuqtXouY3ga7QM26EC86do5Igbenx/ta93d6iFC9/2HbsnGj+uy5c2LD0JAUQnh33HS1G5QKaKNR00q8aidKVBWx4rG7lFU0/FR9U1W/0noq5RKyWpeIWkmhlEVdpq4IiE+84x1OU6kU/uVTPcHTTz828DQM/Lift77+ssb2dtEwMVHMDw4eGX6tAxhjxKZNm6QQ4oLGYF3QDlI9C1Wp6hqjysfbzHvec39YxZOY6WFWCP5i3ToLYDuwIVr1rerCs2H9egtASUuG0zJ2Ma1TFE27pyAi1fSqqpUSRZCIzGG6lnrNSarTcBNFEWUp0k6yCJimUincPCWNXLsmgDu3bw9lXOHncq+O5XKMTTku3HffRrXvs+dtBM44x4yDTDlKDWf0E2JIdelp2gGk5ydtz0lH21LVnCs63xphIrFQqhgqETVtX4vtUipC4hsRp1WvzYJN1DaO2s6KsbGc/W9eE7D5/CmhmF5XGIPZtOmNuxE44yC/YFbx/TE3jhTn47VMDelYhYKIabOSKuDRxNoiQsjaKTavcVZjDK7jCIEy+fGJIZhCC/x7bggXel0x4yA/B9se/62E2UMVJWum6o/pBXe1NxIpVlHDglVTqqi9HHmWAYJayzcCJWK0cR1HopTf2NJxDGDFihUzh37GQX7xzQuF5ygbXSsxNNRAhlNw+enQEhUvbJiorzwFAYF4aj9VyMTKcSRTSUJhBT/YvbuaSM28+T8FkzNvwX+Obejp0QClst7j+aGnpFRTFb6ZauPyo4DGqgOZ+PMCowlNBHOP9anOw1wFWptMOo3jJPp2P/fcgAA2b77wcFIzDvI6ss3xDX/NhmcOOa57ylISIdAyHsgJ8aMjp+q0XBsdLWpVU6nzCvLIgUxM5RNP1E19fQPayJOA1j9nFaYZB5mxf7+jbMYoyxJKqdrWn65yZ2F+AmQ9TrWkxJayJj1dhd1HEUbWamspjEml6yj7wQmAO++8c+b3OOMgv/BmtmzcqECYUJudrq0wWmuBnJZOTb3dNbllKSNCOaFieWmB0dNBjLKmkFvtetlKka7LMj5Z7p1522cc5HVj+1ZEg7lkXf0ryWTSIMJYrtDUlpfOQwq/pg1chaALKWtOxLQlLQAdhqTTKWWkS//gyMsAvb29Mx2sn5LNdLH+E623N5pF5ApBb9pJCsT02qAKNZkiXJi+2jtVhE9fsqpGm9pXo4PQtDU3i6LP2LO7Xt0DEMsIzNhMBPnFtu7ubgPQd3psZ2BEzrZsaYwxGBkjeKeK7qlV3elFe8SlG4ZTNUvNt+KNQm207mhro+KFLx47diy3ZcsWxczgb8ZBXiemt2zcqJ5+6aUB5SRfTCdThEZrED9CkFCdi9R2yKG2FFVlIakOvYWpkkpIUgnHNLfOplAOHwXYt2+fmHnbZxzk9VOHRABBoY18IplOYkJjpNAgTG319rzKvjYbEVNQE8O0oGAw8TZjGHq0t7Yo3zj+/qNnHj6vOJmxmRrk9WCbN/RoejATk6UHG+tSn7RVPDCsrdVW27fVCbuaFi3Orz+qnFzVYSNah4sWLpOTHj3dDz98xBgjf94ilzMRZMb+gx6C7urqkt2PPXNYWqln6+vr8AIdViHq5zsL55UP4jU8VhhTo0E1oSZbl6a5dbY4fmb4nwDuvHPDzO9vJoK8/mz79u0SCCYq+tMNmea3jIzmatGjtiFopuoMISRTw3CDFNF0vcqaooSiElT0siUr5Egh6P/Hf/7a1njjb2ZvYyaCvP6sp6cnMAbxje98/zt+qPY0ZOtUqE1YXZYyhri1O52wQccT96l12+rCRhgGpFKuXrT4UtE/lLsLKMRiNjPdqxkHeX3apk0bJaBLvvrTZKYFoUNTPfxRx1bEBA7nszTKaUyL0XahIPA8fdmKy9Vw2Rz51sP774p36meix4yDvH6tu7s73Lhxo7r34Se2VULngebmRiv0g0ALgTDEOoLVIn1qNSoiidAYHf16yl6FttZm3Tl3udhz9Ojv9Pc/V4rlsGeix4yDvL5tRXe36erqkmcrzidksmUgnXIsE4Q65nR7jU0nk5MIYWFMiCst/81rN1iHTo/e809ffvCxrq4u60IXtflZmpp5C36KtQiYtrY2+dBDD03MnTvvpfpM5v1BaVx4IUgpxfkQ+BrZTwwtCTGh769fd71dJPPY//jbz/zali1b+J3f+Z2Ztu5MBHljpVrr16+3/vWxnu2loO725s6lKuFaMvC9wMQE0lMjkMhBgtA3wvf9t1zzNntSZA996p++8X4hhLdv36aZffKZCPLGs5MnT+r169dbW7/3/X3LFi7prW9suCHpqFSlmCfwvUBrrbU2OgxDjfZ1c0OzWr1mnarIzLP3fXf7zUePHj0bFeY9M9HjZ2wzOJ6foVVpT6+9+uqFy+a3/5WtKu9TYUF45TICsB2bbEMLiUzbcK6oP/fpL3z5r4DgNUyQMzbjIG98JwF41w03rWppsm5xXdFmWQq0JCD58o6Xj2zds+fZc0LAXxjk5hm81YxdaLVftH34k62rq8uauYH9/O3/AK96eEmzLvWUAAAAAElFTkSuQmCC";
const FALLBACK_MASCOT_B64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANgAAAEECAYAAABKq/oNAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAEAAElEQVR42uz9d5Rd13XlC//2PuHmUDmjChkoRBIAwZxJMUskVaBE5WjJSnZLbbu7bYMlZ7fttqRnuS0HyZYtWQCVJYqkxACSYgKJnEMBhcrh5nTi3t8fBcnq9/r199p2d1NmzTEwBjAAjKra58y71pp7rblgEYtYxCIWsYhFLOJ/B8TiESxiEf8LiLVTawkwNDRkLBJtEYv414P8md83/UwgWyTZIhbxL8HQ0JAhhABovf/dH//7d370t2duves9vwsYCAE7d8rFU1rEIv6Z5Lr42/Y3v/tXDry4/6R+Ye9+/aFf/YK+/q4PPNEBiYUgtkiy1yqMxSN47ZLr4d27w5b+VWvuuu8D3/v4R4c2bl3W8GPOcZlNJYKpamqF1TVwlT279+u5xjPuxTRSL57ca6xwXjyC1yi5Hn44bO1dvvwNd73zuQ+/5/bOrWv8IKxNmYWxEUI/5Hiu3f/6c4E1fv7oc+ef+sztR2d1TSzkkmrxBF+bxfMiXgPYuXOnfPjhr4daN6duvuvBhz/8/jd2bl0RBvhl05QS27IInDIrUzPWA9fG/P5lg1f3XPOL3xVCyKGhXWLxQ3Mxgi3if/A8tNZCCBEdet+vPfKLH3jwuqs2EChv3rQMRVCvUZwYoVYu4rkesVQrp4p9wVeenjfHRw79ww+//l/fPrRrl7F7x45w8SgXI9gi/m/k2rlzpyGEUPc8+JF/ePtb7r3uyg12oL26aQkDQoFAoFWA9gJs08Ktl1jdPGfesz0b9PVvfNvtb/nYH+7esSO8budOc/E4F0WORfy3qaE5PDwc3PHmX/j0Pffe+wt3XNPjG3rOsiWgQoQE5TvUCzk8xwGtkVLjODV6W2OyHkaCsXnrmoG+ztM/+ovPHrzuup3m6OiexXpskWCLGBoaMj7/+c+H226579orrr7lb95y9+YwHZkxI4YSItQIQAtB6DvUizncRn1BLlQarcF3ywx0JDif16rkpd/Q25X++lM/+sLczp075Z49exaVxcUU8fWdGg7u2qWXLVuWWbfuii/fetMloj2Rl5ZUAqVRBCjtI5RGKY3WGrRCBQG+H6ACD6FcpDMlb9tsE4+nU+mujV/p7dWxY+vWLYoeiwR7fWPXrl1yWAi16do3/+G11161ZGN/GBCWpCmAMEDoAKkVQiu0WvilghBUiFI+SoVopXHdMj3xeePK5WFgRNu2XH7Txz+9e8eOcGjXrsVnvEiw129quGPHA+Ftb3zXTavWbPzglrWZIGoUTdsUhIEDhKAUWmlAoQIfFfhoFRKGIcoPCH2fwPeQCuqVWS5bGRoZqxFamaW/dPf992/cPTSkdi62Uy0S7PWYGu7atUuBtpes3fyZSzatYqClIaTwUFovkCpUaBWidQBhiA58VBASBiF+EKCChVQx8HwCz0P4IZFwXly1LqoxM2bnkm2/gxB63UKquIhFgr1+cFGS12/70CfevmL1hnVrlyQD2/INS1gYfoBUClSAUCE69FHKW4hgYUCoAlQYEqpwgWRhSKB8NBA4VTYu0YbhV5VvZm+7//43rNuxY0f4M32Ni/jfiMX7kv/NUYudO8XQsWOiu7tbALK5ffXH2lvSurclEEIFGIDS4U9rLqVDtAqRwkCHHjr0CcOAINQIBZqLwoeAUGiQmrQuisHuZPjKRMRMd1z6/p07L/8kYO3atSAoHj36kHj6adizZ1ix2Fr1v/iBL+J/+Rlft3On8fRDDylpGEqrf3qfl69b3nf323/71K2XL49cv9nEVmUhQpcwdED5AGilIAgxTElhdorcxHmKhTxhCGiBUgqtNVJIkAIhDSLRGOecfv2FpwQr++ypz//OJ3r+3745rbXYsWOH3L17t2KxWXiRYD9nNZbc8d+2LZmZ9sySy7ddtywg7N52zZ3vMJOrbr778ojaNIA0qaN8B+07aBbkeMJwQU20JPmZafJTYxTzRcJQoRUXpXsQQiKERhgGKgwhu5rffbih1229RDgzr/xJoerl2zt7ttZr1VAp/5XizNj5PY898mw+n58AkFLyG7/xG+YwKIaHF6PaIsFeu2c6NLRLPvzwA6HWGqB76N0fuqW7r/+uto6+rdFUpqupqSUSSyRINvXx/J7neP8b0vSkK1gyJAh8dOgvyPChBzpA6QDTspibmqQ4PU0hXyYMQkCg9QLBwjBECIlhGThug0TzUj77qEtk4Fqu2LKGXKFMJJlFSIGhHBr1IrXibLk8d/7F04cPfuGJ7+36FhACCCn5zd/4DTm8SLRFgr2WoLWWP5MGtn3w3/2HX1+58Yp3NnWuyIbE8AMI/QAvcJTn+jqeTovC6AH5wTc0kTXnsA0IA4VWPir0EWqBXKEKMA2Dualx8jMzFAoVwgCEED+9fFZKLWhWQlKvlcl2DPDllyzOOStQgjAeS2lpGAIhtBkxSSTToquzzWjL2kREmfLUmYMjp4783eEXH/veoUMnTi+mi4sEe60idv+73/3Wa66/+6HBS67vK4cW8/l6UC6XRbFQFtViWdQdRzRqZfr6ekgwz7tvjJIMx7AtEx0uECwMAlAhgQrROsSWMDc5zuzsDIV8Da0MtLgo52tBqEJAopSgUqnQ2beCv3/F5kypm4mpC8SSTSSTGVrb27FjUcLQRyuhBajW1iwD/Z1GOhYyP3G6YUUio5MnXv7R3/zZn3xca40QYpFsiyri/8kPKU1LS2tyxwc+/l9bulZelW7u7A9jHXznyQNBrVIzbMsyE4kYwrBo+Jp6I6BYaGCYBZY0aQLXx3dLiGgErUGpEMLwp1K8VgHCFHgKXD/EdRRSaLRQ6HAhRVSChTuxAOoNl4brU61DvV6hPDOFChZUSc93MQxB6Lv4ritq9Ybh+AHCiKjm9nbdv2Ig8vY3Xr7Gmz1z/mIUW5yUXiTY/1mCCSFVNNqdsSMtD4r0Sn743IFgbv4F2dGRNVf0dzPQ14ZhmRRKLnNzFaqVCq7rMjNfICEtymWLCA0MQpSQF6NYiL5456WVRmoD5fto38f1XYT6SYqoEEKiEYShpuGGKK3JVXzGpxqUqgGNSgk7nqJ/6QDrNm5gYGk/iWQMgaZSqTA7M8vo6Jgs15XauqxZjO979IePf/VL77w4m7ZIrkWC/R+FevOb32zs3r17/MzRH79ruZX4q96eJnn77VfKtrZ2bBMSMQOEoFL1aG7t4MjR0xTzBRquz5iyGJ0yaW7XNGpVbNMkUCFoTRgspIdKgSSCK1opqoDALyMRaB2iFQgp0GGI0uA2HKxIlHPTHhPTJQqlSeLZFq6+4UZWrl2DHYly/vwEM7M5Qh0SsU2ymTRrBjfqnv5uIQsn/Y8++KG3ArnduzGuu26nAGhvP6YBFuX8xRrsfxfk0NCQmB0cFB9Z95DesUOGoPnDv9o9tvmG+3rHxnNqarogi/k8rltHCklzUxOZdIp63WHk7Bj79h/Ed2oMXZ3gHdsDAmeeWNRGqXBBvAhDQg1ahUQSrTw+0sSB/We4JHESEVaRQqKVRiMQgBKacrlBU1sP391f49vPz9Pas5Qb7txBR88S5nPzHDl8mOnxKZpaW+ns7sSwIHQ9DAGJbFa3t8S1P3v8ubGTz//WE4899qP/3g8+tGuXwe7di2RbJNi/Lnbu3CnXrVsnhoaGtBDiv5GwV6/uH7jp3vf9h0uufuP7pota5HMlGY1GsOwY1brP1PQs9VqJNasHyKSSzM6VGBkZY/8rL7N5qcnvvK0dwxkhFo0ShgE6VKA0odJoHVKPreHvXm3nuT0vcu/Kc3RGi2gtQOgFiR6Jr0ICNyDZPsDv/8Nhprwubht6J519y5ibz/Hys89RyufoW9ZHJptCewrPdajXK9RrZcxogv5Va9h++SW4hQmO7t/7QmF2dl+llj/tes5ZW/j1xtzRo+fOzc5czI25GL0XLQoWU8R/GYZ27TKGf/bSOEbP4KZbN3R1DdyQbW7f3rV01abVG7dnz82WOXToBLOTE0gR0tHeSXNrF6lkHLTm5b1HWbN6OUHgIS2b1q5ejo+c4fRsO2vTEq9RASEIgxAVCtA+vmzifK2XoicokeD4dIpE+zxRW6AvKohaB3hOSDIe4cJMmbGcZsvtt5Boamd6aornnnke5bssXbqEerXI6bHTRA2B6ymqDZ9IPEVfSyeWcjl/8OWwvSUuL9uy4Qodhld4vkej4VEoN6hUr8mvrZX2FHJTf/fC47se2b17t3fRB2Qxmi0S7J8X5S8W++HKlevWrr3sund19PRekU7GN/Qv6W9KJ5MIw6bheVRyJ0Lbwehui1KrZZgYnyE/f5zurjytHd1km9tIJdPse/UQy5YtwXUbpNJpSvNpnj1cYtU1KZxSgYgVIVAehJJQaIp2G2fLaepuEa1NzjfSdBRNlmQcUKBQIAS+H2BGW3hp3wwdqy6jq28pc9MzvPrS8+hA0NnTyez0GG5lDtuC/Pw8lZJPW2srV2wY4LJ1cQY66nS1RoxsvEYk6oaGFddSxHHDlKg2lJiryOZT08G9h05P35vpWna0On9uePeOHbsvnpFYJNkiwf5nkkIpxKeVEELfueODn9x06bbfvmTT+uiapS1kE5oI9VAEFe05eeG7dQmG4fiaYk1wdiDOky9Lnt9X4OShWYI1PipURO0oYehx9swILW2t+G6deDrN80cmuG1dlpSvQPloNDJUOMJkKmjj9JRHtdog8H2KOsFYNUuLPUnEDNFoQgUhkrGcw/EpzcDVW6lWaxx6+QUalTL9AyuYHj2D1yiRTkiKc+PUCtOs7E5x7xuWct1Wi/ZWl3Q6QsxyEcJHWpYhTED4pCxojSg644FenlHqkp4UL19oX7f/VNuu2x9s+YIQ4iNAwM6dcrHV6p+wOMLwP6i3nnnm00pr3bLjvZ/866H77vvknTetM9ctUUHWquuYqIio4cuoGci4FcqoLYRtBkREnZiepydRYWOfzZJ2m2JumlOnzmJGEgRhiGVbzM7OL9RaQYjTcJiZL9CZDljaGhA6dWQo8AKPimjiaGU1Z2Y8SpUKubkZlB+AEKRFnoR0FtRDx8OKJnnpdIlpsYLWnlWcOXmM2YkL9C/pJz8/SSE3TjoRoVGaxS2Ps6pLcvnyCOt6DNIpQWtTgmQ8grBNBAsX2EJIFqgrEGgMEQipajJJSQ40+Srb1BrW6NzWt2rtZX75+Hfz3/iBy/DwYm2/SLD/sUL4zDPPqHhbW8eD7/z4ox9874O3XrOlyc/IvIyanhGLChmxhTBkANpFKw9CH6l9ROCiVYDvOAT1PGmjysqOCBHD59SZUbQZxwtBK83szCyWJXHrdepuHadWZtvqJGE9hxDghIoZVvHyTBu5Yp1atUx+dpLAa+Apm5io0ioKaDSepwisBHuO1Un0bKeYn+fcycN0drTh+j6zkyPEIwbarxKULrAk02BpS8DmwS4uuXQjPf0DSMvGdR2062FIAZKFNqwwwHcbBH6DIHAWBkDREDiiJ+3LjvZWf6IUWx1N916W/J3bvnr1Z3ZxbPfuxbdokWD//Zpr165dcvfu3ZEH3v6xR3/h/W/ftnWp9KXKWfFYRJhSoYMavldFqBDLBFNqDKFwHQ8lTSKJNPFsE5nmLOlkAhuH5lhADI/JmQK10FgwrPEDnHoVIUICz2U+V2DdkjRNURffbeAqi5ON1RwcV9RqVWqlPIWZSbTn4PoBJh7NRhFTBRiRKKN5zdG5FJFUJ+dPHSBqQjQaZW78HEJ5WGZAWBmjP13hrmuX8+H33c/tt91E38AAzW3NNHV2kmnvQIWa8dExPNdDIDE0GDJABQ6+6xI4PoHvIkwTrUJSVtVoSia9s/nISm0ua/nu8K9+b2jXLuPY7t16kWCL+G+wa9cuY8eOHeGdb/3FL77zrUN3XLHG8qFkxaIS/AbaryO0j2VLtOcwNzXFhdNnuHBunNaB5WRaWzGUh3TqGKFHJAJNLWla0zaWqlDIFZmcrzJf8QEDz2kQhD4on2rdJSJdNiyJ4ZTy1Enxaq6Xc/MuvlOnUS5Qmp9G+S5h4KFDlxa7SkT4yGiCfSMOJaufcjFPo5wnm8mQmx3Hr+cRuoHh5ehO1fnwjst4z4O3kk5aVPOzzE+fZ/TkUabPnUPVG7R2dDB6foqvfHkXZ46f5cypc8zPF7Bti2Q8ius28AKPwA0J/Dp+vU4m6hp+EAnGS7Hta9atfO4bv/lrZ4eGhoxjx469rkm2KHL8rBQ/NGTseOCB8Po33HvnDdde8/bL1iYD4c5Y0ahAOQsdFbZt4lUrHNqzl337DjA3PYfnutzznncRi1pMvvoMpdlxHMfFMAws21r4P0rT3hpj44o0U05ANS8pVSso3yP0QyxTY1ome0/kuWGwmxYVUq6FTM7VcOogQw/fdwkCB6F8pJBUHZdSPaTFDvHqIVMViyCiqOSmycbjVHLT+E6FVFs30XiClD/B7Vub2LJxFWNjo/ieplyYZ3x8jnyugucHJGMR+vp7ufyGG9h6xeU8/t0fEk8kOXVugiOHjrNh4wrWDq4ACa5TRSsJ0sCvN9jQHRHHp2OUa+1/CGwdHBx83UewRYL9DAYHBzVa07ds8LdvuGy1TjMpDFknqIOWmmgiy8Sp0zz+rYcZPXMBrU0812HrDdez5bJLOfbkdxk5fJz52QJKabp6uojFTYRQhDpkspHB7bierkgWd7bG3NQkM6OnqZRzSG0TsSTzxYCXT+a4fXUUp+bTaDh4jkYqnzDwEdpHKg8tDPwwpOYGhJhMzDcouBlCZ56YEeK7ZbQOWbJiG6nOPqxoHNuE2XSD589WWJJyqeenOT86x4kzc8zOl1AqpClhsT5fJRIz2bp1K0/teYla3Sdr2fie5tiRs1TKJdauW4nWksBXKCGRUmCZs8bajr7wx+fSl+54x/tvHR4efmxoaOh1fRG9SLCfiV7Dw8Ph9mvvvGPzxnWbl7R7IUHVIHTwPZ94PMHRF17gkV1fJ3AcotE4gadoSINLr72a4pmTvPz0yzz9/EmqlQbSMMg2T7N12zqaMpKq3cN09kb2jZmcPXWOualRnFoJqRxsy8BplEkYClu4HDk6y/aeHsLAwfIrhJ4FesGubaHvUCAEGKGP9h0qdcnUfIgdVAl1BdcN8DFpah2g5joUx88RTzSTSDVR9uLkG1H6jSpGqcCFkRyj4wUiliRhm1Qbmum5ElOjY3T1LqG7p5tD+06QiJhEIwLLNMnPFTh+9CR9fUsIwwXXYTtionSZgeZAPzcisNM9bwMeGxwcfF0riosE+yeCsXv3bjqXLH/XhpXdJERFB2ED7dSJWDBydJSvfemryNAgatsErkut4ZBt66Qjm+DAnud49cAIhbkqVixG1QmYGZllYq7MthtuIXXpHew9pZgcPY9Tr6F8D+FXqdcKWN4cV61t5opN/fR2JokS0JYxKBQrtBfqHJkwiMUtEApDSJAWnl8lbpXobrLp7UywdrAdw47jhIr5osveE0UOj46i4m20dK4gmkpi2gIVeFwomLjpFTgz40yfO0omamNJTVRq0vEYQQDVisv8zBSJRAQn0LiBJuL7uL7AtGJUyy6zsznS6aaFOzth4IU1opGytEMDZUUvA4zhhx4KL8r2epFgr2Pl8IEHHggBMqnmS5tSAuWUpPYcwsDD8QJ+8N3HqVc8YpEY9XodKQR+vUFrcxq/UmDy3ChOw6ElEyMUFugF9a0SxPH77mKklCWfP0W5vKAENspTKK9MWs3x3jcO8v633kBLVmIbiiBcMBb1/IBlayXxRyb50at50AupmOvkWNYccNfWLjYPxGhrz5BpTmObBoZl44dw+UiBx1+6wJ4DBebmRrBqRexoDDOSRgiJU0vQ2XkV9uw8Qf4E0jIwDJN4xCCdsEGD5zSIGAZBoKi5ARE7gu1JLCskYls0Gi52ZEHSF2gwQDolafoG5SBcft9dt678hhAndu7cKYeHhxcJ9rrFzp1CDw/r1atXD9i21WNTxavNCxU4RC2LM6dHGD8/jm0mCfyAUGsQGhU4ZDMJXKdM2KgTERIjauJqjQ4MGr7Fxjd9DL95HfuefYHzR/dTmD0PQR0Dh7ZIkV95zxW8c8eNxJM2nt8gVB4CBVoTsUJW9/j85ju62Lo8wud2HcN1Jnjwpm7uuKKP3habeDJFJGqAXHCXMiyTwA9YtzRJS3yAZZ1xvvr0NBeqIb6bROl5QC7UcM5SetbeQnl/ASOcIWpaWLZJKmmRTNhIFWJGohjRGEoI6g2PiGmiYwsENNAI5eMHYsHCW2pCs4rvSG2ksmb70tVZeJxjx469btPERYIBO4FhoLl3fZMdTcZ0o6jdoCikFGghGDl1FkMLtA5wwwDH9YlENJF0KxUnRuAGmJZBLGYhlMTW4PrQueFuqonVfOuLf834uVNIGZKI29hGkpRf51fefg3veNv1RFNZlPaRUqADA2EIBD6BGyCUR1y73H9dhnjYQrVkcef1a4hYGhlJIO0YUmoMIwpSoLUiCHysRAUpZ9lOjWqjie8fSuKnlhMoD6deo1aeZeL0fqr5TpZ1b4LZF4naPvGoQSxiE4lItIBzUy5HpjTL+5IsyZh4obvgySgkBiEWIV4AoRL4IZh4eIGNNEwSCXtRRVyk1z9BGVIqhfYdlyCsY9gWVc9jbqqAaUhc5VNteAjDoKSyHDqpeWZ2gu2XryeVjpNpTqAamlAJYol2jrsZXvrSF7Ftm6UrB4nEUyi3zNTpl7npqg4euP8a7GQKI5ZAC4X0A7QGRIDhuYhGEbdaRoQN3HKRK1fHSTf3IUwTacWxY2msaBqsKNKAMAgRKIzQIZWIkopbCCHYkKtz+Ow8JxrN2K19xDJtNHX2EVZzlGbOcGpkhsFsGtMsE4tI0pk4hmlSqoTsOzHLbCVGbcxgtqi5bEWS7MVxGoHCEAqUwvEVvh9imB4NV2C7dT17/rS3SLBF/BPB3FroOK6ouUlcVccMLby6R71aQxgmKvCJRCNM1WyeOhZQcpOomTlOTrn0tWTp6W4iP1PGUUClSmH0EHff+1ZCK0MhX2Fm7AxjZ4/QFSnwwXe+kaalywmtJuZKFoZUNKd90C7KaSAMH8uKIY0kXm0et1anWi6SyqSJN7diRpqwkk1gJtDaRfke0XiEujI4eQ5m5jxaU70s27AMYUU5OfIsJ358gHIoSGZakHaUaFM3G1YsZXzvI/hz5zCa4sTiFk3ZCLWGQ9E1OTNZwYql0JEMI/k69eM17tuWQUpYGCfU6FDhuS5KgVJCF2pKDHQZ44VDe0/CT6egFwn2esXw8DAA5fLZ2Vx+S2W+nE21JX2NH4hGtU4Y+iBNTBEgo83sOdwgX4+xdFk3N9/1Jl4dn6ZveQ/9PXkymQzzuQLEbN57z4OMitWcPDVOZW6K0VP78EujfPij17Dtphs4Pprg+8+XmCh4GEIz0B5w85Zm1vRlwJtH+Rol1ILg4ToETm3BAEdIpG2i0BBWEEqhSfLqmZBvPT/HngOT5HJlbOqs7RF84A1LuP7qDRw//xyPnTyMCNYRzWbxQ59QwerL34BzpEI6Nkt7WxOVap3ASPHEwTlmSppESyvLBjfS093BD775LY7O2KzoNFFBg8CHuuPiNRpYiRjlhhG6RI14Irrva69O1V/vO6MXCbYAjRCc3H9ysm+gPHbsQm1wxVpLq3pRNFwPsAnDGvGmJl4+G2O+HNLb385/+PQwp0em+Ycvfo/4za1ct7KDJruAHY/TM3AHB8I1nDteoJrLcerIczjzo1y1JsP7338/P35hjj/8wndwA5uaNqnqNHYsxWPPjXPloME7b87SES1Ry09Tnp0hPz1LtergOS5BowxSYAYOKnQ4Py35r4+e5tmjLhemctCYpzPukoq7HH65xM7jh/jlB7dww/ZVHJ06wYW5syT1AIl0FjdUnJtr4pJtbyYy/X3mZiaRkQwnCy7P7LsARganVubs6bNcf8stNOoNDj73BFeviZFIhnihplLzcB2P9rY2DpxwREfHEhG3Kt8AGDx69HV9D7bYi3gRF3ca654V67urXvqawV4RmioncX2mZ0vUGwFhtJ0fnQhxdZxP/fon8ZXgb//67yhXGuw9dJa4aRHVDkbHeuZabuDQiEtuepxXn/kBbm0O6c6x8xN3sGr1Gr7+j99ie7/Ltq4pVmfzxJxppmfmmMgpDh4cZ2lrjRWtDeYnxshNTjM3NUu17pJIxIiaEi0UgVPHrdV4ZM85/nTXWeZmc/QaY9w0UOWKzgJrUhUuWWKQiEuKxRLrljbj1uucnSjjeAEaEKbEc8ElSaqtj4nxc5yabvCjw/MEIoUdiYE0cDyPfNnj2uuv5eD+w7QmApZ1GoRKMTFdworaeGaX2nPWlOvWL5utTr78kcNHzrp7nn76dS10LK4vuog916MALRn78vjkhHrmuCGF3aqVlqTSCUw7wnzDYKbgcf0tN7Bl61a+990nqNU8LDuOH23jz759hscutFPofhN7z7iMnDnDi09+D7c6S9CosXZ5K7fduB0zKHDLeklHcJby5AjFcwdYn7nAuzfNcUnyAPHGIdrMEsXJSXJTU4yevcDcXI5UOkUQKCZHx8hdOE95Zpr5sXFEY45M4yhXtJ3nnlUuscYkx0+c4/CxUcZHx2hVc3TEHCypWbe0iZ6WBWOdRmmO4swEjfIkFy6c52Qxg1rzVl6ciFKraqRpgLSwo0na2rqYnStwZnSSzt5exnMuwoqSK7oUGy6RdBvfeiGvlq5dKxJm4/f/4R8eLe/62tcMXucTzosR7KcM26MZGjJGv/XduY7egexkKXnl0q5U2GzVpNeoU2mEjFUSHB4P+YWPfYD5QolnnttHIp0lCEMcN2DLNddx1Zs/wMvHc/z4yac48vITBLU8pgmSgPtuXMP9d2+lMH6Sswf28tSr0+x6ZpSc3cOjzx3nwtgU161Oc9tmmyWZgPzsPKeOnsYnZHDTerq62mlub8NxPC6cPc/0xBxz0/PMz0zTnxGYfp3vv3iEfeNV6rF2pquakxemyUYjRHBJN6WIRQzG5xvMec3Es2006hVqxTl8p0I+n8O1smzadj3JTBP5fB7Xd1FCkmnpZNngemr1BtVSiYxRYX1fjAsTMySb2vjeK/kgaLnEvHLzwNEf/PZ/fP8v7tT6ox9dvziussisn8GxYwwNDRnFR3Y/0ehYef+Z6bCjv02HCdOTlbrPSMFmNshyw6038ezzB4gnm6hU6lgRgxtvv5XtN9zAE489y4++vZuZs/sxtUcymSWZaSFpenzkrZexenUrZw8eYM+zJ/jHF6f4yG/8Pt09nchYkhdOTvHKsVEuX9OFrs9x4tRp2rp7ue62m+nu7yUMQxKZLOnmZrQwOH1qhEOHz1MqOpQcycsTAaKpn1yhQGdrmne9852IaIYXXzpI3FS0Zk1ampPMF+ocHQ+Jtiwh09yBZcdwG1XcyjwzE6PMzOXo6F3O8lWr8F2HSqlIw3FpaW9n+bIVnDt9iv5mxfJ2H9fTPLavGk6JFeZ9d23X3uyZu7/78t4L7e1H5bFjx/5n1UOxc+dOs729XfxbGXNZFDn+72IH8Cr4N0RyH8sX7R9+5pvz4j3XGaq7s0nGZgLS6RTz+SrReBO5/CR+EBJPJpmYmOU7336Een6eTNygZWAVdjyNYZrkZycY7Iiy/dIBlNugpbWbR/fPc8v9b+cdD97Lv7v3Rpasu5ZMtoczJ+s8dzTHp957Gd2rlrLx8muQUZvAqZEIQ+xoDIWma6CPbUJQabxMtQavHpihUIvR3ZykWgupTI8jqjPsfOjXuHf/K9jNTXS1Z4jHLXrabJqsCnPFGZraemjqWEJTZx+1aolGYYZypcArLz9HMhYlcMqgNCL0OH5wL+0tLUQjJplMlKmCw9//OBfIlk3mW267sjQ7cvD9X/ziF1/+53TQDw0NGQ8//HA4PDwcLEawf9NB7JgeGhoyvv/db45sWr/2aNE1hvYcmJN9nc1Bpq1THjxXZe2l27gwNk4hX2V+do5KaY4rr7yM1pZm+geW0t2/gli6bWGcpDTL/PQ5hm5awZveeCmB55FoamXztW9ERjO0Z6OceeFx/vbrT3B+okFzPOTGjW1ce+NlLFvVj5lsJdQC5XmEngta4/sefhAgpYEKFb4P56YdRifnOXl+BBDcd90qNm/eSDWwaGtr4S33bCdpVkhnm6iUa4xMlhnNK8BCSwNhGkTiKdItHTS19pDOttI3sBohA/JT41iRKBpNw6mjPJdquciPXpykf+NV8q6bNp8LCmdv+/Mv/NVTu3btMoaHh/+/kksMDQ0ZR48eZceC7Vv0k7/8/l9eu3pF+/6DR0/s3LlT7tmzRy8S7OcMO3ci9+z5H5PsuuuuM3/0w+8evXzbhiORdPudL57yoqPTTjhfqotoukNUykWmxqeROPz6Q/+Ojp4+8iWXQAkKpQozk+PMjo/QqBSIizoffMtm1q0fQGDhuBWWDm7FDU1yhSpRf44NfTaZlOR991xCazZBz6oVNLelCIUNUmKIEIlGSIlpWVhWhDBU1OsNGh7sOz7DktYMK3uauGnbUjau6qEs0vhmkh1vvB5ZP0k8LpCmhe94jI7Nc2bWxxNR0JpAh/i+h+f5GIZFNJHAimfZuv0KDCkYv3COVDKBUorc/BwNbavb735DuHlF21fPvPide//6q98+v3PnTvOjH/3o/xdyiV27dhlf//rX1dGjR/Xw8DBve8ud9378F3/hKztu3/5207Zu/uZ3n/jcM8884/Nzbo77uiOY1lrccMOwFkKwa2jI2H3s2H/3342OjqrrrrvOfOwH3zt68+VLv9O7YsWGfI2BiZwjYsksjXqD2bkL/KfhT6JklCefeoVKxWdibIK58XEKM2MQ+sQsScyd4cNDl9Ld14aSBoauU50foa9/BcpMUWhItOdx+y2X44gYX3/6NHfefTlNbS0IM4J2itQLs5TmZ6jXKqjQB2GQTKdIplOUKh4PP3mKZGsn12wbZOXatcQ7lrFi3Uau2NRLOH8AW+cIg4BGzaVecxi/MMvx83NUA0nETqK0QIUKpQP8wAUhQFr4oWL75ZcxPzdFYX6WZCqNHU/qN771QbFhTY/zm5/68HXHzo6Xt3zwg9ZX/+RP/v+md0NDQ8aJEyfUrl27tNY6/r5333ff+9/zvr/YcNkN/z4k0WFXz/nCInp+Xnxz7PzZ6Z9324HXXQ0mhNBE6deOntmxe7cjpeQf//EfjR3/HWfaPXv2BENDQ8Zf/d3uo9fBjds++Ylb+vo3fKFutfe89NKL+m3vflBGU218/5Hn0CLK9MRZ5qcncCtFEnELFfjkzh/nmtUW3a0mQb2EiKYx7QQxP0dt4hl6U/303rIB/6bLURrW+B5Gppu29i6koanPzxLUZsGvEbfBVwIdOjilKm49SirTxOaNK7n7xgmuv/l21q0ZAKGwjJCgUSKcOIptOPiuQ2m+gOtCvlglYvqs6zI5Oj1FYdoj0bGMaCKF8hWBF6CCEMMwmZ91ORWBN+54gL/87B9Tb9RZvm6TmJ4vhJs2bUu87yOf/Oxf/9kfv++P3vpWfcMXvvA/mvsSWu+SQuwIF1LBD37wisu3fVzGWpdfKKZ4YcRX3XKEDctd0WTFze2bl217fg8Hft4HNl8392A7d+6UALfdduPGh7/4mRNf/8ofvfzOoVverJSK7tixI5RS6l1DQ/+PiL579+5waGjI2APBZ/74M3uEHS0USnVWrV7Ohksv5Ymn9mOaMcZGRinl8tiGJhm3qORnKI8d5qbBCEPXLsGSHm4pT1grEgYuph0jlYiiaiOomZcwc09jF18g5R3m/tvXkMzE8KplpHIwTQFSoi0L0zYxTRMrFkVKi0q5QjRm8MCdG4g5x5g++n0KJ39I8dyzqOIJLF2jViqRn80xN1sgXyhTyRcRKNriAXduaeb61RKjeJL85AiB28CSoPyASm6eRrXAyOkzhCLGPW++n8LsDGEA6VTGENjq5vve+t7Lb777ozfccEPw/0aunTt3SimFFmJHeMst11z71S//2Stvf/vbP+PGli9/4ngsPDARV4VcTq7rdKQVFIlHJC3NqXUA11+/KHL8XOChh643/vZv96j3vfP+33zwgTuucFWy49prL99xzy1X7EglE+He/UcP7z52zNdaC+CnxfXOnTvl5//sz/TWp166+52/9J+eTPRtWvbqKwe57c6b5OR8lemZCnMzc4RuEVO7FKbPMXvuVZamK7z7ph4uX2qRiHisWtlLvVK9uH/ZJ/RcBGCaFlJolPKI2FFCwEw1Lyw2Vz5CXdzbrDVCGAsjKUKisTHNhQFMpfXCqEuosGyTQiGH9nycWplivkA+V2ZiMkehWKPe8CkVajQaAflClWxMsXV1G1du6CBt+UxPzjFXKCNNC9MQeG4VyzaoOi5veMPNHDp4gJmZeVavX0dLNi36l/WHTZnsnQO9PTfXq8VH5+fnaz9bNw0NDRmf//znldZk/+B3f+2zb3/Lmz4by/S2P7K3FBydjqLMjOE6dTEgT3LVshrVwrSOJppl2bWq3/nBk1/+0pee5ud5WPN1kyJef/1DIQyzelnP5VER6n1n3XC+psSd2y9d9am1qz5/9VWbP/boo8/+jhDiHwC9c+dOc3h4OHjooYf0sBD6xt/4vT+8+a63tP/Nwz8M2tubzHQmy+lDYziVCtKtkJ++wOjxl1iVrfOuN/awqTeKGZTJ56pIFSd0PZxanUqhQDKTxYramJaNMBb2gcWzzWAmMKWNGW8HaaCkjUw2Y/keul4k8KoXSWmCgHrdx214RE1FozqHDnyiTS1EHZfZqUl04FEt1ahWXSo1B8OKIISkXnfQShMurIclFglpagoZvKmNu6+2efJgke+/dIq5fIKm1k4alsX8XJ58scYb7ryTL/7NP3Dm+ElWrujDqdbkTVds0flzB1NhGEqtNYiFdUo/kes3bty46lc+/q5vb9q0Yc1T+6f1kamKMpM9pmkuOBSryhhbV4XQKKBQwneKxCLRFUBESunyk7b9RYK9VoUNhBBCd3YO9Gez6TWokrhiQ5vxt083xBefaqj+tKuv27h97bZL1v79Dddd/p4//L+++mvDw8OvaK3FQw89ZAABfvUvi7nJP6qVa2LlsgEMA+KmyVxhksMvP4k3e5yP3rOOHTeuBGeGUrGICmwC1yYMfEqlEqYJtXKZRqWOFY0QiceIZ9KkW7uJZAcQVoLQ08wX4zz8/QPMleus7M+wvCtOd0s36cTC/uXzZ/PsOzHF3oMXmJ2e5b7btpIJK7SkbHoHB4gm0lQqNc4cO0M5X6HhuEjTIhpZ2OuslMYPFWiIWFFMQxKPR4hEJN0xj3ff0s4Nl3Tw2a+9wr7RHNmu1SQybZw+O8rgqtX09vcyMz3D1OS8XrNmuTh0eG/+D3/3d64GqmLBa1v9hFw33XTtFb/47jd9p7W9p/Uvv3U8yIkBM5ZsE47rLkwFBEXWZnP0twe4pTqGkLJRzul4pL//yuuuW/v8nj0Hdu7cKX5eo9jrgmA7dgxJ2B1ef8Ulq9pak/GgUQlXtmeMpZ0JzszZ8nQhyeFHJtWl3Z6+89prblo+0PXirm8/8ZAQ4re11iEgv/HDp/Zm198kyqWGGFzeTTIaozJ3gZd/+B2S1hR/+Xv3s215hNz0GGbMRugYvisp5AzGJ2Yo5kp0dDYjpaBeqhCUiyQSKSKJJHbrEkSiF2knKU8Vec8nfp/j882YiRTpqCCajGALj6gBpVKZyfkKpVKNeqkAYcD+U4+zMlvkM7/1EWItyzCieTrKDgdePU6p7iCUgYHGxb0YMSEINIWKR6xUZbXsxZQm8ZhNJGJSrzXoy2h+6yPX8XtffJHnDp8iGo9TqazFikbJZjI0HM3pE6fFhk0bIRCZ5b1tnWfH587u3LkTQP7Wpz8drtu6ru/t997wdcdTrZ//+umA5nWmsOLUKmUwLOIRG108xdYtEuEVEHIhZa42GrqjMyZv2L4l/vyePT/XlgOvC4L9RIlaurxjRTZpooKGjsfrrO5KcGLCQ8kIRPrkj8+XODl+Lrx3e6v8jx97728N9HZtEEK8F6g9+L6PtlVrklq9pnt7Opibm+fZHz6GEczx13/4DrYt1cxPn6epKU29UkFIwdjYHGfOTJCIJ3DdAI2JISMo4eI5HoIKRNJY2QGQLYROg9bOLi6/ZDk/+P2/RokI6dZ+Ih3LMK0ovqfRYQOvXiQszRDkRwi8AlY2zR1veSvxZJpKNSQZ76B7maC95xXmpvNEIvbCBpZQQOijwpBKtUosaiOkZGxqmmzGIpuOIlBksknKpQqiOsFvfOgmPv57j3P6/FmOH9rHlZdvxBIGhUqBRr3B9Mwcq1qb5dJly8TZ8Tl97NgxOTg4qJXW1vvfeOPDQoVdX/zBVBDp3GJKR4JbxzYkVtSkXpxkMFWiJxFQK5QumueACjwt8XGc6nrg+Z9nJfF1oSL+RIlqa0utiZkKBIR+ibVdASmrhuf6CD/EjkUom6uNL+5xeXTvTLDjjmt2/Pkf/vKL61YObHICY3nN8zANoZuyrTz9wyfJjY3x7z/0Jm7Y1kWtkqM52wyhplx2OHpkhEYjZMtla2lrj3L2zAUCz8c0DKLxGLFoHC0lybZlhEaKWjUHykN4Hr/+Hz7CX/7pv6OvJaR84Vn8iYOI2ixBdRRVnSTizFCfPUjgTbBhsJff+uS7ueGKTfhOneLcNGdPncbDpn/1RkIhAEXo+wt++J5HpeaTq4Q0Z6Ks6mlmoKeVwHMpFku4zoKgkkonMKWgJeLzqQ/dhaWqnDt1gv37DpPKJJmevIDQUMiXMCMxlvStkBc/zIzh4WH1iQ++9WPdLcnLvvKj8aBqLTedhk+jWl7YqOkFqMCD0ggbewKc0gRaCzSghUajtQp8MtlkG8DPs5Bovj4I9pCGYRKxWJ9tCIQKhefU6IpXWd8luHCoAkYSdAhhANFO8Z1D4+bkzNngHddvXJ9Nxp49GayqnK94JKKWMT0zzaGXD3HJ5qW8+/4tONXTpDJp/KrD7HyBkZEJ+vq6SKWi5HN5Ko7gzHiN9p5ZlvdkkcImmoiioxbRbDeGsMFzyFeqGEaMWKLBe99+P1dsvZQv/sMu/urL3yN0msEPMA2TSmmOnvY0993zZq7atpG+9gz1Yp66dgmVS2tbK9KI09o3SEdvH7Yf4ocahUIHAafmCrw66nD5ujSxiIEhBZlMiljEwnVd7KiFZdm0tDdTLExx4/ZbufzSfva8PMax/Qfo6+nAr1coFeZpOA3l+aGshF4PcPKhhx7y//RP/7SpuyXxH57aP63PF7pkKhJSLlaxrAhWTBKJCtxCjvXpEm22S7VWwrJiKKUwzAXhJwwVUsuWn/d37/WiImoAU9AllY8mRAeKwJtmy0A7zx2rUXAliAA/gCAICEWWHx4rmHF1Qr3p6r5Uf+v21J985TCpZEocOniUSqnG7fdvpy0TUJ/TEEpKhQqFfIkVy7pxQ4dibp5GQ3B8PsNLExbtFxRLl7ZjR0EGPp4QaAyq+Tmi0QwRK4nTKCO1RzmXo6M5zn/85V9gcOUqdv7J31Mq+dR8l+V9KT7xgfeydqBjwfFX+1iWJAgM4rEMhUKFSuMY6UyC3NwsQakE0sYwouhohEimjZ4VzZwvOawlRadtEXg+MhYhlowQhCHokEjExDIETmmKO2/exkv7J5kaPcOKpV2Ytkk+N4tbraswFDKdTndfvMjnjbdefV0Y+K0vnSAMjaRRK1UQMoJlB0SCACmiiPII61aF1MvTBGGAChsIAZGoXEislEBKsfB+Xs+C7dciwV7jP6wpUSrAVCFKa1wnT3dccmlvlCdO1Qi0xPPA9T18t46SWR4/PC1X9c7qZnsWwxRC+3D2xBniUc1lm3qQ2kEIjes4FPI5mjNxgtDFrdYxrRinpqOcqRu89Y1ddFt59r16mIGeNJ7TwEhl0Wi0MKnX6oROjUalQBAEBNoiHs9Src1x1dbV/M6/fzu/tvP36Rno5lc/8T7amxKowEVKTa2Yo1rMUyoW8D2HVDpN/9r1uE5Ie3s/brxIrlBlYnKWmbkKhm2ytLOP8yR4YUTT3paipUkTKp8gMInYkiBwcYXEjicp5WdZ1dPPwPJeLkwUOL5/HxHLwKk5jI1N0rh0Oe2dfW0/kdNbMvF3np/09XQxgYg38DyNtAIivgka/LkCl7XmaLZCarUyhmmiVIghJVIaC373WmCYZhGAp39+37nX1URzEISEfoDn1/H9Or7voarTbFkSkrVrNBoudbeG16gRNALC0GHGTfPscUf4IirCIODUsaOcOHyMro4mVg9kUV4DHWrKxQIRy8C2JEhBKp3lVKGJb+6tsXlVmquWgVO8wNh8nnzVJNXehWknKc4VicezC5tYTAPLtJFSYhgGDaeO06hSnJ9iXX8Tt165gQffdDMrepvRXhUVejiNBqHvEzEl2XSK1uYWbNvGsiPMzkwzn8uBYZNu6aC1fxWtfato7e6gt01w7fo0ZyfLfOnJPBNlg0QiAirA9TwCf+HezjRMfM8hG4VlS5fQs6SPYwcO4LoOnudw5uRxxudK1MLI5YC+4447OqOWed3ZyZqoeIF0nDKNRgOn1qBea9CoVJCl82zsdnDLkwS+JnQDQi/ED3xcx8X3A7SUOJ5f/znn1+srgnmuI3zfg8DB0AoVBHhBnY5klP5sgrOT4IUBgeejlU8YhCDiHDjvsLZs4tUdctNTVMvzXLP9atJxgRAhWgvqtRrRiIlGkEjYHDsf8rePjTG4qp133LqEWn6a5avXok6P8dQzr3LJ5n6W9HQzP3aabEsf0xOj4Ddo1F0UGmFEUTqkXinRqFYh8BC+j3IbuLUiTrUMKqThOORzcwihKJXKWHaE9o5uSsUGB/e9StySzE7PcX58ntmiR3dPF8uWtNHeGqerp5NE6zI+9/XjfPXZMr94RxO9zSb1eh2hFW69jhGx0TKOYQnikQQr1y9h9OzpBXtvt0ZlbtLY+8oRfd3W5bcC6aSUl5uWbB6brgbKS5uhrqMMGy0DVMRC+0U29eRJSodKvYZtR5FqYce0BELfQxsRoYVBpVafXqzBfp4imO/Xg8AHt0EIqCAkDAOMxgybenp55rCL27AJQxetNOqi318tkmFsXjM1PUNpdpZEMsXSNWvRQRkjJqk3ahCEKMPCNA3OT7p8+ak5hJT86gevJC6rBHWbs8cPU5gr0NrexNh4noRtkWi+gFOcIh6LUXfqC4v1Ak3DLS1MGTcc3EbA8fPT/OiF/ZyZmKMpadOcjKACF891MYUkVIp0PIGdzJBs7uL7jz8F5Unifp18zceKZei2wWsUccoa0oL83CSXLlvHPdev4bnjdXY9W+Lt1yRJ2uB5Pl7g06hUSLYkCSyLUqNBZ38fTR1dzI6PEXgenlcQr76wVy3pbc/+4qce+kFW5I2pcyd1qeZL8AkBoUMwbLSvMfQMK9tqeJUaytII4aENA5SPhYGvQqLxqJgtupwdL++HhfGhRYK9prFbAIShmg5cF+XUkXIh7w+DEKdeZiBhM5AWjOdTGMJAKbUQxUKXNRs2cOjQKY68+hKN8iyrNt6CncgQ+lPIiKZerYEBhikZna7z1T1zHD3f4Dd/6VZ6WqPMjc8yevYk0hSsW7ecsQuTjJyd41glRyZlU+s7z2g1ilco0JS2qFYdGtUqs/M5Dp+Z5MevnmLvkTN4QciFucO8euQ029Yv55J1K+jvaiEZtzEEGJEkTmDyN19+mEQE2iyf/ScuUHVM0gmDdMyma0kniZSNMCyilk1t/jzXDvZzZrLOpFrJN148xU3rIBsJ8bwQVXdo6jbRdpRStUGXNEk3tTI7McnyVStZ0iypFkpy5vhL+ld/5RevNKoX+PSvPUMQNgukj1IaGSq0AL9ep7+9SJsd0nBcbGWCFihTYhiaUGnQWgkrJfL18Mw3d/39Sa21EEKoRYK9hvH0QwvefJVyfdrzfK0dRxumjdIhQRDguz5SjXFJbysvn1W4OolA4fsezc1NVOs+J156lhtXQN5dQuvSfmqeS8PXIAJU4BO1DPI5h68/O8kFfwmbNpjces1qapULIDTNre34DYdaoUjUcFgx0My+kxX279rLB5L9rLvhzfzOH/w5XjWHAZwbm2BkYo5K1aWluYlrr9xCIh4j8DzyxRKjMzmOnXmCeNSitTlLMp3CCzSTU9NcfcUVbFjRxJOPfZ9XL7h4YcD2lVkSEUVQz2FnO4in4jS3ZDCER3PCIxZMsW+ygVi5nNrLp7h1g6ItpgndOsl0lqnAYna+xDLfw47FkaZNe3uW27a34k8dJZpxxBUb+tW+FycoVOvS11m0Di6aooYoYRBRBS4d0MiwRIDGCDQ+6qdygA4VhmEpM9ljzo41vgo4Tz/0kAkEiwR7DWNu3UKKcXZ0+qV8qUukZShC5YAKCf2Q0HNxggarWhMsbw45MCWxDRMBFPMFJiam6Y8r7rqynbLRzys5Ta5QZrbosbzZROqQ+UrAf9l1mEl7AyXHZNOyKE0xBz+08BoRLAmVWoF0JkYs3sneYzM8Nxnj1KSk9tWXeXjoI/y7T/0Sf/THf0rQ8Nl25Sru7+mmr7OF1ub0RRXUwPM8atUqhUKO8ck5zo9PMTNfpFCqEzgOQ2++nxuv2sKj3/0mPz5epOBnEEJzIR8y0J4gm7IIvAah18CQSSIxG8sM2T7YwTPHxxhv6mC0lOL81FnedX07vW2KSDTG6MlZCoUKTqNBEAaErovruLz7I5/kW5//NC/teZx9Lz8v646L4ygIQrQZIKREaPC8Kmvb6/RmQgLHAWkSaAFKgwDfF8RiMWXEm4ypRrzwoxdf+vOfiV5i586FDv2LJsyan5Pm39dJL+JuJQR84wfP/PD6Ld1zV6xJtdarBW1oRBhqVODjeyExq8Cl/S0cm6wR6AT6J/dBhkkQhMzNFrn0hmuZOelxas7h1FiVa1ZnqDZc/uY7R3nitGD9NSuYPPgK1192PRIPIU28RpXQqdPR1kY0Kjl+ZobvvVqkYG0i0wvPHDvHC6+c4qY3XM9//av/CxoOoR9Sq1YIfRfPd/FcD60UWgUo1Uqp1ETfkh7WVVZSrtRAGqQyzSQTcerlModOT1NwbexYmlDDWLHMTFXT15UkEtFYpkAFLqZMosOAZb0pUtGAarlEJBrjyFSGr+yZ40P39GJHUry87wBeCH7gYuPT2Z4gqM/x2T/7W9yCyZbr76ZWLHB2Yo6GK1CYKB1gKAMtDUxdZ3VHiHCLhIEGQy8EJm3ghSGRqE0QitBKLbX2nTj/0Wcfe2zqsx//eETv2hXIHTvU8PA/EUoKQai+ZuzesZsdr/H1tK8XmV5/7Wu7jHK5nD81VnkkNLMiCIzQ9UI8v4bnhwQhuI0C63t8lmYdtOsCPoEK8cOAQEMYKlJxg8FlKQwBLx6bwQtsntw7yXf3e7Qv3YiSJm1NGVYv70KiUSoAFOmWDM0dLQTa5LvPjTJtriPR3ocSGpFo5/T5HEqHeJUSnu/g+w6mZWFGbGKJOIlkgng8RiweJRKzSaXiRKMW2WyGbDZLMpHEEKBDn2qtzthUESFSIC2saIq6SHJ2PkDbJtmmNHbEXBjkVCE69GlKRcjGBPVqidDziSWbOVJM8+qooujYPLbnCIlUmtB1yMSj3HTjVdx9y1X4lRmOnhrl6UOzNFyLaLyT/s03Uq2WFjavoAhCn45kg54mD891CDWgNTrUuH5IoAT1mudbrautE9PhX/7Zn/3Xrwgh+MTnPueKHTtCDc1LVq1aumTVxqVEs/1Ka0uIHeGO3btDKSU7d7523+PXjYp49OgOrUHceGT6P29Y1f/gxp64nJ0ta1spoVVIoBQ6CGlOlrl0WQtnZmoE2AsDkqEAY2GEXhqCpkSclozglR/PcnxC8ep4nKB5LZnWLqrVCi3ZGM2ZCFI0CAMPU0AymSSVTvLEsyc5lm+lbc02xkYvkM12E6Tr1DwXiQcX56msyMLls2WbqEChDQ2hIlQhYeARhs7FezCXWDRGEChs2yYMAxqOg68k2rDQQoAhsBJtjJfmKdQlq/riIH1AE4YhaI1tQcQMCEo1dDKNCEMiiTaO5hP8/Q+Oc2ZkimWXDXL6zDnOnh7h7GQbZ2cCBlf1cPMdm5mdnuWvvv0Ca9Zfwj3veD+BEWPPk8+TampH+g1WtiniePi+QBoBQoLSEsMQCB362SWbrcl6/LvDv/sHHwRYtWrV6hsuX3PXQH/3FZ2dmWvTiWiTUKGoNJzQ8/VoqeId3HvwzO5/3P3IruFh1MUtmmqRYP/7IIaGhuTg4KC4/np4+ml4aOcx+dTw7qMrl3Z8sr15+WdjUvq1esMyDYHWGonArxfY3JtiT8plNJ8EGYKShKFGyRiNMIuR7qOlfYp81eAvvnOWcmodrR0lIrE4lUKRqFBgBCgEWimE0EQTacrVBs8fnaVp7Z3kPIGpLbqW9TE1OkqlVAY/JPA8LNsiAGr1Oi3ZDJ7n4Do1As8n8H1836NariKB+dlpmls7aTge9RqAYHJiikKphBlJY5gGIIgmktSrLtMFgRmNIMIQrSAMFEprfLFwbUGokKaBkoJkIslsLcpf/eOPkYlmolLQEquycksX81WX06dHODYyz0tH53nDTZfRvizN95/Yx5XXJfjor3yCcqXMocPnaU9r+ppC6rUqhgG2FAS+BqmQ0gjS3eutWqL/27/67x960/ZL1m+87dp1v718oPMNA70tdkdzkoitEDLEIMQPTcMPzZWGlVl53daVb77uso0f+q3/8ncfGh4ePvXP8WNcJNg/g1h61y4pH3gg/MlhD/9MH5uUki/8zT9+LhN7+2V3bGt7u2HWfM9xLduMolCEgUc2mmdjT5RzU3WMaASlNUEo6L/kVgq0MT+foyllk25tZ9eTZ7lk6zZSaUGgBaGS1N0GjquQ5kIBH6KJJ+IcOHSaWdVBqn0pR55/hf6lfcSTMXKzM7yyH86cvEBvVxrf9wiCEOX7OI0qTr2G49TwHIcw8HGcBqV8gWQqSblYQBoWphUj8D1qNYeDR08vOA7Hk2BYIASmbROJtzBZqiCMCIZwUCokUBKtoOq5FCoOggQSgcAAy8ILFMV6SCyVInCL9Ax0ccnabpb2NeO5gt0/PMqP9h9nd7XB4JrlVJ0GBw4fZ3Cwl8uu3MapMxMMtAakIy5Ow8dWEqENBArLNpXZstKcCVq+tPPfP/QL73/z1Z9e29/ya5tXpq2Wdpt01gpsGyEtW0rTwJSSuAFBaOhytaEtv8jNWztuaN75gee/uOup23fv3r33tUayf1OeHBctvtTw7t0ayN5127Ub3njXde++/66b77pkw7qbent7YkeOnSwBtef3HvpmZ9/yy/q7WtfYeKEfBlIL0KGAwMG0Yxy80MBTMXy3wbIlHVx5863Uw5DerEU2neTI6WkmZ/MsXdqH5/nU6jU836Oen+ON1y+jO6MXOjO0xrajPL7nCFPGevJemkIhx/r1g0yeP8/oyRPkChXaOlvZtLKL0twcbqNOtZTHMPTFusihmJvDrdeolCvk83nCIKCYn8eQJrZlEwQeB46d5x++9QxeIFECjGgMpEUslsKIxrHCIlcMtmKbAaGvQSmUgvM5zXefOYOVbMWOp0FDLJVGey6l2QuEXkCl7nBmsszeo5McPDGDsOCNN2+gLRnh2edewi3PYKsquZkcoR8QuiWc4gSt5hytZhVDCJQK0FqjESravkxUY/3/1x985i9+95ffevUTG5emHhhojxipZDSMxmLCNDCUVlIpLVSghVJaBEoLraSIWIaUAjkzOhIMLGlKdveuuOf4yPTXnnrqqRI/46myGMH+Fcl18ZOr/XeHP/nQquUd97ekrPaBnmZiMYnrhUxMFXjw3m3lC2MzL+7fN/LNP/jcV+4O3v/mP7h5S9+nbGNGBY2yFErg+B4dyTqDvTZ7LwT4gUemo5NCGJI2A6amKhw6O08i2Qw6xPd90pkMhWIOQ0Cx3GDvwRG2LFuBQGGakkqtwuhsHdnSTX6yRO+SJUgpGD97BhEqlq69nCf3T7J+xQjRME9Ha5qZ8VEk/bhuDZRLbmYaIQzq9Qa1ao16tYrnOJhNkM8VmJov8uxLJyiWNWYsQRguKI/SNBCGxIjGcF0LL9AkzAA/8AmUJjBT7D8+g+cExEyTIAxALlgjVkpzePUqViKL9H362xxWLMsiDJPn957mmedOcMc1K/nsxy+jryNJpjlNXWQpBXGuvHwbudkb2PvUIxzY8wO8WpGIKfF8TaypVWaXbXG/9Y1v5z9297q9G/tj7U3NqSCVTpuJZMKI2REMM4oZiRGJRjANE9d1cb0GWjn4noPvBaSbMmZu4lywZfXWjne/5Y6/FELcrrX+6VLFRYL9K2DX0JCxY/fu8K333X7/Wx+4/fObB/vaU0mTqGUgRRgEXoOYUSHRZcj+pmh6Y1fbrVtXpm+9asvS93/10Vd2+sK6+vYtbZcLVVdB6MlQSGzqXLY0zisnJljW3U1Pb5ZDew+xJOPh1uscfOU0M04Sy4pSyBVYunQlo6PnLvYwBjz94xHe86aNKOWjAoXbaFBzJI4ncWplujsHyOfmyU1N09rRxtLB1ZwbGWH3j04Tcy7wzvuuXnDRnZ7EjhjUajXqtTpKKSqVKioEBRjSxLKjfOc7T3JuusKp8yXMRBNCXBRnkEhTIkzJwrpXkMbC/VOoFaGvmSqEPL33DBhxBBC4LmYkAmFIpVjASrQipM1t2zN8dOhSGvUyNU9g2P0cHvNIWS73XLcC1ylhyDqJbIJMdy8YeTqWp1nZt4MtWzbxV3/6R9Tys8hoig2bL2d26mxkY2ewc0VXiqasrRLptDlfFbx6dpbpnEuloZBGlNbmOKuWtrBpsJts3KZWKeH5HoHrESqFacbN3MSZcP3SljfcdtNNm4UQ+18rosfPPcF27twpH/j0p8P7779743vfets/blrXYcYTph+LxMyF+VhMtI1QUWSgIPB1KJVqjTT09Ze0bFnWe/P3Dpyvla2WldRL81J5DayYidCKgTaTX//Itdx+6+VcuDDD/pPn2T7YzcY1q7l+czO/99UxWlq6KOamsWwL07DxwgqxWJS9By9w6oJLfzKB5zqoIERjUKrWUToEDfmZaYJ6mc7ujSRTCTLNrew7Nc7Jl15mbHyaX3jbjex7eT/rVvdiCIXne/iOj9eoEUtmOX52ktbWFh5+9CW+/eRBtJFEmzGEZSK0QBiANBHSRJoWXqOOJQKiEQvlCbQPvorw1N7zTMwXsJIDCGkQhCER06JeLuC6imTrAAkZcOf2PmYunOdPvroXR7TS1NbCqiWtfOC+dVSqFZQURM0odVdwaM+zVPMzrFndRtuS5bS1pUi3tnPg9Gm6u5qZOnOE2clzdHc0hXYyK09NIvfvOcfh83WmqxIvjCLMCIZpErHKRM0cS9tP8+47VnDJShuvWsL3AvxggUN+UNbpTERfunngXY8+wf7rQQ7DIsH+pXjoIRge1tbt127+4rrlLWbUCoOopa0gaKA1oBUR2wZDoqTEsoSI2qbhxNIUynnVFq+Lm1bLtE45zLcNkBupEBUCK9nJ5Xe8haaB5VA6TybUFGdSPPrYIfpbTCbOXyAajZLtHKBUKFKtVGhty3KhlCNiRxgfL/P3X3+F//SeS0BPgyHR0qBWqWJIQbVSZX5mGrSita2DaDSOZdtY0ShE0jy1v8RM+UnqpfOkHn+e97/tDtJmBMeroqwYj710kudePEw63cKR01NgpjBlBGGYCGkhkSB9hDAwpIFE06jViLdITKFpNFzCEA6MODx1YBIh4hiWRXjR/14qj/npKSLxNOmWHmxVw/MlQntUE4M4TRsJrSiV6SK3zdboSoGHJFdssPsHr/C177+CEpIP37eKodvrtK/aysd+5Zd59cUbeP7xHzJ+9iRLBrqpqqjxxFN5jk2Dq5IIuxsZE1h64bykYaANG0/aHJl2+b2/Ocovv6WDwW6TWq2GChUaAy/wkFZB9HW2Lge4ft26xRrsX6PuEmI4fMcDd9+xvr/pUkk9tM2M6VQbCCmIRG2kmeDEmQmOHptmdm4egUdXW4JVPc10NLVLz64wNTZKefJFhJkk1Aalis+lN96CSnQxe2GMtozkzIzie0ebaGtp4+CRab751DhNG+4lFJBpSjMxOU9PbzvT0TGcSJRoNML3nj3D9q0ruXpJEoscqYikXqiCnaBSKdOo1hBmBCuewIpYSFMSiccxbIvlg+u5MDPL3KSFn5tmYnY3H33HLSSjCb78rT08v/88SAtm5pGRNEJItBRIqTFNgQ4EaIGQBqZlE7gevtugPWujPZdqqcHZYpRvPD+HE0YWJHMrikYQNQXluUk8x6ejfSnJTBOBl+Tpo+Nct7Gd1q4oQfMA2q0xNzHN+WnNZWvaUJ5P3NTcdu0K1q3pZnymQUvcYXa2QMPfR/ey9dx27/Xccvt17H3+IF/44sM88eocFd2MsGJoQyKUjwoEWktQIdK0ELaBEg7SjjDrdPKNp2bpvqcF6TfwAo0fgud70rRieHXZDmC85YFwkWD/8toLsXs3m1Z0v7U5EWrbCLVbryCEJhaJkSu4/NnfPs4PX5wiV4nhXOxgi5lzLGkZZ8vKFFdtyLCqr5uIHWV2Zho7KuleeQnjBcl3n/khb717EOUavHqyQTW6Ajuo8A8/mODUrGTp/CypdJqW9nbOHDuKU5J0dLTgVKtIO8FsucHfPnqB1O1NbOhK0JI0CZwKwkrgeh5aBZiWja/BkALDMIgl4kQTSexojNbONuqlHK5tcH52kv/y98/Rmo1x8PA4RqQJpUCYAolEiAVVQhoG0rTxgwbCMBY8LkwLx/MwdUBvawbfrXNiKuDrL88xXbdAeUgzimHZmJaB36hQKRaJZdsJgXIhB0hebdiMOwYXZuuUT3yfuJpnSdolpTfi1GN4oU/MthloUSxtj2JdmiVUAmSMWrXB+KkDjI9NI7LLWX/jfdzuD7D7pT/AjiVIiAbpqK/b4jrMxi2EhKovxUwlaszUQoimEP7CeZ2ZjzE2U6cn5VKr+fhK4IchsUSA77qxhd6dxXuwf/F9l3zggRCwm9PyKpOacKraMK0I0WiSXC3g1//Ld3nykI+ZXoKKCyIEoG1CFGcqMPJyg8dfucClKyLcdlUnS7taWbqtg6aOFqarkiu2XoXp5ynlcsxNjVMcmeRURRNPdpHpamVqbIRZY6HGaY5r7tia4uiYZHYmhZPMUJ69wHQJ/vPXz/Mr97SwrL8DcaBBoAO0s9BJYRgGxWqFaq1OMhFHqZBoIo1Tr9HU1kqxpY1GLYowY0yW8kzMFjCS7aBDTMRPLbO1EEjbwrTiWKaBGwZIM4JhLuxjDkJNIirobknw7IFRvv1ykTm/CbwySgXYkRhWNI7yG1RmZ5AighY2lhEhnUnR2tGFV2tw+sRLrO+Cq69Ms2VNP6uWNHP27CjTk3PEbEFdBkSkpFL2KFVKNHd1s3zlKjLZBKGM8oMnT/MnX/57jI51vOmuW9i0phVnZkJv6DV0R3NUplJxMxIx8Xwf33NxPVcfnxO8MtoQgWljCgNHJZjL12mPhjQ8DxUKXN+n4foYplUBCJUSQoj/4zT7eb4Hk4DOdPT33bil61d7m6SptUJrRDSW4W+/+Qq7ni5hNy8nDH00Cq/uQdggYgTI0CEE6iLN6RlNPTB58B13kmlNIaWgszVKY+YUpblpGrUCV1w6wA2XtpFQDtMVi+5122jr7qeluxffrXLTpiS/+KaVvPDc88wHCbxAkZsYIZFK4SRX8NyPj9PalGRk1qWm4gT1On6jjlerkenswQuhpaUZx/Nw6g0atTptXd2EShOLJTCsCIZhooVESIG0FoY7wyBEoTGjEaxYDMOMIghxa1XMSAIrnkJLk8APyZgOpUKOx/YXKelWQq+GXy8vdJqkmrFtQZY5fMfBiHfTunQ17UuW09HZSa0wT2n0OX79bev5xFvWcOWmVpqTFgcOHuPhR/bjqTgrO2PUSgUmxmc5evQUhdk5enr6yWYSKN/HECbL+jtZtaqbUydHWbFyDbddtgQKR8Tg5nUijGXmVDT79Xqk9ceTFb3XlfZ0Uyq1ekmyJuquz3TZwI4kgZB1XS5NkSp1RxH6AWg/NOysKATZfT969sWvrVu3zti9cB+6GMH+WeohC0ZDVmhYvusb9WoF3/eIxQOmA5sfH85DvHvBf08pdFBl+8oIq9tNZRm+Rmmj6ktmakqdnTP0PXdeZ8SjAqHBr1U4dfAQImxgGQmm5j0uuXIJTa0JfuG9W4h//TiPn5ukqXMZDdelpz3JO4fW4zUucGjPIxSMAVp7NjOXTHLhxEE2D6wnn1rDXz51BpBEmiBUCi00fuChL854Ka1oaWkm29LCeLWKkAbNLa14voedSKEUSMvEr5fQQZ16qbjwEKNRoqk0fhCiJXi1OlprzEgcw1roRBEEzBRcpnIBZrQTVa8SVvNgxiCUmGGdqFvkmo0djFY6OTDTRbqlk0QyidNw8Kb28We/cjWXrsjgBiFuI+TVvUf57vNTHA8u4fALJdrbXZpFg/MjUwsGpuk4iahNpVLA9zyKhRIq0Axkkwx/5DqcVLfubm3SkzMTudm6/sTnvv/oY+VjL+Z/9jm/670fvrMvEv3Khl4vdaFkUBe2iJg1LANK1RqBLzBEgLBsfLNJTE7XXljoPT0qFlPEfwGGWehjnZ8fGffV5XN+oLtdr4wOQyplQalqICwJWkFQ4Y2X2GztrWrPV7KuolQbDSIRk772hFzTa+HlD2GwHRkGTJw7QXF6FAvBwamQWnQ5qx0TOybQusZN2zt49tQErlpBYW6C2zfG6e6L85XPPUKplKNQrtDavYpUSxdTJ49x9tBBBi7ZRqiXUs8X0FotLEgQAiECqoUcS3qXMHpuBBEqDNPCjsaolCu0tLRQqdUIAkU0mUaHPjrwKJcLgMCKJ0g0NRO4HjoMUNLDrRWQdppIIothGYS1OoHjou0oloCgUsRvlBFWAmFEEaJOW3OEnoRmw8puLmlbzdldYwuCRyTCyPEf86m7B9jSH6FRr0PE4sjhI7x4dJ7ZyHas5FLGDz3L7keOsqrFxcKjpzOJmYiCqaiUCpQKFSan5gkDSTwVoXP1Ekby07q5uUM+9qMX3vrojx59QgjBrl27jH8ixzE5PPzn33/Lfbd95pL+9t/oao0EJ+dCszvlk5ANKuXGQt0as7QVaZdV0ZzfN7r/i0II/ifW2P4vT7N+XqGV2imBhuOq0742tVf3VK1cx6nW0IQgInh+wKX9gi2dZd0IEOXUylOH5o0P/XhCrfnRoZnB3Y+8eNPY9NSuW65dr6VfV5X5GYr5edy6ZmTc4UhlgFxyG1NlCxExQSm6sjDQ7DM3foGMyPOmG5aQO7af5370DMWqx/VXbaavbylFN4rR0ket4jN++hypRJJEUxYvUAi54D5lmFCcHUdKiFo250ZGKOYLxBMJisUCAo0UF68bIjYYBrVSgcD3iWabSLd3IgyLaq2MaYCuFQlCl3hTC5F4jMD3ceplpAgxQ4VfKOI5dUQkiYi1oM04kWSWVSuXEjE1ba1ZbrlqkOsu6cStlSkU86zvjXL3zWuo+y6xZIRzZ0Y4fLrAoeoy/LZNnLtwgeU9MX7hHTdxy42XkO7u55HDFgfG03i+BYFcGLJU0HAaGMlW9hyY4wtfelTv3rWbzg6rF+ADH/iAtWPHjnB4eDgYHh4Ojh0jHBoaMkbOn39EGYJkImIYymOwF4L6HJX6wqZPX9tBome9nCz6v/fco4/Ofe1rXzNeKzLHz/U82EMPPS0BTpyfea7iaOH6vq5UymivQltKo5SPZXgM9gmlpSRoWnnuj7939vK/+Mu//ovv7N598kc/+tHxZ/cdenK67P7WxIXzImyEYnbiAq8enebgTJzL7n4XPas3UwsjjEyHBF6IqlchrDDYazI/epC7rmqmJVHmkW98izPn5xCE3P/mN2Fn+2hdupm2VVvoGtyKiGSYvDBDxLQxDEGoAgxpIqWgmjtPMTdPPNOE1iH5fI4w8NEKcrkCgbew9FyFPrX8DG6jTrKplVRTO4YRoTQ/h6F8JC5udZqInSCRaSMIfRrlElIH6MDBKU/jKwcRb8WId2BGMhiRLE2tPVy6YQ3JiKReq5OKwdvuWkvMzVGdn+Ceq7tJyDoSqNcazM/Xef60i5vZwPRMDuXWufXyJVyyJsXaVW0kMklyye18++QS/ub75/jxgSlGci6esJHpLr78vUNUGw2+/IX/JJvshmqx7c/ee++d67/whS/4Qz+zBHFwcLfevXu3cgrzeaGFcuuhGOx29fLUHMVSDisSwfOV17Z0mzVaNZ78/T/6oz/ZtWvoJ9tKF1XEf3GaOLxHCeDHBy78xcYVrZ/YusSKTc3O65ivxJqeDPunAiw7TkvaU7HWJnPf6emvXXjuK4WdO3dGYdjj2KB5jHWhdqvbWpuaEKqhjp+ZM84Fm7nxhq10L2nGe7VKua45en6eq1ZFsVSeqB2hyWywqavMHZe2cWzP0/z4x/s4P1HgDTdeyqrBS/jrl8/SsXwQ7ddBWjSpkLnREaanZ8hkIvhCgzQQUqO9OXIXjtO2civxaIJKvUKpUCRiR8nnckSjNrV6jcL0JPXCLJnWduxECiEE5dwkQaNC3A6xvVkysQAv2gLSpl6YQQYNAreKWykhZQwr2YKKZxZkeWkR+IqOnlY2rVuON9bOseNn2X7FNJeuXMobtmf57p6zNEdWMXH+DKZpog2D8zN5zpeTyLRJuTBDKq7ZtCxOozRDw6kzMVMimlxHWdl8/WCdH71yjM5ogd72Fo6MHqOts41337mWVn1UPDB0j/67z/xxOtWb3X1wy5bLdw0OVh662IXx9NPXSdgTrN+46pJiI5SmPxVesdo0Io1pbSTjoZKWbF95mT3mp/Z/Yde33qK1vngRI/Qiwf51oL62a8jYsWP32KGzy/9oWWfvQ6mk4+XyBXtZS5SNPT5HJy3MaIpYIsLUzPkZ0AIeChaG9NrU7uHd6sEH780++8Jx3EZJz4bdpJZvJRP38Ko18qUK5/PgeXXmJip41TH2nSzywqEi73jPPWhniscef4rDp6dIJWM8+JY7mXVsSs6C37sKooRKE6iQjhWrkaMWldwktmURSAetNVFb0yzncEo5QmFjmCahH9JwGmhH4XoWjXKB4vQY6dZOjEgMQxpUy3nq5RxGUCUR9cjEBFMVC9GUxPUaBE4VXSvjNqqISAYj3YcRb8a0JcIwMYWB6zh0dHfQ1dHM0v5WHnl8P88+s5f770vzjjes4pVXz/LZh8+ysbvGYLfF0r4k56bLFIMlWIV5Aq9O1nbIJm0qtQpKaQwpqZQLCNFCvH0ZYT1Bd8cED9zcyxuqPr293Zw/8jRhYz39l/TKOUeEGau85i1XDn5HDA9fp3ftMoaPHpVPP/RQuHXrVqsrm/xUWJkMNnW6KuYFIpJqlc0tvaYX62SsoT/7m/9p+D8CNSHEa25R38+9ZcCOHbvVrqEh4+8efvx3nzo49y1PttltTc1hTJbUTRtdelIOZy80aM5k6GxJ9O/c+dBP1aXruR4hhF4y0BOu37iWk+M+smc7ubkZ2iJVCoUyFyYWZOfxuQrfe+IEf/SVEX7/H2dJd69iy7oOXn7mJU6ePM/5iTzbL13J+k2bOT3lYZhRohGbSDRKJBohFo0Qi8XpWraCTGc/WkQwLQspTRoOCBXQlbUIVYjAwLQjSNMiDEOqpSLF3BzppmYwI/iBj1OvUi/mscIynVlN3JaMTXtU/DSWncCrl/GrRdxGBSPZSbRrPdGOJdjZZux4E3Y0jRVLY0XTNDc3kckkaGptwrRsnvjhM5w7dZamWJ0H717HiRmDrx7t5c9fyPClp2qcmLBxVQTPcdAqQCgP16tSKpdo1KrYBlSKBRQBUinS7at44UKSHx+cYWVriDN9kNnpOcrFIk55Hi/Ra3zjhweDgZbktb/0nh2fEzt2hJ9pbraEEHqgNfInXeno1mzUMKOpjB20rJXFxOqZSdH15efO5q/5zYf+4BNCiNrF1b+vOSOcfwvd9HrH7t1KCBF+7kvffTPvvO/PN6/p+EB/G2S9gnrgyqg+dGJK5+ejqrcjdf2nHhpWWms9PDwsr39ondbDOrp+ac+7Vq7o4JKb7xBH8inc2VFa4wPsPz3DxGSDWsNjEvjSOc1MPsEN23p4572bmTp7ir0v7yU3U6S/OcL1Vw0iE52MTBSIRGNI07xoVyswWOirk4akvXeAvCGpzp5ZkELjfZwtNFGdLGImUihpoQIXwzQwTIvAqRJPpjGlpFTMYVkSt1rCVgVam2M0anXmShqifUSaWwiFhVOdJGy4mK0riLetxUqkwVh4AwULoyiGNDBDgR2xsW2TSDRKSyZOrjrHc3te4KZklHVdgl9520q++WKJI2M2Y9UYUUtiRGKEgQ9CkasGnD03y1KzSjn0MFHUSnNE4h2EIbTGWrCyA3zryCzHxi/QaU3RmYpgJ6YocpxUUwejjQ7zsedHgtuuHvjoB99z3+FPfOITX9i1a5fxpb/40wuTTuy7iqag6gQvSG0998PnXxk5d+SlGYBdu3YZO3bsUK+FS+V/qwQD0FprobVWQogPvu0t93xv/UDXcG9T++auZp/uyyzDK0zSl4iuf++OWz8mhPiznTuHTCF2eB9/371/fvM1Gy594rkz4YnyamP/oSPc2OUivCKHTxSZL0uEhPmSQyzUvP9NK7n3qiaM8llePXyaM2dmCJ0G16xvZ+OG5eSDDBNzMwjLRCmF4Cdy/ELgVEphxWyynX3o0GP6wjliHQMk+9dT9gLMYplYcmGVj/YVQkisSByJopybxhABYaMBbh4ZukzNBfgqjdnci5Vqw4pGUU4Bv9rA7lxNunszImoD6uL3oRFyYWJZCDCsEC0MhGETjdrY0mdJV4ap8XGefvJFVq3uZ3nG4FNvaufVc5ofvjTFqYkGjnaJxpLYtoUbxHj8pQnu26Jxy2WaYikSokCpOI8VS1LI50gn44zOw36xiRjdtMyNcGb+DEsHW+lccRmtnUvZc7JoZDJzwa1XrPgL6z074jt27PhT4D8/8gT/+f/xwHftMh46elTv2LHjNe0q9W9qonl4eFjsGhoyfnPXN0888dyrfyXSfU8X6lGV88LcfE36fcsG20uuvOHA4ck/f/zxl6oPvOmWWy/fcsl/malYwTPHA7NudnP4+Sd4501tNPLTfP0Fh5MzJl5ljstWRfjUmwe4clmDyuwYhw+P8cMnXmBq7AKDy1q4bPsga7ddzQWvn0f2TmNGoggBUkjUxajxkx45pRUahR1LI6PNpDuWkGhqJZbMEATQqBSI2AZ+6GOaFhKF16ji1goYysGrFQlqNVzPQkU7ibStJJLuwEo2Ycab8BoOwk6TWbYZO5ZCGAphGEhpYBoSaZhIYSCEwFea5R0pbt7aRXn6JOfPnCcmA5b3t7PvwCmKVRfbsonoKkuyHpuWpRhos7BxKBZzlPJlAgym8z6lYhVLByTjBsKIcnSkQCSawmnUSWcy1HLTeL5DrHUJS9deQWCl2bf/JFdccy37Xt1HvirE6Kwv0ravrr9y9e19A/25F14++PKRXbvstgVvFdnefpk4duwYw7t3q9fK1PLrIYL9bLoYDg0NGQ8//HD4jW984yngqYW/6o8+8Dbr8oY3N1suT+SFENlLL9nwly+cbOjCkRnZveZSjh85RGcS3Lrmzx85w7NjTbRmG7zt7qVcNRjFci4wOTrLcy+e4fmXjqKcMpsGUly+ZRVt/V1E0+2MjtRwQ0VKSrjoqymFWHBvAqQBFjYq1MiYTe/yNfi+Cxi4vgOyFd+tUa8XicaiP404Tr2CFAtE82oN0BGMVAeRln7MRBtmNIJhRRBmhFTPyoVWKsNGEyJ1HC0A1MWiW6OVRrJg9FOtuygk0jBIJ2M4uTLNaZvBZR28sO8oI6fOs2r1Unp724gnbNZ1xNnQG6foNHHsfINXTs0zOuPw1BGH53SV/pYq69euoKu1znRxmkgyTW56nPb2Fs6dO0d5SrO/WuCaq7ex1Mpw+MhRhu69mc/95fcIzCax6/l5KWUQ3nzd2s8lf+0XV63fsePjC6ngsOLnxHD03yrBALhoHSCGhobk0NAQsJsHdux2vvYPf/00LCyJ+93/9NFd807nkiMTjXDd+gHD8zxGz4zQHlU89IVnaDhwz03t3HlFDxlzjtrcOU6MzPDUU/s5deYCliHpbYrS256htSWNaUUw4s2cnaiihUmoFFLKha6Nf8pjAY282DkvxcUmXWGjJWhMhIqR6VxCcdwldBpYyQSe56P92oJwUa4jpYWIdRBtXYadbceMJrAsC2laYEikmUAKsfC11cKdqwYWvoha8OFAL5jqCoNS1ccPJYZhYtsm9VCQz5fJJi1W9LUxOllg7/MHOZaKsXRFDwMD3SQSMSJSs6XXZmNvkmItyUS+mTPTDUbGS+zZP42n4vgNj0atTEFPks1kCL0GcxNlIokUT3x/mm2Dvay+dB0f/fj7mJrJ8Zf/+CxNLa3ia09PSyGPhUNv3Pox+6FPxnbs2PEBrXcZQuz4uSLZv2XbNr179+5w9+7dP/mz+NjHPmZ/7nOfc3/31z/y+WzH4C3/+L3ZAKHMUqnA9NmzlOYnaWmLcfnWQa7Z1EZfU4jfOMNMrsK+gyd56aUjVMtVWpI2LYkYHU0mS5d1gQyJRWPUdIpz02OYholWilAvvAc/qb+01gghEUIgpVx4weXF11+AZVnoUBFNREm2L6E4dhzLrVN3HbxGieZEhJmyhEQ30bZlRNNtWPEkdiSGtAyENBCG+OnbJ5BopdFqgVQX508RauGm6Cc14ly+RrkaIqWBRlFzXfwQCAMyiSh97SnKKYtSyeHEgTOcPTFOZ1cr3T3tZNJxpFnCRDCQNFk2GENt7qHuGRSqgoqjKDUcqlWXRs3BMCIkk610dXWwYe0AW9YvZ8XqZWjq3HXnVXzh779HoFNou1Xs2lMwTLHff/tbbnm/8dCvBkLs+LDW2rhop71onf1awgc/+EHzc5/7nPuJDz3w4faeNR/+0qNjQb0amu8ZuozBVd28+vLLvP/WG1neChGdo5obZ2Ikx/iFWQ4dOMnk5DSmNOlpSdCUsmlrStLVlSKbTeIHPrFEmrmqZHy+CsQIw3BBsbtIJq31wgstF3w0hBAX5byLayHRGIbAtA2EiCCk5pfefxv1ycN8/u+eJubMsH39AJEr7uJbe+dJtS/BsCKYEXOhTjNM+P+x95/Rel33eS/6m3Ou9tbdK3ojKgl2UuyUqGJVWxIgK+6RWxQ7N8mRHacZhGOnuMWOc+TITmzLliWLcFWXKIkEVUiRBAtAgCA6NrB7e/tqs9wPa1P2uddJfHOdmLS1xtgDgwNlEBvref/tKUqAFOAKMDsHVhicEAgncPbP30lrLcZYcJbF1Q4Lqwn9wsf3PLIsJ88dngehLykFHr5fphZ4xKmj0e5x9dIVLl64QrleZWx8hLGxAWqVEvQ65OYqFuhXikE/gMDD1MEKDyEdkd8j9C5TaqzQnlpk0W9RGyqjGy8R5Iu4dBiCMpka5aGvNP2g+o387W+84Uf/2T95H0KIf+AeekiJgwcdrwBLgG8BrACX/xu/8Rv5e9953xv377/lg3/69RU9t+qrgXLGgTdsZbLcYbcX0WrOEzdXaLUbnL4wx3PHXmRuZgYPx3DVp1LyqFQDhvrrDA5UCHxJp9MlzTI2B3WmVjNWWylhKSjEkGvgMtZ+s2Uz2qxFFzgcAmdNkT6ydsYJfMlKt8vfe9NOfvT1IdPnfC4dS7ny0jK7Buvc9x07kGO7+NJzS1RrVZwSeKqgXEnACYlzoohmsjnCOoQF5yzCFbOXtQ6zlo3mrKXT6XH+ygI3DnsoVWwXe70Ya02hLMYRKIkKPSQ5nqxQiXziNKfd6XLpxSZTZ30q9SqDQ1X6+/sol0pYZbGuR64NWZYWcUgOQl8xVK8RkrLsWbJuhyMP/RHPn7zAbdurHLs6g6tOEIQhqT/C7z/c8vP0Gf3WB/b/aCX4YSEOHvxRKQTveve7X3FGo3+rt4h/2XPo0CHvl3/5l/X3fPub7n3r299+5Csv2PDZC5mQQkhFmzdc20fUu8jcxVMsXp3m6qUpnnjieR5//DgLiyuUQkV/1acW+dQrPrVySF9fBeE0Os/J0pRytcT63bfy7PIAjz2/SBD4GGNxa5XEWgM4hCgqhwWwugimEwUYhCmqWCfR7NpQ5l++dyt68WvUS45dm2vUg4Tbb9vH2KDiptvv5Ojzc8RWEvg+CIXBoLxCCeyELcBhCv/3IjDC4EwBcKM1RudYo3HG0Ou02TwWce1Gj+kLp1maW6IUSNLU0OkmOFtEOUlVWJI6a765F1XKEZYChHB0exnziw2uTi8yPbPM3GKTRjOm19NkmSPPQeeQJJrGapepq3NMX7lMX1+NiW07+PJjz7JxtMxA1TG3kCL8MsIPsKrMqYstmbcX9Jvv3H7r/v27933ukSe/cOrUqfjQoXu9o0cv228B7G8EXPd6hw9/WL/+3luuf98Pfd/nj1/w+j/z1ILzVSBt1iOdP8aWvh7LrZxnXjjPuePP8OSTJ7h0dQFnNNWSR+hJpBAo4fClIPQUofSIuwlJarEIwkrIhn138tj5kKfPrhCu3cCKNq34MublZb0AZzHG0MtykjRBuLT4NU6R9tr803dfw87qRdLePMJJavWQbds30T8wgHI5E2N1OmKMJ16YJ4pK+Eoz1Kfoxo48c2id4zyBM0Www8vtqdUaawxG50X1WgNZlvSoyow7rh1j5vxxFudX0cYAkiTJMNqSZRqjXfGjhXwtSP7lKl2AT+L7HqgiMaXdi1ltdFhcabKw0GBufoXZ+RWWlldptdsEgWLnNVvYuWcbr3/D/Uys38DHP/Eo120eYsOw4OpCj57tK1pgr8JLUx25OH1Fv/HOrftee+/Nb1xoZV/7yEcen/vQh37Y/9SnjrlvAez/4HPvvfd6H/7wUb1nx6brf/In/9EXplbqg0e+PGv8oKLypEP7ylO885YKWsJ/+P1jjE1soD/o0F5ZYGigzKZ1fWyc7Gd4oEJ/vUytGlCpeGBzkm7CSqPDSiOml+bU+qpsvO5uPndS89KVNoGSWGu/OetYy1pFc+gso9droYjZPllh34YS77hrO7NLK1yYbbFnU533PdBHvvgsQhbRqnYtEMLKgudn0g6Do9fwxWcX6aaWa7f08UPffhNLyyv40rJuuMzSfJs8XxsCLDitMUZj8yIw0OocZ4o2EZ2Sdla464bNNGdfYnF2mSxJsdaSpJokM6SZRWuLMZow8hjoL9PfV6Kvr0StGtDfV6G/VqIcSaJIEPiKMPApRx7VckClpKhWFH3VgJGhCuvGamya7Gf71kkmJoewJuPmW65jua347Jee4b7rx9kwKJmea9EzxYZUqTIXV5y8cOGqvveGyXW3Xn/Ne6Na/4mf+3cffWmNKiVfabcx729v5Tqq9+7dvP/QT/7Ew414dPijX5gyqlRXeR7Tnn6et+xX7L/+Gn7lD57hn/yTv8/7v/d+Lj/xSVamr8flKYqCY5ekMXE3IUsyuq0WNs9oribY2VXSRs7KapNWY4RunLPSKoIZdBbhlMWumdkIIXBO0G2vMt4nuWP/BFvHa2wcjlg3PsLMzAyhJ2m0mty6cz1RfpV2mqC8ANZmJiwI5wBJ3FllfGyZrRvqfOOFBUpqmFPHL1ENPK69YZztG6rM37iOP330JV68uLCWHOlhjcPqrAgaNwZrC5GmEo75pVUuzzQIwxpWCDJtkMIRpxlZXvxdqiWfyZF+BgZK9PeHlCsRQRAUJwIJWW6wVtCNM3qJJU4NaZYXM+jaFtX3FdVKRLkcUYp8SiFgY1zeptte4gMf+F7OTK3w8LEzvP01w7zzVssnn73CfHOIUt8oKqpxcinyfuHjF80PvW3LwHe+8aZPrx8f+TkhxL8G7KFDh7zDhw/rb1Ww/40z1+HDH9bXXrtz57/5V//X51t2Yvw3P3HWOK+khLN0r5zgdTtjvv0N+/ngx5/l7tfdx7/6Z9+HiGeoR5aRoTJDQzXq9RKVakA58gkDgScdoe8RBcW8oaRHL9Z0ujlxptl6870cPeeYWYwJAr/wZLTFWr7Ti/Fsmzfcup633bmViXrAudPnqVQiHn/iebqpY6qRce7KIj/w2s1M+OfJs86a+67BWl1sJW2RY5ylPYKowvnmIE+9OMu2iTqjQ30sNzvoVJP1EnyTYQzsv2aS/duHOPbcOXrdHEuOcBabx2id4XSCMJq022bDeI31Q5K5K5fotntI6eh0Dam2OAS1asTwQJXR0Tq1esTwcJ3+/hq1Wonh4T7qfRH1vhJjo/1MjPWzYf0Q6yaHGBvsY3igxvhYHxvWj7BucpCBgTJDgzWqtYBqJaJajUCFVMc3smXzbn7nj56gneTsmpSs74dGc5mlpsYr1fHDCs2sJk9eXHJjNele95rt916/f/ddz822Hv3UH/7hqpSSd7/73eqVEJ7+twpgH/rQh/wPfOAD+o479lz/U//X+7+8Go9M/Jc/Pm/wa8rD0pp+ibs3LfO+d+7nyCOXcH3r+ZVfeD/KLGPbs9i0Cc4AFuMMSkKWxhidE3g+cTdheaWN8nyMNmS5ppU4ZpdabL/hTo7Nhlxdios5xBZ+fd3OCjdvr/Ht9+xg/8YhZq7O0Us1gZIEoWRhqUEUBVxcilleTfie105QzU+jtcYaizUGa4qVutYaqw06T/A9xXy6joefnmHXxkH6AoUnoVoK8DzB6mqTxmrGYNlSkTA7vcKeHUM0FldodzsIdOFXojMwGSZP8UTKDTsnWb56jkazSzdOafUcuRF4CqoVn/56QH9/RL0eUSoH1OoVEBblQbVWIYo8orJPpRJSrQRUKyXq9SpR5KM8qFQDBgZKlEKJ7wmCwMPoHKkUYbmMECETm7fz3PEpvvD4FGEg2Tzo2DpRwukOC0sxMqgjyyUSUxUnL8didbWt771+dPvd1278ruHR0fbTz774/KlTp4x76CHFniPi6NG/uZvZ3xaASeecvPnmm/W73nHX637w7//IJ+bbQyO/8+mLBr+uhMtoTp/ivo0r/OB3bOfYpZhHT/X4hZ/7MSYnQmzzKrRnMFkbcJg8A5uj0x4mT1BKYY1leakBXkSaZySppR1nNNoZS6sxI1t3c7EzxJWFDr4K0DrHFz3ecc8OtvSHXH7pPH0DdfJcI6Wl3WpQDj02TAyw65otPPrcFN3E8J33jaLaZ4oWzlicdWhjMC//tzGYPEX6imWzgYefWSD0FBtHa1R8w6bJURZmF3BWEscpzmY0Wyk4w617N1MPigq4tFwkUDqdImyGwNFsNrhxz0bozbC03GRpNSWzoDUEgaIUCvprBXD6+mqUyyFhGBBFIQ6LUoog8PH9oLj3KYnyJE5CEPiUS2Wcs3gCfF9hrEUAvh8ihMIPIqQXUqoNMjE+wie+9AznZlKG+wTra5atYz6jfY65hRaZrRCWShhZ4eIS8sTZhtk03l+7/+bNb739tuveHNZGp7/zZ372zNGjuEcOHfI233cffxPz2aseYAcOHFAvvviiffDBB92//sD7fuodBw7+7qkrfvmhL89aGdWUzWOWLz3DPRsbvO8tG1hJAj76yDLf9d3v4IH7r8O0pzCNKUxrDpN3yJMeYLA6QScxSa9L3EtoNbtoA70kY3m5w8JiTKOT0unmNFopptTParSFmcUE6UlKyvDOuzdz3aYa7UaP4dE6UhSbQqNT1o8NIxTMraZ84/krPHF6AS8MeNct/ajOOazJMcZitUMoUcQB5TnWGazJUCpiwW7k4WPzNNoZi6sNnHHUItizcyMzV6cIPcvE6Ai9TpfGSotWK6YcGa7bOcZzL1zAWAM2B6eRUtJt9dgw3s/GEcXi3BxLKxlOQp47AgWVkqRW9imHilIpIAzDwjJOKUrlEKWKW5+nFJ7y0Hm2dgt2aF0wRXSu0VYjcDgMzhkcjigqYazAj8ooFbBpyyZeeukyT55aYLFnGRsIGA4S1g0rtoxLlpYaLLcclErIqEYrLclnL3Rcs63ta/ZOrL/tusnvuvbanbtn2/aFX/jYxxaOHj3qioq2R/yfBNqrGWDikUOHvJ/84AcNMP5rv/LTv3XP/W/6R188ltiHn1xFRTWZdZv0Lj3JG3ZlfOd9oxib8vEncnrU+Mn/17uJ/BjTnMK1r5InTZJeEw+HcIYkSei2O7RWWyRxTrMVo7yQxcUV5he6zC/FLDV7xLmj09M0c4Ue2sliC7SxrB+psndDje1bt6CTGKVCLlyapdWMSYXkwkKPP/r883zp2CzHzjboZlCLLG+9eRAvPofTGVZbPE/x3Omc3En6oiKpxZkiv+xKup7PPDGN73usNDPOTTV46vg5Tp29jENQjRSbN0zw7LPHuPmmvcxOLzI6FBCFjq8++SJKShwah0U6jXEancTcdu1GmouXabY0WhuUAmcNlbJP2ZdUqyGBL/F9VRzSTY4nBb6SeJ6iGD8txlranS5ZktLrxnS7MVprtNGFt6Ms1vpSSJRSeL6Po1iWVAZqlKMSnzv6HJ28ynIjZtuGKhV61MKUnZMhTreYnWsR54KwUkf6dXFxGfn8mYYNPdw9N2689q79m9+3/9prJqYXzdkf+/VfWzp69KhzzslTp07JU6dOfQtg/72qdfLkSbfl/vvtd7ztztv//c/+84c3bL7hNb/5mav6+QuZCspVETcWEItP8Z7b4C23DyCyJl+bqvLFExnv/8G3cdMNO8mb55HxArq7TNxcwWQJWZLQajTJ4phuq4PJLcur3WKe6iasLsc0OxmNTkKrm9LLIdOWdlfj6htp2CrGQC1y1D049uQJtIP5+UXqg8OcX2jyha9f4uvPz9DKyzgCPF9gjSNPOrzhphEG7BWyLEEKyVI6wC98tEuzp7hhV0CetBA2p9o3xotLw3z+yWkCKZHa4LAYK5idb3H23Bxnp2ZYXF6gr1Ji1zXrOH/uMmmccXHqCmcvL+IFqghpdw6cQSrHynKHXTvWU5ENOu0GKw1NFAqMsXieRzmQ+IrC91+tRUoDAot1hjRNyNKcLEnJc03cK47xUgqyLC9oWElGlufFDY2ifRQASiKEQ5KRx1323rCPclTli195ni514tiwfV0JmSdIkbB9XLF5SJC0FphfaKBlQKVSJxV94uSMFs9faJrR/ii4+4ZNt9592/b33XDD3s2tnpj+oR/6oZlTp045KQQ/feiQd9//xvbx1QYwcejQIe+DH/ygOXz4sP8vPvDD//Lb3vr231pIRwd/59PTeqlb9jylSOZeYiMv8f33ldm/zSfvNplNB/jdrySMjo3ygR9/B6FYxDan0N0luu0Gaa9HmiQkSUqeprSbLeJuRrMVEyeOXuyYml6m0UppdRI6vYRenJNpg7EOkxlSApJoHQiPxlKDd37bzYwMVVBRwFwz40+/fJrnziyhCQlKEUIVCxW0I8k040Mer7tlC2XZw/cynNfHn3014NnLI8wuWzav99k46qFFP0tmjFU9wjdeWCDLHTiNcznO5Hg4PGWJOynnzl/l6twy1lhqtYD+esTKaocLMwsoz1tr0YogdCkkaZxTKwlu3ruBxbnzdGPo9HK8QNDLHOVKiVBZPCVQSmJyjadk4Wmf5aRJUlhR5oZc54UfSW5wzqE8jyzJKByYDYEn8DyJlFCuVCjVapRrNZRSaGsxeY877ryZlUbC0y/M0sxKpDZl22gAJsUYzWA5Zc/GMuv7cuLGPMuNLrkURFE/bVOTz19O3YtXumaoXgpvvW7TTTfv3fRDN+29Zr8X1Vtnzl+4evTo0ex/Z1VTryZgHT36mD169FH7zrffc/9P/NP3f3T7dXd+92MnnffFp1tWq7LS3UXE3NPctWGF77yvj9H+lKzXIRd9/P5Xuyx2Iw7/1LvYvaMfvXwWs3qZXmuJuNMl7XSQzmCyhNXlJiuLTZZXO7Q7GoTHzOzKGus8odFO6MY5vdSwlhuOwqGlIqtuQROhtWbzaIDJck5cXOLTX36J2IU4B3G3QxLHZEkBUJRPkqfcvncdjcWYT3xpiYQxptvDfO4b4Lw+UqNYaIHzJ3j4Gcnvf2qB0kCV2dWYlVaGyTW9To88bpHHHdK4XfgfSoFxjpOnzrLa7DA2NowKPE6fuYzygoJp7yxCWKQDrTvcceMWtm7ohyyj216hl0g6iaOZCVoZDNRKeGg8qVCyCHkHyHVWpDtLibGOXpKSphlpnNGLE7JMgysMhEJfUquWGBzqp1KvUalWsQikFxKU6wRRP1YqpIA7776VJ46dZmq+x1JLEvqwbgDsWoKnZ2PGBh27N3isryUQL9NaXSDuJlhVFS3TL1+Yxp26HNtKtaRu2je5+9a9G777/ntufu8tt1w3sLSazr7//e9fenmt75wTf10JmeKVDKo1YMmf+Zmf0YWWismf/en3/5Mde2/6wFI2xhefXtKNDsombWEbF9hWWea+fYJrNkSYrIs2Bq19nrkimXEb+YHvfiv7r5HkSxcx3UWy1hKdbpvVpVWc8XEiYHGpzerSMu3YcbVdQYU1dNJlfm6GzuoCeWeFLE3oximZMUjtcMYikJjyKHPjD7DAJtJeymv2jhBFiocfv4QXVujFbbZt6OO6HSMM9pXQ2jHXyLhwtc3p80vcsX+Q6zZt4OEvz1GvlYrtpQyLZYRxOKexuoNzHnES89Zv286fPfoEVxdzbtg5wZ6t/UzWBYIeSZKwtNrjpbPzHD9zFYsizzOqkUfgCTq9HCEkFoNwFoFGZxm1SPMT33sX06ceYd26DczNLnDuzCVW2hkxPi/Nddk2HHH/ripDFUG5LKnVQqrlEM+3+IFHqRShc0uaagqljMPYgh5mtMbzBBs2jBW/r1bFD0uUqjX8KEJ4Pvj9RPVxgvoYaZpRH1/PkyfafOeP/ArdPKBkl3nztbBrJAUyAuXhKYOSilIYof0SK0nA5QXHhSWP+bRKLEdwfh/Sl4zWMnPT5lC+Znef2DBeYmp6Pj1+9sqnv/Lkyd/9/Oe/chRo/HW+xK+4x4FQUjj75/KK+r/+ib//YzuvvfGfevWtQ0+cjN3zZ5dc2l2Qld40m/va3LJNsXtDQCC6ZFmOAQwhtQ23UN94PTt3b4TOWRqXnkV3Fknbq/RSQVv0oyqb8GvbaOt+puZiFi8+SzC4g5MLdTJnSXot0qRL0pghX7lCb/4kycIZVLqKh8WXEl8AYZ3F8Xs4l21GixAd99CZQZXKCNPkh995I+94TR++vorSXQLfg2CIrh7myy+06WQ+Vy51eeZkh3q5hpWiYNmbbE2sKdfYF5ak12bnNWU2rI/YMaG4cbtCdK+QthZpdxdJkhwna2h/mIsrffzOkaeZWW6jVIixDqXWuJJYhLMoLL1ui7tu3MQ7b6tz4rFPIMMq41t20Vhpsri4zMXlnKfPrSKx3La1zp3bykQioVTxKYeCaq2E7xer+TyzRUQTDqUiup2YTqsFGK7ZtZmNm0YIlCg2i85R6+sniELCUhkV1hBRP7V1exFBhSzV1Cd38i9/5g/44EceQwQeAyzyzpuqbO7v4KQhkA5fshaMoQh9nygMMSKimSrm24qFlmCp69FIA7raUfI8u3OdsrfuHvG2rBticXmBc1dWZp58aekHP/rxP/3sX8j9/ttFlRLgsE5t3Lhx07vf+abv2rVr9/vqQ5s2PXe2xXMnT2iypjcRLInNw12u3eixaaSEJ7ukaZssV1hpMarChr33seM1bwQVk868QLZ0Dhuv0FxdZaVXJpq4kdrYbdhwgrlVx2Kcc6F5kU4+xEC4lbaKSbOUxA2Re33o/gF0eTMM3Yi/7gpm/iRu8QShmae/5HGpKbBZk3KgWYkF0o8o+9DqNvmxAzfyfXdqZl86QuwMUhXRQwooRTXeeuP9HDlqeebECuVyDa1zjBVY4fCEh7GGPE/QVhMoQVSucPzUIpVgmB3XKbrnjxK3V9Eux+aOLNfk+SWSLGf94FZ+/Luu45d/6xmWehrPF3xTaO0KQZpxCt/3ufnaDSzPPIMnFS7vMfXic/jVMYLaIHMXpnAuwCmPb1xMUUJy55YStt0j7hri1BC8vFlcE3jmuaHbW8U4GBsd5oYbdzA2Uin+H5DoVBOIImhA5xrPy+n1lsFP8Mqj1MZqOAO6t8oPfu9r+fgnv8RS29Kkn8+90OHdN9cZLXWxRmMp9HbCSrQx9JIYX2mGPY/RCYHcEGCMR5rnZBpiI6S1yHw5dvO9q6bk5+a6vfsnzy3KIYA9e/aIv1Uz2KFDyKNHcW957a13/8O//7ZPv+NNd/zzdRPr3xinov/UyTNGr5wXewcX1T07ety/12P/Fo/+So7Oe5jMFRcXk5Phsfued7H5lteTdWfJ517CtueIew3mVnLy+g1UdxykU7me+U7E1ELM1ELMSrvD6vI8caeNCMs0VmN0ZshsitYpOtfkTmIIyYMBdGUTprweFZRJNDx+tkG5v4+Bsc3MNwy+kvTynM0jFf7RO0ZoXPwMSnl4a9nDngzw/IhEreM3/6TD577aolIbJO4lhJFhy8Yyg8Mh3V6DetWxY0c//XWPldVV2p2YWrWfC5eXefaFWSYn6ozWc6zJKeoRIAS+9OmszhCpjPrYNo6dnsVX/pq6mmINCORpyrZ1gzxw0yhXX3wCZzOELEjKzWabCzNNzs4mCBmCEDjhM70SgwgY7S8XvM04Jcn0N+Up8wtN5hYarNu0gfseuJN77ruZwcEQT4GQCmsdQhTRSsYaHEVouxAe7V4CXkgYVpFCkHabjK8bp9vN+MrXXiSK+mgniuV2ysbxGhVfYzB4yqIonMCEkFhRkK21dpjcYlyOUjmBMtRDy1DV4pues3mKG97jHz3d+tVf+o//+efXQtT//9aavcIq2L0SjtpSVN2zf9PQnqGgqVfitp6ooW68ySlfOoS2aG0wOibv2bV/JIkVxSYMv8ruO97G5N5byFrTyN4s0nboaY32NlK/5nrabgNTq5q55VUajTbLqw2anTaeS2i3llievULvygyxDkjihDRPsUaAivDLFUqVIUKvQuJXScqbiEWNOB2m5ycszC1w6z4DpAgRkGY5e7ZO4ufTaG0Q/lpf7lyhNmaIj35J8NVTEfXBAdrtJjfvH+Af/vBr2TBRB6GYW2pRjnwGaiF5Znjp/Dy/8Vtf5NkXlqlWhlho+/zWp+f4gTf0s7WvR573kBRCy9wa/CCitXiRHaObWT/Wz8xCD8+jsBOgEIZanXPDvg3kzVniXgvfk2uzpSUISix3ExABSghyB54QWFXmq+farHZi7to9RM3rEfc6xYeRscjA49vf8w5uvWM/nkzoNRYRaBCyOA8AyvOohhGZTnBO0u1koCxBqUZreYVKvUlY6yNpt+jrm+d1t27jgxVFojOCIOBSQ/GpYwlvvr7KZJ/C2h5GOHDF3x8EWmqUkYhClIBEIoPCTmF1vqGD+rBnRnfzzJXuj/7bf/sfP+TcISnE4b8WjdkrqoIdPXrZHjqE/PX/evHZeqV/dLDi3TpazikHGulSkacxWZqgtQFnELhigyUEygm0toztvYutt70Bm65CbwaVtun2enTFJGroPlaZ5OJck4uXLjM1dZ65+WnStE3geRgkuzfXOfD2O7m6kNBTI1QHNhCWaniRwmpNpzFHc3WOrLuKdDnK98mch1EVKrUay/NX2Lm5zmIvJLYROsu4ZXc/e0eXMekqnvKKymEFQVDiq2f7+LPHQ6q1EZJehze/aTu//LPvYst4GV/k+DJheKBMX0kRSE0lEmzdOMQbH7iFheUmJ05OE4UVGrFiYaXDtVsEvo2LNbcxaGMxFnSuCUv9zDYjLs208D1VyGBwOGcJlOMdr9tNe/ZZkuYSyglyKxAGGrnP8SsZnuejPEVuCuFlUXAi5luaqysZwg+pVErkmUaFiu/7ofey/8ad5HmXLOkQhIrAk1itkUIWYetK4oV+IQi1CodHO05BhpSrRRKNrwRxu0EUSCySP/nC07RiD8/3ESpkNfa5uJhQiSqM9ZfxpcY4VwS6C68IhHcFYVkIhbAO0tQY7aiM71aL/qaFoyfm3vfLv/zBDz9y6JC35f6/vuijV9wMdvgw1jknhBD/IOOdU3fsG/m3u0cdSre0dUo5KYXE4OyaS+2av5/1Bf2Tu9l+65tweYxrL6A686wuL9CV22DsTq50PC5fOMP09AxxVvgSjlRG0QQstTNqUYeD37YLFV/gR951LT//kbMspIpS3zAur+OXEryoXnhd5B3ajatkvQwRRCi/j7BvI/3rr6PZyRnrk6zOJ4AsXJy0xrm1iotDCUOmKzz9Emi/XtgHSMHs1Rl+8Rf+FGct6yb7uG7vJCNDAVjFpZkGTz59kStXG+g8YX4pRUoPqyWlsMrlhQrn53L2TSpclhd/pitMcKQASU7kR4AozHewCClIexlb1g8wXLacbSzheT5G20J0KUtcXYVEe4RCMFASpKnBCg/pwAmDCgLmO46HT3YYqjlu3aT4yfe9my3bN9HtNVDOEPgeSmjidoyUf24ChCsSKuNeytJCk1rfMOWwQqfVwwtShO6wGieAJm6VGCiPsmGin+mVHk4WpGoVKlbSIf742ZjTc5rbtvWzeTClJFOUM+A0SIkw2sWdrlVSieHJ7Srv28aJxez3/v0vffyfr6ycnX7ooYfU/QcP/rVKXV6ZSw4h3Jol8r9beNsbnl7aN/mb105WNpVpI4U1MigJJ5002iAleGGZVV1l141vxSv3o5dexDSniFfnWNUjZIO3cuVKyoWLJ/CVZGhiEytdS6eX0+nkpMYh8hbf9eZNDKqLTF09RuQC3n/gVn7lDy7T0wPo2DIZtrj25pBLswnn5xVKrqcb9eg05+k1zxKE/VQGxrm6uky52kHZErks000cBm+NwLtmhuNBKzYsthSBFxZtjYTXv/Z6eq0Wn//Cc3z0yDTjI1V+/YM/iNaCf/XgH7Ky2uOWW7Zz/z376Our8dP/4XOkWiKFJLdVppY67Jnw0S5e+8QuZhEQSK9MagrDHbHGvxBC4LTh2p3rEekKedpDKMhzhXCangu4ON9CCJ9MCyrK0fOhlTsE3prdnED5CidCGt0V7n3g9ezYtZ5OewnPUygpwBrSLClEpDjyPMc5SNMca2FluUmr2cOYJkGY0eumVOt96DQlt46oGpHEMcr1MFlWBL6z1vPZgu2PrHBiNuDCYsb20RJ7JyI2DVv6/diJJDbCU1597BrV9fs5lURfe/bEuZ//3d/9/U8ArMUe/bX7e7xiBZcHDx40xV/6yMN/8smB/f/4h974Izsn+/7xtiE1UTM5RvdsJsq2kVfE0y9otXHnNbxu3TZM4yKus4CLV4l1H63ynRx/scX09HkmJ9dj/D5ml1dZP+IzMag4fi4mj7u8866t7B7vkDZmiHxHc+ESo1GF73vzfn7l42cw2mNwSLC93iVenGdk2zAXZlIWlGWVfhpeSNxu4PKMBFi8Mo8zFUR5PdOLbXIqWFu0slIanFPgD6BlGSHAGUd/NeCuO3awY0Odv3fgdr721EV+7yOP0ksVgR+xdcck/+F9b+LGa0fRmebS1R4D/WWuLqQEvsQKR8owhBmm0cA5wcuDh1AeVg0wuzyPUgqHXJuFLH7ksWv7IKsLzxTOU0aS5zleUGJ6QdPKChaGMQZrYbiqaK9aUHLtzy/aPZ2k3H3Tet722v0k3RZSCgLPw5kUZ3TB5pCKJI5xWBwOqzVxnGOtoBfnLC1PU61VEU7izc9T6uujVK4WlnY44m6X9uoKvZbBlwIhA2eFNMVcaxFC0XEhz0wZjl+J5UCQil3jvrhp97g3OjaoF4z/iW88P/1rH//4xx9dq6JSCOEOHvzfY57zilY0Hzy45tJ75EjzV37zD36e6jW/9Q/fe9N3bRos/XBAdc/lVU8euxzTTQ2/9+P3QLJAunwBmSzTzRVL/g08ey7l6vQcUf8GptqGQM9T8jL2jVV57IUFGo2I9YMet+0rkbbOo6RA6wwZePRmT7Jv6zg3X1PhM99Y5qzN2NxncMKi4gYjYc5AX4vRTTVOzIc8PzVK0pghbi8inIfpruCpMpdnBYvxegZkULSI0pG5kIH111OpLrDU1qjQp9uz/Oy//RM+8GOvY/PGOnfcvIWPf/zL/Ng/+q+UygGb15XYsXWIpNfmzLlV/u0vf57ZxRhfVsBYjIHK8BaioRHszCUQOTgfbEpYHmWxU2JqZhnlBWt+GpIs06wfqTFcFVw4PYXDkRsDwqFFiZdm2yDCb74u3Txjy5DPdAu0UCg0TgisEASe462v3U1/ydHppARRgHMak6eYPEcIR5rl9HopQeijhEWpgmm/utokTWKclQgnCKMSjUYb4YX4fkStfwilfC5cnuKOa4e4464dHD87z9JqKpQKPISHF0QEgY8nBVHgITBUSoLQt9NXrDxy9PHp//r5T/7RyZfZGgcPHpRCiP+trlSveMuAl116H3rogDx48MjS//2bZ34V+I03v/7tt1SHR7/PunjPu9508827twbKTb8gStkyvbRLW+3kxfkKVxcWCQdHmF2KKcuYjetLrK60CVxAp2NZXFnh7XdtJzBTZDopvAWtQ+cWiWV16mnuu/YuvvDVq4RRjW57mQ39IY1uzMxiF5W18Ks5+wYi5hZ9LsQjRDqm01wmCiVJd555LXnqzAhv3TVO3L5MJAIqfUNcmGsjvKKKOGsxqsQXvzZHpfpV/v2/fjtJt8W/+7nv47/85qMYp/nHP/Zt6N4qpUqJzz38Fb7x3BJ9Q6M4XQSqK+WztNrhxUtthmuD9Joz4KAX5wxs3ccjD0+TZppSFGHXJCpWa7ZvmMQzTeL2CsIVq/lqvZ+zc7Da1UgvKAZeqehkUPIdoxXHdEfjPIUUkizX7Nta575bNhPHq3iBQuHIem2cyYrNqYA8z/GDoDDecYYkzsnSQkhaKUc4Ck1ZmmqME+g0xtkaUaVMYnzOnjlPn12wQ33jcmFIfu9If/BcnuSvkWE4Uq0F+8vlMkm3m/q+ftGY+KlarTJ/+fLTV3/vw0W4+kMPPaSOHDnCGrD+t1u+vVo8OV4u4eKhhw7I97znSPyZhz/xGPAYwC27+37h+eOLH1hcdjpulrwwHMCWx5hb6VLvn0B3rnDNoGR6KaHbism7PayoEwSSUGl2bfTQnTmczQstmBM4k2MsdJtXGVq/wOaNfbx4scGWgWF0q82pk5fYvaVGQEArdiyuLlDxhojjgFIwWMwRtoHMY3ALfOYrAfdcdwPVSpu0s0RQzkDkeEJjnSoItziGhoZ5+qnLnD6/zLW7RohKATtHfbpdy1h/ibbIaHYcTz4zRa1vYM0G26wR4jVRIKhUfDrzLWySoYVieNudfOOcz+PPThFFAc5ka171EiFgx6Yx0u50oSwWPqUoRKsKJy7Pg/DBCawovPYT7ZHklg19kvmuRYugmPFMj9ffdS0TfR552sOPyuRpjNMZgafIdU4aZ+AceZbirEHnhtWVLgZFGIWYXIOCwJc0mz0MDp2FVCIfZMjvHHmK1myLKpbmlRfcer/+/n/3e5+/CzjxP7+xHvIA+386jeVVJ1c5cuSUA8SBA4eCU6eOmjcd+IEfHtj1+n/y8Gm/9KdPxvLTz7fEfKcf6VcIK3UaK4vsGc9Jkx5Ly6vcuGOQNMvIvYBzM5YoCvm2m8vo1mWEK5TM3XaLuNfG5BlpnBCU+rjYrHJiKuHMdMwzF9pMN3zSNAUhUcIy0hcw0xRcXSl8D4VxYFJ00sJlGa1EcnXFcvttdzIyPAjKY+d1d/LECw0uXe0RhB4CCATkrRb+yhyDtsOx//RhOn/2WTj+IseefpFcw7FHnuZLT8xCUMGawrdDAN24wQP37uTW68ZpthpEfZtw1X189aTg459+Go0HmAJcQmOFIVSCt92/i2TxJVpLs/i+olLt59nzXc7MdpCqskZe85DSYZ2g4hvW9QtWYohtgM0zNk+E/NQP3c9AKSlIuM7isi6+NMS9mDhJ10xPDcIJkjXJSredgJR4fkCWaXSaEgYh3cRQq5epV8ts3LqFlxYc/+znP0OcS3Zu7BMubdmNE/WNu/Zet+Vrx178kx//8R8PP/CBD7Bnzx513333yfvuu0+Ojo6KAwcOiKNHj3L06NG/kTSWV6Wr1IEDD8kjRw5mb3jLu7/rrQd/9EO6upXlFy65yoASSe5QYUg3k4R5j1oQo1zG5ICPVP1ML+ccu2RZOdkhcZI79tTwMXSzuKDaKDA2R+c5OtPkmSbtNgnlIDjwwhDrBjCqxvGFBs9NtZioZbxxfx9WZGht8KwjtxJUBaWWyVqL1AaGeerpS/zYlQavu3cf1VKF6pnj5E6S6xSLj3ABpbzLHXaWaz7/NfSFIcbOTTHR65EFNU583XF2ZoHwwhne6m/iaBYwLSNwFmslDsvMzDI/9+QZLAE6c1y8/CJXL81BKBkeKZFmmiQttFh5njI0UKGv6nGpuUwp9ClValxZNTx/YQWhymutnYdDUai3NI0UhLSs6/NYnsvwKkPc821vYlGPUMvajEUeOl5CSUEvjTE6I1IRuTNEQUSr2SbPMnzfo1zxyPNim9hud7FZStzLsF6FWt8A/SM1ZP84/+23H2W+44ivGjaPSXaP9snVhQWzfmjLew4cePvP/ef//J9fGhwc/GthX/ydBtihQ4ckHHDbt+/d9sA73/dfhjbdbJ954SWszqWxOSVfUA4EndQibYuSaaJtRKWvj7NnVnlmqgdqkFLgyOMerV4PYyroLAc0Uhp0npKkKTZ3pFmKyzIanZg0dwR+QNxZobk8jbAaX0rOdy0facV4UhDIwqjGGYsxEj+o0tWX+PYbxxgb3MjHnrrAHxz5OngVduwd58Z92+gbyL/p+LvVLPP27CKDZoXmC3NF6+cFSJcxLGMevzDHjc7xRj1FLDz+TEygrULKmNEhicPw/EsLLC00IHfISLL/uu3cORGye7yfPzq3yKPPnicqRbgkZt1IHyE5OmlTrURoBOenG/R0hPQDnBUFhenlIUp5tHJDqgXDpZRq3xijN34Hz/XWc+qLKdtHSty3LeT+LYIayxjngVfIYUyc0uh0WVpaoa9eB1ew6/PUMT+3QrebIa2lWi0TRoBJ2LD1Jh55Zp6HPv0sYXWYnhM8enyFwbvqYjgoMeL3gr0bKr90xLm37t176hVHXn/VAWzv3gfFwYPC/IN//ou/UN98R/VLT7ykZ5cXvOZKk2arTc3LKZfHWG3FCLXKunHF2TnD2eNNlrIyQlmMiclyhxOK+YWYVk8XzrsmR6LRaUaWZginSNIca8rMzLVxqWZx4SybRh3fcfMWBvqg20t46cwi3zi1iAjreNLDOAsuB21ARBBWWH72Kd67boq792/ji3vH+OMzTRaXG0TK8B1v3cnXnlzi0lTMkO4QJEv0dI+qknjKkYiAhnV4usU+PLTu0gW2iRlKcoTltMcb793CcL9icXmVpJsy0F/lhm2jvGFdjeu6VxHHvsTl83VMbU8R6SI02IxN64cReQeFxgpHo9kmCMoIERfpt3JtihAv06okmVa00oywNsTkre+GwX108hznyjTnPM42BnnuSpm/d3PExmAaL83p9jpoY+m0uwUNy2ra3ZR2K6bXSXHaYHKDH/jUqlXCWsTE+BhefQP/9chHSWWFklAo4ZjtCb58vM3BO4ZVGrfNronxt/zo97znre95z8c/tXbaMd8C2P9Sa3hAHXyPNK+5+8337Lv5gXdMN3smTla8DUOOu3cOMj9nmL4yj8TSbHQYGbI4r8TXTjWxXkCjdRnd65BlOQQVBkbXc3mhzekrXXZVItK0jbSWLEnIkhyBRRuPdlzj7IUrdGen+PHvvpN3vXErunWJlZmzdLo5t2/r56a9Q/z2n71IZupgTZG8JxzOSYRXZjo3JGnM4B9/jO/euYPXXX8Hj/ljfOWFl/jsl5d50xse4PLUHPMuRAQBm72ENoarsaGbrFLzS/SpKoO2w6iE55zikhfSzHM2rq9Qrfl88EN/wL03XMMP3L+T6z3N9uVL8MhnyGYuo0ZG6b/rfpZP90AWdt5IGBuq0FmdIdc5nU6MFZJSuYRzHZwIkRSs92Ip4pBKYRLDfD7IxLb3IgduxAmParmKM5o07rHaUzxydT0zDcH33w7XVi+RJA2skyRpTrkc0Wj16HZSGqtthAGbaXwJlVpEWC4xODbKxt3X86EjX+erx69QrgwU8hrhEUQBFxYSXpyz3LG9Qtm23a6t1X/hHJ86cHLPK8rZ91W15Dh58qQ4/OCD7rv/0U/9Xji0d/NTT3zZHbijLn/wTet5/U2DvO7mjdx9/RaSdpMXLy7Q6OW8eDnm6nyD8ajB9755J2+/Zz333LiBkZrHpXMXOX91iSj0uG3vEGlzBm0tcdyjsdQgzzJUaYTjs3U+//AT/PxPvY233RIx9dwnWL16krQ1T3d5luXps4z1h0yuW88zp6YwIgSrKex4NTLvsdBYJN92Pdfu3YN6/in65qZ4zR17eP3d15IuNRkZqVEbHuKJC8v0VJWOVLyQGYZecyeDu7dS3byB6Ia9mJlpnE35kjfBH9vNJJ7l21+7i7lTL3Dfxj5+8PoxrrcNBh//MtnXH0XW6vC6t/DYlpt5aMZx8so8ArBGEAWC+2/ZQmv6OVYWp2k0Yqq1Pjo24sJ0BxmUAW8tClfgZIDVCV5ljJGbvxszehMGD88rotUd4Pk+WZbQ63RZTAY4OZ0z2W/p83v0Om1y42i1U7qdjJWVNllqsKbwBCmVfarVKgOjQ1yz/2a+cdHyk7/4GTJbQhZUDZAeEh+lSix3UnZt6Jdh3nBDY4PrB9dvfuRt//HXLx84cOAVYTr6qqpgBw4cUEII87YD73vTxVlx9zee+31z+MfuU3dfKzGNZ8jaEuGXmQwD3ntPmaUF+MSTlmavx9b+mJ/5kVupmilMnqH6y9yyeYg33HwD//kPTvBnn32K77jvHQx7JXS3AUaSaU2e5lQG1/PpL36VH3rvrdy+NealbzxM5IN0hlQ7kIpqqcTi1AtsXncbuzeUeebsEr4sTGxM2sEkTbQWHHnqFKd37+On3vpethz/Cq3L54lcyg9skMj+hLPpKp2hnK91hvjMUo/9Gwb5jn/8w0xesxUXKDrTl/nY1WU+//RVLlfXE4WC77p7C3evk3i1SQalZXFqhsbsDDLtYa7Zy9l7v4MPn17h6TNXMHkPPxBYKTB5yoaRGmVP89LVGeKuwwt8avUStu3hXIjOHUiL8grnJ2M1Uf8GJm98B9766wrhprBF9hgFodjkKZ4UZC6j02hwvlvl177Yx/fd3M962WRlvokWhjwp/BptrqmUPKoljyiQ1KoVNl6zg1U7yqFf+QirqUc1CjBWrpniSBAKKT2Wuo6nzmTU93l2QMTetVsm/wnwlYcOHED8efDityrYXxFg4ujRoy4c2fOhuJNv+dV/8TZ32w1V2T77JFl7CWFidNykMXORlanjLM1O88TZFA/HT33PPmq9Y6zOncZmPZL2Is25s6hkigfuvZallZxjz57n7tt20Fo8CwaWV1fwVImLjTqXZ1v8yIHrmH7hczhjWZhfYW56kZXFBr1OgtFFkkmaWWIb8Owzz+GyLjiLH5URysOkXUqlAaYbDlstcZ9YJhgcgfEJdNLEX17Ff/LrvPnbbmFjf8bmyTpp0uP4008yOTZI8+oUn/rdP+S5uRZyaJB7943z/fvr7MnniXqrDAwN4LTBBh5+tUz7zFni8U38p2nJMxdWKJc9nKdxViOlwGYZe7ev55pJyfzl49RrJQYH+9Em5/zVBrkVbBgv46vCFSrr9RjaejO7HvgevIH1dFodPOnhh0GRRZYXUUh50iPrdoo7V9IljRvMxj7LyxmDUUzenMcYTdazJElxF6uVAiqVgHpfha279hGO7+bBX3+Mz33tAlFYBSWxawRlKGhZQngIVWK13WPruqqoiwalyuCGVV39re//+Z9v8wpR679aKpg8fPiw3Xn7A9euLjfu/MV/+f3uhhsGZPPs48Src3gK0q4jbjdZml8k6aX0FmFxOuS2m25mXa1D9+oMfhBgdUqWJ7jcYtIWK+e+zD9+7wP86//4Gb7y1Az7x+vE6QqedfjVQU4/O8eb795NvPA8K4urzM22CCtlqrVNKJPQWFik1+kipEDoFr4sURucJCj1AQGZ1qRpBi4n1ymiFhA7n25YYnxymBhNaf0kYjVGKYGft7ht1yC3AXq1xsnHvk5+5jTzi4ts669xy9uvoW+oStaJ6R4/ztKps9S3b2Ol1ePKVx9n7Pbr2XznXaw++gieLxEyIqoYpOfwjEGLlwMAJf21OqVQMTJUp1oKWVhu4DC85y3XsWvnNoYGK8RJzsJyl5WO4PGpMs8sXKE8VmK4v4+VdhuBRikfm8XkeYbJEnSe4HSCLy25jnGmy7MtGJAh9w2FmN4KaIUvFaUooFTyqPf3sWHLRmZ7Eb/6b/6Uzz61SKU2RK4z8tjiRVWrnJAIcE6glcZXPq0k4sWpTGyuYyaCvLp7+9ibv/xlfvvQoXvV4cNH9bcA9lcrX4IjR5h6cXrbm9/2beHr7tpkzNyLyrQW6TZWkFJg0pzV5UWWFldZWuzw5Okejdk+Smwjb+piAE8sVy9dotVo4nsh5WqJgYF+ouBx3vPANfzhZ55i13v2gplHOEtsfCyGazZEzJ4+w+JCj/r6vUytwrELMeXyINdt3krz8jPkcRsvUDTaKU6W0dbHaI21Cdamha2aTpFCcKEFp2+5j3ByhMmypHn2DM6LCHZvxWhDutIqgiOsYV0loK/sUduxCWMsSatD+9IKvSuzKAGD42Nki4uszE+z9f47COv9dJqrBK99E+figNlHz/Eyfd8r1UBJnE7IlUV4EYPDg8yXSzSabTqthDtfcx233LSOwaEQ3weBz85Nw0gEd6/G/NGjZ/mTU/OoiVvoqw7QXF4tyL5osriHyVJsnqDzGJOlRfxS3MFaw1NnLHtuGmBCtjHE1EoRpVAyPFpndMMkc6uO//InX+CzxwV+bYzcGEYnx9kwXObYCxekC6rWE54stAA+zkmMCnhpusHt23w3prtu3XDlAeC3H9z7D91hjn6rgv1VHyEgbi4lb7j/FlSoSRrztGbO015eRqBIu12Wl1ZYWukwNR9z/OwSi1OXmbs0Rje+DpvEzM8u0ug4RP+1rMY5QVQh1l0unH6esQ17GO4POH5umevWlXBCsNTOC7ckvcrC0gpyeBcff2ye5y8mCK9KL17iLbdIHth5DRdPf53hiUGunGghhId1+ctJsQhbEISdzVA25Uoj5acfX2XTqSa3jUXcWhFce/0EpZFRXJoxUg1ZeeFF+nduJR2s0JpfIFmYI2vFDGzdRP7Us4iz56m88+0szC4xefvtyNxwhZATL07zwuMznGkZpuZ7JM4hhCVPc2RQIojqYAKM9VhpZZSqQ+QZzF1ZoFqP2LRlhGq9hucpBAaTpaTdFK1zPG1552sqDNbafPirj5CM3UnglVltLK/53Dt00itoZnmCybvotAN5jNMJK8bw1EXJu/b0UyKn1ucxNj5EqT7K409f5fjxy5Sps36wwkycIURgnHFqtN/7zbG6GemkfHui0SoSnidUsURSkoUmXF40cse6VPSXKjcCHgcOvBzD6b4FsP9ZAQOOOFBhKd+2aQRsIpLuIkl7iauXr9Be6eILSaKL6NFHTyzzwoxkYN1ello+jVhhGg3asaMR7uQ3/+B5VruW4b4q9964jnt3rmPmwin2bt7C+asNdoyV0bmjHVtG+kOylWlK/Zv52OPLPH85pD62BawjqFsuzqzQ2VKjNrKVC0shF+dSpF9Dm0Jg6UyRXsKa+NEkbWTQJg76ObXsc3Khy2cHyuxYXOTOzQF3bCnTnJ/Fra6iT5zB0ymVesjI5B56y22SzOLv2sLixXM4Zam+7rX8wYlZnrra5vhL0yx1UrQrwtA9TyFcvubeCy7NEX4JFYSEZcWV2SUanZxWK2Fpsccdr9nPnl1bKUcSmyfkeYKSxWrelwLrOQIb8203lAh0hw8e/TzpwB34MqTbauBJgTNFm+h0gkt6xSxqE6TOADi/rGiZEtetH2RkciONnuHTX3yGqekWnhdQD1P2jIUsXNJo6dNqJcwve5PvfMue7/7i0au7ppfdLm0xQqJeVrXF1uPykpG9RLsw8nbsveGeHUKIF9d8Nb4FsL/qc911G/114/2QG+f7EZ4fobXkwsVplpe6NBOPU7M5x5cjxOBeysO7uBp7PHsuZ0/FJ6r08dVnuix61zK6eytp0uX3j55ids7yjhtKVKIV0lSytBLQ6WnavYT+/hJ5ljK7Yrkwk1EbWEfSjZHCkRlDabzE6OadHH0i4+GnLmFV7ZvaJ+MswqY4myOcAKFwFrK4iYxqlAbXI70+lnNHspzw+nvrpOUpYrWC269oNdu4LGfh0lN4fgi5xUUeuadxb93BrDgHeUp58zU8dfQK7TwirIT4pghYcDZbi5AVINYY+8ZDWA+Hptlc5tTJk1hj+cEffTevf+A2nF3B6Q4Og1KikNf4srAQyAoLbKt73LEH5pa7/N7TX0MN34YnHGmviZIKm3UxWQeT90An4DRKCpzN6ekAW91C31jM8Rcv8cLpy7RaOVFUQgqNcCmb+jI21EPOtow0NidO83v7+wflcN+l+5VX+sp0K9ieGWE84ZQDkAFLrS6dOGd4KFJ7d2yonnwWTp36m2d2yFcDsPbsKY6HvdbiUqu5aDCZKASBIaPjQ+y89hq8cokLc23mOjk5oBQI4UM0wkOPLXElWUd9aIT6wCBBeYC41yNNcvqGt/LM2TZLZoh6vcbWsSrOBZQGx9g4Vmb9YIhfHWDvjgl+8NuvReYrCKcRQuBrTZJk/P7nTvKJr02TiloBJOdwOLAaozOc0wXdSHpIPwIhyLor5J1lJAYVlZhYv479164j8HuoKCYa9/B31BGbFeEWg5howcYucb2HHYF8RGFKKbo3x/ZNfYyN9gMp2mj0WsyR0w6DBKmQKkJGdVRYLbaNvVXS1mWy5hT/6J/+AN/+rvtANMC0cbqH0wnoFKEzXJ6skZ9zTJ7TbjTBJDxwY4071q+SLz6PhwGtyToLkLWLCmYyhDN4QhD4AZ6UlMtVzq9W+G+fPM3Xnz5PnFqikoeQGqVA+YpQplwz4QhkLhzCxomsHjt28bajR4/O7dzC6ybq2WVFrrTNrMTgSY92ougmFiUd4+NDr5hQ9FdFBTt8+PDLPh3HWo3GaeTgXqUCWxsalRv8iL7+PnAeWl1g+dhVRKcLea+I5rGa2U6J//pwh+954wT7d4/wpRMnSG0NaQVxY57vf/1e9m8r01ieYiDo0V7uYrRG6g6N1iy9dg+JR9oJsUmK7wnyXgtPlbgy1+X8lWWiqA/jwDpdiBlxYBKw2Zo1mg8qRAYl/KCEsZa4swJ+RHWoxmwj4Vf+bIl33ftGRqs552e6bBjKCbMv4rsc/ACd9+gb28SM3sPiSpNKtcrsas6nfvMJzk+1UUGpYLILCTYEr3ipX7aKsy7HxD1cskLanmXXkOH7vv0GNk8GtFenkC4Fk2G1Js9ytNYoWUhNdG6Ra+5TEsiyBKVT3ry/xPTKFV5Y8fD8ElnawVqNEKBcjpIFuOq1OpI+fN/x8c8fY1g1eeCaPoTuIAUEQiLlmhGO1Wzqz9hYV5xrONvLhUycvAH4/JEjn5q67bbbXl/zo0daSf8EQloppUy0Ry9zeJ7PwEDVfQtg/2vV1pw+c+G5B+6+Zq/yy9Z5ZVkbKJIid+Yx/f0R/cN1PvaFc5xeuUI0uI3Qi/C8gEVd49c+tcho3xJOa5zrkGc5Esszxy/Bcoe638G5wpG2FmiaLc1CRzAxWOXqcpMvHI/pmDE2jiXcdc8uHvr8c/helZIEY4oZw7lCRu9Mhst7KGHJrUHIAOEVAXPK78MPPLTVZEmPNG5SH1nH81OOE797mXJJsLy0yOHv38FN/QPovIXCI08UlfH1/M4nO3zsM6cZGKjT7sQoFRHUBrFY1kgVICRSioKBoTU6bpJ2l3FpD1xCVazwE993F5vHJe3GDKES6CwjT1NyrcEJPL+ENUV4g1IKJYoKo/MYawROSkaqjtftklx97CUWsnEUCp11UZ6HryShUvT3DTI8PMjs3AyXpy6SJpZGUKaV5wwrBcLgyeL7poRDSJ+qTLh2XZmrnVxYArqx2Q/YN73pTeHnPve5szfddNt3C5JHWnmgle+JzCBy52Ocx+XLl18x991XzaF5LfnC9dX72rffuOt7qp6mszovXqbxlEsRUgr27t3BrTfvpNNucWlqjiS1pNqiZIT1Q5abGmclWdzi9r3j5MkSL5yZ5+rMIm+573rKlSqdLGL7+iFanZiZTokd29czUq+Qh4N40nL/jePcvGuCSzOrzC118NQ3/TsLyQsa02uglEDrHJv1wK+iSoN4pT5EEOFFVUp9w/hRhDNFDlilXscrV7BSkBFw+84Rdo8lONMl8H2QknBkH184oZhp+0S1Pkr1QUr1GmGp0L/5pSpBWMILIySKvNckbkyTdhYRxuCHEXkWs3+D5nvfvA3hkiKGyBryLCucpIRECh9nRUF6lrJwZnKWOM5IemtW3p5HFqcknQ5xknFxvldIdABfQbkUMTQ4wsBAP1NTZ7ly5SLOGaTy0BpGa4aRigZh8YREqsIgR3kSKQy1aoWFOBAraSQmh8vD3/m6nb/54Y9/onvTTTf5x449dWHjpkkhRPm1qQ2MtJm8bWddBKUo/ejnnv6F5fnpxtoM9q0lx1/lOXLkyMtt4le+68DrL7/1zslNSuQ2TZx0xuL7ZfrHQqTnc+u69ey57hqePbPMuamEuYbHN04tc/qqRpX7kEJCnnHPTUPct9fwiYeXeN0tr2G0lvPM2RbOk+isg07blKJ+jp+b5+5tAW/fCfKGEdqLl+nMJkShKwAlvML8xYHvDEmvseb/LTFagyqDVy5sxgDpgfQ9/FKVSq2ONZpe2qXbXaFarVMKK5gIzi7mvHHXOmRrCqV8gnLAsh5hqjnD+IYNa5lca98gZ8jznCyNyeOYvL1Cr7lI1lkClxNEVaKoVoRUxA3G6j7SavLMIj2HCDy0E1gZEgQhaa9wb7LWkCa9ImVJF7NkHKdIJUAblpfnUcJjY59hPIyZzspU+0cxOmN0ZATf83jxxeO02qv4gf/N913LgLl2zI6hCGUNTko8IZBKomThhlWVPfaMV5g5n2AZqK6/dp0HcOzYW82991a9xx47+uC1N3/bfTqu3psnLq9W6z5edPrM8Scvrb0r9pXQdr1aHvfoo48qIDl+8sJH41QgnbUmSzAmJyhF1If6qQ7WCaohowNV3nzHFv7x39vNv3n/Hv7Lv7iWv/+6On48g8s6OAkXzpxhpHuSH7yrxFb/Mp3mChemVxmq+2RJA5N02TwUsrja48mLGXg+eukcXiA4v5Bw7uIK5TDAucIB15MJWbKIJEUEJYyxDNcDyqFACYu0MTbvYnW29o0v5P5RtUb/wChB4GN0hjYZ5VKJZ87GLLlNhJVhur0ufev38/hpn5WOoRRFKOUjrEH3erRXlmhOX6R1+UWal0/Qnn4R25mjFPjU+iapVIZx1pIlq9hsGSU0nV5Mu9EgbXcBgfJLVOoDoHyMLVrNPMvw5RoX0VjiXkyqM7LcsrzUIu5pep02ZZrsHpeEpPSXy2ycnCBLY0688Azt9grBmisUorCKE57HQlcSWx/fkyglii8pUAKEUgibsm0oFwNRYldbafToo2f3FLyDU+Lo0fusc06U1ep3BTSWKp6RpXJEs6OfARxHjshvtYj/Pz4f/vCHEQK3NNs9f93ejT88WjFBe3kBXyohlYdxAuskWIHJeqRxlywpmN2h7rB9UrE8v8jZy03wI5YWlxgZ8JB2FS8o8/SVjOV2xm3b63RX59HGkLSaXHfdXp6bNnztdJdFPcTTl+GxkysYF66t3wXKJSS9VawTyLCO1RarYybqGXvXBZRVF8+2QLcxWQ+bpWRpTNxpErdWMVmMMBajNTpPEMaxutxmfqXDa27cQ31wlK9fGOBX/+B5cu2IOw06zUXaC1dozV+gM3+B3vIV8s4CLu/ieaLQdQFpb5mseRm6FyjrWepyhfFqxvb1VUya0Wh0qA/2EUQlpFAkvS7KOVqNVaQoTHCKdEpDp5finEcnTul0YprNmHYnIfAdUb3OS1cTNk1O0mrOc/rMeYRUeIGHQyDX/OKFKOJjdWYY7zeMVGyxFFkLxBBSoKRCCEmlJGmnyuTBkDc+XLt44vixxw4cOKCOHj1s7r33Ue9rX/tas1bta60bUG+/57Zr7OlLs7/69SefeZ49e9TRo0f/xivYq01waa19SAlx8NJXj536vT1v2fEjcXvZxO2eCnodvKCEF5WJogicRpscnWuSbkpjpc3i7CK3TKSc6u9xrimY1yEf+WqXPVvGyfOYbzx3hW9/7R6sScHllEoRedJAZF0yHXH84hKnr1pwDs+vImWh+TJZlzhuIVVAIGsk2iFEjJCQJl1knLKt5uGPBCAdsY5Z7s2z1PForvjEOqQjQoRXg6CK9EqooIzwAv74XJNzx/vYsmGEzx09QWxDPCFwa0wJl7dBd/FsSiQtvnKEPpSkxbOGQGjK1ZxqBNXQEfkWnXm0VptcmlpGd1sMjA1z7W010m6H2EHgKXppD+cKK7g81XQ7PZrNHrmx5Lmh041JeilGW6TQbF6/HtUpsb1+he2Vc8SrGuH7eMrDYtfcfNU3W0QJ5CJisaPZNRIhTYIUhU++eHlBIz0wOddMOOKmxS9Vqn/xZTh69Kg+dOiQd/jw4Q/df9PbfkAL/7aXLl/4/Nrm+RUhunzVKZoffPCgc86Jffv2/cJt+ya/f1Nfv//M159y5WpFDI+M0Tc8RKYCsiwjzw3tZpdmu8fi4hJJr4fv+4wGKSdaCf2D68h1wNMvtpDCURvcyMNff5HJ2mZuHh9nce4ywWA/q7bO8RdP01+rIZzFSYlzBqMT0riFtoYg7AMXoE2OJzU5AucsA7UQL7TEaYrvYgYHQwYnKlTKEbGWtOOURiemkTg66SKdzCPVijiRJNqj5gQXno05/WRGvVphUDmUtESho1xzlJQmUgYlDZ60lD1LpBylUBIGoghpcJAkmm5syK0GoTHG8JUnL9FXlvzAfa8h6XRorSwTlavgKXqdHjq3xfIj1RjrsK4I0+t0E3qdDJOlOGcZHxmi2j/GwksnuXY0o2qu8Mb73sALD53CaIUUtjh2r3HeCnGLQKiQ5VaMQeLLFNYWVlIUVUwocE4zWjFsDiVpGv9loLEAxsqfePTx57Z/8pNfnl+bv76lB/tfu4lh9+49qE6ePHn+kW/c8Evve+OWf1GunNRXLkx5F89NMbF+gomJMZQf0Gi2SXoZjWZCp93EEwpLxMriAnHTUfIcpdowlaiEtGBcivbqPPTFywx+x/Vcs7lCM47448cWUGFEoCy5ydaY44Wls1IVoiAqomRxCM8rUkl0Rl9oCKUgrAzj11LG65b+iqBWCeire+AMSeqI+xy5Llok4yy5McSZoZdo3NorlVuD1l1830Ni8TyHLyWeLAiPRrvC18NqwOErR8nzCCOPICzjhCLOLRqfNFfkXpOT5xbYt32CMPBYXVoh66UkPYPOc7rdDr4nCAKPzDiME+Ta0O10ydJCGRA6zfjkEPXNO/ntT55DtxK29GuLqshOd+ELea+ZedHIWxzSOiEUa1bezoEQDuEJVhOPZqqploq0F7F2D4OCCCWlwBcp120IOTGbib/sRgrw+3/0Z18BvgK8YsD1qgQYwMGDR+xaxMzPbhr+oYP3Xbtne70amU7q1NSlWV44cZmRsWGicoTyJJ5QDJZrJInhxbMz1H3NjeskV1oLdJspLirjBwG+VISBBCp8+HPP87obtzK7tMi5yysEnk+30y7Ut0rgBXV8VUFbh9EW5RUfppnWGKCqMrYOGcbGJnnyzDKNTszG8RLbxj12b6hRK1cYGwiphGFxmFUUHwAG4l5KnCTkaVK0VBaMK0L1rDXkucbYtQAHKZFCIaAIFPckTghwAqlCrBew2MpYWNXMrmqmVzPmlmKWW4JuMsgWWWVpuU1ZpsTdDt1ugskNUeQxPNKPNoY4zlldaZJ0YtJeh16SoKRg07aNVNbt5JcfOsdjzy3z1v1VcA3rpJLNlfgLiMYF5dffqnXgJC+HdRTfJ+EEUkBP+6x2czZUAqzL1lrEooeUApTykC5nw5jHbFf9d6lPhw4dkjz6qDx89G9eovKqBxjgDh48JYUQ8RceP/d9Q9VdR7cNjnvlpG0GBvao4dE5TrxwgYXlBJyHpySBKgxqehq2j1XZrkqcWoTn5zVSeAjjsGiEcUhfkWnFHz58nEB26eufwDgfr28InI8VPtpatDVEKsCGkGYWk8XFhOEME/2GrWM1Gi5idjlDlddxeklydsXy1HRE37NdRvq6bNs4wIZBxfqRCoP1iL5aQL0uGFKgpCMIPYLAByEKKUuSkqaaNNcYbcm0Ic0tuZG0ejlXFjrML8bMNhNmV3OWVhISNUbXVokTTdQ3TKe3SBhYrIhZSgxTsx0myoW9dbPRpd3usGnTONYKOp2EZqNLt5tiUk2eavrLPuu3bmTFjfGLv3OKJ85ZauVBfBFjtEMFVYws9Tbuir7YmNbzhmBUCOkc9v8BEOlAS5/lrgCpEJa/EEzxMhjB8xSSnERn3f8R2+fldvFbAPvruYuZtQzdr3tB9PY33jDy+3uG7YDoLuutG4e89eMDXJ5uMzffoNPq4ayhXivhlIf0BFJabqxWWEwNy7nHyNgYoYDcOKyzCAdDtT7KLFGtDtDOyqQmJzUGayXWeaTSJ00czV6PVBsQAmsl1dCwoU8wMDDCE8eXcCJCS4nvRyi/RBoNMdXpMGMiziQh3eVpSiXHUL9DZnOUfUsUQOBJKrUqoSqMoKwp2r/VlWXi1GJVmTSztBtNclHCq2+hk/i0Vi1R/xa88gCrvfPUB8apj25EtlYKX0cjsUmT0KsyvbLM8Ysx7eoqtcAWzse5QamQVqtLu92j10mIOwnkXQb6I67ZuZ1nZzz+/UefZyHtwyvVCFWTcqAwmRHWr2CEZ1/6+kvtLdfc+kiO/E5jlRYOzzmHQGGFXYORZLUHGoW3higni1mMtc1jGPjCWEXcsycB9r5C/Db+VgPsZZA9dOCAOnjkyGdPXnnNHd/72m2/ffuW+u3NuRddNZBm2+Z+NTpSEd1WhzRJ6PVSunERJFeuhHSSOvXTF+nGV6nmgnWjmzFeVGT4GoMVUBaKiNyUKp6KE4vT2pUjLea7krNL0Es0uXMIKbF4oGPGKpqJ/jLNPOTyXIdabYh6vc5SbJCqXOQjK5/qwLoit6oqCAbXkZbrLMxcpl6qo41AWkXQjkjjLlJJ0iTFD3w6jWWksJSH1mG8jB5XUMpjaGgffhYjsnOE/evoH5kgSxOSTpOqkIS1QXTaA+GRW0FUKtPuaebzMsnsCpVsmUog2DA5hDWWTicmizPSXozJW0wMD1KJAkRQ5pmLHWY6ZUr9FfLEUCtDNRTOOV/1jJesxO5RQARB75eCvHogxlfO2oLxIooJyyGQyqOdKlIjCTxvLVRpbRkiQDjrSqVIptbPX7qy9ALAyT17XjUAk7zKn4NrIHvh2OOnf/IXPnLPl87J/9CoXo+tTnqdRluEtqsH+wI7OT7Itm2T7N29iR1bRwnDKqfPX2BQLHL7ZJsRM01scxYTS64ignKJqFSm1DfmJndsV+s3jXLT7fu4d39FvGZrj6FqSie1CC9ASv+bs4MnLcNl6Bvs58J8D5ziB77jfn7w9XdQDX2EF+KMRfoBSpXQKQjpI4OIJO5SCkPqA8P4nk9UruBHJaJSRFiJiGpVKtUa1foA5b4xKrVBgqiCiqqE5UGEBJ3HOGPBaqQXUqqPYfAwWYwKAvwgQHkhCIW2GVoENLIqW/beyZkrTc5cbSK8kDRNiLsxSbeLchmb1o0TRhFzy6usukGevhDjlepI4wOWvtARytxVSiUGxiZXp8f/2QWA73zXC894XvqY50mEEEaqYriSovhRKEUn9+hph5BijT9ZmNsIBTjhKn2DYjV2i1/90mevCiH4m9Z4/Z0C2MsgO3TokJRC5Id/+bd/6jc+e/aur8/UPnbJbU7i0nbP+WW5uLDkLl2cYubyVc6du8jTz54gi9vcuL3OvTdtY8uuG7jcqnNqUfHsdMzz04YnTs7YuXYu8lL1V650O3vOLizsmVleOtEfGfpLWOWFIBVKFAkj0kElgLH+AL9U46XLC+zbu4PvfPPdrMzPkqQW6fs44/C9MkIKrMuRyiMUPjpJCcs1nPAKrh8CZw3W2SK3y9k1NgSFXkuCkgqEh3EGKQpzGJQsGPVSUKpWCEol0jQpKF1+CVWqIbwApzVeEHL28iqTm3exa+9eOnHO2cuLdLoZcdxFZwm+B5WSolIL2XHbA3zoU5c5dSUnDEKcNAiRM1gGYTI3MDQMyr947DdutoUvBlaJzn8KSIVACbmWkeyKqHKkVGTWp6s9fOUVm0MhkMKubTqsrfYPolGPAT1rP67+pvmFf2daxL9kyH055ujrjzzC13dff9uOB27Z8e6bduz8e/v2rd8XL111adYTQzms3yQRXkDsj7CUjXPyacuic/iRwWmfDGel78lqPVj45V/65Z8ANMB7Xnvt7183Nvzvx+rSlgIju3mIFA4pU7QVDFYEk0MVMltjZTXl2968i8G+KueaHWICakKSC0kQlguXJOfwgjK2WPwRlEq4NcKtE8XC5C+urF82/7S2iGBVnkcYRaRxh6TXQnkewgvQ1mCtwQ9LVAZH6XW7+HmKVB4qiAqmfJyjopDFRpsLswm799/I7JXzXJiawxc560cj+iKPjZsnKQ9PsCzG+C+fusjnnm4TVfpwNseIgFDFDFUduMzVRiaIo+ofA2Z2dqcPj4qKt/eLme6dkWroGmutFUJKhy2AJot5Nsk1vlIYV2xpnRTgJIEnEEGd+eX4q8Ud9KR4Nb2Xf2sA9ufbxaKaPbh3rxAHD5598blv/Dso/e5//dmDp66fGKuJJHEOI6Qx5MEgH3tM8vjZBCPLCJWBtqACsl7LTgyW5dBg/QvOOXPw4MHSnj170q9/+TOPd6xgvGblYAk6OWsbMB9cwkSfYHSwznNzGunXmLu6yJNfeYaLs6uEpQGEk8iwhAojLA6hFJ4XonWOkAolfbI8XRtECuFmMe8LnFg70UpZmE24gmIURBF5lpB02vhRiBeEyLWfl35AWK6ijSZPOkihsCZHKA9UWEQTyZBnXprnxjfvZmCon9izrDY6bFw3SDA2ycNnUk4+tsBz5y+x2PMIK9WiwqriY2coNIyUDVHgq46o5F8/t/xZgImJCQP3qVOnTnXGt978x0LmP+WsZwVWClFEz4LACo9MK6TwQGqQAiMk1qZUqn2qmXvm+dNzj/zFw/K3WsS/4Womihwo+cJDhwKIpy/Ntb+kZSiSODNpUqy2Wz3BTDtAB314nkBZBUIhlAKn5ehIzXhS/54Qwi0sLOQPHj7sHv7K1LGl2Ls6WFVytJxY4Vyx4SMgUoaJPkFQG+L0lRbDI0NsmdzEmXMLtNMQz4twSuKHVTxVhNoJqVDKwzqN8grOnrO6aAOdXWsVC7x5axUPQCpVmOoI8MISQVTBWYPROcrzkaqYC5UQSOmj/LAwo0ljnLXIIALfw2EIohJnLszhSiNMbNhKteYzMtpPbaDGwIYt/PE3lvnsky2aeZkgLOGwIExxgyNn/QD0e5kZHJ+gpyqPf+7I759a88OwMOoAUfayT3suMWuX5EISgwIpsVKSWYlQHlIWGYieEEjn7NDYuGhl8vTnPveJM8458fJh+VsAe2U89sj//agFxNWlpU+1E4EVQlhXzADGSYyVCGOxzhVB5Aic07ZS8uTESP3KBz/4618EOHr0qHnw0L0K5rsLTfe7SnlsGkxtIAxCFjNQLbRMDIR0s5CpuQ7KC2nnjucWerSlB55EeiGeH6KUQkqFUB5u7X6qvIKCZd3anOWKwAWL+CbQrCl8DQuDwGLV7SmPqFJBBT7OOTzp4fkewjmklPhhgPICpOejggAVllF+CaFCHAIvCFhY7nB+qs2GHdcyMNjH5IYRokrA+skar7t7H8JXSCVxzhaoFg5QBCJj07Ck4jn6J3aIhS7/7f/5bh2xgBsdXDnmk89KIeQaQteCzItH2+IUIYVASQ+FoFwKbG14I5fnep8H9KMPPviqy7P72w4wDh89aoTA/fFXL/zpxYV0tRRG0hjrJCCFA1cwH2QxgqOUR55mdmyk6sbHhv9QCNxaOqKDgp399OWljyx0hdk35smxWlq87s6wcUgyMTbATMPQThyrseETR5/m6ItXsKqEVD5SReAVn9xS+ajCfHCtGoA2GfabprS2qGgCrC0+uAs2hEBI+U3QORyeUgRRhFRq7csH9zL1SOH7AWFYwQ/Kha1cccHFKQW+RyoiTpybYWLLLkYnxhkZq1Hvr1GK4P7XbCVQheGnWAOGQmGNYLSqGa907eDEqGyK/vP/+dePf2yt0rzMG3Tce6/3xBNXY6nMJ30lEQhbaL7WWBtCFptD3F9g0huGRkblQl5Pv/L0hQ8CPPoqq15/JwAGuJ/+6UNe6+rVlYsLnY8F5bpQ0hnrLJKCLQGsVQ2JUBKrcznSH4o86zwMuFN797qi9cQ+9NAB9Y1vPPvihWV+b8tkWd40qa3C4nuS3RMetfoAFxZSrPCQYYCIariwAsovto2qeLHcWpWSa1SnghHlCkXx2pjhnMO5omK9DDAAIdc2hVisK6qvFaKoUJ6P9H2kF+AcGK1J02TNfMdirC5W+TpHAFJ6CBR+qcrpS0uE9UnG12+mVC5RrpTQecp11wyzZaJEnluELGZCIRWKHtdNOobD1PVv3icut+3PwLH8waLSfHPTd2B01AEEQfJZzyWFm8HaJQypkELgq7UbGQIhNEpaPbltn7yyaj79yCOfO+8eekgdfpXNX39XAMZhDlvnEI8+cebXLiybpFypSJ1rJ1xO6BkcpojMEg7nrItKUlYiNz8zc+IpgCMHD37zH/bkySPOOcSXji//66mWaNx5TcBw1HJDpZxtEzWIRrkw10VFFYQMwZOgFNKT4BUs8eKz2mGdXvuIL6qUW1tMvAwmuxa56pzF4jBFbwWq8K+wxq2t711xvBYS6QVIFYAU5HlCp7VK1muTpT3yLMHoFGczhHN4wisWC0IQRBGX59ssdT0mtu7DDyOiUplUa4b64MY9I+g0QUoPKQTGCjb35ewZ6pn127aqmbT6zC/+xw99xLlD8vDhw/r/gxBgAW7YE35Ryd5VKYVESIssKrEvHFHgsM7hEORGu8HxUbnsBtNHHz912DknDr5Cwhy+BbC/HGH2yJED8vFjL5w+fqH98aA8KHOtDS6nv+RwZm2pIASZNmawFqKk+dJHP/rp1T9vD19eoGCPHDwgT5x48urzV5KfHRwqq9vXd82uMcv2rRtIgnHmmpqwVMGpAOGHyCBCBWVkWAI/QIhifjJ2zZzUmT+vRC8Dam3NbozBWIOxBfCMNYXnorEYk2FNhrG6+P22uJM54dBZTLe1StxtkmcpAoVUBfiEKJJKUAo8D2Qxm3VywYlzS4xv3o8X1hFKYK1Auozbb9qMlAYpPJRQhKLFTRssk8MB3sR+jp1rvF8I7MGDf6kXoYMD6siRJ+LAs08qJZ1DOKTCOfCUpR4WHzvWOYQwZv2Om+SJqdXf/uQnP3n80QcfVEeOHDHfAtgr+Dl5co9zzolPffXFn3nhSi+uVEtSp103VitMV4QEKR0m74m+ikCo9HOAePTRv/SwbR966ID6b3/4xV977mr69bt2l70H9gZ2aMM25roBuQsK05kgQHolZBDh+yV8PyIMI7xSCS8sIfwQJ1VRzazFWoczL0fQajB5YWJqNCbPMLrQcRljsFZjTF6ISo0uZjeT46zG6LQAlRCE5SqVviHqA8OUq3WUHyB9H+WtbUulh5Be0fKFZY69MIVfmUCGfeR5hnCCLE64df861g2XEc7gbMb1E5bdQx29/Zb71aVm6dc/8pGPfOPjH3/ofwoEYZOPKpEJIUBhEdZS8gx9JVcEHmrnNm7ZLq50y+0//dLT/845Jx59FbaGf+cAdvjwYXvkyEF54sSJC0+8tPB/uWhMClI7Vssp+xqHh3SASVWtTLZr6+RXAHfffX/pP647efCIE4Ls00/NvHcx9+ev2zkiwsEN9uTFZcJyHyqooLwIpQI86X/zSFzsFkJUUMIPQjw/AKkK7p1zOGtA51iTYnWK1QkuT0AnWJ3htC6Apou4IGsN1mhsrjG5xmqNRFIq99E/PMHQ6AYGhieoVOvFIkUKfKmQykMqhZACJwstWxhVOXVhjksLMVHfaJFTjabXi9m5aYg7btlCN+6ypT/jjo2J2Xn9fu9Sd/D8v/i1P/op55w8+Bda6f/v54gFRJ7kX0L3rkrlKSewxjlGKoL+MuQ6Z6AvMH2br1dPnpn9V8e+9rWpI0eOyMOvwuXG3zmAARw8eMQ89NBD6jc+8ulff2ZKP9E/vF4NlWIzWbNYpzBO2FKoKAXy6j//54enXgbmX951Yn/6pw95x44dm5pq+h+prN8tEvrs5bk2lb5BpB+i/ABvrSU0JiNPOiSdJnFrmbzXwKY9hMmR1iCdRTgNVmNths0zTB5jsxirY0we4/Sff6ELADqdF5G1zhZeF35EUKpRKlcJwgrKC7DGEne76DwpNpPi5WWCLNTDayx2JWG5lXDs+BXK/Rvpxabw48hzfE/z2ju3MRI0uHdLZq/ft1G1S7t7H/v0k28XK+daDz74IPyPKUwODsjLl59vCBv/CdI6R2Cdzdk46BjwLaEv9fbrbvOevtT65H/81f/2nx45dMj7H4P2WwB7BbaKJ51zTnz+6fP/YKYTphtGym7joHWQkVhna5WAvlr0WcA+9NBD/8O7y4N79zohoL+q1vWNr+PisqGVCMrlGl5QSFOkHxabPVmMciaPSboNes0F4uYSabdBnrTRaQ+TxxizVqnyl79SbJ7hdIbNU8hTyJMCaGszmDUah0N5Pr4fIpWPsZY0iel1msSdJlnaW5vvikXCy8ASouAECru29hceTx+/COEwhhCjDVYoet0Od9+wnrddH7kbdw7LfOzm/OGvXz7w5S9/7tS7DxxQf7UqsyAAYWz8qLKJkM6KksrZOiQIRM/s2LPHO9/uu/SrDx39PuecuO/BBw2vIt7hX/Z4f9cAdvjwYbv31Cn18MNHn9syXv2XB+/Z9Yv71q3mx2Yzv9vOGJusMThSfWINjP8j3ptQ73mPcY5ofHzwtsGRTRz/0qy0XmGn5llXrJ2lXFtqOLy15YXRKTpP0DrDmbTIAlt7k9zakgNjwOXw8v3LWZzThQrRFkESeD4ID1xhxGOwWJMihSIVa9tFt0apWvPBcKKQ47/MAlk7RIEsPDf8wOeFs1dodG8lqk6SJQtFgkmaMzEauXe87WZ3daWUfvprZ9710EMPfeahhx5SBwvWzF/hOWoAJ7LFx4wcnLYqWjdR0W68mjKxflI0w83ZF56cOjB14sTqwYMHX7WLjb/TFezlJcWhQ/d6v/F7n/6lT37tpY+sG438TfU0z9NUSZt00/by02u/9L/7qXzgwAFpneO1d9903eb1w1taWeROX27IIKogpMTzA1RQtIjK85C+hwxCVFTGr/QT1ocJqoN4QRUhPayjIPmaHKEzMGmRTGIS0DHkXVxWBDNYHa+FMxQ/5/IeNm2Qd5fI2gv8v9t77yg9r+re/3POecrbpzeNumTJktxkuRtbkg3GYEwfmRICIaGkkOSG3JubhDAa53KTXC4JpuR3aSEhIQRN6C0EjCTA4N4ty7Z6nV7e9tRzzu+P55XtkBAwAWzk2WvN8loz1pT3Pd9n77P3d3+/YfUk4fwY4fwEUX2GJKyRJAFpGqHTJGPnt4bVKAkyG7YbLEq5jE01OHiySceiM6lFKWmaksQRaTxnzrx4s/z+gerv7PjUjq9+6EMfcn98cPF4CXny5MkpqdMZk4YsLjfMkq68TrrWy5vvG3vTP/39P905PDzsnA7getYCDLAjI7v1jh1D6qa//fLrbn/oyCfPXVlwPRXavp6eIze99wN7/7P7F8D69esFwLnrFl1xxsqlHJky+uR0Hd/1s6zlKpTjIpRodSizORsiI+g6jk+u2EG+0o1f6cYtdeDkS0jHz35Ay1dM6BbIdIRNA0QaItLW59M4u38Z0+I1OkiVQ7ll3HwnuUofxY5FFDsHKbYPkK/04BfbcLw8ynFRym3peTxBHlYYmonlvkeOUO5fjRaFlj5ISpw20aQoZeeGhobUiRP/+BOUb0MKEFGsP1ERc1y4VGp/0Vrn1gPJ2z700U984kNvfrP7g3O0BYD9goIsE8+x8j0f//LrJqbG/2XTGW1S2Mik+kcbaG/fvt0ALBnoub53cCkPHJgXQZjxEqVUKLIGguJxYjzWGIS2YDTWJmB1Rsh1PJxWx1Egsq+bFGsSjEkwJsLaGKNDrA5boEsyJxVrkMpDFdrJtQ1S6llBW99K2vtWUuldRrFrkEKlj0Kpi3yhDT9XxHNzOMrJRD5FxqkQFoTNht/ScbnvoSOkooN8uY8gaBJGDaJ6aHvbXc5bv+zVo6Ojevv2XU+5AbF584QArLIz8UXLtF654Wxv197Z//Pn73nfB3YODztv+fCHk9PpkDk8u8Nu375dWGvp6jrjhi1bLv7O7OTcTiGwLb2PH1amSCGEOeOMxYOrVg5eJHJd9pHDx6QS/inFv8d3vR43hbAtGpTJ9rusNZnKbxqRxE1MHLaaGZkFqzAaSMGmGKvBaqzJ7nBWOYjW54yxCGtRQmBVDvwiQmXZ08pMPkYKm83YOEXPUlmzQ4BqKZxpm/3e2lhc1+XAsSmOTQa0dwxSPX6YchAR+k1pk5Bli/s3Ap6SMuYntGld0qWczVsvV0cDPXLThz+yfefOYWfr1tMncy1ksCc1PYQQzMzsq372s5+88HOf+6c/hEzv44f9m+HhzRLgonNWbV25rC9fSyrm0PF5oRwHqzN/MEN2gI3IwKW1waQpOo5IgxpRdYpg7iTNmaOEM8dIqmMkzRl01MSmEdYmrSxmwBik0ShrEDpu3dFShDaQRCTNWaK54wQTj1I9sYf5iX3UZo+TNKuY1p3LmCcoWJnat0Rwav3FPt6qz+Z0itlaxAOPjlHuWEqzaQjDkCRJZdBMbHulsPjqq68+11jL8PDwU1qA3L17twZYNlD8u7sPjr32j9910/bh4WG5detPW4l3WA4N7Xi8gFjIYE9zJmu9EfGP8z9vYQsj7GbV0s6z+3u7ODRr7eRsM5t3pWnWucO22nRZaZhpzieYNEbHAToJsakGHBy/DaEclBTZHCwNMVEtc2axBmkN0mStdWM16BSLwlE5HL8Iykdbsq5kc5Y0mCd2J2j6JZx8G16+guu6mYWtbRGNrWltS5snElDWcszKWSG5+/79vPDiS9HGJWwGROUycWz04kUDzqUXnHX2zTfffGfrIW2e4mvN52++Yxru+Ech/vO77n/h0WmeCfRFuYCtfweyH/nEa81n6OvuvqZY7uTg8YZsNExri/hU1mkRd23WgJCWzMTOzeHmKvjlHvKdiyn0rKDQu5xCxyAq14YVLjrRpGk2s8o4iaZFjYqRNkVJjSQl1REAyi/jVwbI96yi0LOSXKU/kwRIA+LaOMHsUepz4wT1aZKwio4bLRO95Aljs9bmmSXjSEpH8fC+Y8w2LCrfST0ISKKEMDJoU6ZnYPDaVon9k86pxPDmzY79qU+5hiUgzr7k+edf8cJf+dj69ZtLP+77ugCwnw/IftRbLoUQ9owzFg/2dBZWKbdsHz4wJZI0zUowk2UCkQm5Z/cmm+0XSsfF8Yt4pTZylU78cidurgRIokaVYH6coHaSJJjBpBkArM62lLVOieKIRr1K2Kih48SmUWKSsEEUzKFtivKL+G39GWj7VlHsXkGurQ/pFbAmJY2axEGVOKySRE3SJM4Iwja7x2VUrex3lkpxcnKOYyfnKFYGSKMEk0pOzgv1t/9ynCMTuWt//Q03LBFC6Nahfuqd3J+BCu+mTYsUYJ3K0t9YtvHlbzzjvI2/Adjh4WG1ALBfgBgaGhIAV1159fIVy5aVm7Fr9x2aEkKojIT7eKmVdeWEaZVcMjMjF63Bs0kT0uY84ewY9ckjBDNHMPVxiOvZnUg6rWbIqWHx46LupEnM+jVLxfJlfdIYC0lMOH+SuD6BSQKEcnC8El6hk3ylj3xbP7lSN65fQTm5jFnf+n7aZGQJgc0aL2TsfikEzWbMgSNTtHUvJUldglCQU64o+o5evWpt2S9UtgBiePiZcY42bx527rrrrUlHR25JsW/d9SdmSfPl3rcC/vas6hALAHumA4whAI4en3+hl++lGnr25GQTJUW2fkJLXs2aJ6qv1sayEgJpEnRQI56bIJg6TDBziKR+ApvUsUIh3RKulwHBIjh1XcpoTiCFtKVymUUDxWMlP97rOgo/X7aekMTzk4Qzx0lqU5i4npnAC4nj5vByFfxCG16ujOsVkI6bjROUc2oKlrXqaakBYNAWDh2ZIl/uASdPmKQEtVlKqmkvuuhMm2/rvgSwW7ZseTreCrF587AzPDzsbN682dmxw6rdu0dSsIOXv/JdX42dxb2HjxzEKQ2suP5lQ5cLIezQ0JBcANgzH2EAdPW1X9rV18XEbMp8I0aIbJcJm23qWtHazbKZgi0WdBoTN6uE8+ME1TGSYA6TxggUyq2gCt24hU6E45CmmX1rpoVoniQPIE1/3yKKxdL3J8f2/1kxJ0i00X65i1yhknEdqxMEtSmisJ55RJuUbP1KIR0nc4CR2bqKlC0ZAPOkp8Gp7qJUHD05hRU+hXyZRrNBHCc88OBheejQrOjp6Ly+q4vyli1bfq7ZYWhoSCGE3b17JB0ZGUl3796dbtsm9MWXb37Oa97+kZ1pz6azjh46ZOJmSGDLFNqXvbr1Dxe6iM/wEDfcsE0DHVdcsOqsjqJi37SVYRyTWpVtILfEQbOc0JKsMVmLPg5rJPU50qiOScOMAe/kcf0ijpsHASYKSOIInUYZQ8NkpeYpBxWpPHo6K7RXCl+KovpnHFH/AKpY1sZYv9QpZByShg102Gg1Cg3Wy6EcL2MgWvM4kKw1Le7jv+XUntK0cZRicnqeeiMm0ZIwrNFs1lnSNyBOPnbALm5rW7JixZnLhBAP/oi54U/t9bfWkt37aL/qule/fvWyLrtv//GoZ/WF15b6Nrx0LOxi//59xlXIMAztXC1gbe/idQDrHxr6uROHFzLYU+lPDQ8ra+HXfuW11z7n3MU9cVjVPX3twvcdEg2ipcL7eM/ZZiv9OolIwxpp2MDqNFsTcXKoXDu5Si9euQs8H21S4mgenTRadaFFtACRSUk75PJ50dVdsY6nD548ebIpVPKgJww2NcYYcAtteOUepONhdEgaN9BxQBoHmDRbyjQmzbaodeujxbJ/op4FK7LsW8jnEMJSa9RJm3VyBFzak4olcwf1oOvZa7c89wJrrThFHfsZvvgShBVC2Iu3vvzN57/kjx+86Prfeu/mV/zWTWc9723/Ty7a+tKHTgimZ2fNQE+fDKLsb2zUG4Qx0UKb/hcgTl01zj9nxWUDnYrqzLhd0ltmSW+JMAozAq3NWBPamNb2cbYcmaZJliNcD/wiKt+OX+rCzZexgE5C0qCKjutZSdcaANvH7XwsQirT0dEp/bx7/L77dt0LCNcx/+wpY4VJMUmEMRbHL+GXOnC8PABpkpBETeIoII7DrHuo08ebGqeyl3jccMG2ZnoxZ61bQikvSKIqVhsajQmKhUnOWF8QTtkRXb19vySEsKeoYz+zczoyYsD2bxn6/S+0b3j5hzpWPGdwKmlLR781me6883h674OP6FK5RKW9Xe7fd5A0jsFqEQUBM7MzKxYvJj8yIs3Pu9GxALCnUJ5s2bJdA145J64RMqVWnZJ5UeWctf2EYRMtVHaVaTEn9CltDUAoF+nmEF4e6RdQuRLKL2RKT3EDHVQxUaO1pmIfz1q0GBdSSlzPs23t7Uglb9m9e08dsFbUv+Q7iVXCKNNawjTWgJvDzbWh3AJCZW+z1mlLbsC0upOtDqdt0ahOZTApsFZQ9CWXX7yecH4SE9YRMiGNEwInJMjPqlxXaC7btOzqF77wyq1SCrNjx5D6WWQua61dvGrj6mtfP/K90sqrXxyo3jS1wn7/e3c7d9x1h9PeWXQG+vvU2NhxHrj9ThqzYziuRAkh0jQFKXvOO29N8elYLVsA2FNBmBC2SLFjcX/HYkxKEs+L+ZMPc+E5A3iOReuWxdyphoR5ojmBVI+36h3HwXWcbDYVNkiCKklUx5gEhG1lEvF4y0G01IY9v2B7e7qQ2L3ZnX3Y6ygUDuWl/n4u54OxmjRB6yhzWFEK5fuZ6KhSLWtWHgfXqRGAOMVGJhMVFUIQNBtsXLeYDWcs5sBjd6PjuZYYT5plQT1HuWjYcOYSbnjpCz5gLX6rA/TTzBBiaMMGIYRg4xXXf9zrv3hFNZKxDpvO3XfeKxBw4SWXEkYJD95zL2P7HyWYO4FSknyxiBCyZS0lKC+UiM/w+9fmzQpg22uuvXBwUVchiZvaEakYO3w/Zy3Ns2ppJ2EUoQRYsu1g8XjZlb3MUqhMdVd5WCxpVCcJ59FRkHELW8Z/jzs8QiZ3q0C5DoVimywUXZ0vu98GqNVuE3fddVeiVPItz7VIKa01Gpu0xHJOyQgomSkJK/U4eDMnyexnZNxJkYnCSYM14KJ58bUXYesTzJ54GClAa5sJ7KQpSZpgVF7KfF967daL17/zHb/zzm3btmm7Y8dP7UwNDe2Qo9u26ec87w3/rbzk0uccGm8kSVD3HnrgXlasXMqqM9exZ89j7Ht4L6YxQzR9AklER0cnylrCILC+5+ApJg7e+2hjAWDP4Ni+6zctwMoVvc8f6C0TRpF1pKAxe4SinOW6K9eTpBFGuk88w59EoBVCoZTCUQphDWncIA1rmDhAWY16Il1lDY1T/5WZSZ3r+7atrSJLJdUY7KvdCRAEgQaIw6mvkNaMUkJlcyyL1Qk2TbJWf7Ys1vrerQ9rs/mXeGJud0qnIw6abDxzkEvPXcrRx76PiaYRjsiUGU2K1imkKVEzwrqdKue6ZuvF63//grPPXsnQkBkeHv5pnCsx+s836HK53NV1xvnvGKtJY5LQObRvL5X2Ct09Xdz+nVuYPHYYlTapTR/F8xU93YOEzRkas0dJk6Yt5h1WLRs4fOsxguHhx62iFwD2DByAWYBlS/vPkaJJHDUzYVoiZsYe4SVXrWdJT5k0iXlcQMo+AbQsi1mMSUiSJmnUwCQhorUs+UQHTz6BTQFSyaykdHOmp7cTR9nvjox8sj40tEOdYqYLkd5D2jzuuUqQUTGQNpOAQ2cDatMaG4jHJauz5c9TPzcTEVBIXJTQvPz5F1KyNSaO3I0vE5SUKCmzeZ+JiOIYhODhAzPiwQM1c/aKTu/VQ9fcKISwW7b818/V5s3DCmtZe/HLf1e2r+qYnJkxUbMqGtVZ2ksFHr7nVuoThyCcpjp1gnLbAO0Dq5icPkbcmCacHYe0SaXo0t9dkACZLs9CBntGXr9acPG7OtsHomYDHc4KY1Okm2Nu7DEW9cKLtp5DFMaZToYgK7mMfZwZgdZZyz4KMEkM2rZUe1vGeqaFypYJhZSiRRBW5PMl29Get46rvwaY9esfEpDtre3Zsyd2Cb+bcx2UlKYlx5EBusWQl9b+m8Ut+2Q1KSGQQiElhFHIxrVLuGbzWRw9eBdJYwxHOVnpKgVCGEhjokYDoVz2PDLB6K4Tzv4Dx8xl5w686nnP23LxVVtH0qGh/1rDY8uWrCuZ71xx9WxN26hWE9XZKXJ+jqBeY37yGCqdpz51lFKlm0rfEibHTqCbNURcJ47mMWnC8kVleiq5p+3gLADsx5t/CSGEPeecS88YXH7uaplfagNdkWGcIjGQzNIc28dLn3sWnSVLrHUmc20thky8xuoYnYboJMImUbZyYjVW2H9TFvLkxCezu5PvexTyOdnVXhBRWH0IYE/LCHxiYkIAKDf8jC9iPOUIKbJOpCAj8PK4DZL4Nw2UU615hEIJi5Qujol5zcueQ3suZezQHfjC0JKMR6GROiKOQhpRiqGN8bmAb9x+gi986whtTl2++VVXfcJC544dO+x/oVQUIyPStLXRXmsmKycmp0VYnxdho4GXKzE/O42TNAlnjpP3fQpd/Uwd30dcncQRlmhuDAnkC65c3N/DY0cmz+3r6+uVcqFN/4yMXbt2SQC30n3FA8c8kVQu0MvOeQWdS6+G0mqMynN8/12s7FVceu5SokYTR2W2stZajE7QSZhpw8dZ9rJat1KjbDmW8KTyLftQMru3uZ5vK+WylMRTOqrthSf03k+ViZPHv7Nbmrn5nKuUBCuszjJiqwVvrf2BeVcmdPN4Zao8wiDg/A2LecHWczn+2F3QOIHrQWxT4iih3jTEqo983yYWr38hqrSKYydrTI8d5fv3z8hH9xwyV53Tv+av/+8ffUoIYbZv3y5+sjM2JMHS1XXW6jSJ+6pT40SNWWnjJiaOiIN54toUUklKXd3Ux/cRzo/hiAQdNQiDCCE9ers77Z0PHLD7j8/V+vr6GtaaBbLvMzJaE+b2nmVrP/X1g+a//99v8o0HNO7AFtZd+qucefEv4xYGCWbH2HbNJmQ8xfz0DM1mQJwmpK3NZGmy5clTjpWZE9CTOoatFjpkriuOK3Eche95pq+nm5yn9nzyk587+QOXdTs0NKROnmTKprVdOd9FCUdLYVq0qJa/87/JjU8MlaUU2f1KKZRp8JrrL8ZLZzn48HcwaUiMh5PrpWvJRaze9HLWXPQa2pdexb6pbj706e+z95Gj+MExHnnw+zy455jad9+t6cuvOvOakf/5lo8JIbRS0jz1cnF96xdNIhM1LMEsOppD6AgdVglq0xgL5Z5F1OenCacOo0yIQ0xYHccoh0K5xPxc1dZmJoWn5//x/vvvb+zYMfpzb3IscBF/rBTWOpRpM+dJI+99pJbc+9j31BkDD4lz13azcf0Aaxc/B69g2LTeYftbLuO2W+/j8ESDwxMhc0FMFFlsmmJJkBakMI+z123rToQQtEZVOCrzKnOVT85rs6WiRxDW9gBs2DD6b57Ep8pEmza+6Mv4xXlXiWasMRiwstXMPMXYaHVPWpZIJhUYHdOYnWDz+Uu48vzVPLbnLtxCP8s3raPYNoDyO6nW4cCJeR648xHuf2SMI5MR0nFZ0tfL6s6Ucj4kmD7Og3dNOZ7vpb/ysovf2N5e7Pid//mXbxgdHa0ODw87P75a1IjBWnFAiEc2DF6634RmdVqvGiFc2ZxvoIOAzp7FRI0awfw0jtRIm9CsVRFK4eeKWJS1qRFLOgnmxm9/P8C2bdt+7pPmBYD9GLF7C8busuKa6677fxWz5/lr+pcsPzbn8+CJmHsOHeITX3qI/i7FWau62Li6l3PPXM7FqwW6Mc3EbMiRY1PsOzrDvuMRJyYiZucD6s2YKJbExpKeuiMZmwEPS+o6CCRKxPgiFl0VSJN0J/x7QdTdu7cY2I20ze+IpCoiXVZxkpAYixZxq6EpWs2OFEGKpzRtHnRVoLsNBs5p49WvuYpiQdA9sJL2wRXMNTQPHJrmrnv3cvcD+zg8VqXeSFDSwfdztBdieniUs/snjK0F0okCqhM+93zv+855Wqe/+vKrX9bd/a5lf/zOD75mZGTkEWut2LZtm/xxSMGbt2xRu4aH0/O+etf9y8tdqw9Xx+xsQ2JQFHMVkrBBMD9JzhFYo2nW65khfL4bz81Tq9bS520+320vJB//29FvHX9qAqk/3e7YQjyFTuLrXnp1V8fKc//AdRe98ei47tg3jainOdEIA5pRhKcD2vIpizphsJKwssewpMvSVZb4MjNoqDdC5qsxM/Mp0/Mhs9WI+XpMEMaEiUZrcB1FIS/p6yrb51x8nkjcXPihf/zG2rvuuuUI/14HQwgh7Jo1l5YvPn/Fg4VC79IDR2dNqBOJlPi+R7Hg0F7y6a44dHfkGOwq0d+Vo7OiUAi038ts2s9DB8bYd2icxw6Nc3RsjrGZkGaQKQo7wqJ0nbydZ1Gxyate/Bye+9yLeOwrf8X0oX2mHqTSSB83VyDfVuCciy9Iz7n8KueWPRNzn/z8d97+95/8/N8AKCl5x5/8ibNnzx576i55Kr0ODQ3JHTuGcJxXaa0NV16+6TXv3f4bn9x7/73puz/yHeehiRxeqQ0bRUihSXVCGAZ4fg6/UMHJ5UhibdatWSWvvHhwnxo/cEFuYKA2MjLy42yrLwDsaW4ntkin8JbXveSFS8v5Lz/22Lg9UCvIOdNBXXUQqQJxqoijBJ0GyLRBjoBKLqC7CIvKls5iSntRUcqDLy3KWozO+IuidQY8V1DM5ym0dRmv0ivv2jd++7s/+DeXDg8P/4ciMcPDm52Rkd3p7735JX/yyqsvGDFxqFOL47gOjuegHIGSAmMlSQrVhmVsJuXwTMrB8ZhDE4KjEwHVekAYWTSZX7IrNU5ax9VV2lWdNmZZ3QNXbBrkxUPX83CtJ/jKpz++/+qlyVmHHn1AV+tGGesi3TyFtgpnbFhlzrnsObIhO7nl7sdu/fzXv/tnn/vizi/+27ugQGstpBBPluhoe93Qc1/8oqvPufGSVZVlR/cf4Es3Pyo+ufMEM0kHKIlBYoXC9X3cltGGVJ5Zs2KRfe4V66cnTjzw3A9+8MMPPGHI/vOPhRLxqcTIiBkCNbRjB9te/+v3fuT3nhcMrKoWeh991M40pZiLC8ybNuZtGw0K1IVH4HgkictYTXBsVnNXGiO0RdkmjojwRIonUlyV4joCz1EoaRFSWaka1qgoWbXS8/q787taWcvhP1Bx2rNntwX48q4Hdo7PFW/saO8UCg3SECSaILSZb3TToR5J5iNFPVJo4ZHozKpWWY2yUFAhblrF11WKVGmXDSq5Bh05TbtvWLWqn43nr0bZxKzsc5z7Tsr3d3d0vPr8teu3HHh4T9oIrRMmDeZnNHvve0Q2qqFde95Z5pVb1l1y0Tkrv/CyF155z10P7PvMd299cNddd933qLV2WghhgP6XvXjrRZduWr1t9eKeK89Y3LGkMxdx8vAhxo8dpj8fcPYixbcP1nGcNoTrIJ1cphMppbUW01kp2M2XrHOixslfa4HLeTqVghcA9hRjPdht27aZfOegXLxsselfpSiWfU4cO0m9Osv8/EnCWJLaHDWTYy5xqYo8DenRcDwC6RFrRaIFqfGJjEdgDSIGbSO0TU3OLQmhhCgUC6Kvu8Pv7uuhsyP99pPnXz8Yo6MZ6KJIP3j//mhW57yO+WaSaJRMjSYzR3JQrutIkVWY0sYoXcVP6/i6gZ/O4ttpSiKkImPKXkBOxeQci+dKHFfQ1d3B4hVLKbV1EKYx/R3S/f23vvzt17z0V6+56fdf+bFVq9ddPX5oX2KbiRvFCdW5eQ7uOyCa1bo6ceCgWX7mGl562cqNz7tg+cYj117I0cm5+SiOj0lhZm2anr1+7dK2Jd0+8ewEJw/v0YeaTVmdrYrazBxJMG1W9rfZhyYtM7G1TovuIo0VOc9VXe0ltXxJibvu2P3ur33lM196usG1ALD/QnhaeSqXc/v6ejE2oW9RO7XpKlMnpzl2bIygWaUtnadfKUxOkVpBYDxi6xKlihiHSCtiLdEy24bOd/bQu+Z8OTtTw5jEVJvhw2es7K57Yv5j//t/3/SVVqnzwy7qtvX1uQsWr3t9X186KvyKPzPfJE0ESIeiK0hmD2FtSi6t4okmvqzjeQ1U0sRzYjAhVltcB/K+wfEUfq6A57n4nkNPTxvLly8jVyjRbERybnxMP+/qC9f83Uff+/7X/9rvvuhPf+tlo+etPutFueMHzczUHE1tZNRoMHHiJPPzc/LE0eMMLHnU9C/qNX2dnWrluu4215VtkpTa3BzV+X360X1TdmZySjbqgYrjkKDWoNlo6CVnnKd0PMDA7EG6ZQ4lsyXVnu52CkUvbi/ldiuZvOejH/3M1621UgjxtCsFLwDsqd/DYGSEzk6/2y/m/HxF2XKlLpI0xXcVnivwfMn4+DzT01WkzobJYZyCqZNXEqkyhrsVDhaLVC5pEujFZ69QDLa/977myc9197fP3HTTmj1CjJzyLxIjQpj/vIIdMYC885Z/+dIvbctf0Na5aGVRVI3jCJdEDyzq7byiXKu+yp/bb8NmUySJJoljEmNInBRpBY7jYQW4SlIo+GgBjhS4rgMKym05vLxDkqZUp4/h5ISqzB5LXnndFdcf3v7ff+dPtr/7+t/9lRf9+Vk9a/97T/6onBk/mTZio9IkFOl8RNxsEDTqcm5qUipHYbC2UMxZ13OsTqzUSaLqjTqN+SpRlKBMYnxfmrUXX+UcjvsfOX6k+Ue9gyVK+fYtrudUZqan71i0yD+idXj4Yx/7yP3ZWzQsxY94rRYA9gyNPXsyk+8zlvc7PT3d+KXIWjkhXOXSCEKiNKVUKdBshihRJo4M89WIKE5QUrUUnCRJYrA2zuS1bYRSwnqe5LY9D+z8px1f/DbA+96XHZY9e/aI0UyH4scJA8PyH3aMPAg8+ANf++s3XHvBxAU96rdNEGikUFoaHCylcoGcJ6mU8xSKeVIgSTPpgCiMsVbgOCbzcxYwcXQ/SVSjrbuT6RNH1aL1fWbDutVvAt793o9/+X9e/4ItX7pkxdL3rVrZc35h6gjV2VpqDDJNtJifjUVtbh43l0dIIaREKCVIE42xGteVVsehURjb0b/YaVt9gTzUKP/DW2686b9Rr0+1/pbP/vtnX/Za/SdZfgFgz/QYGoLRUTjvnFXljkoRY7RVrk8QhNTna4SNgDRKCBoB1kriRFOtN1DSwXEyIkGiDakxaAMpGYG+r7PCueeso3Y42Tg0NPSV9evXq5GRkeQn636NmFOH7UmfVENDQ/rPtv/h+wdLlbe0eb4n0hjXU5gwIecJBgbayOUEuXyeVEMQJjSDAOE7NIMYm2Z6ibW5OY4ePEip5GPigLgxLZOZE3bZQPeyCy64dP3/+B+LH962bfSWL8Hlb3rti/7H+v4Nv724P+1yommC+jTVuVoaxTEmjgRCicRAZA2OI6xjrS3kKk7H8jVKdC1jLC7sv+2RZOQ9733X3wvgncObnT17eu3ExHrR+5sb7MQHPyh6e3vt+vXr7TPRy3kBYE8xeh7KxF1KeXmZ78Q0a5NWWE1tdo6g1iQOU2pzAdVaSjOIaDbirIXsOKRpihECozM3yQRBmBrKxRyLFvWwdLCdgWZw9jv/16i2dgcjIz/53OY/OGx6/fpRec8e9m1ccvZd7eXcZYhEK2uV57k0mgHNZo5isQ2dGuIoRmiQ1pLoBGEtqbFI6fDYw48xOTbO2vUrCBpVkILZsUN6w6oLnRdcfdG2bdtueudNb3ub/7sfeH/4kU9++cYzzr3kY9dfuf7lg5X+1xXa588cXOGVdWMSG0dokyAUKOkihIcsdDCd5szhNP/9I0ftx9/zVzd9Cmi27lR2ZORJasC7n/nnZQFgTzG2bN9gGYHuzs6NBddlTsciCuo056vU5xsEoWZ8Yo56M8VYQ6VSRGtDqi1SQqItxmamfAKJspAv5KhUihLToK+no2UNdMNPbA30Q2PXZgm7jXH9m4UvLrPUbaoNQkhcz2NifJZmI6Kzq0KaJqRxxuWKU00UpkglGR+fZnJ8hnzeI4oSqnM1QOF506J3aZ2zNyx/ETD82+97X/w773+/2LFjSG7bNnr8L++79f3A+8/d/JLlV24oXV5wOpfl/cJFhZy7pqNcFMJRjM/Wj4Tzzuf2HJ++8zN//9d30noBPr1jSIkfv0ReANgveJFoARYv6i46SqDjFEdJ/FKO2eka01NzCCno6iiilCJJEoKmRkkwVmWaG9IgUThYpJR4rkApV5o0obPsL1uyZMmSo0eP7h8eHhYtBsJP6emQPfVzxY6aXwpoTI3h+i6OMLieg+fmCYOIE8cmUUpmWiBSEiWaRGuQgvrRMaIkJVfwaDaa1OZ9HNfDywcqrE3btcv7z7vswo2bhBB3Dg8Py23bRjQgh4c3y+3bd2khxKH7dnPoR/2q1lqxffsWNTKyW2/b9otrJ7sAsKcWQillgFyURiu1SdBWC6EUHd2d1KshOA6dXR00a3XmZ2vUmwZfeCRRipUWq4Ak2yRxXA9DNmPCGqIwtPkOT23cuLH76NGj+3/gDvXTC6lUpb1MXMrhei5530EIQc53kUJSqzWo15qEYUIYJASxQToSIwyuK8jlfIyxhFFKrd6k1N5Bmlqqs1N65ZL1zjUv2Hrx9+6458nWRmZkZLcZGRFkOvabJWxhw4YN9lU33HBqbwetjdy+fbsETKsL+AtvyLcAsKcYrXUS31GyDWMwRglrBZ7vU+loo39wgCgOCcMA3/ex0sWJYxIvIQgSbKJBKFKTravk/Ryeck45smjf9x3fEWcBt61fP/EzAZhylW3rKGO6KyhX4UowqcXzFEpJpFOk3F4gjhKazZSpuTpRYlBKIVSmE6IN1BshXi7H+Ng0pXI39dl5ugY1fd2V1QBbtmxhZGTkB+6GGNht/t0FykILVOZ0Oi8LAPvJAGbb2/JGJyECi+/7eH6e9s5OwBAnEZ7nkbgJKI3j+wTN1gvuKuLEECYaKSW+JykWci0enQNKghA/UyXaRGvR0VVBNTowViOMJo5SPM9BOQ44KUKAn3cotkG5o8h8LSCKU+LEkCSZpHfUjGj4IcrNMzY+TntHFzbVeK6/sgUw+2w/LwsLl08hhoczcnRHx6I2T8h8EtchjTLtGJuZnqeJwfNyuJ7CL7l4OYec76OUg59z8TyF40gcJfBcB0cJ/JxDLuchpOs0Q8vUTPOB1qXpp/s039VqJ0r/oJsrUS4Vhed6uI5LsVygUCygXJdcIYfn+7i5PK7vkS/4tLUXKZZ8cnkPx1EgBUhFFCXEYYgjBPV6TZo0QVmzDBCOUk+LZdACwH5xIQbAwEBv2ZEyp9MUnWrCKCSKI7Q1OK7zuEez53soR7U2lzOHS8dxcJTzxBaxVCgp8X3X5splZqvNmZ07bzvSslb9qWaAPb29FuDgwemHY5vT+UJFYgXK8cjn89lAzoJEIGW28JlJx2Waiq7n4roOnu+jnMxIXUhJmqTEUYy1mjiOkEp0A67lWZ/AFgD2FMAl9+zZ4zA0pHo6ip2Fgi8zhwQp4ijCdVqGeUAYZcwHYyxaZ+4lSklAZF7MSpL3PVxHoSRZVpPW5Crd9tDxmXtgftaYn76G3+joqBECvvXd7+6bmIsm8+3tAmGsch1AorU5tTrS0knMpAuElCjHxfP8LOs62YNBSkkcx6TGECUJYRhibYrnugvIWgDYU+seZqbaozGjo7o5Px8qkWLSxDbrTRCSNDUkcUqaWrTOtA6jMCJJDGmaHdwwSohiDcjM8ByDapWLxVLJNlNX7Ds88TVAtLppP/UrpPn0DgU0Hzs6+XUnV7G+l9MYiNME8yRJbYTAUQrlZB+O46KkxHUUIJBKZY7O2hLHmiTVaJOZXIiFLcMFgD01cGHb+/uXPe951w2dedZ5my/bunmovWsZjTiTRzOJJowCktQQNAPiIMKY1nBWuuiWdbNsseajVIMQ+I7Ed11c17FtvQNq79HZ5Eu77hoVYPkZ0X62jY4CcOeDBz9xZKopcvm8zCyWzONWRlK0HDWFeEIZy6ZIKVt6ii0fNCuIk5R6PSAJE0yS4sjHZeEWYLbQRfyRXQ3JyIjZsPHKdede9sLvOcW+dvpPUC8O8vHdkopcIyu6TN6cJJ9qbDSNDgNSDVFk0GhEYokjTWo0QiogMxo3WuLmXAp5Rcl3daF70Hn49qlP77nrliPW7lBC/Gz0I0ZHR7W1w1KIkV3POXvRnVefUdzUbNS1TK1K4gjXzWZi1ooMRDpz2TTaZP7QGlINiTYYbbEms86tzs2jo07SNCCMIwvom2/+lrN161a9ALCF+A9jx4YNYhtw5nkX/s6Kc57ffnTWRhV/uXt8rsr9t81LEyd4dOCmkj7fY3lZsqI8Qz6dRDdjwsDgeII01WiTtfh1alCipYVoNfm8Z/uWr5L7plT6te/c96dCCLZvf+hneocZHd0jAH3f/pmbzl++9O89V9pGrGm5JaGkRKcaYQxKQqQ1aZKgdXanTNKUJLGkRhJEKQhJ0bpYv0Kh0m/7e/J+Vxf5rVu31lo7as/aO9lCGv/PLizWCiGEffWv/+ldpu85Gw8fOWauWmeVNorvPqrIl8rEsWB2epb5mTF04xgr8hNcumicATGOjZp4+RxJEpHEJmM/BBGOUrgKOsoO/UsG9IpLX6q+dOfkB/74xne/7eekfiTs8LAQIyPir/7nL93xnGXpxskThzWglCMRKLTWKNfBGk2tEaMTg1Y+J6sw03SYDSUNUyC07RhVoa2jh1JbiXJbm1V+Xnzv1u/ef+zQI3+15+7df4u14kkeSQsZbCGyQyiltEAh0bK9GSbCM/PiRWfn2Hd4ls8dS/DaF+FIB2xMKe9TC8vcP15nvprnBSs8+pyIWj1ACkjiTO5MyEx8xpOSvO+avqWrxZ6xaOz/3PTpd1o7LLeLn4t2n922Z48UAv39+yfevrij/1t9xaJtNAJMYhFKZ/qMUhKFIZ6jmKKLR+a6eWSqwEzgMxdKGqkHqkRqJWZS47kRypkT5dwci3rOP2dlacnHC4XSc+4U4k0/dV7lQpPjF/36NSystVyyceMivMKK8akJ1vUaubgQ0F0IyYsacaNJY26a6vQYtblxTDyPY2OOzyn2nEyYCzVxCmGYorVBa4MULkJbHM+h1N5uvb618u5Hxv5ofv7I7PbtyJGfE1VodHRUf/rTQ2rHV/9153cemny/KfQ4wrWplC7CCgwOUmfumifTfj53YA2f37eCB2srGBdLiIpLkeV+4lyefF6TV/PUGrPE9WnqszMcG5sybmlxunTF2b96+eUXrh8ZGflp2RotAOx0iFNE2/m0tKHsSXHZktAMFmaQCnxhCeuTzMweJwyq2DRER1V0VMPGdeIk4siE4fiUZbaqaUYpqbYkqUaQgSvvYZasO1s9NGHv+z/v+eAnrbXy572Ju23bqNmxY0i97xNf+4PvH0zvLJV7HWmNtkJhrEXrlFSW+JdHO7h9ohe/cxmlSjtKKsKwSdBsUp04xNbVNX754pB4+hGmJo8xNXmU6fET8rH9Ryl3LLZr1m16nrVWPBvP2wLAfkhMTGSLlW2d7Vet64v44+uL5qy+JkmUcuLEGBcs1/z68ysMFidI4ypCp5kXlwlIoyonpmqcqBsenYh4ZCLh6IxmtmlpJhbhOHT39tDIL+fb9x3/HQHx6Oi2n+7u149ZKj700KiVQgT//O0Dr3p4ujjntFVEYq01BppRyPGaz4PjGcUrqE8xPXWSuflZwjCgHtXp9kIuWhKysWuSy5ZDHDcRWKQRpEkg64ERxXLvrwgh7IYNG+yz7d6vFqD0H8fy5Vvk4cO7zRlrz3rJsmWDFySNqik4RirbJA7qvOa6c7lg0Sw5FXPHw3UiIxBxSNCYIS/n+KM3vYArz19EX2eZjq4eIllioqaZrkUUlNXrNm1Sdx0XO//8/77/RmutPOusbU8Li3z3buw7N292PvX970+X2zsPLF7Us60sU9MIUxnECccb7dx2vICROUyS2dIiM5ZKENRZ1tnkmnUW25xiLpDcsXcOmzpYJShXKqJam9d5Zgde+9KreOtv/e7O4eFhuXv37mfNXWwhg/3Q2AVAs1E9fHimxIe+LfjmnhATp+TK7bznH27n1jun6CtJJAZrNCkJjbkx3vLKi1ncKfnKzfdwdLxB0dGcs6KbzVdsYsPFlxN0rueWQwXufHS61Go0Pa0HbmT37nR4eNj5xy/uHn3wuP5cw+1VR2ddfXCuwD1H66QGMAlWpqQSgljjqICevKYxP08jSpA4iDhgZVfAG6/tYetZOWwaUKvVZG3ymPFcf/u55266fGRkxPxXzfkWuoinQfS2iLGusPcerVkmkjb5nEJEFE3w8EHNJ3fWCb1lhEGTauLjoJmqz3PmijLnrOzhf/1//8LBuQIVL6U9X2NV5yRnDpY5d+0S+jeer0TbUrNJ5S50mmPPEULsGhoaUj+OKcLP8oEyPDwsJ4/sGTVtK1626bIl1hrNtz68k9rcNJVSN0iPNDYMVOq8/RXLyMVjfPfWwxw/NkV+wCVHnV+6spP1S6o0nF5Ofldz4FhVzEYn9OTsanHWuRtffN99d92yfv36Z02ZuJDBfkTkVDrneB5dnXnR11NiphHT1d3O+RtX8cW7I76xx0V4PhpN2qyy9cLl7HnkGEfrOcrtXUSqjaNBN9870cuX9pb4/O3TPPjgA8jp+20vE5x15uougKf/0G1hZGTEdBTkphW9BY4dm+DEeJ3XvuhCSnYCnRocxyNNUs5fmePc9sMUqvdz6eocMgmZrgZUior9R2v8/b8eZC4UCARxWMPPKTSOaO/oNc+287MAsB8So+szEzhhgvG0Maen6o749C0nbM1UuPXhGWLtY4xESIvQmjiNKeUtZy7p4e5Hp0hSS9ScB8BzFNLNUU9KPDDZy7/ubePWPXNMTdfIFSvPCCrR9u3bNUClXLjqi9/ez59/cVa+45MzHG+UufaiAYKZYwgp8HzF/iPzHJ0y/PPtKcOfPMB0IBAa3GKZ7+yDW4638fk75phpOBCHtOVdhHAIw2ABYAtx6mKSDUUnTx6p91fSeSeZY++Y4nN3O3zhnoS9xyIcR2BNDBLiKGbV4iIlX/HokRk8LwfSRyBbJrG2NWT2mIw6uHN8MYfDQVS59xnx5wohLcD9+5v5XQ8XiP1VJF4vO++usXHDUtqcOdIkJudK9s8Uee83BPfO9DOWVAgiQViPcVLD+iUFtPC5/zDE1sHaGp6jqDUiXNcuDJoX4okYtlbeu2+s+arrLpDv+/0XcNH6Hg5OJpTyLjk7TTp7iNr4IWbGDtMYO8Sq3iLj01Um51IMCiE9hFRk2x8KISQGgWMMMQUmGoqJiYlnxh/bKlCPzzmJ9ftRwkXKlMdOBjRjxUUrfILqOFJYPNfjoTGf/XN5Nq0dZKCnwthcnVq1xuCiCu0lHyV90igipyzFXE5IKels7zz0bDtDC02OHxI7d+5UW4VIf/e3f/u1y5ataT/zjGXm797zG/Lk2Cxho8b07DyTU9PMzNSo1iIOHz5EpzfLg3sfJdYpyiRYmwMpEPLUjFWCEBip8FyXNAl4aO9eAbBr166n9e8deuWn1ejoNu05/iPWUWc7yppCvijr1uH+/XOcu6Kd7x2cR1T6kTrAU1Dy8oxXNf98T40rVnXRVijypW/ViZwuvJwkjpq4vSpzKAAAFyJJREFUAiyWuVqVrr7uo/DDHWIWAPZsyVzDw87WrVvTtWvP3bLunEs+8Nlv3GOOffKb4rdffx3L+kvMTqd0d1c468wVjB0/ysH9B7no3Cso+A7zV9SQ7d/gs/9yJ46KSG2AlD5KgBASRzpIR+AppEgMYVifeHLX8umKiYnMltaasOY7GkeCdRWVgseBE9NcfkaZwfIsk2mC9PKINMVVhukgx4lGGxAiTI0T8xrHDyjjUMm7rFg5QPuibvYemkU5jzzrVlcWAPYD8eY3v9n90z/90+S66647401v+vXRjRdd5EzXGxw+Pi/2HTxJd9sK/EKBBx96iOmpaVauWMnUVJU/vPHDGHKsXbOMsbkQJ9+BLwM68im1oEGS5JBeEaUcHFy0scw1mlirniHvQZZBG83q7ZUO8yuezBEnNYQ0HDkxx979dTwzzcSRB+lo7yY1CUZr0DGuCbjnkRnKecVVF2xgw7pVrDljkBUrlrB6ca/FaPVPo5+p/+u/fmkPwOjoDvNsIXQsAOxJ99GdO3fKq666KrHWFs7b9Jwvpm5H95f/9Va9+aL16gUXr2RseoY4iBjo7+biTRfy3/7gL7jt/s/zjrf/Ki9+xav4v389yuH5MZQyCEfQDCyugFJBU69VSdM8QnaDcJipx6bUnldtnT1dWQaZeFpP3KkMapK5fVrXre+UZLVWZWquxtlnrubS557PpdcYgtSjrdJFLu+TJjGNRgNjDI5SLOrpoqurgjUJadjg0QOP8aEvfprOnkWkWpjBwcHw2XaoFqhSIHbs2KFGR0fN3/3d35lcqX/zX/zFuz/1K2/8pXMWD3abxQNdSmDp6u5EGsvX/mU3X735Ttq6O7n0kov4xOfu5Ms338/JsUnCONv1kjogjUOE4xNajygWuF6OKMo6jq6XA79gu7sqclFn4dO33LJr7xve8Aa5e/fup62NvWfPHosQHDt25MiKVWf9cpKojvrcMRMZJba98oVcuOkslFJcceE5LFrUQX1+nLxnWLt6GUsX94GN+e737uCzX/k6k1NzSOXh+D7KEcLxy2Z6tuZPTx778t69e48MDe1Rz5Z72LO6izg0NKSEEHbbtm3a80rr3rn9XR//sz971862rkUX3HvfHtNe9OXalYP4Lnz9m7dRTxyuuf5abnvoGG/63Q9y592HWLxkBXOpz75j80RxQhTOk6QWqXzAIHWKMQ5aFCmWe0itC65PGMWYRMMzSB566JWvVEDaqE3cmjQPsmRJm620d/KPX7idX//Dv0F7RR4bn+edf/FRTpyosnhwJePHJ7n7rvu4695HmGsaVq47j1LXALN1zdR0nbnZhGKp01x48UUin28/DxDPJibHs7ZEfNLmcMev/uqbfud1v/za377yys0dIuMFmrn5WTkxOUuPFaxYsYJdtzzMK16/nd9722t57dDL+L2Rj/POmz6PEYocIcamaOmB4yGMQZAirAGrwSYkoaFUaqdY6aLWCOjp6bY5P8eBIw+ckXURn/7X5FSZ2qxPf6fcvuJV80HRWukS4dLVv5g7Hq3x2R2f4k2vu4bnXnc53/jSV+koe2w8/1yu6uwFKdl/6BgnxiYpFYsU8gVmB6c5fPiEsBVF70DfdcAHWqz6BYCdjuXg8PCw2r59uxFC6I7eNb92+WUXveO6F7142Zlr17B/38Op0cIptbWLrs526o2Yz3/tOySJ4BVD1/Ldh6b5Xzd9kQ0rB3BdjzhNiZtVbBoghEQpH2MTJAnCGgQgpEQYhRQaHdeYm7UUC+0UcjmhlE+l2PYC4C937dpuhBh5RrxI5XLbXL48yFxVgrJI5TFd1bz/U3fzqy9/CZdecQ6/9NZ3cun6QX7jra/D8TxmZyZ4aO8B7n3gICena4RhDCalq1KgUsjJ7oFuu3r12qs2nXXWmdtuuGFvS6vDLADs9ACVAOSNN96YjoyMpCMjI7zhjW99x0te9oo/3br5MtrKBW20lh3tHc7cXJUjR0/wve8/yhnrz+DyKy7n9/7oI9y+Zxoj26ilHt+97zBWN0iqVaTjg5NH2wSThkib4GCwAjAGgUUJgaMckliDm+J5LmEzFHGiKbd19rR+z2fMUz1JojgvBEr5CG2JUwffcVjUP8i9j4yze+f7+LVXb+OFW8/htu/fQmc5z8pVK7nikku48rLLODo2zcHDY+TyBcqFHLWZaVEParqja9A759LnfuCuBx983p4NG54VZeJpDbDh4WF54403mpYWhAE6X/Oa179y69bLX/WyV7x8a1dHl0Yj4iRSxma7gG0dFS7o6+Vrt3+Fd/y/D/LW172AJavX8uVvPYAQApPEGGszDV9HIX0vu0uZBGGT7FLbApcUAtGSozYI0jQln1dEcYyfJoRhiuulz0CLHs9xvQLSzSN0gLCCOEpoL1j2Hhrnl6+/iiXLBvn1//6XPO/SNWw8dz3WGk4cP8ixE+Pced8Bjo/X8fN5+vs68ZSlrVJR3X2L9dnnXnb1i1928pWj224YHRraoUZHt+kFgP2CgqtVgjivesX163v6Bi9/7jXX/MElF1+6rLe/H62NCYJAGWsRQpDECVhLksQkhYQ1ywbQieR9H7uZYiGHEBA0G6BjpHKQ0se6IUlURwqJEBolLNJqsBqBaZWJ2ffXJkUDWiekaUiqCzTDkLyIn3FP8lwul1fKQbkS1+Qhk0TEpBHd7R3c98g4993/EL/3tteSz0luvvk7rFzcSW9fN2etW8O5521Cuj5pajAWjp8Y47Zb7yfWJ4VX6rKLlq3532A/PzSEGR3l6djkXgDYTwNcF15++YbNV73ib85YvfaiNWesYOO56yj6aKNBSalc5ZEkMXEUkaQpxlhSrQmmZrn0rF5+84YL+dA/7qZRByMErgQrHdI4RicRwlhImzjKwWKxwmBtirUJaI3BIAVYBIk2oDySJEWqhOmZGborDutWdD+D7iFbgN24Oa9gAIXAkw5Ii8rlkC0ziKMTES9+7kb27Jtk97dv4/UvuZDBlf2kUcTsbJU4niC1KdoIdGoxBs48YxFG+HLR0uW6o+SuPnn4wDu3bdv2J8PDw87IyEh6ugLsdJyDyV27dtmPf/zTA9e8/C3fPuuSl6w7PGXNbQ8e19/89gPccd8+9eihk3J6LiCIE1IE2qjsMLSUalNtMHGNdSsHKPiSb99yK9paBAaTRJBGoGOE1ZA0wcQZq15HWB2BThA2RdgUJSFOYxJjSVJLGDSxJmH5kg5eff2VorvN5L7wxS9+ZGTkxoCnmd5wSiZh5apzr5Re/zVBbIwrhUQYXN9DuAohBJ0dXRw6WiPnx/zR217Cg4+N8Zkdn8VajZ/zKRSLlNo6KJXa8bw8QjocPz7Bhz++gzsefEysWLveLB1cdEVt7uSuT3ziEweHhoZO27nYaZfBhnbsEEIIc+22t79Ht503uOvW/bFyrWcoy3okefThSWq3HUZHtyNNSHu5gO87OCor71wJOU8w0F3m8vNWce0VGzh06AQf/8xuiqUuHCmxVmNbABJoUh1nJWGateatzUz40jTEagMIym0dLFnSy5pVyzjrzBWsWz0gesuOna/nO697/vPP+srXv/6doaEh+fRuNWcRR0mbYyAKmhTyORwh8bBoC4VKJXtgWAhlhXf+5Vf5wj9/mv/xa1ez7ZUvxtLSsLdkeqNSIKVi06ZzeeELr2b0S98SN3/z2/R296i15131gQteesHFlWolgtOzVDy9ADY8LEe3bdPr169fqoqLb3js0LTVNvJyOR/PVSTWIPwibtEhETmCMGJuNkHbFJMkCJOSpjFCJ6TBQb76zbt55bUX0d7ZTaGQzxYoczkEAmk1wkZgDUInCFKSOCSJAgQpnW1FFvX2sai/i8UDfSxd3M9AXxeeY7BREz17mER1mXK5pPLt5X54+ulSp6KzqxhFIqFWncN3yrhuASXA8yW5XI4gjhBWsPvme6G2l/f8yWt57SufT5JGj1sgGWsAi5QKqTy0NhQLDm963Yt46Ytq6qtfvzP99nePn33bF+74m+9/56uvfvolExYA9iNj8y7kbjC9g+uuT4wjTxzar7UQKpcvUsjnEMISxRFBs0EQBCRRiDUaYU3mJmL04/Y9bq7EdLPGB/7hX8nlPKSbxzUSHTfxXIUQFoTG2pigNocgoL2SY82aZaxfOcjivk4KOYkSKdZYpJ6lNj6LcATFfIlSqR0hLFJI21Uu5yHzNN69e/fTdwPbArt3w7o1Sw619azm0cceZXYmYmBgORJNLpfD2JS8n+PQYw9yRmed7Tf+JmeuXkqjWUMKUEJgMuX97MNYlLQgDIk2pM2U9oLH67dtca64+Jzk3e9JXxU2qztHR0c/fDqC7LQC2PbtW9i6dYTnbbng4ue//CXc99AR+9iBGfadmGZsYpzJ6Qa1eoTWMdmGlkGaFK3TDFgms+/BGlJACYmXrxCnSXbAPI/UxOgoIk0j4qhKW0Gx4ezlnL12kMU9ZcoOxGGDMJyi0UiQSuC6Hr7vI5WP5xbwvALSz3NoOjXHHtqnajWTAx63eH26Y3riSPjy669lUc8NfORvv8jMzFF6F69FCUkapxw5+CAXrs3z5+/4XRxjmK83KeZzmaGgMI8vmVqRGfgZITAWtJZEqaERpYRRhHU85wUvu8EI19507MijXxgdHZ0go++ZBYA980Js2bJFA875Z6+74JzFBZZ3LpNqy5kEsebkZI1HDkzw8GOH2bv/KAcPjnFyYibzttIp1rSYF1ikaBGmyHywsAZhNUqKbIic1lm0qIuLzruCC9Yvp6sEaWOa2uw09WoNY8CRCuEVEY6DVIoUaaPEIQhiM7b/mD14Yq8Yn266K1d209lVvB1gT+8z46Lf2V7p8G3EhWd2sO7GX+Gfvng7dz4yS9H2MXXyOJ6t8pobbuAfPnMXjxyeoLunzKLuCt1dRXxXIi0EUUqtEVNrhlTrIfO1JvVmSJSEuNKlmK9QKefFQH+3vviKa3Mzk8fe8ulPfujG4eFhdToxPE4bgA0NDUkhhL7wkuuuf+yEWZe764ju7ymociFCRwEVmmxcCucuXkG6dRX1JoxNT3P0xCQnTswyPjHD7HyDZhASJQlGWxwh8H2Xcsmno6ONns4yXR0l2ose3WUfl5BadZpgfg6TJKBclF+i0UjsfC2y882GmZ0PmK3WRa0RqFqUYKSncsUS7ZUi52xYPF7w7R++731/fW9rtPCMKI8KpTavWCnSrNVxheFtb3ohn/7KA3zj1jHq9TkWDazmr//he4zPheTL3Tw21cSYeazROFKQ8xxcR6KtoBEmBGFMHKXESYQUKYWcR193jjVtnVjpyyhJ7aLBNb+1rK3tfTfeeOPc6dTwOG0AdqpB4HjFgS98/f70K7v22v7edjXQU2Kgq8BAV4H+To+8azBpjEwjepyYUr9idWcbxnRghQvKQ8pMckyS+WVJAVIYhE3RaUgUNAjnxwnTFMdxiVSB/YdPmgcfPWoOn5yQs9WGDKNUoJDlchnPUxQKXnPVkr5GzvfuWLZi8X05l9sOH75v50c/9C9VrBUjQjxjntr3P3QsuPyShl61vGKb9QZRdZyLzh7kSzv3IkXmqjIzGVMoloniCFcpcn4Jx1XkXIHvOviOJE5SjG0SxwZrYnQcE5uYNIpI45QoqDE10Sa72oppoaO/5+wtL3zl4S986qOtLJYuAOwZGFEw22yz005Q9+wj1Zq+56HIpkkslTCis5ITK5f0snJRBwNdObqKLo6NiOM6UdgkjoKWAXhGcZJCgMiu7J7j4HoK1/VwPY/2jg7mGtbe/dAhvfPWe5yxyRnZ2dEuc5UO1gz2B0pxyHGdbywa7I1yjrxj9aJFt0w1TzRHRm6a+4HMq0aFeEZkrlO6IPfvuX/upo9+Tj13y5VccdFyXXQj1d+j6GtLGZuKgBRjE2qNOYwRKOHguopcziHyHDxHIiw0w5B6s0lQbxJFAUkUYJIYMIQ1h/q0y+zENH3dZdHf7tt8of1VwEdhu4GR0+I8nk6ES2Gt5bzzzmtbtmTVe/OFtm21wOZrzZSZekqiHaJU6CQxVlotHNfKUt6jr90Ti3rK9HcU6e8s0FHxyXkKpUBJQBiUcABJbIQNEs1MTZt9R6btA3sPOI1mlb6eEosHem/v6Cjfomzy7eUDbbet2ZhMbt3675/CLQsfuWfPHjs6OmqegaWQePOb3+zsPzTxVwldv7lsxVou2bRKX7PlbHlisin+8M//mcmmj+OW0FKhUShH4joCx8me18akxHFM0GjQqM+RNuuYNMQkIcpqlLR4nkPOz1EsFejpajNrVyyRHfm5sb941x+sAMLTpUw8bRnNb3zjGxdJ6b6gWq2dNzvXuNzgnKPxVaIFc9WQRiMhiFKiOLFRnGhlDXlXUS56dLTl6GwvUC54CCCIYmr1kGozcpqRwfOLdHQU6Ovym0sG2/5uyeK2D7397e+8/wcPxObNm50tW7bQApNtfd3+gpwL+6KXvOTqepj/4ygtbb3s4o1s/4M3cHRils9+7R4eePgoh09MUQsShHBwHEk+71EoeBTyWRYr5hzKBUW54FIp5mgr5ijlXFwlUErgeg75nI/ve3S1d9jJ8YP2z9/9vy/+5jd333m6rLOcjlxE0XJTPAF8DGDnzmHnU586uCzR7osdx10zOyPOkKpyUa0a5ptB5Ph+yQkjTa0Z0QhCpmsBk3M1sBrHcXFcgVIW38WuWd0Xt5dKtw4Odtziuo2/ede73rP/SdnJeVJmYvfu3enTOdf6L4RtzaRuBm5+/ote9msimbpp6uTxfFka3vryTSLU5zFbb1JvJKQGlCPI+S6FnIsSYHWCTiNMGpNGAXHQJAoikrBOFIUEzYB4NkILQeq7eNVO3dXR6axZtvKKb7L7ztOlXX867+TIoaEhsX79evEfXZjf/ObXDhQKlXwc68XFfPm5Urr9URRTrTdEGIboJEE6ji2VighrAm3Te0sl71bHiZrvec/fHD71fXbs2KEeeugh21qJOa2oPkNDQ2poaIht27bp33jLG9/wm2/6jb/pbiuZ+eq8Ekrheh5SCSwGbCs9WzBGoxNDEqdEUUoYhDSDgEYjJAyzQX8Yhmit8V2XcrlEV29n2j846Hzpq18d/cN3vnPbzp07na1bt/7CNzpO530wMzo6+m+y2i6QW4ARMB8eGTnZ+toB4NtP7fluxfD27QowPwfD8qctRkdH9ejoqGjJK3yyrX35//q11/3you7evHE9VwLEaUqaGIJYU21GTM8FTEzPMz45z8TUPNPT80xPzTIzM81crUYzCIjCAK1ThJSUcnnKlTLdvb0s6us30jRdgL/+68mFNv0vUslzauly9w+Uknv27Pl3IixP1sfYsuWJDtuWLVvMyAgghBl5BonV/Kxfuw9+8IPCWpuuWrf5wwemyiNnn7067u4suYCs1htMTMxzYmKWk5MzzM7VaTZjkjgiTSJMEqGTEJ3GGJ1Ya7URGc8Day2NesxcramOjc3Z5sqaXDroRvCEEOpCibgQz4YQAGdu2tTfXjnru2776pW1xCGKtdWxIY0CUhNhbYxMA0gakEaYNAOX0TGAkFLgOApHgec5eJ6LIy3WGpYuW0R3d2VvHMy+/BOf+MTe7du3i9OhybEAsIV4Sp3FoRde2B8X1/yxtu1Xe35+3dx8kyBoEoVVkrABJsVzwHdd/JxPPufjOBKbbYuPz89X93iemuru7hKe75k0Ce8JgsbNZ599drRv3/cOjI7urnMaMTkWALYQTxlkAK/fTE4tfcW6ZjMBwC0USJpNEqCtUMArtlMoFHBdlyRJmJmZSZctW3Z4ZGSk+p9fb60QQtjT6QVbiIV4Smdm8+ZhtXv3T0xlkkNDQyK7Z60XsIve3l67fv3607ITuwCwhfiJz05LDu/HjtMRQAuxEAuxEAuxEKdn/P8xynsiuvjJmQAAAABJRU5ErkJggg==";

const LSBSC_KEYWORDS = [
  "U9 MIXTE", "U11 FILLES", "U13 FILLE", "U15 FILLES",
  "MINIMES GARCONS U15", "U18 FILLES", "U18 GARÇONS",
  "SENIORS MASCULINS 1", "SENIORS MASCULINS 2", "LSBSC", "LILLE SUD"
];

const CLUB_PALETTES = {
  "LOMME": ["#1D4ED8", "#93C5FD", "LBC"],
  "COMINOISE": ["#B91C1C", "#FCA5A5", "LLC"],
  "HELLEMMES": ["#047857", "#6EE7B7", "BFC"],
  "TOURCOING": ["#7C2D12", "#FDBA74", "TUS"],
  "WAMBRECHIES": ["#0F766E", "#5EEAD4", "WJ"],
  "WASQUEHAL": ["#B45309", "#FCD34D", "WFB"],
  "VILLENEUVE": ["#15803D", "#86EFAC", "ESB"],
  "COEUR DE FLANDRE": ["#6D28D9", "#C4B5FD", "CFB"],
  "ESTAIRES": ["#1E40AF", "#BFDBFE", "BCE"],
  "BAUVIN": ["#BE123C", "#FDA4AF", "BBC"],
  "HEM": ["#C2410C", "#FDBA74", "HEM"],
  "MARCQ": ["#0369A1", "#7DD3FC", "ASJ"],
  "LILLE-EST": ["#4338CA", "#A5B4FC", "LEB"],
  "SEQUEDIN": ["#15803D", "#BBF7D0", "OSM"],
  "RONCHIN": ["#0F766E", "#99F6E4", "RBC"],
  "ARMENTIERES": ["#1E3A8A", "#93C5FD", "SOA"],
  "CHERENG": ["#9D174D", "#F9A8D4", "ABC"],
  "CROIX": ["#991B1B", "#FCA5A5", "CBB"],
  "SAINT POL": ["#0369A1", "#BAE6FD", "SPBC"],
  "FRETIN": ["#166534", "#86EFAC", "FBC"]
};

const DEFAULT_CLOUD_SYNC_URL = "https://lsbsc-ecran-default-rtdb.europe-west1.firebasedatabase.app/lsbsc.json";
let bcChannel = null;
try {
  if (typeof BroadcastChannel !== "undefined") {
    bcChannel = new BroadcastChannel("lsbsc_live_channel");
  }
} catch (e) {}

const state = {
  matches: [],
  currentWeek: null,   // déterminée automatiquement (detectCurrentWeek)
  autoWeek: true,      // false dès que l'utilisateur navigue manuellement
  selectedMatchId: null,
  baseMatches: [],
  catFilter: "ALL",
  locFilter: "ALL",
  displayMode: "tv", // 'tv' | 'mobile'
  mobileTab: "live", // 'live' | 'schedule' | 'buvette'
  staffUnlocked: false,
  staffMode: "live",
  logosUnlocked: false,
  pinStaff: "5900",
  pinLogos: "9694",
  pinTarget: null,
  pinBuffer: "",
  lastUpdatedAt: 0,
  tickerText: "🦁 Bienvenue à la Salle Municipale de Lille Sud ! Allez les Lions du LSBSC (South Lille) !  •  🍔 BUVETTE OUVERTE : Sandwichs, croque-monsieur, crêpes et boissons fraîches au profit du club !  •  🏀 Suivez les scores en direct et les résultats du week-end sur tous vos écrans.",
  clubAssets: {
    logo: "assets/logo-lsbsc.png",
    mascot: "assets/mascotte-lsbsc.png",
    customBadges: {}
  },
  syncUrl: localStorage.getItem("lsbsc_sync_url") || "https://lsbsc-ecran-default-rtdb.europe-west1.firebasedatabase.app/lsbsc.json"
};

/* ================= GESTION DU FORMAT (TV 16:9 VS TÉLÉPHONE ALLÉGÉ) ================= */
function initDisplayFormatSelection() {
  const isSmallScreen = window.innerWidth <= 820;
  const recTv = document.getElementById("badgeRecTv");
  const recMob = document.getElementById("badgeRecMobile");
  if (recTv && recMob) {
    recTv.style.display = isSmallScreen ? "none" : "inline-block";
    recMob.style.display = isSmallScreen ? "inline-block" : "none";
  }

  const splashLogo = document.getElementById("splashLogoImg");
  const splashMasc = document.getElementById("splashMascotImg");
  if (splashLogo) splashLogo.onerror = () => { splashLogo.src = FALLBACK_LOGO_B64; };
  if (splashMasc) splashMasc.onerror = () => { splashMasc.src = FALLBACK_MASCOT_B64; };

  const savedMode = localStorage.getItem("lsbsc_preferred_format");
  if (savedMode === "tv" || savedMode === "mobile") {
    applyDisplayMode(savedMode);
    document.getElementById("formatSelectorOverlay").classList.remove("open");
  } else {
    // Pré-applique visuellement en arrière-plan selon l'appareil tout en laissant le choix au démarrage
    applyDisplayMode(isSmallScreen ? "mobile" : "tv");
    document.getElementById("formatSelectorOverlay").classList.add("open");
  }
}

function applyDisplayMode(mode) {
  state.displayMode = mode;
  document.body.classList.remove("mode-tv", "mode-mobile");
  document.body.classList.add(mode === "mobile" ? "mode-mobile" : "mode-tv");
  const switchBtn = document.getElementById("btnSwitchFormat");
  if (switchBtn) {
    switchBtn.innerHTML = mode === "mobile" ? "🖥️ Mode TV" : "📱 Version Mobile";
  }
  if (mode === "mobile") {
    switchMobileTab(state.mobileTab || "live");
  }
}

window.chooseDisplayMode = function(mode) {
  const remember = document.getElementById("chkRememberFormat");
  if (remember && remember.checked) {
    localStorage.setItem("lsbsc_preferred_format", mode);
  }
  applyDisplayMode(mode);
  document.getElementById("formatSelectorOverlay").classList.remove("open");
};

window.toggleDisplayMode = function() {
  const nextMode = state.displayMode === "mobile" ? "tv" : "mobile";
  localStorage.setItem("lsbsc_preferred_format", nextMode);
  applyDisplayMode(nextMode);
};

window.openFormatOverlay = function() {
  localStorage.removeItem("lsbsc_preferred_format");
  document.getElementById("formatSelectorOverlay").classList.add("open");
};

window.switchMobileTab = function(tabName) {
  state.mobileTab = tabName;
  document.querySelectorAll(".mob-tab").forEach(btn => {
    btn.classList.toggle("active", btn.getAttribute("data-tab") === tabName);
  });
  const secLive = document.getElementById("sectionLive");
  const secSched = document.getElementById("sectionSchedule");
  const secInfos = document.getElementById("sectionMobileInfos");
  if (secLive) secLive.classList.toggle("active-mobile-sec", tabName === "live");
  if (secSched) secSched.classList.toggle("active-mobile-sec", tabName === "schedule");
  if (secInfos) secInfos.classList.toggle("active-mobile-sec", tabName === "buvette");
};

/* ================= UTILITAIRES CLUBS & LOGOS ================= */
function isLSBSC(teamName) {
  const up = (teamName || "").toUpperCase();
  return LSBSC_KEYWORDS.some(k => up.includes(k));
}

function normalizeClubKey(teamName) {
  if (isLSBSC(teamName)) return "LSBSC";
  return (teamName || "").replace(/\s*-\s*\d+$/, "").trim().toUpperCase();
}

function generateClubSvgDataUri(teamName) {
  const key = normalizeClubKey(teamName);
  let c1 = "#334155", c2 = "#94A3B8", abbr = "";
  for (const [k, pal] of Object.entries(CLUB_PALETTES)) {
    if (key.includes(k)) {
      c1 = pal[0]; c2 = pal[1]; abbr = pal[2];
      break;
    }
  }
  if (!abbr) {
    const words = key.split(/\s+/).filter(w => w.length > 1 && !["DE","DU","LA","LE","BC","AS"].includes(w));
    abbr = words.slice(0, 3).map(w => w[0]).join("") || key.slice(0, 3);
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${c1}"/>
        <stop offset="100%" stop-color="#0F172A"/>
      </linearGradient>
    </defs>
    <path d="M40 4 L72 16 L72 42 C72 60 40 76 40 76 C40 76 8 60 8 42 L8 16 Z" fill="url(#g)" stroke="${c2}" stroke-width="4"/>
    <circle cx="40" cy="38" r="18" fill="none" stroke="${c2}" stroke-width="1.5" stroke-dasharray="3,3" opacity="0.5"/>
    <text x="40" y="44" text-anchor="middle" fill="#FFFFFF" font-family="Arial, sans-serif" font-weight="900" font-size="18">${abbr}</text>
  </svg>`;
  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

function getTeamBadgeSrc(teamName) {
  if (isLSBSC(teamName)) {
    return state.clubAssets.logo || FALLBACK_LOGO_B64;
  }
  const key = normalizeClubKey(teamName);
  if (state.clubAssets.customBadges && state.clubAssets.customBadges[key]) {
    return state.clubAssets.customBadges[key];
  }
  return generateClubSvgDataUri(teamName);
}

/* ================= SAUVEGARDE & SYNCHRONISATION TEMPS RÉEL ================= */
function loadLocalData() {
  try {
    const saved = localStorage.getItem("lsbsc_state_v4");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed.matches) && parsed.matches.length > 0) state.matches = parsed.matches;
      if (parsed.tickerText) state.tickerText = parsed.tickerText;
      if (parsed.updatedAt) state.lastUpdatedAt = parsed.updatedAt;
      if (parsed.clubAssets) {
        state.clubAssets = Object.assign(state.clubAssets, parsed.clubAssets);
      }
    }
  } catch (e) {}
  if (!state.matches || state.matches.length === 0) {
    state.matches = JSON.parse(JSON.stringify(DEFAULT_MATCHES));
  }
  if (state.autoWeek || !state.currentWeek) state.currentWeek = detectCurrentWeek();
}

/* ================= SEMAINE EN COURS (AUTOMATIQUE) ================= */
const MONTHS_FR = { JAN:0, "FÉV":1, FEV:1, MAR:2, AVR:3, MAI:4, JUN:5, JUIN:5, JUIL:6, "AOÛ":7, AOU:7, SEP:8, OCT:9, NOV:10, "DÉC":11, DEC:11 };

function matchDateOf(m) {
  const d = /(\d{1,2})\s+([A-ZÉÛ]+)/i.exec(m.date || "");
  if (!d) return null;
  const mo = MONTHS_FR[d[2].toUpperCase().replace(/\.$/, "")];
  if (mo === undefined) return null;
  const y = /(\d{4})/.exec(m.wkLabel || "");
  return new Date(y ? +y[1] : new Date().getFullYear(), mo, +d[1]);
}

// Semaine dont le dernier match n'est pas encore passé (aujourd'hui compris).
function detectCurrentWeek() {
  const ends = {};
  state.matches.forEach(m => {
    const d = matchDateOf(m);
    if (d && (!ends[m.wk] || d > ends[m.wk])) ends[m.wk] = d;
  });
  const keys = Object.keys(ends).sort();
  if (keys.length === 0) return state.currentWeek || (state.matches[0] && state.matches[0].wk) || null;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return keys.find(k => ends[k] >= today) || keys[keys.length - 1];
}

function pickDefaultMatch(wkMatches) {
  return wkMatches.find(m => m.status === "live")
      || wkMatches.find(m => m.status === "upcoming")
      || wkMatches[0];
}

/* ================= PLANNING : data/matches.json ================= */
const SCHEDULE_FIELDS = ["wk", "wkLabel", "wkShort", "date", "time", "home", "away", "cat", "comp"];
const DYNAMIC_FIELDS = ["sh", "sa", "status", "period", "fh", "fa", "liveTracking"];

// Réapplique le calendrier officiel (dates, équipes...) sur une liste de matchs (locale ou cloud).
function overlaySchedule(list) {
  if (!Array.isArray(state.baseMatches) || state.baseMatches.length === 0) return list;
  const byId = new Map(list.map(m => [m.id, m]));
  const out = state.baseMatches.map(b => {
    const s = byId.get(b.id);
    if (!s) return Object.assign({}, b);
    SCHEDULE_FIELDS.forEach(k => { s[k] = b[k]; });
    return s;
  });
  list.forEach(m => { if (!state.baseMatches.some(b => b.id === m.id)) out.push(m); });
  return out;
}

function persistLocalOnly() {
  try {
    localStorage.setItem("lsbsc_state_v4", JSON.stringify({
      matches: state.matches, tickerText: state.tickerText,
      clubAssets: state.clubAssets, updatedAt: state.lastUpdatedAt
    }));
  } catch (e) {}
}

async function loadBaseMatches() {
  let base = null;
  try {
    const res = await fetch("data/matches.json", { cache: "no-cache" });
    if (res.ok) base = await res.json();
  } catch (e) {}
  if (!Array.isArray(base) || base.length === 0) base = DEFAULT_MATCHES;
  state.baseMatches = base;

  let prev = [];
  try { prev = JSON.parse(localStorage.getItem("lsbsc_base_prev") || "[]"); } catch (e) {}
  const nextStr = JSON.stringify(base);
  const prevStr = JSON.stringify(prev);
  const prevById = new Map(prev.map(m => [m.id, m]));

  // Les champs dynamiques (score, statut) du fichier ne remplacent ceux du direct
  // que si le fichier a changé pour ce match depuis la dernière version chargée.
  const merged = overlaySchedule(state.matches);
  merged.forEach(m => {
    const b = base.find(x => x.id === m.id);
    const p = prevById.get(m.id);
    if (!b || !p) return;
    if (DYNAMIC_FIELDS.some(k => b[k] !== p[k])) DYNAMIC_FIELDS.forEach(k => { m[k] = b[k]; });
  });
  state.matches = merged;
  if (nextStr !== prevStr) {
    try { localStorage.setItem("lsbsc_base_prev", nextStr); } catch (e) {}
  }
  persistLocalOnly();
  if (state.autoWeek) state.currentWeek = detectCurrentWeek();
  renderAll();
}

function refreshAutoWeek() {
  if (!state.autoWeek) return;
  const wk = detectCurrentWeek();
  if (wk && wk !== state.currentWeek) window.selectWeek(wk, { auto: true });
}

function saveState(pushCloud = true) {
  const now = Date.now();
  state.lastUpdatedAt = now;
  const payload = {
    matches: state.matches,
    tickerText: state.tickerText,
    clubAssets: state.clubAssets,
    updatedAt: now
  };
  try {
    localStorage.setItem("lsbsc_state_v4", JSON.stringify(payload));
  } catch (e) {}
  if (bcChannel) {
    try { bcChannel.postMessage(payload); } catch (e) {}
  }
  const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
  if (pushCloud && targetUrl) {
    fetch(targetUrl, {
      method: "PUT",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    }).then(() => {
      const syncEl = document.getElementById("syncStatusBadge");
      if (syncEl) syncEl.textContent = "● Direct Synchronisé";
    }).catch(() => {});
  }
}

let cloudPolling = false;

// Sur Firebase, on ne lit d'abord que le champ updatedAt (quelques octets).
function cloudLightUrl(url) {
  if (!/firebaseio\.com|firebasedatabase\.app/.test(url)) return null;
  if (!/\.json(\?.*)?$/.test(url)) return null;
  return url.replace(/\.json(\?.*)?$/, (m, q) => "/updatedAt.json" + (q || ""));
}

async function pollCloudSync() {
  if (cloudPolling || document.hidden) return;
  const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
  if (!targetUrl) return;
  cloudPolling = true;
  try {
    const light = cloudLightUrl(targetUrl);
    if (light) {
      const r = await fetch(light);
      if (!r.ok) return;
      const ts = await r.json();
      if (typeof ts !== "number" || ts <= state.lastUpdatedAt) return;
    }
    const res = await fetch(targetUrl, { headers: { "Accept": "application/json" } });
    if (!res.ok) return;
    const data = await res.json();
    if (data && Array.isArray(data.matches) && data.updatedAt && data.updatedAt > state.lastUpdatedAt) {
      state.lastUpdatedAt = data.updatedAt;
      state.matches = overlaySchedule(data.matches);
      if (data.tickerText) state.tickerText = data.tickerText;
      if (data.clubAssets) state.clubAssets = Object.assign(state.clubAssets, data.clubAssets);
      persistLocalOnly();
      renderAll();
    }
  } catch (e) {
  } finally {
    cloudPolling = false;
  }
}

/* ================= RENDU DE L'INTERFACE ================= */
function getWeeksList() {
  const map = new Map();
  state.matches.forEach(m => {
    if (!map.has(m.wk)) {
      map.set(m.wk, { wk: m.wk, label: m.wkLabel, short: m.wkShort });
    }
  });
  return Array.from(map.values());
}

function computeMatchOutcome(m) {
  if (m.status === "postponed") return "postponed";
  if (m.status === "forfeit") {
    if ((m.sh || 0) === 0 && (m.sa || 0) === 0) return "forfeit";
    const homeIsUs = isLSBSC(m.home);
    const usScore = homeIsUs ? m.sh : m.sa;
    const themScore = homeIsUs ? m.sa : m.sh;
    if (usScore > themScore) return "win";
    if (usScore < themScore) return "loss";
    return "forfeit";
  }
  if (m.status !== "finished") return m.status;
  const homeIsUs = isLSBSC(m.home);
  const usScore = homeIsUs ? m.sh : m.sa;
  const themScore = homeIsUs ? m.sa : m.sh;
  if (usScore > themScore) return "win";
  if (usScore < themScore) return "loss";
  return "draw";
}

function renderFoulDots(foulsCount) {
  const count = Math.min(5, Math.max(0, foulsCount || 0));
  let dots = "";
  for (let i = 1; i <= 5; i++) {
    const active = i <= count;
    const cls = active ? (count >= 5 ? "foul-dot bonus" : "foul-dot active") : "foul-dot";
    dots += `<span class="${cls}"></span>`;
  }
  return `<div class="foul-box">
    <span class="foul-label">Fautes : ${foulsCount || 0} ${count >= 5 ? "(BONUS)" : ""}</span>
    <div class="foul-dots">${dots}</div>
  </div>`;
}

function renderHeaderAndTicker() {
  const logoEl = document.getElementById("headerLogoImg");
  const mascEl = document.getElementById("headerMascotImg");
  const wmEl = document.getElementById("sbMascotWatermark");

  if (logoEl) {
    logoEl.src = state.clubAssets.logo || FALLBACK_LOGO_B64;
    logoEl.onerror = () => { logoEl.src = FALLBACK_LOGO_B64; };
  }
  if (mascEl) {
    mascEl.src = state.clubAssets.mascot || FALLBACK_MASCOT_B64;
    mascEl.onerror = () => { mascEl.src = FALLBACK_MASCOT_B64; };
  }
  if (wmEl) {
    wmEl.src = state.clubAssets.mascot || FALLBACK_MASCOT_B64;
    wmEl.onerror = () => { wmEl.src = FALLBACK_MASCOT_B64; };
  }

  const wkMatches = state.matches.filter(m => m.wk === state.currentWeek);
  let wins = 0, losses = 0, draws = 0;
  wkMatches.forEach(m => {
    const out = computeMatchOutcome(m);
    if (out === "win") wins++;
    else if (out === "loss") losses++;
    else if (out === "draw") draws++;
  });

  document.getElementById("kpiTotal").textContent = `${wkMatches.length} Matchs`;
  document.getElementById("kpiWin").textContent = `${wins} V`;
  document.getElementById("kpiLoss").textContent = `${losses} D`;
  document.getElementById("kpiDraw").textContent = `${draws} N`;

  const staffBtn = document.getElementById("btnStaffToggle");
  if (state.staffUnlocked) {
    staffBtn.classList.add("unlocked");
    staffBtn.innerHTML = "🔓 Staff Actif";
  } else {
    staffBtn.classList.remove("unlocked");
    staffBtn.innerHTML = "🔒 Direct / Scores";
  }

  document.getElementById("tickerTextDisplay").textContent = state.tickerText;
  const mobInfoEl = document.getElementById("mobileTickerStaticText");
  if (mobInfoEl) mobInfoEl.textContent = state.tickerText;
}

function renderWeekNavigation() {
  const weeks = getWeeksList();
  const select = document.getElementById("weekSelect");
  select.innerHTML = weeks.map(w =>
    `<option value="${w.wk}" ${w.wk === state.currentWeek ? "selected" : ""}>${w.label}</option>`
  ).join("");

  const strip = document.getElementById("weekTabsStrip");
  strip.innerHTML = weeks.map(w =>
    `<button class="wk-tab ${w.wk === state.currentWeek ? "active" : ""}" onclick="selectWeek('${w.wk}')">${w.short}</button>`
  ).join("");
}

function renderMatchesList() {
  const container = document.getElementById("matchesListContainer");
  const filtered = state.matches.filter(m => {
    if (m.wk !== state.currentWeek) return false;
    if (state.catFilter !== "ALL" && m.cat !== state.catFilter) return false;
    if (state.locFilter === "HOME" && !isLSBSC(m.home)) return false;
    if (state.locFilter === "AWAY" && !isLSBSC(m.away)) return false;
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `<div style="padding:24px;text-align:center;color:#64748B;font-weight:800;">Aucun match pour ce filtre sur ce week-end.</div>`;
    return;
  }

  container.innerHTML = filtered.map(m => {
    const outcome = computeMatchOutcome(m);
    const homeUs = isLSBSC(m.home);
    const awayUs = isLSBSC(m.away);
    let scoreHtml = "";
    let tagHtml = "";

    if (m.status === "postponed") {
      scoreHtml = `<div class="score-pill postponed">📅 REPORTÉ</div>`;
      tagHtml = `<span class="res-tag postponed">${m.statusNote ? m.statusNote : "Date à fixer"}</span>`;
    } else if (m.status === "forfeit") {
      const hasScore = (m.sh || 0) > 0 || (m.sa || 0) > 0;
      const pillCls = outcome === "win" ? "forfeit-win" : (outcome === "loss" ? "forfeit-loss" : "forfeit");
      scoreHtml = `<div class="score-pill ${pillCls}">${hasScore ? (m.sh + " - " + m.sa) : "FORFAIT"}</div>`;
      tagHtml = `<span class="res-tag forfeit">${m.statusNote ? m.statusNote : "Forfait officiel"}</span>`;
    } else if (m.status === "finished") {
      const lbl = outcome === "win" ? "Victoire LSBSC" : (outcome === "loss" ? "Défaite" : "Égalité");
      scoreHtml = `<div class="score-pill ${outcome}">${m.sh} - ${m.sa}</div>`;
      tagHtml = `<span class="res-tag ${outcome}">${lbl}</span>`;
    } else if (m.status === "live") {
      const showLiveDigits = (m.liveTracking !== false) || m.sh > 0 || m.sa > 0;
      const liveTxt = showLiveDigits ? `${m.sh} - ${m.sa}` : "EN JEU";
      scoreHtml = `<div class="score-pill live">${liveTxt}</div>`;
      tagHtml = `<span class="res-tag live">🔴 ${m.period || "QT1"}</span>`;
    } else {
      scoreHtml = `<div class="score-pill upcoming">${m.time}</div>`;
      tagHtml = `<span class="res-tag">À venir</span>`;
    }

    const staffRowBtn = state.staffUnlocked
      ? `<div class="row-staff-actions">
           <button class="btn-row-edit" style="background:#EA580C;" onclick="event.stopPropagation();startLiveMatch(${m.id})">🏀 Direct</button>
           <button class="btn-row-edit" onclick="event.stopPropagation();selectMatchForEdit(${m.id})">✏️ Score</button>
         </div>`
      : `<div></div>`;

    const rowExtraCls = m.status === "live"
      ? "live-match"
      : (m.status === "postponed" ? "postponed-match" : (m.status === "forfeit" ? "forfeit-match" : ""));

    return `
      <div class="match-row ${m.id === state.selectedMatchId ? "selected-match" : ""} ${rowExtraCls}" onclick="selectMatch(${m.id})">
        <div class="m-meta">
          <span class="m-date">${m.date}</span>
          <span class="m-time">${m.time}</span>
          <span class="m-cat-badge">${m.cat}</span>
        </div>
        <div class="m-team home">
          <span class="team-name-txt ${homeUs ? "is-lsbsc" : ""}">${m.home}</span>
          <img class="club-badge-sm" src="${getTeamBadgeSrc(m.home)}" onerror="this.src=FALLBACK_LOGO_B64" alt="">
        </div>
        <div class="m-score-center">
          ${scoreHtml}
          ${tagHtml}
          ${(Array.isArray(m.youtubeVideos) && m.youtubeVideos.length > 0) ? `<button class="row-youtube-badge" onclick="event.stopPropagation();openMatchVideoModal(${m.id}, 0)">📺 ${m.youtubeVideos.length} vidéo${m.youtubeVideos.length > 1 ? "s" : ""}</button>` : ""}
        </div>
        <div class="m-team away">
          <img class="club-badge-sm" src="${getTeamBadgeSrc(m.away)}" onerror="this.src=FALLBACK_LOGO_B64" alt="">
          <span class="team-name-txt ${awayUs ? "is-lsbsc" : ""}">${m.away}</span>
        </div>
        ${staffRowBtn}
      </div>
    `;
  }).join("");
}

function renderRightColumn() {
  const wkMatches = state.matches.filter(m => m.wk === state.currentWeek);
  let current = state.matches.find(m => m.id === state.selectedMatchId);
  if (!current || current.wk !== state.currentWeek) {
    current = pickDefaultMatch(wkMatches) || state.matches[0];
    if (current) state.selectedMatchId = current.id;
  }

  if (!current) return;

  const sbStatus = document.getElementById("sbStatusBadge");
  if (current.status === "live") {
    sbStatus.className = "sb-status-badge live";
    sbStatus.textContent = `🔴 EN DIRECT — ${current.period || "QT1"}`;
  } else if (current.status === "postponed") {
    sbStatus.className = "sb-status-badge postponed";
    sbStatus.textContent = "📅 MATCH REPORTÉ";
  } else if (current.status === "forfeit") {
    sbStatus.className = "sb-status-badge forfeit";
    sbStatus.textContent = "🚫 MATCH FORFAIT";
  } else if (current.status === "finished") {
    sbStatus.className = "sb-status-badge finished";
    sbStatus.textContent = "✅ MATCH TERMINÉ — SCORE FINAL";
  } else {
    sbStatus.className = "sb-status-badge upcoming";
    sbStatus.textContent = "🕒 RENCONTRE À VENIR";
  }

  document.getElementById("sbMetaInfo").textContent = `${current.date} à ${current.time} • ${current.cat} (${current.comp})`;

  const homeLogo = document.getElementById("sbHomeLogo");
  const awayLogo = document.getElementById("sbAwayLogo");
  homeLogo.src = getTeamBadgeSrc(current.home);
  awayLogo.src = getTeamBadgeSrc(current.away);

  const homeTitle = document.getElementById("sbHomeName");
  const awayTitle = document.getElementById("sbAwayName");
  const homeIsLsbsc = isLSBSC(current.home);
  const awayIsLsbsc = isLSBSC(current.away);
  homeTitle.textContent = current.home;
  awayTitle.textContent = current.away;
  homeTitle.className = "sb-team-title " + (homeIsLsbsc ? "is-lsbsc" : "");
  awayTitle.className = "sb-team-title " + (awayIsLsbsc ? "is-lsbsc" : "");

  const homeLocPill = document.getElementById("sbHomeLocPill");
  const awayLocPill = document.getElementById("sbAwayLocPill");
  if (homeLocPill) {
    homeLocPill.textContent = homeIsLsbsc ? "🦁 LSBSC • DOMICILE" : "🏠 LOCAUX (DOMICILE)";
    homeLocPill.className = "sb-loc-pill" + (homeIsLsbsc ? " lsbsc-pill" : "");
  }
  if (awayLocPill) {
    awayLocPill.textContent = awayIsLsbsc ? "🦁 LSBSC • EXTÉRIEUR" : "🚌 VISITEURS";
    awayLocPill.className = "sb-loc-pill" + (awayIsLsbsc ? " lsbsc-pill" : "");
  }

  const summaryBar = document.getElementById("sbMatchSummaryBar");
  if (summaryBar) {
    const venueTxt = homeIsLsbsc ? "📍 Salle Municipale de Lille Sud" : "📍 Déplacement à l'extérieur";
    const diff = Math.abs((current.sh || 0) - (current.sa || 0));
    let outcomePill = "";
    if (current.status === "postponed") {
      outcomePill = `<span class="sb-summary-pill postponed">📅 Reporté : ${current.statusNote || "Date ultérieure"}</span>`;
    } else if (current.status === "forfeit") {
      outcomePill = `<span class="sb-summary-pill forfeit">🚫 ${current.statusNote || "Forfait enregistré"}</span>`;
    } else if (current.status === "finished") {
      const out = computeMatchOutcome(current);
      if (out === "win") outcomePill = `<span class="sb-summary-pill win">🏆 Victoire LSBSC (+${diff} pts)</span>`;
      else if (out === "loss") outcomePill = `<span class="sb-summary-pill loss">Défaite LSBSC (-${diff} pts)</span>`;
      else outcomePill = `<span class="sb-summary-pill">Match Nul</span>`;
    } else if (current.status === "live") {
      outcomePill = `<span class="sb-summary-pill live">🔥 Écart actuel : ${diff} pt${diff > 1 ? "s" : ""}</span>`;
    } else {
      outcomePill = `<span class="sb-summary-pill">⏳ Coup d'envoi ${current.time}</span>`;
    }
    const vidsCount = Array.isArray(current.youtubeVideos) ? current.youtubeVideos.length : 0;
    const ytBtnHtml = vidsCount > 0
      ? `<button class="youtube-pill-btn" onclick="openMatchVideoModal(${current.id}, 0)">📺 Regarder (${vidsCount} vidéo${vidsCount > 1 ? "s" : ""})</button>`
      : "";
    summaryBar.innerHTML = `
      <span class="sb-summary-pill">${venueTxt}</span>
      <span class="sb-summary-pill">🏀 Catégorie ${current.cat}</span>
      ${outcomePill}
      ${ytBtnHtml}
    `;
  }

  const homeFoulsEl = document.getElementById("sbHomeFouls");
  const awayFoulsEl = document.getElementById("sbAwayFouls");
  if (homeFoulsEl && awayFoulsEl) {
    if (current.status === "live" && current.liveTracking !== false) {
      homeFoulsEl.innerHTML = renderFoulDots(current.fh || 0);
      awayFoulsEl.innerHTML = renderFoulDots(current.fa || 0);
    } else {
      homeFoulsEl.innerHTML = "";
      awayFoulsEl.innerHTML = "";
    }
  }

  const centerWrap = document.getElementById("sbCenterWrap");
  if (current.status === "postponed") {
    centerWrap.innerHTML = `
      <div class="special-status-banner postponed">
        <span class="special-status-title">📅 RENCONTRE REPORTÉE</span>
        <span class="special-status-reason">Motif : ${current.statusNote || "Conditions météo / Décision officielle"}</span>
      </div>
      <div class="sb-period-pill" style="background:#F3E8FF;color:#6B21A8;border-color:#9333EA;">Nouvelle date à communiquer</div>
    `;
  } else if (current.status === "forfeit") {
    const hasScore = (current.sh || 0) > 0 || (current.sa || 0) > 0;
    centerWrap.innerHTML = `
      ${hasScore ? `<div class="big-digits-wrap" style="padding:8px 18px;margin-bottom:4px;">
        <span class="big-digit" style="font-size:2.2rem;">${current.sh}</span>
        <span class="big-sep" style="font-size:1.6rem;">-</span>
        <span class="big-digit" style="font-size:2.2rem;">${current.sa}</span>
      </div>` : ""}
      <div class="special-status-banner forfeit">
        <span class="special-status-title">🚫 RENCONTRE FORFAIT</span>
        <span class="special-status-reason">${current.statusNote || "Forfait officiel enregistré"}</span>
      </div>
    `;
  } else if (current.status === "live" && current.liveTracking === false && current.sh === 0 && current.sa === 0) {
    centerWrap.innerHTML = `
      <div class="no-live-banner">
        🏀 RENCONTRE EN COURS (SANS TABLE DIRECT)<br>
        <span style="font-size:0.76rem;font-weight:700;">Le score final sera affiché dès la fin du match</span>
      </div>
      <div class="sb-period-pill">${current.period || "En jeu"}</div>
    `;
  } else if (current.status === "upcoming" && current.sh === 0 && current.sa === 0) {
    centerWrap.innerHTML = `
      <div class="big-digits-wrap">
        <span class="big-digit" style="font-size:1.85rem;">${current.time}</span>
      </div>
      <div class="sb-period-pill">Coup d'envoi prévu à ${current.time}</div>
    `;
  } else {
    centerWrap.innerHTML = `
      <div class="big-digits-wrap">
        <span class="big-digit">${current.sh}</span>
        <span class="big-sep">-</span>
        <span class="big-digit">${current.sa}</span>
      </div>
      <div class="sb-period-pill">${current.status === "finished" ? "Score Final Officiel" : ("En Direct • " + (current.period || "QT1"))}</div>
    `;
  }

  const staffPanel = document.getElementById("staffScorePanel");
  if (state.staffUnlocked) {
    staffPanel.style.display = "flex";
    const periods = ["QT1", "QT2", "Mi-Temps", "QT3", "QT4", "Prol."];
    const periodButtonsHtml = periods.map(p =>
      `<button class="btn-period ${current.period === p ? "active" : ""}" onclick="setLivePeriod(${current.id}, '${p}')">${p}</button>`
    ).join("");

    if (state.staffMode === "live") {
      staffPanel.innerHTML = `
        <div class="staff-tabs">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <button class="staff-tab-btn active" onclick="switchStaffMode('live')">🏀 Table Direct</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('final')">✏️ Score Final</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('special')">⚠️ Report / Forfait</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('multivid')">📺 Médias</button>
          </div>
          <div style="display:flex;gap:5px;">
            <button class="btn-action-sm btn-save-score" onclick="finishCurrentAndLaunchNext(${current.id})">🏁 Terminer & Suivant</button>
          </div>
        </div>
        <div class="live-table-grid">
          <div class="live-team-ctrls">
            <div style="width:100%;text-align:center;font-size:0.7rem;font-weight:900;color:#1E3A8A;margin-bottom:2px;">🏠 LOCAUX : ${current.home}</div>
            <button class="btn-pt" onclick="updateLivePoints(${current.id}, 'home', 1)">+1</button>
            <button class="btn-pt" onclick="updateLivePoints(${current.id}, 'home', 2)">+2</button>
            <button class="btn-pt pt-plus3" onclick="updateLivePoints(${current.id}, 'home', 3)">+3</button>
            <button class="btn-pt pt-minus" onclick="updateLivePoints(${current.id}, 'home', -1)">-1</button>
            <button class="btn-pt pt-foul" onclick="updateLiveFouls(${current.id}, 'home', 1)">+Faute (${current.fh || 0})</button>
            <button class="btn-pt pt-minus" onclick="updateLiveFouls(${current.id}, 'home', -1)">-F</button>
          </div>
          <div class="period-selector">
            ${periodButtonsHtml}
          </div>
          <div class="live-team-ctrls">
            <div style="width:100%;text-align:center;font-size:0.7rem;font-weight:900;color:#9A3412;margin-bottom:2px;">🚌 VISITEURS : ${current.away}</div>
            <button class="btn-pt" onclick="updateLivePoints(${current.id}, 'away', 1)">+1</button>
            <button class="btn-pt" onclick="updateLivePoints(${current.id}, 'away', 2)">+2</button>
            <button class="btn-pt pt-plus3" onclick="updateLivePoints(${current.id}, 'away', 3)">+3</button>
            <button class="btn-pt pt-minus" onclick="updateLivePoints(${current.id}, 'away', -1)">-1</button>
            <button class="btn-pt pt-foul" onclick="updateLiveFouls(${current.id}, 'away', 1)">+Faute (${current.fa || 0})</button>
            <button class="btn-pt pt-minus" onclick="updateLiveFouls(${current.id}, 'away', -1)">-F</button>
          </div>
        </div>
      `;
    } else if (state.staffMode === "special") {
      const safeNote = (current.statusNote || "").replace(/"/g, "&quot;");
      staffPanel.innerHTML = `
        <div class="staff-tabs">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <button class="staff-tab-btn" onclick="switchStaffMode('live')">🏀 Table Direct</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('final')">✏️ Score Final</button>
            <button class="staff-tab-btn active" onclick="switchStaffMode('special')">⚠️ Report / Forfait</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('multivid')">📺 Médias</button>
          </div>
          <button class="btn-action-sm btn-reset-up" onclick="saveMatchScore(${current.id}, 'upcoming')">🕒 Remettre À venir</button>
        </div>
        <div class="staff-special-box">
          <div class="preset-chips">
            <button class="chip-reason" onclick="fillSpecialReason('Conditions météo')">🌧️ Conditions météo</button>
            <button class="chip-reason" onclick="fillSpecialReason('Salle indisponible')">🏟️ Salle indisponible</button>
            <button class="chip-reason" onclick="fillSpecialReason('Décision Comité / FFBB')">📋 Décision Comité</button>
            <button class="chip-reason" onclick="fillSpecialReason('Forfait équipe adverse (20-0)')">🏆 Forfait adverse (20-0)</button>
            <button class="chip-reason" onclick="fillSpecialReason('Forfait LSBSC (0-20)')">🚫 Forfait LSBSC (0-20)</button>
          </div>
          <div class="staff-special-row">
            <input type="text" id="inpSpecialReason" class="inp-special-reason" placeholder="Motif (ex : Conditions météo, Forfait...)" value="${safeNote}">
            <button class="btn-action-sm btn-postpone" onclick="applySpecialMatchStatus(${current.id}, 'postponed')">📅 Marquer Reporté</button>
            <button class="btn-action-sm btn-forfeit" onclick="applySpecialMatchStatus(${current.id}, 'forfeit')">🚫 Marquer Forfait</button>
          </div>
        </div>
      `;
    } else if (state.staffMode === "multivid") {
      const allVids = [
        ...(Array.isArray(current.youtubeVideos) ? current.youtubeVideos.map((v, i) => ({...v, mediaType: 'youtube', origIdx: i})) : []),
        ...(Array.isArray(current.twitchVideos) ? current.twitchVideos.map((v, i) => ({...v, mediaType: 'twitch', origIdx: i})) : [])
      ];

      const chipsHtml = allVids.length > 0
        ? allVids.map((v, i) => `
            <span class="${v.mediaType === 'twitch' ? 'staff-tw-chip' : 'staff-yt-chip'}">
              <span style="cursor:pointer;" onclick="openMatchVideoModal(${current.id}, ${i})">${v.mediaType === 'twitch' ? '🎮 ' : '▶️ '}${v.title}</span>
              <button class="${v.mediaType === 'twitch' ? 'staff-tw-del' : 'staff-yt-del'}" onclick="removeVideoFromMatch(${current.id}, '${v.mediaType}', ${v.origIdx})" title="Supprimer">✖</button>
            </span>
          `).join("")
        : `<span style="font-size:0.74rem;color:#64748B;font-weight:700;">Aucun flux YouTube ou Twitch associé à ce match.</span>`;

      staffPanel.innerHTML = `
        <div class="staff-tabs">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <button class="staff-tab-btn" onclick="switchStaffMode('live')">🏀 Direct</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('final')">✏️ Score</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('special')">⚠️ Report</button>
            <button class="staff-tab-btn active" onclick="switchStaffMode('multivid')">📺 Médias (${allVids.length})</button>
          </div>
          ${allVids.length > 0 ? `<button class="youtube-pill-btn" onclick="openMatchVideoModal(${current.id}, 0)">▶️ Lancer</button>` : ""}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div class="staff-youtube-box">
            <div style="font-size:0.72rem;font-weight:900;color:#991B1B;margin-bottom:2px;">📺 YouTube :</div>
            <div class="staff-youtube-inputs">
              <input type="text" id="inpYoutubeUrl" class="inp-youtube" placeholder="Lien YouTube">
              <input type="text" id="inpYoutubeTitle" class="inp-youtube" style="max-width:90px;" placeholder="Titre">
              <button class="btn-action-sm btn-youtube-full" onclick="addYoutubeVideoToMatch(${current.id})">➕</button>
            </div>
          </div>
          <div class="staff-twitch-box">
            <div style="font-size:0.72rem;font-weight:900;color:#6D28D9;margin-bottom:2px;">🎮 Twitch :</div>
            <div class="staff-twitch-inputs">
              <input type="text" id="inpTwitchChannel" class="inp-twitch" placeholder="Chaîne Twitch">
              <input type="text" id="inpTwitchTitle" class="inp-twitch" style="max-width:90px;" placeholder="Titre">
              <button class="btn-action-sm btn-twitch-full" onclick="addTwitchVideoToMatch(${current.id})">➕</button>
            </div>
          </div>
        </div>
        <div class="staff-youtube-list" style="margin-top:6px;">${chipsHtml}</div>
      `;
    } else {
      staffPanel.innerHTML = `
        <div class="staff-tabs">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <button class="staff-tab-btn" onclick="switchStaffMode('live')">🏀 Table Direct</button>
            <button class="staff-tab-btn active" onclick="switchStaffMode('final')">✏️ Score Final</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('special')">⚠️ Report / Forfait</button>
            <button class="staff-tab-btn" onclick="switchStaffMode('multivid')">📺 Médias</button>
          </div>
          <button class="btn-action-sm" style="background:#9A3412;color:#FFF;" onclick="setMatchNoLiveTable(${current.id})">En jeu (sans score direct)</button>
        </div>
        <div class="staff-quick-row">
          <span style="font-size:0.78rem;font-weight:900;color:#1E3A8A;">Score (${current.cat}) :</span>
          <div style="display:flex;align-items:center;gap:6px;">
            <input type="number" id="inpScoreHome" class="score-input-num" min="0" value="${current.sh}">
            <span style="font-weight:900;">-</span>
            <input type="number" id="inpScoreAway" class="score-input-num" min="0" value="${current.sa}">
          </div>
          <button class="btn-action-sm btn-save-score" onclick="saveMatchScore(${current.id}, 'finished')">✅ Valider Final</button>
          <button class="btn-action-sm btn-set-live" onclick="saveMatchScore(${current.id}, 'live')">🔴 En Direct</button>
          <button class="btn-action-sm btn-reset-up" onclick="saveMatchScore(${current.id}, 'upcoming')">🕒 À venir</button>
        </div>
      `;
    }
  } else {
    staffPanel.style.display = "none";
  }

  const isPlayableNext = (x) => x.status === "live" || x.status === "upcoming";
  const idxInWk = wkMatches.findIndex(m => m.id === current.id);
  let nextMatch = wkMatches.slice(idxInWk + 1).find(isPlayableNext)
               || wkMatches[idxInWk + 1]
               || state.matches.find(m => m.id > current.id && isPlayableNext(m));

  const nextBox = document.getElementById("nextMatchContainer");
  if (nextMatch) {
    nextBox.innerHTML = `
      <div class="next-header">
        <span class="next-title-badge">⏭️ MATCH SUIVANT • ${nextMatch.cat}</span>
        <span class="next-datetime">${nextMatch.date} à ${nextMatch.time}</span>
      </div>
      <div class="next-teams-grid">
        <div class="next-team home">
          <span>${nextMatch.home}</span>
          <img class="club-badge-sm" src="${getTeamBadgeSrc(nextMatch.home)}" alt="">
        </div>
        <span class="vs-circle">VS</span>
        <div class="next-team away">
          <img class="club-badge-sm" src="${getTeamBadgeSrc(nextMatch.away)}" alt="">
          <span>${nextMatch.away}</span>
        </div>
      </div>
    `;
  } else {
    nextBox.innerHTML = `
      <div class="next-header">
        <span class="next-title-badge">⏭️ PROCHAINE RENCONTRE</span>
      </div>
      <div style="font-size:0.85rem;font-weight:800;color:#64748B;text-align:center;padding:6px;">
        Tous les matchs de cette sélection ont été joués. Utilisez les onglets de semaine pour voir la suite.
      </div>
    `;
  }

  const ovCard = document.getElementById("clubOverviewCard");
  if (ovCard) {
    const homeCount = wkMatches.filter(m => isLSBSC(m.home)).length;
    const awayCount = wkMatches.filter(m => !isLSBSC(m.home)).length;
    const playedCount = wkMatches.filter(m => m.status === "finished").length;
    const mascSrc = state.clubAssets.mascot || FALLBACK_MASCOT_B64;
    ovCard.innerHTML = `
      <div class="overview-left">
        <img class="overview-mascot" src="${mascSrc}" onerror="this.src=FALLBACK_MASCOT_B64" alt="Mascotte LSBSC">
        <div class="overview-texts">
          <h4>🦁 Lille Sud Basketball Sporting Club</h4>
          <p>${current.wkLabel} • ${playedCount}/${wkMatches.length} matchs joués</p>
        </div>
      </div>
      <div class="overview-stats">
        <div class="ov-stat-box">
          <span class="ov-stat-val">${homeCount}</span>
          <span class="ov-stat-lbl">Domicile</span>
        </div>
        <div class="ov-stat-box">
          <span class="ov-stat-val">${awayCount}</span>
          <span class="ov-stat-lbl">Extérieur</span>
        </div>
        <div class="ov-stat-box">
          <span class="ov-stat-val">${wkMatches.length - playedCount}</span>
          <span class="ov-stat-lbl">À jouer</span>
        </div>
      </div>
    `;
  }

  const mqCard = document.getElementById("mobileQuickMatchesCard");
  if (mqCard) {
    const itemsHtml = wkMatches.map(m => {
      const out = computeMatchOutcome(m);
      let pillHtml = `<span class="score-pill upcoming" style="min-width:68px;padding:4px 6px;font-size:0.78rem;">${m.time}</span>`;
      if (m.status === "postponed") {
        pillHtml = `<span class="score-pill postponed" style="min-width:68px;padding:4px 6px;font-size:0.72rem;">REPORTÉ</span>`;
      } else if (m.status === "forfeit") {
        pillHtml = `<span class="score-pill forfeit" style="min-width:68px;padding:4px 6px;font-size:0.72rem;">${(m.sh||m.sa) ? (m.sh+" - "+m.sa) : "FORFAIT"}</span>`;
      } else if (m.status === "finished") {
        pillHtml = `<span class="score-pill ${out}" style="min-width:68px;padding:4px 6px;font-size:0.84rem;">${m.sh} - ${m.sa}</span>`;
      } else if (m.status === "live") {
        pillHtml = `<span class="score-pill live" style="min-width:68px;padding:4px 6px;font-size:0.84rem;">${m.sh} - ${m.sa}</span>`;
      }
      return `
        <div class="mq-item ${m.id === state.selectedMatchId ? "active-mq" : ""}" onclick="selectMatch(${m.id})">
          <div class="mq-team ${isLSBSC(m.home) ? "is-us" : ""}">
            <img src="${getTeamBadgeSrc(m.home)}" onerror="this.src=FALLBACK_LOGO_B64" alt="">
            <span>${m.home}</span>
          </div>
          <div class="mq-mid">
            <span class="mq-cat">${m.cat} • ${m.date.replace(/\.$/,"")}</span>
            ${pillHtml}
          </div>
          <div class="mq-team ${isLSBSC(m.away) ? "is-us" : ""}">
            <img src="${getTeamBadgeSrc(m.away)}" onerror="this.src=FALLBACK_LOGO_B64" alt="">
            <span>${m.away}</span>
          </div>
        </div>
      `;
    }).join("");

    mqCard.innerHTML = `
      <div class="mq-header">
        <h4>📅 Programme du Week-end (${wkMatches.length})</h4>
        <button class="mq-see-all" onclick="switchMobileTab('schedule')">Filtres & Semaines ▶</button>
      </div>
      ${itemsHtml}
    `;
  }
}

function renderAll() {
  renderHeaderAndTicker();
  renderWeekNavigation();
  renderMatchesList();
  renderRightColumn();
}

/* ================= ACTIONS TABLE DE MARQUE EN DIRECT ================= */
window.switchStaffMode = function(mode) {
  state.staffMode = mode;
  renderRightColumn();
};

window.startLiveMatch = function(id) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  state.selectedMatchId = id;
  state.staffMode = "live";
  m.status = "live";
  m.liveTracking = true;
  if (!m.period || m.period === "À venir" || m.period === "Terminé") {
    m.period = "QT1";
  }
  saveState(true);
  renderAll();
  if (state.displayMode === "mobile") switchMobileTab("live");
};

window.updateLivePoints = function(id, side, delta) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  m.status = "live";
  m.liveTracking = true;
  if (!m.period || m.period === "À venir" || m.period === "Terminé") m.period = "QT1";
  if (side === "home") {
    m.sh = Math.max(0, (m.sh || 0) + delta);
  } else {
    m.sa = Math.max(0, (m.sa || 0) + delta);
  }
  saveState(true);
  renderAll();
};

window.updateLiveFouls = function(id, side, delta) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  m.status = "live";
  m.liveTracking = true;
  if (side === "home") {
    m.fh = Math.max(0, Math.min(5, (m.fh || 0) + delta));
  } else {
    m.fa = Math.max(0, Math.min(5, (m.fa || 0) + delta));
  }
  saveState(true);
  renderAll();
};

window.setLivePeriod = function(id, period) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  m.status = "live";
  m.liveTracking = true;
  m.period = period;
  saveState(true);
  renderAll();
};

window.setMatchNoLiveTable = function(id) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  m.status = "live";
  m.liveTracking = false;
  m.sh = 0;
  m.sa = 0;
  m.period = "En cours";
  saveState(true);
  renderAll();
};

window.finishCurrentAndLaunchNext = function(id) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  m.status = "finished";
  m.period = "Terminé";

  const wkMatches = state.matches.filter(x => x.wk === state.currentWeek);
  const idx = wkMatches.findIndex(x => x.id === id);
  const next = wkMatches.slice(idx + 1).find(x => x.status !== "finished");
  if (next) {
    next.status = "live";
    next.liveTracking = true;
    next.period = "QT1";
    state.selectedMatchId = next.id;
  }
  saveState(true);
  renderAll();
};

/* ================= NAVIGATION & FILTERS ================= */
window.selectWeek = function(wk, opts) {
  if (!(opts && opts.auto)) state.autoWeek = false;
  state.currentWeek = wk;
  const wkMatches = state.matches.filter(m => m.wk === wk);
  if (wkMatches.length > 0) {
    state.selectedMatchId = pickDefaultMatch(wkMatches).id;
  }
  renderAll();
};

window.selectCurrentWeek = function() {
  state.autoWeek = true;
  window.selectWeek(detectCurrentWeek(), { auto: true });
};

window.shiftWeek = function(delta) {
  const weeks = getWeeksList();
  const idx = weeks.findIndex(w => w.wk === state.currentWeek);
  const nextIdx = Math.max(0, Math.min(weeks.length - 1, idx + delta));
  window.selectWeek(weeks[nextIdx].wk);
};

window.setCatFilter = function(cat, btn) {
  state.catFilter = cat;
  document.querySelectorAll(".cat-pill").forEach(el => el.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderMatchesList();
};

window.setLocFilter = function(loc, btn) {
  state.locFilter = loc;
  document.querySelectorAll(".loc-pill").forEach(el => el.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderMatchesList();
};

window.selectMatch = function(id) {
  state.selectedMatchId = id;
  renderMatchesList();
  renderRightColumn();
  if (state.displayMode === "mobile") {
    switchMobileTab("live");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
};

window.selectMatchForEdit = function(id) {
  state.selectedMatchId = id;
  state.staffMode = "final";
  renderMatchesList();
  renderRightColumn();
  if (state.displayMode === "mobile") {
    switchMobileTab("live");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  setTimeout(() => {
    const inp = document.getElementById("inpScoreHome");
    if (inp) inp.focus();
  }, 60);
};

window.saveMatchScore = function(id, newStatus) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  const inpH = document.getElementById("inpScoreHome");
  const inpA = document.getElementById("inpScoreAway");
  const hVal = inpH ? (parseInt(inpH.value, 10) || 0) : m.sh;
  const aVal = inpA ? (parseInt(inpA.value, 10) || 0) : m.sa;
  m.sh = newStatus === "upcoming" ? 0 : hVal;
  m.sa = newStatus === "upcoming" ? 0 : aVal;
  m.status = newStatus;
  m.statusNote = "";
  m.liveTracking = newStatus === "live";
  m.period = newStatus === "finished" ? "Terminé" : (newStatus === "live" ? "QT1" : "À venir");
  saveState(true);
  renderAll();
};

window.fillSpecialReason = function(txt) {
  const inp = document.getElementById("inpSpecialReason");
  if (inp) inp.value = txt;
};

window.applySpecialMatchStatus = function(id, specialStatus) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  const inp = document.getElementById("inpSpecialReason");
  const reason = inp ? inp.value.trim() : "";
  m.status = specialStatus;
  m.liveTracking = false;

  if (specialStatus === "postponed") {
    m.sh = 0;
    m.sa = 0;
    m.period = "Reporté";
    m.statusNote = reason || "Conditions météo";
  } else if (specialStatus === "forfeit") {
    m.period = "Forfait";
    m.statusNote = reason || "Forfait officiel";
    const low = m.statusNote.toLowerCase();
    const homeIsUs = isLSBSC(m.home);
    if (low.includes("20-0") || low.includes("adverse")) {
      m.sh = homeIsUs ? 20 : 0;
      m.sa = homeIsUs ? 0 : 20;
    } else if (low.includes("0-20") || low.includes("lsbsc")) {
      m.sh = homeIsUs ? 0 : 20;
      m.sa = homeIsUs ? 20 : 0;
    } else {
      m.sh = 0;
      m.sa = 0;
    }
  }
  saveState(true);
  renderAll();
};

/* ================= PIN SECURITY (STAFF 5900 vs LOGOS & MASCOTTE 9694) ================= */
window.requestPinAccess = function(target) {
  if (target === "staff" && state.staffUnlocked) {
    state.staffUnlocked = false;
    renderAll();
    return;
  }
  state.pinTarget = target;
  state.pinBuffer = "";
  const titleEl = document.getElementById("pinModalTitle");
  if (target === "logos") {
    titleEl.textContent = "🛡️ Accès Protégé — Logos & Mascotte";
  } else if (target === "settings") {
    titleEl.textContent = "⚙️ Accès Protégé — Réglages & Buvette";
  } else {
    titleEl.textContent = "🔒 Accès Staff — Direct & Saisie Résultats";
  }
  document.getElementById("pinDisplayBox").textContent = "";
  document.getElementById("pinModal").classList.add("open");
};

window.pressPinDigit = function(d) {
  if (d === "C") {
    state.pinBuffer = "";
  } else if (d === "OK") {
    verifyPinCode();
    return;
  } else if (state.pinBuffer.length < 6) {
    state.pinBuffer += String(d);
  }
  document.getElementById("pinDisplayBox").textContent = "•".repeat(state.pinBuffer.length);
  if (state.pinBuffer.length === 4) {
    setTimeout(verifyPinCode, 120);
  }
};

function verifyPinCode() {
  const expected = (state.pinTarget === "logos" || state.pinTarget === "settings")
    ? state.pinLogos
    : state.pinStaff;
  if (state.pinBuffer === expected) {
    document.getElementById("pinModal").classList.remove("open");
    if (state.pinTarget === "logos") {
      state.logosUnlocked = true;
      openLogosManagerModal();
    } else if (state.pinTarget === "settings") {
      openCloudModal();
    } else {
      state.staffUnlocked = true;
      renderAll();
      if (state.displayMode === "mobile") switchMobileTab("live");
    }
  } else {
    const box = document.getElementById("pinDisplayBox");
    box.style.borderColor = "#DC2626";
    box.textContent = "CODE ERRONÉ";
    state.pinBuffer = "";
    setTimeout(() => {
      box.style.borderColor = "#CBD5E1";
      box.textContent = "";
    }, 900);
  }
}

window.closeModals = function() {
  document.querySelectorAll(".modal-backdrop").forEach(m => m.classList.remove("open"));
  state.logosUnlocked = false;
};

/* ================= LOGOS & MASCOTTE MANAGER (PIN 9694) ================= */
function openLogosManagerModal() {
  if (!state.logosUnlocked) return;
  const clubsSet = new Set();
  state.matches.forEach(m => {
    if (!isLSBSC(m.home)) clubsSet.add(normalizeClubKey(m.home));
    if (!isLSBSC(m.away)) clubsSet.add(normalizeClubKey(m.away));
  });
  const clubs = Array.from(clubsSet).sort();

  const grid = document.getElementById("clubsLogoGrid");
  grid.innerHTML = clubs.map(c => `
    <div class="club-logo-item">
      <img src="${getTeamBadgeSrc(c)}" style="width:44px;height:44px;object-fit:contain;" alt="">
      <div style="font-size:0.7rem;font-weight:800;color:#0F172A;">${c}</div>
      <label class="btn-action-sm" style="background:#1E3A8A;color:#FFF;cursor:pointer;">
        Importer Logo
        <input type="file" accept="image/*" style="display:none;" onchange="uploadOpponentLogo(event, '${c.replace(/'/g, "\\'")}')">
      </label>
    </div>
  `).join("");

  document.getElementById("logosModal").classList.add("open");
}

function resizeImageFile(file, maxDim, cb) {
  const reader = new FileReader();
  reader.onload = e => {
    const raw = e.target.result;
    const img = new Image();
    img.onload = () => {
      try {
        const k = Math.min(1, maxDim / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(img.width * k));
        c.height = Math.max(1, Math.round(img.height * k));
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        cb(c.toDataURL("image/png"));
      } catch (err) { cb(raw); }
    };
    img.onerror = () => cb(raw);
    img.src = raw;
  };
  reader.readAsDataURL(file);
}

window.uploadClubAsset = function(ev, type) {
  const file = ev.target.files[0];
  if (!file) return;
  resizeImageFile(file, 320, data => {
    if (type === "logo") state.clubAssets.logo = data;
    if (type === "mascot") state.clubAssets.mascot = data;
    saveState(true);
    renderAll();
  });
};

window.uploadOpponentLogo = function(ev, clubKey) {
  const file = ev.target.files[0];
  if (!file) return;
  resizeImageFile(file, 160, data => {
    if (!state.clubAssets.customBadges) state.clubAssets.customBadges = {};
    state.clubAssets.customBadges[clubKey] = data;
    saveState(true);
    openLogosManagerModal();
    renderAll();
  });
};

/* ================= CLOUD SYNC & TICKER MODAL ================= */
window.openCloudModal = function() {
  document.getElementById("inpSyncUrl").value = state.syncUrl || "https://lsbsc-ecran-default-rtdb.europe-west1.firebasedatabase.app/lsbsc.json";
  document.getElementById("inpTickerText").value = state.tickerText || "";
  document.getElementById("cloudModal").classList.add("open");
};

window.saveCloudAndTicker = function() {
  state.syncUrl = document.getElementById("inpSyncUrl").value.trim();
  state.tickerText = document.getElementById("inpTickerText").value.trim() || state.tickerText;
  localStorage.setItem("lsbsc_sync_url", state.syncUrl);
  saveState(true);
  renderAll();
  closeModals();
};

/* ================= INITIALIZATION ================= */
function updateClock() {
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  const el = document.getElementById("liveClock");
  if (el) el.textContent = `${hh}:${mm}:${ss}`;
}

window.addEventListener("storage", (e) => {
  if (e.key === "lsbsc_state_v4") {
    loadLocalData();
    renderAll();
  }
});

if (bcChannel) {
  bcChannel.onmessage = (ev) => {
    if (ev.data && Array.isArray(ev.data.matches)) {
      state.matches = ev.data.matches;
      if (ev.data.selectedMatchId) state.selectedMatchId = ev.data.selectedMatchId;
      if (ev.data.tickerText) state.tickerText = ev.data.tickerText;
      renderAll();
    }
  };
}

document.addEventListener("DOMContentLoaded", () => {
  initDisplayFormatSelection();
  loadLocalData();
  renderAll();
  loadBaseMatches();
  updateClock();
  setInterval(updateClock, 1000);
  setInterval(pollCloudSync, 5000);
  setInterval(refreshAutoWeek, 60000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { pollCloudSync(); refreshAutoWeek(); } });
});


/* ================= PWA : INSTALLATION SUR TÉLÉPHONE / PC / TV ================= */
let deferredInstallPrompt = null;

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  const btnInstall = document.getElementById("btnInstallApp");
  const btnInstallSplash = document.getElementById("btnInstallSplash");
  if (btnInstall) btnInstall.style.display = "inline-flex";
  if (btnInstallSplash) btnInstallSplash.style.display = "flex";
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  const btnInstall = document.getElementById("btnInstallApp");
  const btnInstallSplash = document.getElementById("btnInstallSplash");
  if (btnInstall) btnInstall.style.display = "none";
  if (btnInstallSplash) btnInstallSplash.style.display = "none";
});

window.triggerPwaInstall = async function() {
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    const choiceResult = await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    if (choiceResult && choiceResult.outcome === "accepted") {
      const btnInstall = document.getElementById("btnInstallApp");
      if (btnInstall) btnInstall.style.display = "none";
    }
  } else {
    alert("Pour installer l'application LSBSC :\n• Sur Android (Chrome) : Menu (⋮) → « Ajouter à l'écran d'accueil » ou « Installer l'application ».\n• Sur iPhone (Safari) : Bouton Partager (↑) → « Sur l'écran d'accueil ».\n• Sur PC (Chrome/Edge) : Icône d'installation dans la barre d'adresse.");
  }
};

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}


/* ================= INTÉGRATION STREAMING YOUTUBE & TWITCH (V12) ================= */
function parseYoutubeUrl(rawInput) {
  const txt = (rawInput || "").trim();
  if (!txt) return null;
  const patterns = [
    /(?:youtube\.com\/watch\?(?:.*&)?v=)([a-zA-Z0-9_-]{11})/i,
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/i,
    /(?:youtube\.com\/(?:live|shorts|embed)\/)([a-zA-Z0-9_-]{11})/i,
    /^([a-zA-Z0-9_-]{11})$/
  ];
  let videoId = null;
  for (const rx of patterns) {
    const m = txt.match(rx);
    if (m && m[1]) {
      videoId = m[1];
      break;
    }
  }
  if (!videoId) return null;
  return {
    id: videoId,
    mediaType: 'youtube',
    url: `https://www.youtube.com/watch?v=${videoId}`,
    embedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`
  };
}

function parseTwitchInput(rawInput) {
  const txt = (rawInput || "").trim();
  if (!txt) return null;
  const urlMatch = txt.match(/twitch\.tv\/([a-zA-Z0-9_]{4,25})/i);
  const chanName = urlMatch ? urlMatch[1] : (/^[a-zA-Z0-9_]{4,25}$/.test(txt) ? txt : null);
  if (!chanName) return null;

  const currentHost = window.location.hostname || "";
  const parents = ["localhost", "127.0.0.1", "github.io", "netlify.app", "vercel.app", "pages.dev", currentHost].filter(Boolean);
  // Remove duplicates
  const uniqueParents = Array.from(new Set(parents));
  const parentParams = uniqueParents.map(p => `parent=${encodeURIComponent(p)}`).join("&");

  return {
    id: chanName,
    mediaType: 'twitch',
    title: `Live Twitch (${chanName})`,
    url: `https://www.twitch.tv/${chanName}`,
    embedUrl: `https://player.twitch.tv/?channel=${encodeURIComponent(chanName)}&${parentParams}&autoplay=true`
  };
}

window.addYoutubeVideoToMatch = function(matchId) {
  const m = state.matches.find(x => x.id === matchId);
  if (!m) return;
  const urlInp = document.getElementById("inpYoutubeUrl");
  const titleInp = document.getElementById("inpYoutubeTitle");
  const parsed = parseYoutubeUrl(urlInp ? urlInp.value : "");
  if (!parsed) {
    alert("Lien YouTube invalide.");
    return;
  }
  if (!Array.isArray(m.youtubeVideos)) m.youtubeVideos = [];
  const customTitle = (titleInp ? titleInp.value.trim() : "") || "🔴 Direct YouTube";
  m.youtubeVideos.push({
    id: parsed.id,
    mediaType: 'youtube',
    title: customTitle,
    url: parsed.url,
    embedUrl: parsed.embedUrl,
    addedAt: Date.now()
  });
  saveState(true);
  renderAll();
};

window.addTwitchVideoToMatch = function(matchId) {
  const m = state.matches.find(x => x.id === matchId);
  if (!m) return;
  const chanInp = document.getElementById("inpTwitchChannel");
  const titleInp = document.getElementById("inpTwitchTitle");
  const parsed = parseTwitchInput(chanInp ? chanInp.value : "");
  if (!parsed) {
    alert("Chaîne ou lien Twitch invalide. Exemple : lsbsc_lillesud");
    return;
  }
  if (!Array.isArray(m.twitchVideos)) m.twitchVideos = [];
  const customTitle = (titleInp ? titleInp.value.trim() : "") || `🎮 Live Twitch (${parsed.id})`;
  m.twitchVideos.push({
    id: parsed.id,
    mediaType: 'twitch',
    title: customTitle,
    url: parsed.url,
    embedUrl: parsed.embedUrl,
    addedAt: Date.now()
  });
  saveState(true);
  renderAll();
};

window.removeVideoFromMatch = function(matchId, type, idx) {
  const m = state.matches.find(x => x.id === matchId);
  if (!m) return;
  if (type === 'youtube' && Array.isArray(m.youtubeVideos)) {
    m.youtubeVideos.splice(idx, 1);
  } else if (type === 'twitch' && Array.isArray(m.twitchVideos)) {
    m.twitchVideos.splice(idx, 1);
  }
  saveState(true);
  renderAll();
};

window.openMatchVideoModal = function(matchId, globalClipIdx = 0) {
  const m = state.matches.find(x => x.id === matchId);
  if (!m) return;
  const allVids = [
    ...(Array.isArray(m.youtubeVideos) ? m.youtubeVideos.map(v => ({...v, mediaType: 'youtube'})) : []),
    ...(Array.isArray(m.twitchVideos) ? m.twitchVideos.map(v => ({...v, mediaType: 'twitch'})) : [])
  ];
  if (allVids.length === 0) return;
  const safeIdx = Math.max(0, Math.min(allVids.length - 1, globalClipIdx));
  const clip = allVids[safeIdx];

  document.getElementById("videoModalTitle").textContent = `📺 ${m.cat} • ${m.home} vs ${m.away}`;

  const playlistHtml = allVids.map((v, i) => `
    <button class="video-clip-item ${i === safeIdx ? "active-clip" : ""}" onclick="openMatchVideoModal(${m.id}, ${i})">
      <div class="video-clip-meta">
        <span class="video-clip-title">${i === safeIdx ? "▶️ " : (v.mediaType === 'twitch' ? "🎮 " : "📺 ")}${v.title}</span>
        <span class="video-clip-sub">${v.url}</span>
      </div>
      <span style="font-size:0.75rem;font-weight:900;color:${v.mediaType === 'twitch' ? '#7C3AED' : '#DC2626'};">Regarder</span>
    </button>
  `).join("");

  document.getElementById("videoModalBody").innerHTML = `
    <div class="video-player-frame-wrap">
      <iframe src="${clip.embedUrl}" title="${clip.title}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>
    </div>
    <div class="video-player-footer">
      <div style="font-size:0.86rem;font-weight:900;color:#0F172A;">${clip.title}</div>
      <a class="video-external-link" style="background:${clip.mediaType === 'twitch' ? '#9146FF' : '#DC2626'};" href="${clip.url}" target="_blank" rel="noopener noreferrer">↗️ Ouvrir sur ${clip.mediaType === 'twitch' ? 'Twitch' : 'YouTube'}</a>
    </div>
    <div style="font-size:0.78rem;font-weight:900;color:#475569;">Médias associés à ce match (${allVids.length}) :</div>
    <div class="video-playlist">${playlistHtml}</div>
  `;

  document.getElementById("videoModal").classList.add("open");
};

window.openVideoGalleryModal = function(selectedGlobalIdx = 0) {
  const allClips = [];
  state.matches.forEach(m => {
    if (Array.isArray(m.youtubeVideos)) {
      m.youtubeVideos.forEach(v => allClips.push({ match: m, clip: {...v, mediaType: 'youtube'} }));
    }
    if (Array.isArray(m.twitchVideos)) {
      m.twitchVideos.forEach(v => allClips.push({ match: m, clip: {...v, mediaType: 'twitch'} }));
    }
  });

  document.getElementById("videoModalTitle").textContent = `📺 Directs & Vidéos du Club (YouTube & Twitch) (${allClips.length})`;

  if (allClips.length === 0) {
    document.getElementById("videoModalBody").innerHTML = `
      <div style="padding:22px;text-align:center;color:#475569;font-weight:800;line-height:1.5;">
        Aucun direct YouTube ou Twitch enregistré pour le moment.<br>
        <span style="font-size:0.82rem;font-weight:600;">Le Staff (PIN 5900) peut ajouter un flux depuis l'onglet « 📺 Médias Live » d'un match.</span>
      </div>
    `;
    document.getElementById("videoModal").classList.add("open");
    return;
  }

  const safeIdx = Math.max(0, Math.min(allClips.length - 1, selectedGlobalIdx));
  const active = allClips[safeIdx];

  const listHtml = allClips.map((item, i) => `
    <button class="video-clip-item ${i === safeIdx ? "active-clip" : ""}" onclick="openVideoGalleryModal(${i})">
      <div class="video-clip-meta">
        <span class="video-clip-title">${i === safeIdx ? "▶️ " : (item.clip.mediaType === 'twitch' ? "🎮 " : "📺 ")}${item.clip.title} (${item.match.cat})</span>
        <span class="video-clip-sub">${item.match.date} • ${item.match.home} vs ${item.match.away}</span>
      </div>
      <span style="font-size:0.75rem;font-weight:900;color:${item.clip.mediaType === 'twitch' ? '#7C3AED' : '#DC2626'};">Regarder</span>
    </button>
  `).join("");

  document.getElementById("videoModalBody").innerHTML = `
    <div class="video-player-frame-wrap">
      <iframe src="${active.clip.embedUrl}" title="${active.clip.title}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>
    </div>
    <div class="video-player-footer">
      <div>
        <div style="font-size:0.86rem;font-weight:900;color:#0F172A;">${active.clip.title}</div>
        <div style="font-size:0.74rem;font-weight:700;color:#475569;">${active.match.cat} • ${active.match.home} vs ${active.match.away}</div>
      </div>
      <a class="video-external-link" style="background:${active.clip.mediaType === 'twitch' ? '#9146FF' : '#DC2626'};" href="${active.clip.url}" target="_blank" rel="noopener noreferrer">↗️ Ouvrir sur ${active.clip.mediaType === 'twitch' ? 'Twitch' : 'YouTube'}</a>
    </div>
    <div class="video-playlist">${listHtml}</div>
  `;

  document.getElementById("videoModal").classList.add("open");
};

window.closeVideoModal = function() {
  const modal = document.getElementById("videoModal");
  if (modal) modal.classList.remove("open");
  const body = document.getElementById("videoModalBody");
  if (body) body.innerHTML = "";
};

/* ================= EXTENSION : PIN 9694 UNIFIÉ, FICHES MATCHS, ADRESSES & QR TV ================= */
try {
  // Nettoyage automatique de l'ancien cache incompatible si présent
  localStorage.removeItem("lsbsc_matches_v2027");
  localStorage.removeItem("lsbsc_club_addresses_v2027");
} catch (e) {}

state.pinStaff = "9694";
state.pinLogos = "9694";
if (typeof SCHEDULE_FIELDS !== "undefined") {
  ["salle", "address", "precision"].forEach(k => {
    if (!SCHEDULE_FIELDS.includes(k)) SCHEDULE_FIELDS.push(k);
  });
}

// Adapter loadBaseMatches au cas où data/matches.json est soit un tableau [...] soit un objet {matches: [...]}
const _origLoadBaseMatches = loadBaseMatches;
loadBaseMatches = async function() {
  let base = null;
  try {
    const res = await fetch("data/matches.json", { cache: "no-cache" });
    if (res.ok) {
      const raw = await res.json();
      base = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.matches) ? raw.matches : null);
    }
  } catch (e) {}
  if (!Array.isArray(base) || base.length === 0 || !base[0].wk) {
    base = DEFAULT_MATCHES;
  }
  state.baseMatches = base;

  // Si state.matches a un format incompatible (ex: absence de champ wk), on réinitialise proprement
  if (!Array.isArray(state.matches) || state.matches.length === 0 || !state.matches[0].wk) {
    state.matches = JSON.parse(JSON.stringify(base));
  } else {
    state.matches = overlaySchedule(state.matches);
  }
  persistLocalOnly();
  if (state.autoWeek || !state.currentWeek) state.currentWeek = detectCurrentWeek();
  renderAll();
};

const _origRenderAll = renderAll;
renderAll = function() {
  document.body.classList.toggle("staff-unlocked", Boolean(state.staffUnlocked));
  _origRenderAll();
  enhanceTvAndAddressesUI();
};

function getMatchVenueInfo(m) {
  const salle = m.salle || (isLSBSC(m.home) ? "ANTOINE BLONDIN A 790M2" : "Salle Municipale");
  const address = m.address || (isLSBSC(m.home) ? "3 RUE FRANCOIS COPPÉE 59000 LILLE" : normalizeClubKey(m.home));
  const precision = m.precision || "";
  const gpsUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(salle + " " + address);
  return { salle, address, precision, gpsUrl };
}

function enhanceTvAndAddressesUI() {
  const current = state.matches.find(m => m.id === state.selectedMatchId);
  const summaryBar = document.getElementById("sbMatchSummaryBar");
  if (current && summaryBar) {
    const info = getMatchVenueInfo(current);
    const firstPill = summaryBar.querySelector(".sb-summary-pill");
    if (firstPill) {
      firstPill.outerHTML = `<a class="sb-summary-pill gps-pill" href="${info.gpsUrl}" target="_blank" rel="noopener">📍 ${info.salle} — ${info.address} (GPS ↗)</a>`;
    }
    if (info.precision && !summaryBar.querySelector(".precision-pill")) {
      summaryBar.insertAdjacentHTML("beforeend", `<span class="sb-summary-pill precision-pill">📌 ${info.precision}</span>`);
    }
  }

  const ovCard = document.getElementById("clubOverviewCard");
  if (ovCard && !ovCard.querySelector(".tv-qr-inline")) {
    ovCard.insertAdjacentHTML("beforeend", `
      <div class="tv-qr-inline" style="display:flex;align-items:center;gap:8px;background:rgba(255,255,255,0.14);padding:4px 8px;border-radius:10px;border:1px solid rgba(255,255,255,0.3);cursor:pointer;" onclick="document.getElementById('qrModal').classList.add('open')" title="Agrandir le QR Code">
        <img src="assets/qrcode-lsbsc.png" alt="QR" style="width:42px;height:42px;border-radius:6px;background:#FFF;padding:2px;">
        <span style="font-size:0.65rem;font-weight:800;line-height:1.15;color:#FDE68A;">📱 Scannez<br>Direct Mobile</span>
      </div>
    `);
  }

  const filtered = state.matches.filter(m => {
    if (m.wk !== state.currentWeek) return false;
    if (state.catFilter !== "ALL" && m.cat !== state.catFilter) return false;
    if (state.locFilter === "HOME" && !isLSBSC(m.home)) return false;
    if (state.locFilter === "AWAY" && !isLSBSC(m.away)) return false;
    return true;
  });
  const rows = document.querySelectorAll("#matchesListContainer .match-row");
  rows.forEach((row, idx) => {
    const m = filtered[idx];
    if (!m) return;
    const info = getMatchVenueInfo(m);
    const center = row.querySelector(".m-score-center");
    if (center && !center.querySelector(".m-address-sub")) {
      center.insertAdjacentHTML("beforeend", `<a class="m-address-sub" href="${info.gpsUrl}" target="_blank" rel="noopener" onclick="event.stopPropagation()">📍 ${info.salle}</a>`);
      if (info.precision) {
        center.insertAdjacentHTML("beforeend", `<span class="m-precision-tag">📌 ${info.precision}</span>`);
      }
    }
    const staffActions = row.querySelector(".row-staff-actions");
    if (staffActions && state.staffUnlocked && !staffActions.querySelector(".btn-edit-sheet-row")) {
      staffActions.insertAdjacentHTML("beforeend", `<button class="btn-row-edit btn-edit-sheet-row" style="background:#1E3A8A;" onclick="event.stopPropagation();openMatchSheetModal(${m.id})">✏️ Fiche</button>`);
    }
  });
}

window.openMatchSheetModal = function(matchId) {
  if (!state.staffUnlocked) {
    requestPinAccess("staff");
    return;
  }
  const isNew = matchId === "NEW";
  const currentWkObj = getWeeksList().find(w => w.wk === state.currentWeek) || { wk: "w11", label: "Week-end en cours", short: "Actuel" };
  const m = isNew ? {
    id: Date.now(),
    wk: currentWkObj.wk,
    wkLabel: currentWkObj.label,
    wkShort: currentWkObj.short,
    date: "SAM. 21 NOV.",
    time: "17H00",
    cat: state.catFilter !== "ALL" ? state.catFilter : "U13F",
    comp: "Champ.",
    home: "U13 FILLE BENJAMINES",
    away: "CLUB ADVERSE",
    sh: 0,
    sa: 0,
    status: "upcoming",
    salle: "ANTOINE BLONDIN A 790M2",
    address: "3 RUE FRANCOIS COPPÉE 59000 LILLE",
    precision: ""
  } : state.matches.find(x => x.id === matchId);

  if (!m) return;
  const info = getMatchVenueInfo(m);
  document.getElementById("matchSheetModalTitle").textContent = isNew ? "➕ Ajouter un Match" : `✏️ Modifier Fiche Match (${m.cat})`;
  document.getElementById("msMatchId").value = isNew ? "NEW" : m.id;
  document.getElementById("msDate").value = m.date || "";
  document.getElementById("msTime").value = m.time || "";
  document.getElementById("msCat").value = m.cat || "U13F";
  document.getElementById("msComp").value = m.comp || "Champ.";
  document.getElementById("msHome").value = m.home || "";
  document.getElementById("msAway").value = m.away || "";
  document.getElementById("msSalle").value = info.salle;
  document.getElementById("msAddress").value = info.address;
  document.getElementById("msPrecision").value = m.precision || "";
  document.getElementById("matchSheetModal").classList.add("open");
};

window.saveMatchSheetModal = function() {
  const idVal = document.getElementById("msMatchId").value;
  const isNew = idVal === "NEW";
  const currentWkObj = getWeeksList().find(w => w.wk === state.currentWeek) || { wk: "w11", label: "Week-end", short: "WE" };
  let m = isNew ? {
    id: Math.max(0, ...state.matches.map(x => Number(x.id) || 0)) + 1,
    wk: currentWkObj.wk,
    wkLabel: currentWkObj.label,
    wkShort: currentWkObj.short,
    sh: 0, sa: 0, status: "upcoming", period: "À venir", fh: 0, fa: 0, liveTracking: false
  } : state.matches.find(x => String(x.id) === String(idVal));

  if (!m) return;
  m.date = document.getElementById("msDate").value.trim().toUpperCase();
  m.time = document.getElementById("msTime").value.trim().toUpperCase();
  m.cat = document.getElementById("msCat").value;
  m.comp = document.getElementById("msComp").value.trim();
  m.home = document.getElementById("msHome").value.trim();
  m.away = document.getElementById("msAway").value.trim();
  m.salle = document.getElementById("msSalle").value.trim();
  m.address = document.getElementById("msAddress").value.trim();
  m.precision = document.getElementById("msPrecision").value.trim();

  if (isNew) {
    state.matches.push(m);
    state.selectedMatchId = m.id;
  }
  const bIdx = state.baseMatches.findIndex(x => x.id === m.id);
  if (bIdx !== -1) state.baseMatches[bIdx] = Object.assign({}, m);

  saveState(true);
  closeModals();
  renderAll();
};

window.openClubAddressesModal = function() {
  if (!state.staffUnlocked) {
    requestPinAccess("staff");
    return;
  }
  const map = new Map();
  state.matches.forEach(m => {
    const ck = normalizeClubKey(m.home);
    if (!map.has(ck)) {
      const info = getMatchVenueInfo(m);
      map.set(ck, { club: ck, salle: info.salle, address: info.address, precision: info.precision });
    }
  });
  const list = Array.from(map.values()).sort((a, b) => a.club.localeCompare(b.club));
  const container = document.getElementById("clubAddressesList");
  container.innerHTML = list.map((item, i) => `
    <div class="club-addr-card">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <strong style="color:#1E3A8A;font-size:0.86rem;">🏀 ${item.club}</strong>
        <button class="btn-action-sm btn-save-score" onclick="applyClubAddressToAllMatches('${item.club.replace(/'/g, "\'")}', ${i})">💾 Appliquer aux matchs</button>
      </div>
      <div class="form-grid-2">
        <div class="form-field">
          <label>Nom de la salle</label>
          <input type="text" id="caSalle_${i}" value="${item.salle.replace(/"/g, "&quot;")}">
        </div>
        <div class="form-field">
          <label>Adresse complète</label>
          <input type="text" id="caAddr_${i}" value="${item.address.replace(/"/g, "&quot;")}">
        </div>
        <div class="form-field full">
          <label>📌 Précision (Accès, parking, salle bis...)</label>
          <input type="text" id="caPrec_${i}" value="${(item.precision || "").replace(/"/g, "&quot;")}">
        </div>
      </div>
    </div>
  `).join("");
  document.getElementById("clubAddressesModal").classList.add("open");
};

window.applyClubAddressToAllMatches = function(clubKey, idx) {
  const salle = document.getElementById("caSalle_" + idx).value.trim();
  const address = document.getElementById("caAddr_" + idx).value.trim();
  const precision = document.getElementById("caPrec_" + idx).value.trim();
  let count = 0;
  state.matches.forEach(m => {
    if (normalizeClubKey(m.home) === clubKey) {
      m.salle = salle;
      m.address = address;
      m.precision = precision;
      count++;
    }
  });
  state.baseMatches.forEach(m => {
    if (normalizeClubKey(m.home) === clubKey) {
      m.salle = salle;
      m.address = address;
      m.precision = precision;
    }
  });
  saveState(true);
  renderAll();
  alert(`Adresse enregistrée sur ${count} match(s) à domicile de ${clubKey} !`);
};


/* ================= EXTENSION KIOSQUE TV : CARROUSEL 3 VUES + AUTO-SCROLL VERTICAL + TARIFS BUVETTE & INFOS ================= */
const DEFAULT_BUVETTE_MENU = [
  "Boissons Fraîches & Chaudes | Eau Cristaline (50cl) | 1,00 €",
  "Boissons Fraîches & Chaudes | Coca-Cola, Oasis, Ice Tea, Fanta (33cl) | 2,00 €",
  "Boissons Fraîches & Chaudes | Capri-Sun / Jus de fruits | 1,50 €",
  "Boissons Fraîches & Chaudes | Café Expresso / Thé chaud | 1,00 €",
  "Snacks & Restauration Chaude | Croque-Monsieur (Jambon/Fromage ou Volaille) | 2,50 €",
  "Snacks & Restauration Chaude | Hot-Dog chaud (Ketchup / Mayo / Moutarde) | 2,50 €",
  "Snacks & Restauration Chaude | Sandwich Baguette Frais | 3,00 €",
  "Snacks & Restauration Chaude | Chips (Sachet individuel) | 1,00 €",
  "Sucré, Crêpes & Goûter | Crêpe Maison (Sucre / Chocolat / Spéculoos) | 1,50 €",
  "Sucré, Crêpes & Goûter | Gaufre / Pâtisserie maison | 2,00 €",
  "Sucré, Crêpes & Goûter | Barre chocolatée (Kinder, Mars, Twix, Snickers) | 1,50 €",
  "Sucré, Crêpes & Goûter | Sachet de Bonbons | 1,00 €",
  "Formules Supporters LSBSC | Formule Match (1 Croque ou Hot-Dog + 1 Boisson) | 4,00 €",
  "Formules Supporters LSBSC | Formule Goûter (1 Crêpe + 1 Capri-Sun ou Café) | 2,50 €"
].join("\n");

const DEFAULT_CLUB_INFOS = [
  "🏟️ | Salle Antoine Blondin — Lille Sud | Bienvenue au complexe sportif Antoine Blondin (3 rue François Coppée, 59000 Lille). Merci de respecter la propreté des tribunes et le travail de nos bénévoles.",
  "🦁 | Esprit Sportif & Fair-Play | Au LSBSC South Lille, nous encourageons nos équipes avec passion et dans le respect absolu des arbitres, des adversaires et des jeunes officiels.",
  "👕 | Boutique, Goodies & Atelier Flocage | Soutenez le club avec nos gourdes, mugs, t-shirts et sweats personnalisés aux couleurs des Lions de Lille Sud ! Renseignements auprès du staff à la buvette.",
  "🤝 | Vie du Club & Actions Solidaires | Toutes les recettes de la buvette financent directement les équipements, les tournois jeunes et les actions solidaires du club (Octobre Rose, événements jeunes)."
].join("\n");

state.tvCurrentSlide = "matches"; // 'matches' | 'buvette' | 'infos'
state.tvCarouselPaused = false;
state.tvDurations = { matches: 18, buvette: 14, infos: 14 };
state.buvetteMenuText = DEFAULT_BUVETTE_MENU;
state.clubInfosText = DEFAULT_CLUB_INFOS;

// Charger les données Buvette & Infos depuis localStorage si présentes
function loadTvKioskExtraData() {
  try {
    const saved = localStorage.getItem("lsbsc_state_v4");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.buvetteMenuText) state.buvetteMenuText = parsed.buvetteMenuText;
      if (parsed.clubInfosText) state.clubInfosText = parsed.clubInfosText;
      if (parsed.tvDurations) state.tvDurations = Object.assign(state.tvDurations, parsed.tvDurations);
    }
  } catch (e) {}
}
loadTvKioskExtraData();

// Surcharger saveState et persistLocalOnly pour inclure les tarifs buvette et infos club
const _basePersistLocalOnly = persistLocalOnly;
persistLocalOnly = function() {
  try {
    localStorage.setItem("lsbsc_state_v4", JSON.stringify({
      matches: state.matches,
      tickerText: state.tickerText,
      clubAssets: state.clubAssets,
      buvetteMenuText: state.buvetteMenuText,
      clubInfosText: state.clubInfosText,
      tvDurations: state.tvDurations,
      updatedAt: state.lastUpdatedAt
    }));
  } catch (e) {}
};

saveState = function(pushCloud = true) {
  const now = Date.now();
  state.lastUpdatedAt = now;
  const payload = {
    matches: state.matches,
    tickerText: state.tickerText,
    clubAssets: state.clubAssets,
    buvetteMenuText: state.buvetteMenuText,
    clubInfosText: state.clubInfosText,
    tvDurations: state.tvDurations,
    updatedAt: now
  };
  try {
    localStorage.setItem("lsbsc_state_v4", JSON.stringify(payload));
  } catch (e) {}
  if (bcChannel) {
    try { bcChannel.postMessage(payload); } catch (e) {}
  }
  const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
  if (pushCloud && targetUrl) {
    fetch(targetUrl, {
      method: "PUT",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    }).then(() => {
      const syncEl = document.getElementById("syncStatusBadge");
      if (syncEl) syncEl.textContent = "● Direct Synchronisé";
    }).catch(() => {});
  }
};

function parseBuvetteCategories(rawText) {
  const lines = (rawText || DEFAULT_BUVETTE_MENU).split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const catMap = new Map();
  lines.forEach(line => {
    const parts = line.split("|").map(s => s.trim());
    if (parts.length >= 3) {
      const [cat, name, price] = parts;
      if (!catMap.has(cat)) catMap.set(cat, []);
      catMap.get(cat).push({ name, price });
    } else if (parts.length === 2) {
      const [name, price] = parts;
      const cat = "Carte Buvette";
      if (!catMap.has(cat)) catMap.set(cat, []);
      catMap.get(cat).push({ name, price });
    }
  });
  return Array.from(catMap.entries()).map(([category, items]) => ({ category, items }));
}

function parseClubInfosList(rawText) {
  const lines = (rawText || DEFAULT_CLUB_INFOS).split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  return lines.map(line => {
    const parts = line.split("|").map(s => s.trim());
    if (parts.length >= 3) {
      return { icon: parts[0] || "🏀", title: parts[1], body: parts.slice(2).join(" | ") };
    } else if (parts.length === 2) {
      return { icon: "🏀", title: parts[0], body: parts[1] };
    }
    return { icon: "ℹ️", title: "Information LSBSC", body: line };
  });
}

function getCategoryIcon(catName) {
  const low = (catName || "").toLowerCase();
  if (low.includes("boisson") || low.includes("café")) return "🥤";
  if (low.includes("snack") || low.includes("chaud") || low.includes("salé")) return "🌭";
  if (low.includes("sucré") || low.includes("crêpe") || low.includes("goûter")) return "🥞";
  if (low.includes("formule") || low.includes("menu")) return "⭐";
  return "🍔";
}

function renderBuvetteAndInfosViews() {
  const buvContainer = document.getElementById("tvBuvetteContainer");
  const infContainer = document.getElementById("tvInfosContainer");
  const mobBuvMirror = document.getElementById("mobileBuvetteMirror");
  const mobInfMirror = document.getElementById("mobileInfosMirror");

  const categories = parseBuvetteCategories(state.buvetteMenuText);
  const categoriesHtml = categories.map(cat => `
    <div class="buvette-cat-card">
      <div class="buvette-cat-title">
        <span>${getCategoryIcon(cat.category)}</span>
        <span>${cat.category}</span>
      </div>
      <div class="buvette-items-list">
        ${cat.items.map(it => `
          <div class="buvette-item-row">
            <span class="buvette-item-name">${it.name}</span>
            <span class="buvette-item-dots"></span>
            <span class="buvette-item-price">${it.price}</span>
          </div>
        `).join("")}
      </div>
    </div>
  `).join("");

  const buvetteFullHtml = `
    <div class="buvette-hero-banner">
      <div class="buvette-hero-left">
        <span class="buvette-hero-icon">🍔</span>
        <div class="buvette-hero-titles">
          <h3>Buvette des Lions — Tarifs & Carte</h3>
          <p>Ouverte pendant toutes les rencontres à domicile • Au profit des jeunes du club</p>
        </div>
      </div>
      <div class="buvette-pay-badges">
        <span class="buvette-pay-pill">💳 CB / SumUp & Espèces</span>
        <span class="buvette-pay-pill">🦁 100% Club LSBSC</span>
      </div>
    </div>
    <div class="buvette-categories-grid">
      ${categoriesHtml}
    </div>
    <div class="buvette-footer-note">
      🙏 Merci pour votre soutien ! Chaque consommation aide à financer les équipements et tournois de nos équipes jeunes.
    </div>
  `;

  if (buvContainer) buvContainer.innerHTML = buvetteFullHtml;
  if (mobBuvMirror) mobBuvMirror.innerHTML = `<div class="buvette-categories-grid" style="margin-top:8px;">${categoriesHtml}</div>`;

  const infoCards = parseClubInfosList(state.clubInfosText);
  const logoSrc = state.clubAssets.logo || FALLBACK_LOGO_B64;
  const mascSrc = state.clubAssets.mascot || FALLBACK_MASCOT_B64;

  const infoCardsHtml = infoCards.map(c => `
    <div class="info-topic-card">
      <div class="info-topic-header">
        <span class="info-topic-icon">${c.icon}</span>
        <span class="info-topic-title">${c.title}</span>
      </div>
      <div class="info-topic-body">${c.body}</div>
    </div>
  `).join("");

  const infosFullHtml = `
    <div class="infos-hero-banner">
      <div class="infos-hero-left">
        <img src="${logoSrc}" onerror="this.src=FALLBACK_LOGO_B64" alt="Logo LSBSC">
        <div class="infos-hero-titles">
          <h3>Informations & Vie du Club LSBSC</h3>
          <p>Lille Sud Basketball Sporting Club • Complexe Sportif Antoine Blondin</p>
        </div>
      </div>
      <img src="${mascSrc}" onerror="this.src=FALLBACK_MASCOT_B64" alt="Mascotte" style="width:clamp(48px,4.2vw,76px);height:clamp(48px,4.2vw,76px);object-fit:contain;">
    </div>
    <div class="infos-cards-grid">
      ${infoCardsHtml}
    </div>
    <div class="buvette-footer-note" style="background:#EFF6FF;border-color:#60A5FA;color:#1E3A8A;">
      📲 Scannez le QR Code affiché à droite de l'écran pour retrouver le programme complet et les adresses GPS sur votre téléphone !
    </div>
  `;

  if (infContainer) infContainer.innerHTML = infosFullHtml;
  if (mobInfMirror) mobInfMirror.innerHTML = `<div class="infos-cards-grid" style="margin-top:8px;">${infoCardsHtml}</div>`;

  // Mettre à jour le libellé de la pastille "Matchs du Week-end" avec le nom de la semaine active
  const wkObj = getWeeksList().find(w => w.wk === state.currentWeek);
  const lblEl = document.getElementById("tvSlideMatchesLabel");
  if (lblEl && wkObj) {
    lblEl.textContent = wkObj.label || "Matchs du Week-end";
  }
}

// Surcharger renderAll pour rafraîchir aussi les vues Buvette & Infos
const _prevRenderAll = renderAll;
renderAll = function() {
  _prevRenderAll();
  renderBuvetteAndInfosViews();
};

// Surcharger openCloudModal et saveCloudAndTicker pour éditer aussi les tarifs Buvette, Infos et Durées TV
window.openCloudModal = function() {
  document.getElementById("inpSyncUrl").value = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
  document.getElementById("inpTickerText").value = state.tickerText || "";
  const buvEl = document.getElementById("inpBuvetteMenu");
  const infEl = document.getElementById("inpClubInfos");
  const dM = document.getElementById("inpDurMatches");
  const dB = document.getElementById("inpDurBuvette");
  const dI = document.getElementById("inpDurInfos");
  if (buvEl) buvEl.value = state.buvetteMenuText || DEFAULT_BUVETTE_MENU;
  if (infEl) infEl.value = state.clubInfosText || DEFAULT_CLUB_INFOS;
  if (dM) dM.value = (state.tvDurations && state.tvDurations.matches) || 18;
  if (dB) dB.value = (state.tvDurations && state.tvDurations.buvette) || 14;
  if (dI) dI.value = (state.tvDurations && state.tvDurations.infos) || 14;
  document.getElementById("cloudModal").classList.add("open");
};

window.saveCloudAndTicker = function() {
  state.syncUrl = document.getElementById("inpSyncUrl").value.trim();
  state.tickerText = document.getElementById("inpTickerText").value.trim() || state.tickerText;
  const buvEl = document.getElementById("inpBuvetteMenu");
  const infEl = document.getElementById("inpClubInfos");
  const dM = document.getElementById("inpDurMatches");
  const dB = document.getElementById("inpDurBuvette");
  const dI = document.getElementById("inpDurInfos");
  if (buvEl && buvEl.value.trim()) state.buvetteMenuText = buvEl.value.trim();
  if (infEl && infEl.value.trim()) state.clubInfosText = infEl.value.trim();
  state.tvDurations = {
    matches: Math.max(8, parseInt(dM ? dM.value : 18, 10) || 18),
    buvette: Math.max(6, parseInt(dB ? dB.value : 14, 10) || 14),
    infos: Math.max(6, parseInt(dI ? dI.value : 14, 10) || 14)
  };
  localStorage.setItem("lsbsc_sync_url", state.syncUrl);
  saveState(true);
  renderAll();
  closeModals();
};

/* ================= MOTEUR DE ROTATION & AUTO-SCROLL VERTICAL FLUIDE (MODE TV) ================= */
const TV_SLIDE_ORDER = ["matches", "buvette", "infos"];
let tvSlideStartTime = performance.now();
let tvScrollPhase = "top_pause"; // 'top_pause' | 'scrolling_down' | 'bottom_pause'
let tvPhaseStartTime = performance.now();
let tvCurrentScrollY = 0;

function getActiveSlideContainer() {
  if (state.tvCurrentSlide === "buvette") return document.getElementById("tvBuvetteContainer");
  if (state.tvCurrentSlide === "infos") return document.getElementById("tvInfosContainer");
  return document.getElementById("matchesListContainer");
}

window.setTvSlide = function(slideName, manualClick = false) {
  if (!TV_SLIDE_ORDER.includes(slideName)) slideName = "matches";
  state.tvCurrentSlide = slideName;

  document.querySelectorAll(".tv-slide-pill").forEach(btn => {
    btn.classList.toggle("active", btn.getAttribute("data-slide") === slideName);
  });

  const mEl = document.getElementById("matchesListContainer");
  const bEl = document.getElementById("tvBuvetteContainer");
  const iEl = document.getElementById("tvInfosContainer");
  if (mEl) mEl.classList.toggle("active-slide", slideName === "matches");
  if (bEl) bEl.classList.toggle("active-slide", slideName === "buvette");
  if (iEl) iEl.classList.toggle("active-slide", slideName === "infos");

  const activeContainer = getActiveSlideContainer();
  if (activeContainer) {
    activeContainer.scrollTop = 0;
  }
  tvCurrentScrollY = 0;
  tvSlideStartTime = performance.now();
  tvPhaseStartTime = performance.now();
  tvScrollPhase = "top_pause";

  const progEl = document.getElementById("tvSlideProgressBar");
  if (progEl) progEl.style.width = "0%";
};

window.toggleTvCarouselPause = function() {
  state.tvCarouselPaused = !state.tvCarouselPaused;
  const btn = document.getElementById("btnToggleTvPause");
  if (btn) {
    btn.innerHTML = state.tvCarouselPaused ? "▶️ Reprendre rotation" : "⏸️ Pause rotation";
    btn.style.background = state.tvCarouselPaused ? "#DCFCE7" : "#FEF3C7";
    btn.style.color = state.tvCarouselPaused ? "#166534" : "#9A3412";
  }
  tvSlideStartTime = performance.now();
  tvPhaseStartTime = performance.now();
};

let lastFrameTime = performance.now();

function stepTvKioskLoop(now) {
  const dt = Math.min(0.1, (now - lastFrameTime) / 1000);
  lastFrameTime = now;

  // Le carrousel et l'auto-scroll ne tournent qu'en Mode TV et si non mis en pause
  const isOverlayOpen = document.getElementById("formatSelectorOverlay")?.classList.contains("open");
  const isAnyModalOpen = document.querySelector(".modal-backdrop.open") !== null;

  if (state.displayMode === "tv" && !state.tvCarouselPaused && !isOverlayOpen && !isAnyModalOpen) {
    const container = getActiveSlideContainer();
    if (container) {
      const maxScroll = Math.max(0, container.scrollHeight - container.clientHeight);
      const baseDurationMs = ((state.tvDurations && state.tvDurations[state.tvCurrentSlide]) || 15) * 1000;
      const topPauseMs = 3500;
      const bottomPauseMs = 3500;
      const scrollSpeedPxPerSec = 36; // Vitesse de défilement vertical douce et lisible à distance

      let progressPct = 0;

      if (maxScroll > 8) {
        // Il y a du contenu à faire défiler verticalement (ex: 9 matchs du week-end)
        const scrollDurationMs = (maxScroll / scrollSpeedPxPerSec) * 1000;
        const totalEffectiveMs = Math.max(baseDurationMs, topPauseMs + scrollDurationMs + bottomPauseMs);

        if (tvScrollPhase === "top_pause") {
          container.scrollTop = 0;
          tvCurrentScrollY = 0;
          if (now - tvPhaseStartTime >= topPauseMs) {
            tvScrollPhase = "scrolling_down";
            tvPhaseStartTime = now;
          }
        } else if (tvScrollPhase === "scrolling_down") {
          tvCurrentScrollY += scrollSpeedPxPerSec * dt;
          if (tvCurrentScrollY >= maxScroll) {
            tvCurrentScrollY = maxScroll;
            container.scrollTop = maxScroll;
            tvScrollPhase = "bottom_pause";
            tvPhaseStartTime = now;
          } else {
            container.scrollTop = tvCurrentScrollY;
          }
        } else if (tvScrollPhase === "bottom_pause") {
          container.scrollTop = maxScroll;
          const elapsedTotal = now - tvSlideStartTime;
          if (now - tvPhaseStartTime >= bottomPauseMs && elapsedTotal >= baseDurationMs) {
            advanceToNextTvSlide();
            requestAnimationFrame(stepTvKioskLoop);
            return;
          }
        }
        progressPct = Math.min(100, ((now - tvSlideStartTime) / totalEffectiveMs) * 100);
      } else {
        // Tout rentre à l'écran sans ascenseur : on attend simplement la durée configurée de la vue
        const elapsed = now - tvSlideStartTime;
        progressPct = Math.min(100, (elapsed / baseDurationMs) * 100);
        if (elapsed >= baseDurationMs) {
          advanceToNextTvSlide();
          requestAnimationFrame(stepTvKioskLoop);
          return;
        }
      }

      const progEl = document.getElementById("tvSlideProgressBar");
      if (progEl) progEl.style.width = `${progressPct.toFixed(1)}%`;
    }
  }

  requestAnimationFrame(stepTvKioskLoop);
}

function advanceToNextTvSlide() {
  const idx = TV_SLIDE_ORDER.indexOf(state.tvCurrentSlide);
  const nextSlide = TV_SLIDE_ORDER[(idx + 1) % TV_SLIDE_ORDER.length];
  window.setTvSlide(nextSlide, false);
}

document.addEventListener("DOMContentLoaded", () => {
  renderBuvetteAndInfosViews();
  window.setTvSlide("matches", false);
  lastFrameTime = performance.now();
  requestAnimationFrame(stepTvKioskLoop);
});


/* ================= CORRECTIFS : PERSISTANCE BOUTONS GPS (TV & MOBILE) + FORÇAGE PLEIN ÉCRAN ================= */

// 1. Surcharger renderMatchesList et renderRightColumn pour que les boutons GPS restent TOUJOURS affichés
// même lorsqu'on clique sur un autre match, qu'on filtre par catégorie/lieu ou qu'on change d'onglet.
const _rawRenderMatchesList = renderMatchesList;
renderMatchesList = function() {
  _rawRenderMatchesList();
  enhanceTvAndAddressesUI();
};

const _rawRenderRightColumn = renderRightColumn;
renderRightColumn = function() {
  _rawRenderRightColumn();
  enhanceTvAndAddressesUI();
};

// 2. Enrichir enhanceTvAndAddressesUI pour ajouter aussi le bouton GPS dans les cartes rapides Mobile (#mobileQuickMatchesCard)
const _prevEnhanceTvAndAddressesUI = enhanceTvAndAddressesUI;
enhanceTvAndAddressesUI = function() {
  _prevEnhanceTvAndAddressesUI();

  // Ajouter le bouton GPS sur chaque match de l'aperçu rapide Mobile (onglet Direct & Suivant)
  const wkMatches = state.matches.filter(m => m.wk === state.currentWeek);
  const mqItems = document.querySelectorAll("#mobileQuickMatchesCard .mq-item");
  mqItems.forEach((item, idx) => {
    const m = wkMatches[idx];
    if (!m) return;
    const info = getMatchVenueInfo(m);
    const mid = item.querySelector(".mq-mid");
    if (mid && !mid.querySelector(".mq-gps-link")) {
      mid.insertAdjacentHTML(
        "beforeend",
        `<a class="mq-gps-link" href="${info.gpsUrl}" target="_blank" rel="noopener" onclick="event.stopPropagation()">📍 ${info.salle} (GPS ↗)</a>`
      );
    }
  });
};

// 3. Forcer l'affichage Plein Écran (Fullscreen API) en Mode TV
window.forceFullScreen = function() {
  const docEl = document.documentElement;
  if (!document.fullscreenElement && !document.webkitFullscreenElement) {
    if (docEl.requestFullscreen) {
      docEl.requestFullscreen().catch(() => {});
    } else if (docEl.webkitRequestFullscreen) {
      docEl.webkitRequestFullscreen();
    } else if (docEl.msRequestFullscreen) {
      docEl.msRequestFullscreen();
    }
  }
};

window.toggleFullScreen = function() {
  if (!document.fullscreenElement && !document.webkitFullscreenElement) {
    window.forceFullScreen();
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen().catch(() => {});
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  }
};

// Déclencher automatiquement le plein écran dès qu'on choisit le Mode TV ou au premier clic sur l'écran TV
const _origChooseDisplayMode = window.chooseDisplayMode;
window.chooseDisplayMode = function(mode) {
  _origChooseDisplayMode(mode);
  if (mode === "tv") {
    window.forceFullScreen();
  }
};

document.addEventListener("click", function(e) {
  // En mode TV passif (hors saisie dans un champ ou clic sur un lien externe), basculer automatiquement en plein écran au premier clic
  if (state.displayMode === "tv" && !document.fullscreenElement && !document.webkitFullscreenElement) {
    const tag = (e.target && e.target.tagName) ? e.target.tagName.toUpperCase() : "";
    if (!["INPUT", "SELECT", "TEXTAREA", "A"].includes(tag) && !e.target.closest("#btnFullscreen")) {
      window.forceFullScreen();
    }
  }
}, { passive: true });

// Ré-appliquer immédiatement au chargement
document.addEventListener("DOMContentLoaded", () => {
  enhanceTvAndAddressesUI();
  if (state.displayMode === "tv") {
    window.forceFullScreen();
  }
});


/* ================= EXTENSION V21 : DÉMARRAGE DIRECT EN MODE TV & CODES PIN PERSONNES DE CONFIANCE ================= */

const DEFAULT_TRUSTED_PINS = [
  { id: "tp_1", name: "Table de marque", pin: "5900" },
  { id: "tp_2", name: "Bénévole / Coach 1", pin: "1111" },
  { id: "tp_3", name: "Bénévole / Coach 2", pin: "2222" }
];

state.pinMaster = "9694";
state.trustedPins = JSON.parse(JSON.stringify(DEFAULT_TRUSTED_PINS));
state.activeStaffName = "";
state.isAdminUser = false;

// 1. Charger les codes PIN de confiance depuis le stockage local
function loadTrustedPinsFromStorage() {
  try {
    const saved = localStorage.getItem("lsbsc_state_v4");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed.trustedPins) && parsed.trustedPins.length > 0) {
        state.trustedPins = parsed.trustedPins;
      }
    }
  } catch (e) {}
}
loadTrustedPinsFromStorage();

// 2. Réactiver la fenêtre de choix de format (TV 16:9 vs Téléphone) au démarrage
function restoreFormatOverlayBehavior() {
  const overlay = document.getElementById("formatSelectorOverlay");
  if (overlay) {
    overlay.style.display = "";
  }
  initDisplayFormatSelection();
}
restoreFormatOverlayBehavior();

window.openFormatOverlay = function() {
  localStorage.removeItem("lsbsc_preferred_format");
  const overlay = document.getElementById("formatSelectorOverlay");
  if (overlay) {
    overlay.style.display = "";
    overlay.classList.add("open");
  }
};

// Navigation par tuiles (4 onglets Mobile : 'live', 'schedule', 'buvette', 'infos')
window.switchMobileTab = function(tabName) {
  state.mobileTab = tabName;
  document.querySelectorAll(".mob-tab").forEach(btn => {
    btn.classList.toggle("active", btn.getAttribute("data-tab") === tabName);
  });
  const secLive = document.getElementById("sectionLive");
  const secSched = document.getElementById("sectionSchedule");
  const secInfos = document.getElementById("sectionMobileInfos");

  if (secLive) secLive.classList.toggle("active-mobile-sec", tabName === "live");
  if (secSched) secSched.classList.toggle("active-mobile-sec", tabName === "schedule");
  if (secInfos) secInfos.classList.toggle("active-mobile-sec", tabName === "buvette" || tabName === "infos");

  // Afficher soit les tuiles Buvette, soit les tuiles Infos Club selon l'onglet touché
  const buvMirror = document.getElementById("mobileBuvetteMirror");
  const infMirror = document.getElementById("mobileInfosMirror");
  const tickerBody = document.getElementById("mobileTickerStaticText");
  const infoTitle = secInfos ? secInfos.querySelector("h3") : null;

  if (tabName === "buvette") {
    if (infoTitle) infoTitle.innerHTML = "🍔 Carte & Tarifs de la Buvette LSBSC";
    if (buvMirror) buvMirror.style.display = "block";
    if (infMirror) infMirror.style.display = "none";
    if (tickerBody) tickerBody.style.display = "none";
  } else if (tabName === "infos") {
    if (infoTitle) infoTitle.innerHTML = "ℹ️ Informations & Vie du Club LSBSC";
    if (buvMirror) buvMirror.style.display = "none";
    if (infMirror) infMirror.style.display = "block";
    if (tickerBody) tickerBody.style.display = "block";
  }
};

// 3. Sauvegarder et synchroniser les codes PIN de confiance avec Firebase & LocalStorage
persistLocalOnly = function() {
  try {
    localStorage.setItem("lsbsc_state_v4", JSON.stringify({
      matches: state.matches,
      tickerText: state.tickerText,
      clubAssets: state.clubAssets,
      buvetteMenuText: state.buvetteMenuText,
      clubInfosText: state.clubInfosText,
      tvDurations: state.tvDurations,
      trustedPins: state.trustedPins,
      updatedAt: state.lastUpdatedAt
    }));
  } catch (e) {}
};

saveState = function(pushCloud = true) {
  const now = Date.now();
  state.lastUpdatedAt = now;
  const payload = {
    matches: state.matches,
    tickerText: state.tickerText,
    clubAssets: state.clubAssets,
    buvetteMenuText: state.buvetteMenuText,
    clubInfosText: state.clubInfosText,
    tvDurations: state.tvDurations,
    trustedPins: state.trustedPins,
    updatedAt: now
  };
  try {
    localStorage.setItem("lsbsc_state_v4", JSON.stringify(payload));
  } catch (e) {}
  if (bcChannel) {
    try { bcChannel.postMessage(payload); } catch (e) {}
  }
  const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
  if (pushCloud && targetUrl) {
    fetch(targetUrl, {
      method: "PUT",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    }).then(() => {
      const syncEl = document.getElementById("syncStatusBadge");
      if (syncEl) syncEl.textContent = "● Direct Synchronisé";
    }).catch(() => {});
  }
};

// Surcharger pollCloudSync pour récupérer aussi les nouveaux codes PIN de confiance mis à jour par l'Admin
pollCloudSync = async function() {
  if (cloudPolling || document.hidden) return;
  const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
  if (!targetUrl) return;
  cloudPolling = true;
  try {
    const light = cloudLightUrl(targetUrl);
    if (light) {
      const r = await fetch(light);
      if (!r.ok) return;
      const ts = await r.json();
      if (typeof ts !== "number" || ts <= state.lastUpdatedAt) return;
    }
    const res = await fetch(targetUrl, { headers: { "Accept": "application/json" } });
    if (!res.ok) return;
    const data = await res.json();
    if (data && Array.isArray(data.matches) && data.updatedAt && data.updatedAt > state.lastUpdatedAt) {
      state.lastUpdatedAt = data.updatedAt;
      state.matches = overlaySchedule(data.matches);
      if (data.tickerText) state.tickerText = data.tickerText;
      if (data.buvetteMenuText) state.buvetteMenuText = data.buvetteMenuText;
      if (data.clubInfosText) state.clubInfosText = data.clubInfosText;
      if (data.tvDurations) state.tvDurations = Object.assign(state.tvDurations, data.tvDurations);
      if (Array.isArray(data.trustedPins)) state.trustedPins = data.trustedPins;
      if (data.clubAssets) state.clubAssets = Object.assign(state.clubAssets, data.clubAssets);
      persistLocalOnly();
      renderAll();
    }
  } catch (e) {
  } finally {
    cloudPolling = false;
  }
};

// 4. Vérification multi-PIN : Code Maître Admin (9694) vs Codes PIN Personnes de Confiance
window.requestPinAccess = function(target) {
  if (target === "staff" && state.staffUnlocked) {
    state.staffUnlocked = false;
    state.isAdminUser = false;
    state.activeStaffName = "";
    renderAll();
    return;
  }
  // Si l'utilisateur est déjà connecté en tant qu'Admin Maître (9694), ouvrir directement les fenêtres de réglages ou logos
  if ((target === "settings" || target === "logos") && state.staffUnlocked && state.isAdminUser) {
    if (target === "logos") {
      state.logosUnlocked = true;
      openLogosManagerModal();
    } else {
      openCloudModal();
    }
    return;
  }

  state.pinTarget = target;
  state.pinBuffer = "";
  const titleEl = document.getElementById("pinModalTitle");
  if (target === "logos") {
    titleEl.textContent = "🛡️ Code Admin Requis — Logos & Mascotte";
  } else if (target === "settings") {
    titleEl.textContent = "⚙️ Code Admin Requis — Réglages & Buvette";
  } else {
    titleEl.textContent = "🔒 Code PIN — Direct / Scores (Staff ou Admin)";
  }
  document.getElementById("pinDisplayBox").textContent = "";
  document.getElementById("pinModal").classList.add("open");
};

window.pressPinDigit = function(d) {
  if (d === "C") {
    state.pinBuffer = "";
  } else if (d === "OK") {
    verifyMultiUserPinCode();
    return;
  } else if (state.pinBuffer.length < 6) {
    state.pinBuffer += String(d);
  }
  document.getElementById("pinDisplayBox").textContent = "•".repeat(state.pinBuffer.length);

  // Vérification automatique dès que le code saisi correspond à un code à 4 chiffres connu
  if (state.pinBuffer.length >= 4) {
    const code = state.pinBuffer;
    const isAdminMatch = (code === state.pinMaster);
    const isTrustedMatch = (state.pinTarget === "staff") && (state.trustedPins || []).some(u => String(u.pin).trim() === code);
    if (isAdminMatch || isTrustedMatch || state.pinBuffer.length === 4) {
      setTimeout(verifyMultiUserPinCode, 120);
    }
  }
};

function verifyMultiUserPinCode() {
  const code = (state.pinBuffer || "").trim();
  if (!code) return;

  // Pour Logos et Réglages/Buvette : seul le code Admin Maître (9694) est autorisé
  if (state.pinTarget === "logos" || state.pinTarget === "settings") {
    if (code === state.pinMaster) {
      state.staffUnlocked = true;
      state.isAdminUser = true;
      state.activeStaffName = "Admin";
      document.getElementById("pinModal").classList.remove("open");
      renderAll();
      if (state.pinTarget === "logos") {
        state.logosUnlocked = true;
        openLogosManagerModal();
      } else {
        openCloudModal();
      }
      return;
    }
  } else {
    // Pour Direct / Scores : accepte soit le code Admin Maître (9694), soit le code PIN d'une personne de confiance
    if (code === state.pinMaster) {
      state.staffUnlocked = true;
      state.isAdminUser = true;
      state.activeStaffName = "Admin";
      document.getElementById("pinModal").classList.remove("open");
      renderAll();
      if (state.displayMode === "mobile") switchMobileTab("live");
      return;
    }

    const trustedUser = (state.trustedPins || []).find(u => String(u.pin).trim() === code);
    if (trustedUser) {
      state.staffUnlocked = true;
      state.isAdminUser = false;
      state.activeStaffName = trustedUser.name || "Staff";
      document.getElementById("pinModal").classList.remove("open");
      renderAll();
      if (state.displayMode === "mobile") switchMobileTab("live");
      return;
    }
  }

  // Code erroné
  const box = document.getElementById("pinDisplayBox");
  if (box) {
    box.style.borderColor = "#DC2626";
    box.textContent = "CODE ERRONÉ";
    state.pinBuffer = "";
    setTimeout(() => {
      box.style.borderColor = "#CBD5E1";
      box.textContent = "";
    }, 900);
  }
}

// Afficher le nom de la personne de confiance connectée sur le bouton en haut de l'écran
const _prevRenderHeaderAndTicker = renderHeaderAndTicker;
renderHeaderAndTicker = function() {
  _prevRenderHeaderAndTicker();
  const staffBtn = document.getElementById("btnStaffToggle");
  if (staffBtn) {
    if (state.staffUnlocked) {
      staffBtn.classList.add("unlocked");
      const label = state.activeStaffName ? `🔓 Direct : ${state.activeStaffName}` : "🔓 Staff Actif";
      staffBtn.innerHTML = label;
    } else {
      staffBtn.classList.remove("unlocked");
      staffBtn.innerHTML = "🔒 Direct / Scores";
    }
  }
};

// Tracer le nom de la personne de confiance qui met à jour un score
function stampMatchScorer(matchId) {
  const m = state.matches.find(x => x.id === matchId);
  if (m && state.activeStaffName) {
    m.updatedBy = state.activeStaffName;
  }
}

const _prevUpdateLivePoints = window.updateLivePoints;
window.updateLivePoints = function(id, side, delta) {
  stampMatchScorer(id);
  _prevUpdateLivePoints(id, side, delta);
};

const _prevSaveMatchScore = window.saveMatchScore;
window.saveMatchScore = function(id, newStatus) {
  stampMatchScorer(id);
  _prevSaveMatchScore(id, newStatus);
};

// 5. Interface de gestion des codes PIN Personnes de Confiance dans la modale Réglages & Buvette (⚙️)
function renderTrustedPinsManager() {
  const container = document.getElementById("trustedPinsListContainer");
  if (!container) return;
  if (!Array.isArray(state.trustedPins) || state.trustedPins.length === 0) {
    container.innerHTML = `<div style="font-size:0.78rem;color:#64748B;font-weight:700;padding:6px;">Aucun code PIN secondaire configuré.</div>`;
    return;
  }
  container.innerHTML = state.trustedPins.map((u, idx) => `
    <div class="trusted-pin-row">
      <div class="trusted-pin-info">
        <span style="font-size:1rem;">👤</span>
        <input type="text" value="${(u.name || "").replace(/"/g, "&quot;")}" onchange="updateTrustedPinEntry(${idx}, 'name', this.value)" style="flex:1;padding:5px 8px;border:1px solid #CBD5E1;border-radius:6px;font-size:0.82rem;font-weight:800;color:#0F172A;" title="Nom de la personne de confiance">
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="font-size:0.72rem;font-weight:800;color:#475569;">PIN :</span>
        <input type="text" class="trusted-pin-input-edit" inputmode="numeric" maxlength="6" value="${(u.pin || "").replace(/"/g, "&quot;")}" onchange="updateTrustedPinEntry(${idx}, 'pin', this.value)" title="Modifier le code PIN">
        <button type="button" class="btn-action-sm" style="background:#FEE2E2;color:#B91C1C;padding:5px 8px;" onclick="removeTrustedPinUser(${idx})" title="Supprimer cet accès">🗑️</button>
      </div>
    </div>
  `).join("");
}

window.updateTrustedPinEntry = function(idx, field, val) {
  if (!state.trustedPins || !state.trustedPins[idx]) return;
  const clean = (val || "").trim();
  if (!clean) return;
  if (field === "pin" && !/^\d{4,6}$/.test(clean)) {
    alert("Le code PIN doit contenir entre 4 et 6 chiffres.");
    renderTrustedPinsManager();
    return;
  }
  state.trustedPins[idx][field] = clean;
  saveState(true);
  renderTrustedPinsManager();
};

window.addTrustedPinUser = function() {
  const nameInp = document.getElementById("inpNewTrustedName");
  const pinInp = document.getElementById("inpNewTrustedPin");
  const name = nameInp ? nameInp.value.trim() : "";
  const pin = pinInp ? pinInp.value.trim() : "";

  if (!name) {
    alert("Veuillez indiquer le prénom ou le rôle de la personne de confiance (ex : Sarah, Noah, Coach U13...).");
    return;
  }
  if (!/^\d{4,6}$/.test(pin)) {
    alert("Veuillez saisir un code PIN de 4 à 6 chiffres (ex : 1234).");
    return;
  }
  if (pin === state.pinMaster || (state.trustedPins || []).some(u => String(u.pin).trim() === pin)) {
    alert("Ce code PIN est déjà utilisé. Choisissez un code différent.");
    return;
  }

  if (!Array.isArray(state.trustedPins)) state.trustedPins = [];
  state.trustedPins.push({
    id: "tp_" + Date.now(),
    name: name,
    pin: pin
  });

  if (nameInp) nameInp.value = "";
  if (pinInp) pinInp.value = "";
  saveState(true);
  renderTrustedPinsManager();
};

window.removeTrustedPinUser = function(idx) {
  if (!state.trustedPins || !state.trustedPins[idx]) return;
  const target = state.trustedPins[idx];
  if (confirm(`Supprimer l'accès Direct / Scores de « ${target.name} » (PIN ${target.pin}) ?`)) {
    state.trustedPins.splice(idx, 1);
    saveState(true);
    renderTrustedPinsManager();
  }
};

// Surcharger openCloudModal pour afficher la liste des codes PIN de confiance à chaque ouverture
const _prevOpenCloudModal = window.openCloudModal;
window.openCloudModal = function() {
  _prevOpenCloudModal();
  renderTrustedPinsManager();
};

document.addEventListener("DOMContentLoaded", () => {
  restoreFormatOverlayBehavior();
  loadTrustedPinsFromStorage();
  renderAll();
});


/* ================= EXTENSION V23 : TUILE SÉLECTION D'ÉQUIPE & TOUS SES MATCHS (PASSÉS / À VENIR) SUR MOBILE ================= */

const LSBSC_TEAMS_CATALOG = [
  { cat: "U9",   short: "U9 Mixte",       fullName: "U9 Mixte Mini-Poussins" },
  { cat: "U11F", short: "U11F Poussines", fullName: "U11 Filles Poussines" },
  { cat: "U13F", short: "U13F Benjamines",fullName: "U13 Filles Benjamines" },
  { cat: "U15F", short: "U15F Minimes",   fullName: "U15 Filles Minimes" },
  { cat: "U15M", short: "U15M Minimes G", fullName: "U15 Garçons Minimes" },
  { cat: "U18F", short: "U18F Cadettes",  fullName: "U18 Filles Cadettes" },
  { cat: "U18M", short: "U18M Cadets",    fullName: "U18 Garçons Cadets" },
  { cat: "SM1",  short: "Seniors M1",     fullName: "Seniors Masculins 1" },
  { cat: "SM2",  short: "Seniors M2",     fullName: "Seniors Masculins 2" }
];

state.mobileSelectedTeamCat = localStorage.getItem("lsbsc_mob_selected_team") || "";
state.mobileTeamTimeFilter = "ALL"; // 'ALL' | 'UPCOMING' | 'PAST'
state.mobileTeamGridCollapsed = false;

window.selectMobileTeam = function(catCode) {
  state.mobileSelectedTeamCat = catCode || "";
  if (catCode) {
    localStorage.setItem("lsbsc_mob_selected_team", catCode);
    state.mobileTeamGridCollapsed = true;
  } else {
    localStorage.removeItem("lsbsc_mob_selected_team");
    state.mobileTeamGridCollapsed = false;
  }
  const tabLbl = document.getElementById("mobTabTeamsLbl");
  if (tabLbl) {
    tabLbl.textContent = catCode ? `Équipe ${catCode}` : "Sélection Équipe";
  }
  renderMobileTeamsSection();
  setTimeout(() => {
    const banner = document.getElementById("mobSelectedTeamAnchor");
    if (banner && catCode) {
      banner.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, 60);
};

window.toggleMobileTeamGrid = function() {
  state.mobileTeamGridCollapsed = !state.mobileTeamGridCollapsed;
  renderMobileTeamsSection();
};

window.setMobileTeamTimeFilter = function(filterMode) {
  state.mobileTeamTimeFilter = filterMode || "ALL";
  renderMobileTeamsSection();
};

function renderSingleMobileMatchTile(m) {
  const outcome = computeMatchOutcome(m);
  const homeUs = isLSBSC(m.home);
  const awayUs = isLSBSC(m.away);
  const info = getMatchVenueInfo(m);

  let scoreHtml = "";
  let tagHtml = "";

  if (m.status === "postponed") {
    scoreHtml = `<div class="score-pill postponed">📅 REPORTÉ</div>`;
    tagHtml = `<span class="res-tag postponed">${m.statusNote || "Date à fixer"}</span>`;
  } else if (m.status === "forfeit") {
    const hasScore = (m.sh || 0) > 0 || (m.sa || 0) > 0;
    const pillCls = outcome === "win" ? "forfeit-win" : (outcome === "loss" ? "forfeit-loss" : "forfeit");
    scoreHtml = `<div class="score-pill ${pillCls}">${hasScore ? (m.sh + " - " + m.sa) : "FORFAIT"}</div>`;
    tagHtml = `<span class="res-tag forfeit">${m.statusNote || "Forfait officiel"}</span>`;
  } else if (m.status === "finished") {
    const lbl = outcome === "win" ? "✅ Victoire LSBSC" : (outcome === "loss" ? "❌ Défaite" : "🤝 Égalité");
    scoreHtml = `<div class="score-pill ${outcome}">${m.sh} - ${m.sa}</div>`;
    tagHtml = `<span class="res-tag ${outcome}">${lbl}</span>`;
  } else if (m.status === "live") {
    scoreHtml = `<div class="score-pill live">${m.sh} - ${m.sa}</div>`;
    tagHtml = `<span class="res-tag live">🔴 EN DIRECT (${m.period || "QT1"})</span>`;
  } else {
    scoreHtml = `<div class="score-pill upcoming">${m.time}</div>`;
    tagHtml = `<span class="res-tag" style="color:#1E3A8A;">🕒 À venir</span>`;
  }

  const locBadge = homeUs
    ? `<span style="background:#DCFCE7;color:#166534;font-size:0.75rem;font-weight:900;padding:3px 8px;border-radius:6px;border:1px solid #86EFAC;">🏠 Domicile</span>`
    : `<span style="background:#FEF3C7;color:#9A3412;font-size:0.75rem;font-weight:900;padding:3px 8px;border-radius:6px;border:1px solid #FDE68A;">🚌 Extérieur</span>`;

  const staffRowBtn = state.staffUnlocked
    ? `<div class="row-staff-actions">
         <button class="btn-row-edit" style="background:#EA580C;" onclick="event.stopPropagation();startLiveMatch(${m.id})">🏀 Direct</button>
         <button class="btn-row-edit" onclick="event.stopPropagation();selectMatchForEdit(${m.id})">✏️ Score</button>
         <button class="btn-row-edit" style="background:#1E3A8A;" onclick="event.stopPropagation();openMatchSheetModal(${m.id})">📍 Fiche</button>
       </div>`
    : "";

  return `
    <div class="match-row ${m.status === "live" ? "live-match" : ""}" onclick="selectMatch(${m.id})">
      <div class="m-meta">
        <span class="m-date">📅 ${m.date} (${m.wkShort || ""})</span>
        <span class="m-time">⏰ ${m.time}</span>
        ${locBadge}
      </div>
      <div class="m-team home">
        <span class="team-name-txt ${homeUs ? "is-lsbsc" : ""}">${m.home}</span>
        <img class="club-badge-sm" src="${getTeamBadgeSrc(m.home)}" onerror="this.src=FALLBACK_LOGO_B64" alt="">
      </div>
      <div class="m-score-center">
        ${scoreHtml}
        ${tagHtml}
        <a class="m-address-sub" href="${info.gpsUrl}" target="_blank" rel="noopener" onclick="event.stopPropagation()">📍 ${info.salle} (GPS ↗)</a>
        ${info.precision ? `<span class="m-precision-tag">📌 ${info.precision}</span>` : ""}
      </div>
      <div class="m-team away">
        <img class="club-badge-sm" src="${getTeamBadgeSrc(m.away)}" onerror="this.src=FALLBACK_LOGO_B64" alt="">
        <span class="team-name-txt ${awayUs ? "is-lsbsc" : ""}">${m.away}</span>
      </div>
      ${staffRowBtn}
    </div>
  `;
}

function renderMobileTeamsSection() {
  const container = document.getElementById("mobileTeamsViewContainer");
  if (!container) return;

  const tabLbl = document.getElementById("mobTabTeamsLbl");
  if (tabLbl) {
    tabLbl.textContent = state.mobileSelectedTeamCat ? `Équipe ${state.mobileSelectedTeamCat}` : "Sélection Équipe";
  }

  const tilesHtml = LSBSC_TEAMS_CATALOG.map(t => {
    const teamMatches = state.matches.filter(m => m.cat === t.cat);
    let w = 0, l = 0;
    teamMatches.forEach(m => {
      const out = computeMatchOutcome(m);
      if (out === "win") w++;
      else if (out === "loss") l++;
    });
    const isSelected = state.mobileSelectedTeamCat === t.cat;
    return `
      <button type="button" class="mob-team-tile ${isSelected ? "active-team-tile" : ""}" onclick="selectMobileTeam('${t.cat}')">
        <div class="mob-team-tile-top">
          <span class="mob-team-cat-badge">${t.cat}</span>
          <span class="mob-team-record">${w}V - ${l}D</span>
        </div>
        <div class="mob-team-full-name">${t.fullName}</div>
        <div style="font-size:0.74rem;font-weight:800;opacity:0.85;">📅 ${teamMatches.length} matchs (passés & à venir)</div>
      </button>
    `;
  }).join("");

  const selectedTeamObj = LSBSC_TEAMS_CATALOG.find(t => t.cat === state.mobileSelectedTeamCat);

  let teamHistoryHtml = "";
  if (selectedTeamObj) {
    const allTeamMatches = state.matches.filter(m => m.cat === selectedTeamObj.cat);
    const upcomingMatches = allTeamMatches.filter(m => m.status !== "finished" && m.status !== "forfeit");
    const pastMatches = allTeamMatches.filter(m => m.status === "finished" || m.status === "forfeit").slice().reverse();

    let wins = 0, losses = 0;
    allTeamMatches.forEach(m => {
      const out = computeMatchOutcome(m);
      if (out === "win") wins++;
      else if (out === "loss") losses++;
    });

    const showUpcoming = state.mobileTeamTimeFilter === "ALL" || state.mobileTeamTimeFilter === "UPCOMING";
    const showPast = state.mobileTeamTimeFilter === "ALL" || state.mobileTeamTimeFilter === "PAST";

    const upcomingSectionHtml = showUpcoming ? `
      <div class="mob-section-divider">
        <span>🕒 MATCHS À VENIR & EN DIRECT</span>
        <span>${upcomingMatches.length} match${upcomingMatches.length > 1 ? "s" : ""}</span>
      </div>
      ${upcomingMatches.length > 0
        ? `<div class="matches-list">${upcomingMatches.map(renderSingleMobileMatchTile).join("")}</div>`
        : `<div style="background:#FFFFFF;border-radius:14px;padding:16px;text-align:center;font-weight:800;color:#64748B;border:1.5px solid #CBD5E1;">Aucun match à venir programmé pour ${selectedTeamObj.cat}.</div>`
      }
    ` : "";

    const pastSectionHtml = showPast ? `
      <div class="mob-section-divider past-div">
        <span>✅ MATCHS PASSÉS (RÉSULTATS)</span>
        <span>${pastMatches.length} joué${pastMatches.length > 1 ? "s" : ""}</span>
      </div>
      ${pastMatches.length > 0
        ? `<div class="matches-list">${pastMatches.map(renderSingleMobileMatchTile).join("")}</div>`
        : `<div style="background:#FFFFFF;border-radius:14px;padding:16px;text-align:center;font-weight:800;color:#64748B;border:1.5px solid #CBD5E1;">Aucun match terminé pour ${selectedTeamObj.cat}.</div>`
      }
    ` : "";

    teamHistoryHtml = `
      <div id="mobSelectedTeamAnchor" class="mob-selected-team-banner">
        <div class="mob-st-top">
          <div>
            <div class="mob-st-title">🏀 ${selectedTeamObj.fullName} (${selectedTeamObj.cat})</div>
            <div class="mob-st-sub">Saison complète : ${allTeamMatches.length} matchs • Bilan : ${wins} Victoire${wins > 1 ? "s" : ""} / ${losses} Défaite${losses > 1 ? "s" : ""}</div>
          </div>
          <button type="button" class="btn-action-sm" style="background:#FEF3C7;color:#0F172A;font-weight:900;padding:8px 12px;border-radius:10px;white-space:nowrap;" onclick="toggleMobileTeamGrid()">
            ${state.mobileTeamGridCollapsed ? "🔄 Changer d'équipe" : "🔼 Masquer les tuiles"}
          </button>
        </div>
        <div class="mob-period-filter-row">
          <button type="button" class="mob-pf-btn ${state.mobileTeamTimeFilter === "ALL" ? "active" : ""}" onclick="setMobileTeamTimeFilter('ALL')">
            📋 Tous (${allTeamMatches.length})
          </button>
          <button type="button" class="mob-pf-btn ${state.mobileTeamTimeFilter === "UPCOMING" ? "active" : ""}" onclick="setMobileTeamTimeFilter('UPCOMING')">
            🕒 À venir (${upcomingMatches.length})
          </button>
          <button type="button" class="mob-pf-btn ${state.mobileTeamTimeFilter === "PAST" ? "active" : ""}" onclick="setMobileTeamTimeFilter('PAST')">
            ✅ Passés (${pastMatches.length})
          </button>
        </div>
      </div>
      ${upcomingSectionHtml}
      ${pastSectionHtml}
    `;
  } else {
    teamHistoryHtml = `
      <div style="background:#FFFFFF;border:2px dashed #93C5FD;border-radius:16px;padding:18px;text-align:center;color:#1E3A8A;font-weight:900;font-size:0.95rem;">
        👆 Touchez une équipe ci-dessus pour afficher tous ses matchs passés et à venir !
      </div>
    `;
  }

  const showGrid = !selectedTeamObj || !state.mobileTeamGridCollapsed;

  container.innerHTML = `
    ${showGrid ? `
      <div class="mob-team-selector-card">
        <div class="mob-team-selector-title">
          <h3>🏀 Sélectionnez votre équipe LSBSC</h3>
          <span style="font-size:0.76rem;font-weight:900;color:#EA580C;background:#FFF7ED;padding:4px 8px;border-radius:8px;border:1px solid #FDBA74;">9 Équipes</span>
        </div>
        <div class="mob-team-tiles-grid">
          ${tilesHtml}
        </div>
      </div>
    ` : ""}
    ${teamHistoryHtml}
  `;
}

// Surcharger switchMobileTab pour gérer l'onglet 'teams' (Sélection Équipe) placé juste à côté de 'live' (Direct)
window.switchMobileTab = function(tabName) {
  if (tabName === "schedule") tabName = "teams";
  state.mobileTab = tabName;
  document.querySelectorAll(".mob-tab").forEach(btn => {
    btn.classList.toggle("active", btn.getAttribute("data-tab") === tabName);
  });

  const secLive = document.getElementById("sectionLive");
  const secSched = document.getElementById("sectionSchedule");
  const secTeams = document.getElementById("sectionMobileTeams");
  const secInfos = document.getElementById("sectionMobileInfos");

  if (secLive) secLive.classList.toggle("active-mobile-sec", tabName === "live");
  if (secSched) secSched.classList.remove("active-mobile-sec");
  if (secTeams) secTeams.classList.toggle("active-mobile-sec", tabName === "teams");
  if (secInfos) secInfos.classList.toggle("active-mobile-sec", tabName === "buvette" || tabName === "infos");

  if (tabName === "teams") {
    renderMobileTeamsSection();
  }

  const buvMirror = document.getElementById("mobileBuvetteMirror");
  const infMirror = document.getElementById("mobileInfosMirror");
  const tickerBody = document.getElementById("mobileTickerStaticText");
  const infoTitle = secInfos ? secInfos.querySelector("h3") : null;

  if (tabName === "buvette") {
    if (infoTitle) infoTitle.innerHTML = "🍔 Carte & Tarifs de la Buvette LSBSC";
    if (buvMirror) buvMirror.style.display = "block";
    if (infMirror) infMirror.style.display = "none";
    if (tickerBody) tickerBody.style.display = "none";
  } else if (tabName === "infos") {
    if (infoTitle) infoTitle.innerHTML = "ℹ️ Informations & Vie du Club LSBSC";
    if (buvMirror) buvMirror.style.display = "none";
    if (infMirror) infMirror.style.display = "block";
    if (tickerBody) tickerBody.style.display = "block";
  }
};

// Surcharger renderAll pour mettre à jour aussi la vue Équipe Mobile
const _prevRenderAllV22 = renderAll;
renderAll = function() {
  _prevRenderAllV22();
  renderMobileTeamsSection();
};

document.addEventListener("DOMContentLoaded", () => {
  renderMobileTeamsSection();
});




/* ================= EXTENSION V28 : PARTAGE PROPRE (ADRESSE EXACTEMENT MASQUÉE + LIEN GPS COURT ?gps=ID & ?match=ID) & BOUTON PAUSE/LECTURE CARROUSEL ================= */

const OFFICIAL_LSBSC_APP_URL = "https://fabsm59520.github.io/LSBSC-Organisation/";
state.selectedMatchViewTab = "match"; // 'match' | 'share'
state.publicAppUrl = OFFICIAL_LSBSC_APP_URL;

function getAppShareUrl(matchId) {
  const base = OFFICIAL_LSBSC_APP_URL;
  return matchId ? `${base}?match=${encodeURIComponent(matchId)}` : base;
}

function getShortGpsShareUrl(matchId) {
  const base = OFFICIAL_LSBSC_APP_URL;
  return matchId ? `${base}?gps=${encodeURIComponent(matchId)}` : base;
}

// Synchroniser l'état des boutons Pause / Lecture du carrousel (en-tête principal + barre du carrousel)
window.toggleTvCarouselPause = function() {
  state.tvCarouselPaused = !state.tvCarouselPaused;
  updateTvCarouselPauseButtons();
  tvSlideStartTime = performance.now();
  tvPhaseStartTime = performance.now();
};

function updateTvCarouselPauseButtons() {
  const btn1 = document.getElementById("btnToggleTvPause");
  const btn2 = document.getElementById("btnToggleTvPauseTop");
  if (btn1) {
    btn1.innerHTML = state.tvCarouselPaused ? "▶️ Lecture" : "⏸️ Pause";
    btn1.classList.toggle("paused", Boolean(state.tvCarouselPaused));
  }
  if (btn2) {
    btn2.innerHTML = state.tvCarouselPaused ? "▶️ Lecture Carrousel" : "⏸️ Pause Carrousel";
    btn2.classList.toggle("paused", Boolean(state.tvCarouselPaused));
  }
}

// Redirection automatique immédiate vers Google Maps si ?gps=ID est ouvert, ou sélection du match si ?match=ID
function handleIncomingUrlParams() {
  try {
    const params = new URLSearchParams(window.location.search);
    const gpsId = parseInt(params.get("gps"), 10);
    if (gpsId) {
      const targetGps = state.matches.find(m => m.id === gpsId);
      if (targetGps) {
        const info = getMatchVenueInfo(targetGps);
        window.location.replace(info.gpsUrl);
        return;
      }
    }
    const sharedId = parseInt(params.get("match"), 10);
    if (sharedId) {
      const target = state.matches.find(m => m.id === sharedId);
      if (target) {
        state.autoWeek = false;
        state.currentWeek = target.wk;
        state.selectedMatchId = target.id;
        state.selectedMatchViewTab = "match";
        renderAll();
      }
    }
  } catch (e) {}
}

// Génère les informations propres du match : adresse exacte masquée derrière le lien GPS cliquable
function buildMatchSharePayload(m) {
  if (!m) return { subject: "Match LSBSC", plainText: "", htmlText: "", appUrl: OFFICIAL_LSBSC_APP_URL, gpsUrl: "", shortGpsUrl: "" };
  const info = getMatchVenueInfo(m);
  const homeUs = isLSBSC(m.home);
  const locType = homeUs ? "Match à Domicile (Lille Sud)" : "Match à l'Extérieur";
  const outcome = computeMatchOutcome(m);
  const appUrl = getAppShareUrl(m.id);
  const shortGpsUrl = getShortGpsShareUrl(m.id);

  let statusLine = "";
  let subjectPrefix = `[LSBSC ${m.cat}]`;

  if (m.status === "live") {
    statusLine = `EN DIRECT (${m.period || "En cours"}) : ${m.home} ${m.sh} - ${m.sa} ${m.away}`;
    subjectPrefix = `DIRECT [LSBSC ${m.cat}] ${m.home} ${m.sh}-${m.sa} ${m.away}`;
  } else if (m.status === "finished") {
    const resLbl = outcome === "win" ? "VICTOIRE LSBSC" : (outcome === "loss" ? "DÉFAITE" : "MATCH NUL");
    statusLine = `RÉSULTAT FINAL (${resLbl}) : ${m.home} ${m.sh} - ${m.sa} ${m.away}`;
    subjectPrefix = `RÉSULTAT [LSBSC ${m.cat}] ${m.home} ${m.sh}-${m.sa} ${m.away}`;
  } else if (m.status === "postponed") {
    statusLine = `MATCH REPORTÉ (${m.statusNote || "Nouvelle date à fixer"})`;
    subjectPrefix = `REPORTÉ [LSBSC ${m.cat}] ${m.home} vs ${m.away}`;
  } else if (m.status === "forfeit") {
    statusLine = `MATCH FORFAIT (${m.statusNote || "Forfait officiel"})`;
    subjectPrefix = `FORFAIT [LSBSC ${m.cat}] ${m.home} vs ${m.away}`;
  } else {
    statusLine = `RENCONTRE À VENIR — Coup d'envoi à ${m.time}`;
    subjectPrefix = `MATCH [LSBSC ${m.cat}] ${m.date} à ${m.time}`;
  }

  // 1. Version HTML riche (E-mail, Word, Messageries) : adresse exacte et URLs totalement masquées derrière les liens cliquables
  const htmlParts = [
    `<div style="font-family:Arial,sans-serif;line-height:1.5;color:#0F172A;">`,
    `<strong>LILLE SUD BASKETBALL SPORTING CLUB (LSBSC)</strong><br>`,
    `<strong>Catégorie :</strong> ${m.cat} (${m.comp || "Champ."}) — ${locType}<br><br>`,
    `<strong style="font-size:1.05em;color:#1E3A8A;">${m.home} vs ${m.away}</strong><br>`,
    `<strong>Date :</strong> ${m.date} à ${m.time} (${m.wkLabel || ""})<br>`,
    `<strong>Statut :</strong> ${statusLine}<br><br>`,
    `<strong>Lieu :</strong> <a href="${info.gpsUrl}" target="_blank" rel="noopener" style="color:#1D4ED8;font-weight:bold;text-decoration:underline;">Itinéraire Google Maps (${info.salle})</a><br>`,
    info.precision ? `<strong>Précisions :</strong> ${info.precision}<br>` : ``,
    `<br><strong>Direct & Résultats :</strong> <a href="${appUrl}" target="_blank" rel="noopener" style="color:#EA580C;font-weight:bold;text-decoration:underline;">Application LSBSC</a>`,
    `</div>`
  ];

  // 2. Version Texte universelle (WhatsApp & SMS) : adresse exacte masquée, remplacée par le lien court ?gps=ID
  const plainLines = [
    `*LILLE SUD BASKETBALL SPORTING CLUB (LSBSC)*`,
    `• Catégorie : ${m.cat} (${m.comp || "Champ."}) — ${locType}`,
    ``,
    `*${m.home}  VS  ${m.away}*`,
    `• Date : ${m.date} à ${m.time} (${m.wkLabel || ""})`,
    `• ${statusLine}`,
    ``,
    `• Itinéraire GPS (${info.salle}) :`,
    `${shortGpsUrl}`
  ];

  if (info.precision) {
    plainLines.push(`• Précisions : ${info.precision}`);
  }

  plainLines.push(
    ``,
    `• Direct & Résultats — Application LSBSC :`,
    `${appUrl}`
  );

  return {
    subject: subjectPrefix,
    plainText: plainLines.join("\n"),
    htmlText: htmlParts.join(""),
    appUrl: appUrl,
    gpsUrl: info.gpsUrl,
    shortGpsUrl: shortGpsUrl,
    info: info
  };
}

window.switchSelectedMatchTab = function(tabName) {
  state.selectedMatchViewTab = tabName === "share" ? "share" : "match";
  const btnMatch = document.getElementById("btnSbTabMatch");
  const btnShare = document.getElementById("btnSbTabShare");
  const arenaWrap = document.getElementById("sbArenaMainWrap");
  const shareWrap = document.getElementById("sbShareTabWrap");

  if (btnMatch) btnMatch.classList.toggle("active", state.selectedMatchViewTab === "match");
  if (btnShare) btnShare.classList.toggle("active", state.selectedMatchViewTab === "share");

  if (arenaWrap) arenaWrap.style.display = state.selectedMatchViewTab === "match" ? "flex" : "none";
  if (shareWrap) {
    shareWrap.style.display = state.selectedMatchViewTab === "share" ? "flex" : "none";
    if (state.selectedMatchViewTab === "share") {
      renderSelectedMatchShareTab();
    }
  }
};

window.openShareTabForMatch = function(matchId) {
  state.selectedMatchId = matchId;
  state.selectedMatchViewTab = "share";
  renderAll();
  if (state.displayMode === "mobile") {
    switchMobileTab("live");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  window.switchSelectedMatchTab("share");
};

function renderSelectedMatchShareTab() {
  const shareWrap = document.getElementById("sbShareTabWrap");
  if (!shareWrap) return;
  const current = state.matches.find(m => m.id === state.selectedMatchId) || state.matches[0];
  if (!current) return;

  const payload = buildMatchSharePayload(current);
  const info = payload.info;
  const homeUs = isLSBSC(current.home);
  const locBadge = homeUs ? "🏠 Match à Domicile (Lille Sud)" : "🚌 Match à l'Extérieur";
  const outcome = computeMatchOutcome(current);

  let statusBadgeHtml = "";
  if (current.status === "live") {
    statusBadgeHtml = `<span style="color:#EA580C;font-weight:900;">🔴 EN DIRECT (${current.period || "QT1"}) : ${current.sh} - ${current.sa}</span>`;
  } else if (current.status === "finished") {
    const resTxt = outcome === "win" ? "✅ VICTOIRE LSBSC" : (outcome === "loss" ? "❌ DÉFAITE" : "🤝 ÉGALITÉ");
    statusBadgeHtml = `<span style="color:#15803D;font-weight:900;">${resTxt} — Score final : ${current.sh} - ${current.sa}</span>`;
  } else {
    statusBadgeHtml = `<span style="color:#1E3A8A;font-weight:900;">🕒 Coup d'envoi à ${current.time}</span>`;
  }

  const encodedText = encodeURIComponent(payload.plainText);
  const encodedSubject = encodeURIComponent(payload.subject);
  const encodedUrl = encodeURIComponent(payload.appUrl);

  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent || "");
  const smsUrl = isIOS ? `sms:&body=${encodedText}` : `sms:?body=${encodedText}`;
  const mailtoUrl = `mailto:?subject=${encodedSubject}&body=${encodedText}`;
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`;

  shareWrap.innerHTML = `
    <div class="share-preview-card">
      <div class="share-preview-header">
        <strong>📋 Fiche de Partage — ${current.cat} (${locBadge})</strong>
        <button type="button" id="btnCopyShareInline" class="btn-action-sm" style="background:#1E3A8A;color:#FFF;" onclick="copyMatchShareText(${current.id})">
          📋 Copier Fiche & Liens
        </button>
      </div>

      <div class="share-clean-box">
        <div class="share-clean-club">🦁 Lille Sud Basketball Sporting Club (LSBSC) • ${current.cat} (${current.comp || "Champ."})</div>
        <div class="share-clean-matchup">${current.home} &nbsp;VS&nbsp; ${current.away}</div>
        <div class="share-clean-meta">
          <div>📅 <strong>Date :</strong> ${current.date} à ${current.time} (${current.wkLabel || ""})</div>
          <div>📊 <strong>Statut :</strong> ${statusBadgeHtml}</div>
          <div>🏟️ <strong>Salle :</strong> ${info.salle}</div>
          ${info.precision ? `<div>📌 <strong>Précisions :</strong> ${info.precision}</div>` : ""}
        </div>
        <div class="share-clean-links-row">
          <a class="share-clean-link" href="${info.gpsUrl}" target="_blank" rel="noopener">
            📍 Itinéraire Google Maps (${info.salle}) ↗
          </a>
          <a class="share-clean-link app-link" href="${payload.appUrl}" target="_blank" rel="noopener">
            📲 Application LSBSC ↗
          </a>
        </div>
      </div>
    </div>

    <div class="share-tiles-grid">
      <button type="button" class="share-tile-btn sh-native" onclick="triggerNativeMatchShare(${current.id})">
        <span class="share-tile-ico">📲</span>
        <span>Partager (Réseaux / Menu Téléphone)</span>
      </button>

      <a class="share-tile-btn sh-whatsapp" href="${whatsappUrl}" target="_blank" rel="noopener">
        <span class="share-tile-ico">💬</span>
        <span>WhatsApp</span>
      </a>

      <a class="share-tile-btn sh-sms" href="${smsUrl}">
        <span class="share-tile-ico">✉️</span>
        <span>SMS / Message</span>
      </a>

      <a class="share-tile-btn sh-mail" href="${mailtoUrl}">
        <span class="share-tile-ico">📧</span>
        <span>E-mail</span>
      </a>

      <a class="share-tile-btn sh-facebook" href="${facebookUrl}" target="_blank" rel="noopener">
        <span class="share-tile-ico">📘</span>
        <span>Facebook</span>
      </a>

      <button type="button" id="btnCopyShareTile" class="share-tile-btn sh-copy" onclick="copyMatchShareText(${current.id})">
        <span class="share-tile-ico">📋</span>
        <span>Copier avec Liens Cachés</span>
      </button>
    </div>
  `;
}

window.triggerNativeMatchShare = async function(matchId) {
  const m = state.matches.find(x => x.id === matchId) || state.matches.find(x => x.id === state.selectedMatchId);
  if (!m) return;
  const payload = buildMatchSharePayload(m);
  if (navigator.share) {
    try {
      await navigator.share({
        title: payload.subject,
        text: payload.plainText,
        url: payload.appUrl
      });
      return;
    } catch (err) {
      if (err && err.name === "AbortError") return;
    }
  }
  window.copyMatchShareText(m.id);
};

window.copyMatchShareText = function(matchId) {
  const m = state.matches.find(x => x.id === matchId) || state.matches.find(x => x.id === state.selectedMatchId);
  if (!m) return;
  const payload = buildMatchSharePayload(m);

  const confirmCopied = () => {
    const b1 = document.getElementById("btnCopyShareInline");
    const b2 = document.getElementById("btnCopyShareTile");
    if (b1) {
      b1.textContent = "✅ Copié !";
      b1.style.background = "#16A34A";
    }
    if (b2) {
      b2.innerHTML = `<span class="share-tile-ico">✅</span><span>Copié !</span>`;
      b2.style.background = "#16A34A";
    }
    setTimeout(() => {
      renderSelectedMatchShareTab();
    }, 1800);
  };

  if (navigator.clipboard && window.ClipboardItem) {
    try {
      const htmlBlob = new Blob([payload.htmlText], { type: "text/html" });
      const textBlob = new Blob([payload.plainText], { type: "text/plain" });
      const item = new ClipboardItem({ "text/html": htmlBlob, "text/plain": textBlob });
      navigator.clipboard.write([item]).then(confirmCopied).catch(() => {
        navigator.clipboard.writeText(payload.plainText).then(confirmCopied).catch(() => {
          fallbackCopyText(payload.plainText, confirmCopied);
        });
      });
      return;
    } catch (e) {}
  }

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(payload.plainText).then(confirmCopied).catch(() => {
      fallbackCopyText(payload.plainText, confirmCopied);
    });
  } else {
    fallbackCopyText(payload.plainText, confirmCopied);
  }
};

function fallbackCopyText(txt, cb) {
  const ta = document.createElement("textarea");
  ta.value = txt;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand("copy"); } catch (e) {}
  document.body.removeChild(ta);
  if (cb) cb();
}

const _prevRenderRightColumnV24 = renderRightColumn;
renderRightColumn = function() {
  _prevRenderRightColumnV24();
  if (state.selectedMatchViewTab === "share") {
    renderSelectedMatchShareTab();
  }
};

const _prevRenderSingleMobileMatchTileV24 = renderSingleMobileMatchTile;
renderSingleMobileMatchTile = function(m) {
  const baseHtml = _prevRenderSingleMobileMatchTileV24(m);
  if (baseHtml.includes("openShareTabForMatch")) return baseHtml;
  const shareBtnHtml = `<button type="button" class="m-address-sub" style="background:#FFF7ED;color:#EA580C;border-color:#FDBA74;cursor:pointer;" onclick="event.stopPropagation();openShareTabForMatch(${m.id})">📤 Partager ce match</button>`;
  return baseHtml.replace("</div>\n      <div class=\"m-team away\">", `${shareBtnHtml}</div>\n      <div class="m-team away">`);
};

/* ================= EXTENSION V27 : MISE À L'ÉCHELLE AUTOMATIQUE MOBILE (VW/REM) & OCCUPATION PLEIN ÉCRAN ================= */

const _prevApplyDisplayModeV27 = applyDisplayMode;
applyDisplayMode = function(mode) {
  document.documentElement.classList.toggle("html-mode-mobile", mode === "mobile");
  document.documentElement.classList.toggle("html-mode-tv", mode !== "mobile");
  _prevApplyDisplayModeV27(mode);
};

document.documentElement.classList.toggle("html-mode-mobile", state.displayMode === "mobile" || document.body.classList.contains("mode-mobile"));

document.addEventListener("DOMContentLoaded", () => {
  updateTvCarouselPauseButtons();
  const isMob = state.displayMode === "mobile" || document.body.classList.contains("mode-mobile");
  document.documentElement.classList.toggle("html-mode-mobile", isMob);
  setTimeout(handleIncomingUrlParams, 100);
});


/* ================= EXTENSION V29 : COMPTABILISATION & STATISTIQUES PAR QUART-TEMPS (POINTS, FAUTES, TIRS & BILAN ÉQUIPE) ================= */

const QT_KEYS = ["QT1", "QT2", "QT3", "QT4", "Prol"];

if (typeof DYNAMIC_FIELDS !== "undefined" && !DYNAMIC_FIELDS.includes("quarterStats")) {
  DYNAMIC_FIELDS.push("quarterStats");
}

function normalizeActiveQuarter(period) {
  const p = String(period || "").trim();
  if (p === "QT1") return "QT1";
  if (p === "QT2" || p === "Mi-Temps") return "QT2";
  if (p === "QT3") return "QT3";
  if (p === "QT4") return "QT4";
  if (p === "Prol." || p === "Prol") return "Prol";
  return "QT1";
}

function createEmptyQuarterSlot() {
  return { ph: 0, pa: 0, fh: 0, fa: 0, h1: 0, h2: 0, h3: 0, a1: 0, a2: 0, a3: 0 };
}

function ensureQuarterStats(m) {
  if (!m) return null;
  if (!m.quarterStats || typeof m.quarterStats !== "object") {
    m.quarterStats = {};
  }
  QT_KEYS.forEach(k => {
    if (!m.quarterStats[k] || typeof m.quarterStats[k] !== "object") {
      m.quarterStats[k] = createEmptyQuarterSlot();
    } else {
      const s = m.quarterStats[k];
      s.ph = Number(s.ph) || 0;
      s.pa = Number(s.pa) || 0;
      s.fh = Number(s.fh) || 0;
      s.fa = Number(s.fa) || 0;
      s.h1 = Number(s.h1) || 0;
      s.h2 = Number(s.h2) || 0;
      s.h3 = Number(s.h3) || 0;
      s.a1 = Number(s.a1) || 0;
      s.a2 = Number(s.a2) || 0;
      s.a3 = Number(s.a3) || 0;
    }
  });

  // Si le match avait déjà des points ou fautes saisis avant l'activation du suivi QT, les rattacher au QT actif
  const sumPh = QT_KEYS.reduce((acc, k) => acc + (m.quarterStats[k].ph || 0), 0);
  const sumPa = QT_KEYS.reduce((acc, k) => acc + (m.quarterStats[k].pa || 0), 0);
  if (sumPh === 0 && sumPa === 0 && ((m.sh || 0) > 0 || (m.sa || 0) > 0)) {
    const qk = normalizeActiveQuarter(m.period);
    m.quarterStats[qk].ph = Number(m.sh) || 0;
    m.quarterStats[qk].pa = Number(m.sa) || 0;
  }

  const sumFh = QT_KEYS.reduce((acc, k) => acc + (m.quarterStats[k].fh || 0), 0);
  const sumFa = QT_KEYS.reduce((acc, k) => acc + (m.quarterStats[k].fa || 0), 0);
  if (sumFh === 0 && sumFa === 0 && ((m.fh || 0) > 0 || (m.fa || 0) > 0)) {
    const qk = normalizeActiveQuarter(m.period);
    m.quarterStats[qk].fh = Number(m.fh) || 0;
    m.quarterStats[qk].fa = Number(m.fa) || 0;
  }

  return m.quarterStats;
}

function hasRecordedQuarterStats(m) {
  if (!m || !m.quarterStats) return false;
  return QT_KEYS.some(k => {
    const q = m.quarterStats[k];
    return q && ((q.ph || 0) > 0 || (q.pa || 0) > 0 || (q.fh || 0) > 0 || (q.fa || 0) > 0);
  });
}

function recomputeTotalsFromQuarters(m) {
  const qs = ensureQuarterStats(m);
  if (!qs) return;
  m.sh = QT_KEYS.reduce((acc, k) => acc + (qs[k].ph || 0), 0);
  m.sa = QT_KEYS.reduce((acc, k) => acc + (qs[k].pa || 0), 0);
}

// 1. Surcharger updateLivePoints pour comptabiliser les points & types de paniers (1/2/3 pts) par quart-temps
window.updateLivePoints = function(id, side, delta) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  if (typeof stampMatchScorer === "function") stampMatchScorer(id);

  m.status = "live";
  m.liveTracking = true;
  if (!m.period || m.period === "À venir" || m.period === "Terminé") {
    m.period = "QT1";
  }

  const qs = ensureQuarterStats(m);
  const qk = normalizeActiveQuarter(m.period);
  const slot = qs[qk];

  if (side === "home") {
    const nextPh = Math.max(0, (slot.ph || 0) + delta);
    const actualDelta = nextPh - (slot.ph || 0);
    slot.ph = nextPh;
    if (actualDelta === 1) slot.h1 = (slot.h1 || 0) + 1;
    else if (actualDelta === 2) slot.h2 = (slot.h2 || 0) + 1;
    else if (actualDelta === 3) slot.h3 = (slot.h3 || 0) + 1;
    else if (actualDelta === -1) {
      if ((slot.h1 || 0) > 0) slot.h1 -= 1;
      else if ((slot.h2 || 0) > 0) { slot.h2 -= 1; slot.h1 = (slot.h1 || 0) + 1; }
      else if ((slot.h3 || 0) > 0) { slot.h3 -= 1; slot.h2 = (slot.h2 || 0) + 1; }
    }
  } else {
    const nextPa = Math.max(0, (slot.pa || 0) + delta);
    const actualDelta = nextPa - (slot.pa || 0);
    slot.pa = nextPa;
    if (actualDelta === 1) slot.a1 = (slot.a1 || 0) + 1;
    else if (actualDelta === 2) slot.a2 = (slot.a2 || 0) + 1;
    else if (actualDelta === 3) slot.a3 = (slot.a3 || 0) + 1;
    else if (actualDelta === -1) {
      if ((slot.a1 || 0) > 0) slot.a1 -= 1;
      else if ((slot.a2 || 0) > 0) { slot.a2 -= 1; slot.a1 = (slot.a1 || 0) + 1; }
      else if ((slot.a3 || 0) > 0) { slot.a3 -= 1; slot.a2 = (slot.a2 || 0) + 1; }
    }
  }

  recomputeTotalsFromQuarters(m);
  saveState(true);
  renderAll();
};

// 2. Surcharger updateLiveFouls pour comptabiliser les fautes par quart-temps (tout en conservant les fautes des QT précédents)
window.updateLiveFouls = function(id, side, delta) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  if (typeof stampMatchScorer === "function") stampMatchScorer(id);

  m.status = "live";
  m.liveTracking = true;
  if (!m.period || m.period === "À venir" || m.period === "Terminé") {
    m.period = "QT1";
  }

  const qs = ensureQuarterStats(m);
  const qk = normalizeActiveQuarter(m.period);
  const slot = qs[qk];

  if (side === "home") {
    slot.fh = Math.max(0, Math.min(5, (slot.fh || 0) + delta));
    m.fh = slot.fh;
  } else {
    slot.fa = Math.max(0, Math.min(5, (slot.fa || 0) + delta));
    m.fa = slot.fa;
  }

  saveState(true);
  renderAll();
};

// 3. Surcharger setLivePeriod : change de quart-temps, conserve l'historique et affiche les fautes du nouveau quart-temps
window.setLivePeriod = function(id, period) {
  const m = state.matches.find(x => x.id === id);
  if (!m) return;
  const qs = ensureQuarterStats(m);
  m.status = "live";
  m.liveTracking = true;
  m.period = period;

  const qk = normalizeActiveQuarter(period);
  m.fh = qs[qk].fh || 0;
  m.fa = qs[qk].fa || 0;

  saveState(true);
  renderAll();
};

// 4. Surcharger finishCurrentAndLaunchNext et saveMatchScore pour conserver les stats par quart-temps après la fin du match
const _prevFinishCurrentV29 = window.finishCurrentAndLaunchNext;
window.finishCurrentAndLaunchNext = function(id) {
  const m = state.matches.find(x => x.id === id);
  if (m && hasRecordedQuarterStats(m)) {
    recomputeTotalsFromQuarters(m);
  }
  _prevFinishCurrentV29(id);
};

const _prevSaveMatchScoreV29 = window.saveMatchScore;
window.saveMatchScore = function(id, newStatus) {
  const m = state.matches.find(x => x.id === id);
  if (m && newStatus === "upcoming") {
    m.quarterStats = null;
    m.fh = 0;
    m.fa = 0;
  }
  _prevSaveMatchScoreV29(id, newStatus);
};

// 5. Gestion de l'onglet [ 📊 Stats & QT ] sur le match sélectionné
window.switchSelectedMatchTab = function(tabName) {
  const validTab = ["match", "stats", "share"].includes(tabName) ? tabName : "match";
  state.selectedMatchViewTab = validTab;

  const btnMatch = document.getElementById("btnSbTabMatch");
  const btnStats = document.getElementById("btnSbTabStats");
  const btnShare = document.getElementById("btnSbTabShare");
  const arenaWrap = document.getElementById("sbArenaMainWrap");
  const statsWrap = document.getElementById("sbStatsTabWrap");
  const shareWrap = document.getElementById("sbShareTabWrap");

  if (btnMatch) btnMatch.classList.toggle("active", validTab === "match");
  if (btnStats) btnStats.classList.toggle("active", validTab === "stats");
  if (btnShare) btnShare.classList.toggle("active", validTab === "share");

  if (arenaWrap) arenaWrap.style.display = validTab === "match" ? "flex" : "none";
  if (statsWrap) {
    statsWrap.style.display = validTab === "stats" ? "flex" : "none";
    if (validTab === "stats") renderSelectedMatchStatsTab();
  }
  if (shareWrap) {
    shareWrap.style.display = validTab === "share" ? "flex" : "none";
    if (validTab === "share") renderSelectedMatchShareTab();
  }
};

window.openStatsTabForMatch = function(matchId) {
  state.selectedMatchId = matchId;
  state.selectedMatchViewTab = "stats";
  renderAll();
  if (state.displayMode === "mobile") {
    switchMobileTab("live");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  window.switchSelectedMatchTab("stats");
};

window.saveManualQuarterStats = function(matchId) {
  const m = state.matches.find(x => x.id === matchId);
  if (!m) return;
  const qs = ensureQuarterStats(m);
  QT_KEYS.forEach(k => {
    const phEl = document.getElementById(`inpQtPh_${k}`);
    const paEl = document.getElementById(`inpQtPa_${k}`);
    const fhEl = document.getElementById(`inpQtFh_${k}`);
    const faEl = document.getElementById(`inpQtFa_${k}`);
    if (phEl) qs[k].ph = Math.max(0, parseInt(phEl.value, 10) || 0);
    if (paEl) qs[k].pa = Math.max(0, parseInt(paEl.value, 10) || 0);
    if (fhEl) qs[k].fh = Math.max(0, Math.min(5, parseInt(fhEl.value, 10) || 0));
    if (faEl) qs[k].fa = Math.max(0, Math.min(5, parseInt(faEl.value, 10) || 0));
  });
  recomputeTotalsFromQuarters(m);
  const activeQk = normalizeActiveQuarter(m.period);
  m.fh = qs[activeQk].fh || 0;
  m.fa = qs[activeQk].fa || 0;
  saveState(true);
  renderAll();
  renderSelectedMatchStatsTab();
};

window.copyMatchQuarterStatsText = function(matchId) {
  const m = state.matches.find(x => x.id === matchId);
  if (!m) return;
  const qs = ensureQuarterStats(m);
  const mt1H = (qs.QT1.ph || 0) + (qs.QT2.ph || 0);
  const mt1A = (qs.QT1.pa || 0) + (qs.QT2.pa || 0);
  const mt2H = (qs.QT3.ph || 0) + (qs.QT4.ph || 0);
  const mt2A = (qs.QT3.pa || 0) + (qs.QT4.pa || 0);
  const totFh = QT_KEYS.reduce((a, k) => a + (qs[k].fh || 0), 0);
  const totFa = QT_KEYS.reduce((a, k) => a + (qs[k].fa || 0), 0);

  const lines = [
    `*FEUILLE DE STATS PAR QUART-TEMPS — LSBSC (${m.cat})*`,
    `${m.home}  ${m.sh} - ${m.sa}  ${m.away}`,
    `Date : ${m.date} à ${m.time}`,
    ``,
    `*Points par Quart-Temps :*`,
    `• QT1 : ${qs.QT1.ph} - ${qs.QT1.pa}`,
    `• QT2 : ${qs.QT2.ph} - ${qs.QT2.pa}  (Mi-Temps : ${mt1H} - ${mt1A})`,
    `• QT3 : ${qs.QT3.ph} - ${qs.QT3.pa}`,
    `• QT4 : ${qs.QT4.ph} - ${qs.QT4.pa}  (2e MT : ${mt2H} - ${mt2A})`
  ];
  if ((qs["Prol"].ph || 0) > 0 || (qs["Prol"].pa || 0) > 0) {
    lines.push(`• Prol. : ${qs["Prol"].ph} - ${qs["Prol"].pa}`);
  }
  lines.push(
    `• TOTAL : ${m.sh} - ${m.sa}`,
    ``,
    `*Fautes d'équipe par Quart-Temps :*`,
    `• QT1 : ${qs.QT1.fh} - ${qs.QT1.fa} | QT2 : ${qs.QT2.fh} - ${qs.QT2.fa}`,
    `• QT3 : ${qs.QT3.fh} - ${qs.QT3.fa} | QT4 : ${qs.QT4.fh} - ${qs.QT4.fa}`,
    `• Total Fautes : ${totFh} - ${totFa}`
  );

  const txt = lines.join("\n");
  const done = () => {
    const b = document.getElementById("btnCopyQtStats");
    if (b) {
      b.textContent = "✅ Stats copiées !";
      b.style.background = "#16A34A";
      setTimeout(() => { renderSelectedMatchStatsTab(); }, 1600);
    }
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(done).catch(() => fallbackCopyText(txt, done));
  } else {
    fallbackCopyText(txt, done);
  }
};

function renderSelectedMatchStatsTab() {
  const statsWrap = document.getElementById("sbStatsTabWrap");
  if (!statsWrap) return;
  const current = state.matches.find(m => m.id === state.selectedMatchId) || state.matches[0];
  if (!current) return;

  const hasData = hasRecordedQuarterStats(current);
  const qs = ensureQuarterStats(current);
  const homeUs = isLSBSC(current.home);
  const awayUs = isLSBSC(current.away);

  const hasOT = (qs["Prol"].ph || 0) > 0 || (qs["Prol"].pa || 0) > 0 || (qs["Prol"].fh || 0) > 0 || (qs["Prol"].fa || 0) > 0 || current.period === "Prol.";

  const mt1H = (qs.QT1.ph || 0) + (qs.QT2.ph || 0);
  const mt1A = (qs.QT1.pa || 0) + (qs.QT2.pa || 0);
  const mt2H = (qs.QT3.ph || 0) + (qs.QT4.ph || 0);
  const mt2A = (qs.QT3.pa || 0) + (qs.QT4.pa || 0);

  const totPh = QT_KEYS.reduce((a, k) => a + (qs[k].ph || 0), 0);
  const totPa = QT_KEYS.reduce((a, k) => a + (qs[k].pa || 0), 0);
  const totFh = QT_KEYS.reduce((a, k) => a + (qs[k].fh || 0), 0);
  const totFa = QT_KEYS.reduce((a, k) => a + (qs[k].fa || 0), 0);

  // Calcul des indicateurs clés pour LSBSC
  const regKeys = ["QT1", "QT2", "QT3", "QT4"];
  let bestOffQt = "QT1", bestOffPts = -1;
  let bestDefQt = "QT1", bestDefPts = 9999;
  regKeys.forEach(k => {
    const usPts = homeUs ? (qs[k].ph || 0) : (qs[k].pa || 0);
    const oppPts = homeUs ? (qs[k].pa || 0) : (qs[k].ph || 0);
    if (usPts > bestOffPts) { bestOffPts = usPts; bestOffQt = k; }
    if (oppPts < bestDefPts) { bestDefPts = oppPts; bestDefQt = k; }
  });

  const us1 = QT_KEYS.reduce((a, k) => a + (homeUs ? (qs[k].h1 || 0) : (qs[k].a1 || 0)), 0);
  const us2 = QT_KEYS.reduce((a, k) => a + (homeUs ? (qs[k].h2 || 0) : (qs[k].a2 || 0)), 0);
  const us3 = QT_KEYS.reduce((a, k) => a + (homeUs ? (qs[k].h3 || 0) : (qs[k].a3 || 0)), 0);
  const usTotalFouls = homeUs ? totFh : totFa;
  const oppTotalFouls = homeUs ? totFa : totFh;

  const shotsSummaryTxt = (us1 + us2 + us3) > 0
    ? `${us1}×1pt • ${us2}×2pts • ${us3}×3pts`
    : "Saisie globale (utiliser +1/+2/+3 en direct)";

  const staffEditHtml = state.staffUnlocked ? `
    <div class="qt-box-card" style="border-left-color:#EA580C;background:#FFF7ED;">
      <div class="qt-box-header">
        <strong>✏️ Édition Staff — Points & Fautes par Quart-Temps</strong>
        <button type="button" class="btn-action-sm btn-save-score" onclick="saveManualQuarterStats(${current.id})">💾 Enregistrer QT</button>
      </div>
      <div class="qt-table-scroll">
        <table class="qt-table">
          <thead>
            <tr>
              <th>Quart-Temps</th>
              <th>Pts ${current.home.slice(0, 12)}</th>
              <th>Pts ${current.away.slice(0, 12)}</th>
              <th>Fautes Loc.</th>
              <th>Fautes Vis.</th>
            </tr>
          </thead>
          <tbody>
            ${QT_KEYS.map(k => `
              <tr>
                <td><strong>${k}</strong></td>
                <td><input type="number" id="inpQtPh_${k}" min="0" value="${qs[k].ph}" style="width:52px;padding:4px;text-align:center;font-weight:900;border:1px solid #93C5FD;border-radius:6px;"></td>
                <td><input type="number" id="inpQtPa_${k}" min="0" value="${qs[k].pa}" style="width:52px;padding:4px;text-align:center;font-weight:900;border:1px solid #93C5FD;border-radius:6px;"></td>
                <td><input type="number" id="inpQtFh_${k}" min="0" max="5" value="${qs[k].fh}" style="width:46px;padding:4px;text-align:center;font-weight:900;border:1px solid #FCA5A5;border-radius:6px;"></td>
                <td><input type="number" id="inpQtFa_${k}" min="0" max="5" value="${qs[k].fa}" style="width:46px;padding:4px;text-align:center;font-weight:900;border:1px solid #FCA5A5;border-radius:6px;"></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  ` : "";

  statsWrap.innerHTML = `
    <div class="qt-box-card">
      <div class="qt-box-header">
        <strong>📊 Points par Quart-Temps (${current.cat})</strong>
        <button type="button" id="btnCopyQtStats" class="btn-action-sm" style="background:#1E3A8A;color:#FFF;" onclick="copyMatchQuarterStatsText(${current.id})">
          📋 Copier Stats
        </button>
      </div>

      ${!hasData ? `
        <div style="background:#FEF3C7;border:1.5px solid #F59E0B;color:#92400E;padding:10px;border-radius:10px;font-size:0.82rem;font-weight:800;text-align:center;">
          ℹ️ Aucun point ou faute enregistré en direct sur ce match pour le moment.<br>
          Dès qu'un match est suivi via la <strong>Table Direct</strong>, les points et fautes de chaque quart-temps sont archivés ici !
        </div>
      ` : ""}

      <div class="qt-table-scroll">
        <table class="qt-table">
          <thead>
            <tr>
              <th style="text-align:left;padding-left:8px;">Équipe</th>
              <th>QT1</th>
              <th>QT2</th>
              <th class="qt-col-half">MT1</th>
              <th>QT3</th>
              <th>QT4</th>
              <th class="qt-col-half">MT2</th>
              ${hasOT ? `<th>Prol.</th>` : ""}
              <th class="qt-col-tot">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            <tr class="${homeUs ? "is-lsbsc-row" : ""}">
              <td class="qt-team-cell">${homeUs ? "🦁 " : ""}${current.home}</td>
              <td>${qs.QT1.ph}</td>
              <td>${qs.QT2.ph}</td>
              <td class="qt-half-cell">${mt1H}</td>
              <td>${qs.QT3.ph}</td>
              <td>${qs.QT4.ph}</td>
              <td class="qt-half-cell">${mt2H}</td>
              ${hasOT ? `<td>${qs["Prol"].ph}</td>` : ""}
              <td class="qt-tot-cell">${totPh}</td>
            </tr>
            <tr class="${awayUs ? "is-lsbsc-row" : ""}">
              <td class="qt-team-cell">${awayUs ? "🦁 " : ""}${current.away}</td>
              <td>${qs.QT1.pa}</td>
              <td>${qs.QT2.pa}</td>
              <td class="qt-half-cell">${mt1A}</td>
              <td>${qs.QT3.pa}</td>
              <td>${qs.QT4.pa}</td>
              <td class="qt-half-cell">${mt2A}</td>
              ${hasOT ? `<td>${qs["Prol"].pa}</td>` : ""}
              <td class="qt-tot-cell">${totPa}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="qt-box-card" style="border-left-color:#DC2626;">
      <div class="qt-box-header">
        <strong style="color:#991B1B;">⚠️ Fautes d'Équipe par Quart-Temps (Bonus à 5)</strong>
      </div>
      <div class="qt-table-scroll">
        <table class="qt-table">
          <thead>
            <tr>
              <th style="text-align:left;padding-left:8px;">Équipe</th>
              <th>QT1</th>
              <th>QT2</th>
              <th>QT3</th>
              <th>QT4</th>
              ${hasOT ? `<th>Prol.</th>` : ""}
              <th class="qt-col-tot">TOTAL FAUTES</th>
            </tr>
          </thead>
          <tbody>
            <tr class="${homeUs ? "is-lsbsc-row" : ""}">
              <td class="qt-team-cell">${homeUs ? "🦁 " : ""}${current.home}</td>
              <td class="${qs.QT1.fh >= 5 ? "qt-foul-bonus" : ""}">${qs.QT1.fh}</td>
              <td class="${qs.QT2.fh >= 5 ? "qt-foul-bonus" : ""}">${qs.QT2.fh}</td>
              <td class="${qs.QT3.fh >= 5 ? "qt-foul-bonus" : ""}">${qs.QT3.fh}</td>
              <td class="${qs.QT4.fh >= 5 ? "qt-foul-bonus" : ""}">${qs.QT4.fh}</td>
              ${hasOT ? `<td class="${qs["Prol"].fh >= 5 ? "qt-foul-bonus" : ""}">${qs["Prol"].fh}</td>` : ""}
              <td class="qt-tot-cell">${totFh}</td>
            </tr>
            <tr class="${awayUs ? "is-lsbsc-row" : ""}">
              <td class="qt-team-cell">${awayUs ? "🦁 " : ""}${current.away}</td>
              <td class="${qs.QT1.fa >= 5 ? "qt-foul-bonus" : ""}">${qs.QT1.fa}</td>
              <td class="${qs.QT2.fa >= 5 ? "qt-foul-bonus" : ""}">${qs.QT2.fa}</td>
              <td class="${qs.QT3.fa >= 5 ? "qt-foul-bonus" : ""}">${qs.QT3.fa}</td>
              <td class="${qs.QT4.fa >= 5 ? "qt-foul-bonus" : ""}">${qs.QT4.fa}</td>
              ${hasOT ? `<td class="${qs["Prol"].fa >= 5 ? "qt-foul-bonus" : ""}">${qs["Prol"].fa}</td>` : ""}
              <td class="qt-tot-cell">${totFa}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    ${hasData ? `
      <div class="qt-kpi-grid">
        <div class="qt-kpi-tile best-off">
          <span class="qt-kpi-lbl">🔥 Meilleur QT Offensif LSBSC</span>
          <span class="qt-kpi-val">${bestOffQt} : ${bestOffPts} pts marqués</span>
          <span class="qt-kpi-sub">1re MT : ${homeUs ? mt1H : mt1A} pts • 2e MT : ${homeUs ? mt2H : mt2A} pts</span>
        </div>
        <div class="qt-kpi-tile best-def">
          <span class="qt-kpi-lbl">🛡️ Meilleur QT Défensif LSBSC</span>
          <span class="qt-kpi-val">${bestDefQt} : ${bestDefPts} pts encaissés</span>
          <span class="qt-kpi-sub">Total encaissé : ${homeUs ? totPa : totPh} pts</span>
        </div>
        <div class="qt-kpi-tile shots-tile">
          <span class="qt-kpi-lbl">🎯 Répartition Paniers LSBSC</span>
          <span class="qt-kpi-val">${shotsSummaryTxt}</span>
          <span class="qt-kpi-sub">Total LSBSC : ${homeUs ? totPh : totPa} pts</span>
        </div>
        <div class="qt-kpi-tile fouls-tile">
          <span class="qt-kpi-lbl">⚖️ Discipline & Fautes</span>
          <span class="qt-kpi-val">LSBSC : ${usTotalFouls} fautes (${(usTotalFouls / 4).toFixed(1)}/QT)</span>
          <span class="qt-kpi-sub">Adversaire : ${oppTotalFouls} fautes (${(oppTotalFouls / 4).toFixed(1)}/QT)</span>
        </div>
      </div>
    ` : ""}

    ${staffEditHtml}
  `;
}

// 6. Afficher un aperçu cliquable des quarts-temps sur le scoreboard principal et rafraîchir l'onglet Stats
const _prevRenderRightColumnV29 = renderRightColumn;
renderRightColumn = function() {
  _prevRenderRightColumnV29();
  const current = state.matches.find(m => m.id === state.selectedMatchId);
  const summaryBar = document.getElementById("sbMatchSummaryBar");
  if (current && summaryBar && hasRecordedQuarterStats(current)) {
    const qs = ensureQuarterStats(current);
    const stripTxt = `QT1 ${qs.QT1.ph}-${qs.QT1.pa} • QT2 ${qs.QT2.ph}-${qs.QT2.pa} • QT3 ${qs.QT3.ph}-${qs.QT3.pa} • QT4 ${qs.QT4.ph}-${qs.QT4.pa}`;
    if (!summaryBar.querySelector(".qt-inline-strip")) {
      summaryBar.insertAdjacentHTML(
        "beforeend",
        `<button type="button" class="qt-inline-strip" onclick="switchSelectedMatchTab('stats')" title="Voir les stats détaillées par quart-temps">📊 ${stripTxt} (Détails ↗)</button>`
      );
    }
  }
  if (state.selectedMatchViewTab === "stats") {
    renderSelectedMatchStatsTab();
  }
};

// 7. Ajouter le bouton "📊 Stats QT" sur chaque tuile de match Mobile ayant des données enregistrées + Bilan cumulé par QT par équipe !
const _prevRenderSingleMobileMatchTileV29 = renderSingleMobileMatchTile;
renderSingleMobileMatchTile = function(m) {
  let html = _prevRenderSingleMobileMatchTileV29(m);
  if (hasRecordedQuarterStats(m) && !html.includes("openStatsTabForMatch")) {
    const qs = ensureQuarterStats(m);
    const statsBtnHtml = `<button type="button" class="m-address-sub" style="background:#EFF6FF;color:#1E3A8A;border-color:#93C5FD;cursor:pointer;" onclick="event.stopPropagation();openStatsTabForMatch(${m.id})">📊 Stats QT (${qs.QT1.ph}-${qs.QT1.pa} / ${qs.QT2.ph}-${qs.QT2.pa} / ${qs.QT3.ph}-${qs.QT3.pa} / ${qs.QT4.ph}-${qs.QT4.pa})</button>`;
    html = html.replace("</div>\n      <div class=\"m-team away\">", `${statsBtnHtml}</div>\n      <div class=\"m-team away\">`);
  }
  return html;
};

const _prevRenderMobileTeamsSectionV29 = renderMobileTeamsSection;
renderMobileTeamsSection = function() {
  _prevRenderMobileTeamsSectionV29();
  const container = document.getElementById("mobileTeamsViewContainer");
  if (!container || !state.mobileSelectedTeamCat) return;

  const teamLiveMatches = state.matches.filter(m => m.cat === state.mobileSelectedTeamCat && hasRecordedQuarterStats(m));
  if (teamLiveMatches.length === 0) return;

  const n = teamLiveMatches.length;
  const agg = {
    QT1: { usP: 0, oppP: 0, usF: 0, oppF: 0 },
    QT2: { usP: 0, oppP: 0, usF: 0, oppF: 0 },
    QT3: { usP: 0, oppP: 0, usF: 0, oppF: 0 },
    QT4: { usP: 0, oppP: 0, usF: 0, oppF: 0 }
  };
  let tot1 = 0, tot2 = 0, tot3 = 0;

  teamLiveMatches.forEach(m => {
    const qs = ensureQuarterStats(m);
    const homeUs = isLSBSC(m.home);
    ["QT1", "QT2", "QT3", "QT4"].forEach(k => {
      agg[k].usP += homeUs ? (qs[k].ph || 0) : (qs[k].pa || 0);
      agg[k].oppP += homeUs ? (qs[k].pa || 0) : (qs[k].ph || 0);
      agg[k].usF += homeUs ? (qs[k].fh || 0) : (qs[k].fa || 0);
      agg[k].oppF += homeUs ? (qs[k].fa || 0) : (qs[k].fh || 0);
    });
    QT_KEYS.forEach(k => {
      tot1 += homeUs ? (qs[k].h1 || 0) : (qs[k].a1 || 0);
      tot2 += homeUs ? (qs[k].h2 || 0) : (qs[k].a2 || 0);
      tot3 += homeUs ? (qs[k].h3 || 0) : (qs[k].a3 || 0);
    });
  });

  const seasonCardHtml = `
    <div class="team-season-qt-card">
      <h4>📊 Moyennes par Quart-Temps — ${state.mobileSelectedTeamCat} (${n} match${n > 1 ? "s" : ""} suivi${n > 1 ? "s" : ""} en direct)</h4>
      <div class="qt-table-scroll">
        <table class="qt-table">
          <thead>
            <tr>
              <th style="text-align:left;padding-left:8px;">Indicateur (Moy. / Match)</th>
              <th>QT1</th>
              <th>QT2</th>
              <th>QT3</th>
              <th>QT4</th>
            </tr>
          </thead>
          <tbody>
            <tr class="is-lsbsc-row">
              <td class="qt-team-cell">🦁 Pts Marqués LSBSC</td>
              <td>${(agg.QT1.usP / n).toFixed(1)}</td>
              <td>${(agg.QT2.usP / n).toFixed(1)}</td>
              <td>${(agg.QT3.usP / n).toFixed(1)}</td>
              <td>${(agg.QT4.usP / n).toFixed(1)}</td>
            </tr>
            <tr>
              <td class="qt-team-cell">🛡️ Pts Encaissés</td>
              <td>${(agg.QT1.oppP / n).toFixed(1)}</td>
              <td>${(agg.QT2.oppP / n).toFixed(1)}</td>
              <td>${(agg.QT3.oppP / n).toFixed(1)}</td>
              <td>${(agg.QT4.oppP / n).toFixed(1)}</td>
            </tr>
            <tr>
              <td class="qt-team-cell">⚠️ Fautes LSBSC / QT</td>
              <td>${(agg.QT1.usF / n).toFixed(1)}</td>
              <td>${(agg.QT2.usF / n).toFixed(1)}</td>
              <td>${(agg.QT3.usF / n).toFixed(1)}</td>
              <td>${(agg.QT4.usF / n).toFixed(1)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      ${(tot1 + tot2 + tot3) > 0 ? `
        <div style="font-size:0.84rem;font-weight:800;color:#1E3A8A;background:#EFF6FF;padding:0.55rem 0.75rem;border-radius:0.7rem;">
          🎯 Paniers cumulés sur les matchs suivis : <strong>${tot1}</strong> LF (1 pt) • <strong>${tot2}</strong> paniers (2 pts) • <strong>${tot3}</strong> tirs (3 pts)
        </div>
      ` : ""}
    </div>
  `;

  const banner = container.querySelector("#mobSelectedTeamAnchor");
  if (banner) {
    banner.insertAdjacentHTML("afterend", seasonCardHtml);
  }
};


/* ================= EXTENSION V30 : DÉBLOCAGE GARANTI DE L'ÉCRAN DE CHOIX DE FORMAT ================= */

function forceCloseFormatOverlay() {
  const overlay = document.getElementById("formatSelectorOverlay");
  if (overlay) {
    overlay.classList.remove("open");
    overlay.style.display = "none";
  }
}

window.chooseDisplayMode = function(mode) {
  const targetMode = mode === "mobile" ? "mobile" : "tv";
  try {
    const remember = document.getElementById("chkRememberFormat");
    if (remember && remember.checked) {
      localStorage.setItem("lsbsc_preferred_format", targetMode);
    }
  } catch (e) {}

  forceCloseFormatOverlay();

  try {
    if (typeof applyDisplayMode === "function") {
      applyDisplayMode(targetMode);
    } else {
      state.displayMode = targetMode;
      document.body.classList.remove("mode-tv", "mode-mobile");
      document.body.classList.add(targetMode === "mobile" ? "mode-mobile" : "mode-tv");
    }
  } catch (e) {}

  try {
    if (typeof renderAll === "function") {
      renderAll();
    }
  } catch (e) {}
};

window.openFormatOverlay = function() {
  try { localStorage.removeItem("lsbsc_preferred_format"); } catch (e) {}
  const overlay = document.getElementById("formatSelectorOverlay");
  if (overlay) {
    overlay.style.display = "flex";
    overlay.classList.add("open");
  }
};

document.addEventListener("DOMContentLoaded", () => {
  try {
    const savedMode = localStorage.getItem("lsbsc_preferred_format");
    if (savedMode === "tv" || savedMode === "mobile") {
      forceCloseFormatOverlay();
      if (typeof applyDisplayMode === "function") {
        applyDisplayMode(savedMode);
      }
    }
  } catch (e) {}

  const choices = document.querySelectorAll("#formatSelectorOverlay .format-card-btn");
  if (choices && choices.length >= 2) {
    choices[0].addEventListener("click", () => window.chooseDisplayMode("tv"));
    choices[1].addEventListener("click", () => window.chooseDisplayMode("mobile"));
  }
});


/* ================= EXTENSION V31 : FERMETURE IMPÉRATIVE DU SÉLECTEUR DE FORMAT ================= */
(function() {
  function hideFormatOverlayNow() {
    var ov = document.getElementById("formatSelectorOverlay");
    if (ov) {
      ov.classList.remove("open");
      ov.style.setProperty("display", "none", "important");
    }
  }

  var prevChoose = window.chooseDisplayMode;
  window.chooseDisplayMode = function(mode) {
    hideFormatOverlayNow();
    if (typeof prevChoose === "function") {
      try { prevChoose(mode); } catch (e) {}
    }
    hideFormatOverlayNow();
  };

  document.addEventListener("DOMContentLoaded", function() {
    var btns = document.querySelectorAll("#formatSelectorOverlay .format-card-btn");
    if (btns[0]) {
      btns[0].addEventListener("click", function(ev) {
        ev.preventDefault();
        window.chooseDisplayMode("tv");
      });
    }
    if (btns[1]) {
      btns[1].addEventListener("click", function(ev) {
        ev.preventDefault();
        window.chooseDisplayMode("mobile");
      });
    }
  });
})();


/* ================= EXTENSION V32 : SYNCHRONISATION IMMÉDIATE AU CHARGEMENT & FIX PLEIN ÉCRAN ================= */
(function() {
  // 1. Corriger window.forceFullScreen pour éviter l'avertissement navigateur sans geste utilisateur
  window.forceFullScreen = function() {
    try {
      const docEl = document.documentElement;
      if (!document.fullscreenElement && !document.webkitFullscreenElement) {
        if (docEl.requestFullscreen) {
          const p = docEl.requestFullscreen();
          if (p && typeof p.catch === "function") p.catch(() => {});
        } else if (docEl.webkitRequestFullscreen) {
          docEl.webkitRequestFullscreen();
        }
      }
    } catch (e) {}
  };

  // 2. Forcer la récupération immédiate depuis Firebase dès l'ouverture (avant d'attendre 5s)
  async function syncNowFromCloud(forceFullRead) {
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (!targetUrl) return;
    try {
      const res = await fetch(targetUrl + (targetUrl.includes("?") ? "&" : "?") + "_t=" + Date.now(), {
        headers: { "Accept": "application/json" },
        cache: "no-store"
      });
      if (!res.ok) {
        const syncEl = document.getElementById("syncStatusBadge");
        if (syncEl) syncEl.textContent = "⚠️ Erreur Sync (" + res.status + ")";
        return;
      }
      const data = await res.json();
      if (data && Array.isArray(data.matches) && data.matches.length > 0) {
        const remoteTs = Number(data.updatedAt) || 0;
        if (forceFullRead || remoteTs > state.lastUpdatedAt) {
          state.lastUpdatedAt = remoteTs || Date.now();
          state.matches = overlaySchedule(data.matches);
          if (data.tickerText) state.tickerText = data.tickerText;
          if (data.buvetteMenuText) state.buvetteMenuText = data.buvetteMenuText;
          if (data.clubInfosText) state.clubInfosText = data.clubInfosText;
          if (data.tvDurations) state.tvDurations = Object.assign(state.tvDurations, data.tvDurations);
          if (Array.isArray(data.trustedPins)) state.trustedPins = data.trustedPins;
          if (data.clubAssets) state.clubAssets = Object.assign(state.clubAssets, data.clubAssets);
          persistLocalOnly();
          renderAll();
          const syncEl = document.getElementById("syncStatusBadge");
          if (syncEl) syncEl.textContent = "● Direct Synchronisé";
        }
      }
    } catch (err) {
      const syncEl = document.getElementById("syncStatusBadge");
      if (syncEl) syncEl.textContent = "⚠️ Hors-ligne / Sync";
    }
  }

  window.forceSyncNow = function() {
    syncNowFromCloud(true);
  };

  document.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => syncNowFromCloud(true), 250);
  });
})();


/* ================= EXTENSION V33 : SANITISATION CLÉS FIREBASE (SANS '.', '$', '#', '[', ']', '/') ================= */
(function() {
  function sanitizeFirebaseKeys(obj) {
    if (Array.isArray(obj)) {
      return obj.map(sanitizeFirebaseKeys);
    }
    if (obj && typeof obj === "object") {
      const out = {};
      for (const [k, v] of Object.entries(obj)) {
        const cleanKey = String(k).replace(/[.$#\[\]\/]/g, "_");
        out[cleanKey] = sanitizeFirebaseKeys(v);
      }
      return out;
    }
    return obj;
  }

  function normalizeQuarterStatsObj(m) {
    if (!m || !m.quarterStats || typeof m.quarterStats !== "object") return;
    if (m.quarterStats["Prol_"] && !m.quarterStats["Prol"]) {
      m.quarterStats["Prol"] = m.quarterStats["Prol_"];
    }
    if (m.quarterStats["Prol."] && !m.quarterStats["Prol"]) {
      m.quarterStats["Prol"] = m.quarterStats["Prol."];
    }
    if (typeof ensureQuarterStats === "function") {
      ensureQuarterStats(m);
    }
  }

  const _origSaveStateV33 = window.saveState;
  window.saveState = function(pushCloud = true) {
    if (Array.isArray(state.matches)) {
      state.matches.forEach(normalizeQuarterStatsObj);
    }
    const now = Date.now();
    state.lastUpdatedAt = now;
    const rawPayload = {
      matches: state.matches,
      tickerText: state.tickerText,
      clubAssets: state.clubAssets,
      buvetteMenuText: state.buvetteMenuText,
      clubInfosText: state.clubInfosText,
      tvDurations: state.tvDurations,
      trustedPins: state.trustedPins,
      updatedAt: now
    };
    try {
      localStorage.setItem("lsbsc_state_v4", JSON.stringify(rawPayload));
    } catch (e) {}
    if (bcChannel) {
      try { bcChannel.postMessage(rawPayload); } catch (e) {}
    }
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (pushCloud && targetUrl) {
      const safePayload = sanitizeFirebaseKeys(rawPayload);
      fetch(targetUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(safePayload)
      }).then(async (res) => {
        const syncEl = document.getElementById("syncStatusBadge");
        if (res.ok) {
          if (syncEl) syncEl.textContent = "● Direct Synchronisé";
        } else {
          let errTxt = "";
          try { errTxt = await res.text(); } catch (e) {}
          console.warn("Firebase PUT error:", res.status, errTxt);
          if (syncEl) syncEl.textContent = "⚠️ Erreur Sync (" + res.status + ")";
        }
      }).catch((err) => {
        console.warn("Firebase PUT network error:", err);
        const syncEl = document.getElementById("syncStatusBadge");
        if (syncEl) syncEl.textContent = "⚠️ Hors-ligne / Sync";
      });
    }
  };

  document.addEventListener("DOMContentLoaded", () => {
    if (Array.isArray(state.matches)) {
      state.matches.forEach(normalizeQuarterStatsObj);
    }
  });
})();


/* ================= EXTENSION V34 : GÉNÉRATION DE CARTE VISUELLE (PNG) & PARTAGE IMAGE WHATSAPP ================= */
(function() {
  function drawRoundedRect(ctx, x, y, w, h, r) {
    const rad = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }

  function wrapCanvasLines(ctx, text, maxWidth, maxLines) {
    const words = String(text || "").split(/\s+/).filter(Boolean);
    const lines = [];
    let current = "";
    for (const w of words) {
      const test = current ? (current + " " + w) : w;
      if (ctx.measureText(test).width <= maxWidth) {
        current = test;
      } else {
        if (current) lines.push(current);
        current = w;
        if (lines.length >= maxLines) break;
      }
    }
    if (current && lines.length < maxLines) {
      lines.push(current);
    }
    return lines.length > 0 ? lines : [""];
  }

  function loadImageSafe(src, fallbackSrc) {
    return new Promise((resolve) => {
      if (!src) {
        resolve(null);
        return;
      }
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = () => {
        if (fallbackSrc && fallbackSrc !== src) {
          const fb = new Image();
          fb.onload = () => resolve(fb);
          fb.onerror = () => resolve(null);
          fb.src = fallbackSrc;
        } else {
          resolve(null);
        }
      };
      img.src = src;
    });
  }

  async function renderMatchShareCardCanvas(m) {
    const W = 1080;
    const H = 1080;
    const canvas = document.createElement("canvas");
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");

    // 1. Fond dégradé sportif bleu nuit / ardoise
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, "#0F172A");
    bgGrad.addColorStop(0.55, "#1E3A8A");
    bgGrad.addColorStop(1, "#0F172A");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // Halo décoratif orange & bleu
    const glow1 = ctx.createRadialGradient(W * 0.85, H * 0.15, 20, W * 0.85, H * 0.15, 420);
    glow1.addColorStop(0, "rgba(234, 88, 12, 0.28)");
    glow1.addColorStop(1, "rgba(234, 88, 12, 0)");
    ctx.fillStyle = glow1;
    ctx.fillRect(0, 0, W, H);

    // Cadre extérieur doré/orange
    ctx.strokeStyle = "rgba(245, 158, 11, 0.75)";
    ctx.lineWidth = 6;
    drawRoundedRect(ctx, 28, 28, W - 56, H - 56, 36);
    ctx.stroke();

    // 2. En-tête Club LSBSC
    const logoSrc = (state.clubAssets && state.clubAssets.logo) || FALLBACK_LOGO_B64;
    const mascotSrc = (state.clubAssets && state.clubAssets.mascot) || FALLBACK_MASCOT_B64;
    const homeBadgeSrc = getTeamBadgeSrc(m.home);
    const awayBadgeSrc = getTeamBadgeSrc(m.away);

    const [logoImg, mascotImg, homeImg, awayImg] = await Promise.all([
      loadImageSafe(logoSrc, FALLBACK_LOGO_B64),
      loadImageSafe(mascotSrc, FALLBACK_MASCOT_B64),
      loadImageSafe(homeBadgeSrc, FALLBACK_LOGO_B64),
      loadImageSafe(awayBadgeSrc, FALLBACK_LOGO_B64)
    ]);

    if (logoImg) {
      ctx.drawImage(logoImg, 64, 56, 108, 108);
    }
    if (mascotImg) {
      ctx.drawImage(mascotImg, W - 172, 56, 108, 108);
    }

    ctx.textAlign = "center";
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "900 34px Arial, sans-serif";
    ctx.fillText("LILLE SUD BASKETBALL", W / 2, 102);
    ctx.fillStyle = "#FCD34D";
    ctx.font = "800 24px Arial, sans-serif";
    ctx.fillText("SPORTING CLUB • SOUTH LILLE", W / 2, 140);

    // 3. Pastille Catégorie & Domicile/Extérieur
    const homeUs = isLSBSC(m.home);
    const locLabel = homeUs ? "DOMICILE • LILLE SUD" : "EXTÉRIEUR • DÉPLACEMENT";
    const catBannerText = `${m.cat} (${m.comp || "Champ."})  •  ${locLabel}`;
    ctx.font = "900 24px Arial, sans-serif";
    const pillW = Math.min(W - 140, ctx.measureText(catBannerText).width + 64);
    ctx.fillStyle = "#EA580C";
    drawRoundedRect(ctx, (W - pillW) / 2, 186, pillW, 52, 26);
    ctx.fill();
    ctx.fillStyle = "#FFFFFF";
    ctx.fillText(catBannerText, W / 2, 220);

    // 4. Carte Centrale Blanche (Équipes + Score ou Horaire)
    ctx.fillStyle = "#FFFFFF";
    drawRoundedRect(ctx, 56, 268, W - 112, 470, 32);
    ctx.fill();

    // Bandeau de statut en haut de la carte blanche
    const outcome = computeMatchOutcome(m);
    let statusBg = "#EFF6FF";
    let statusFg = "#1E3A8A";
    let statusTitle = `🕒 RENCONTRE À VENIR • ${m.date} À ${m.time}`;

    if (m.status === "live") {
      statusBg = "#FEF2F2";
      statusFg = "#DC2626";
      statusTitle = `🔴 EN DIRECT • ${m.period || "QT1"}`;
    } else if (m.status === "finished") {
      if (outcome === "win") {
        statusBg = "#DCFCE7";
        statusFg = "#15803D";
        statusTitle = "🏆 VICTOIRE LSBSC • SCORE FINAL";
      } else if (outcome === "loss") {
        statusBg = "#FEE2E2";
        statusFg = "#B91C1C";
        statusTitle = "SCORE FINAL • MATCH TERMINÉ";
      } else {
        statusBg = "#F1F5F9";
        statusFg = "#334155";
        statusTitle = "🤝 ÉGALITÉ • SCORE FINAL";
      }
    } else if (m.status === "postponed") {
      statusBg = "#F3E8FF";
      statusFg = "#6B21A8";
      statusTitle = "📅 MATCH REPORTÉ";
    } else if (m.status === "forfeit") {
      statusBg = "#FEF3C7";
      statusFg = "#92400E";
      statusTitle = "🚫 FORFAIT OFFICIEL";
    }

    ctx.fillStyle = statusBg;
    drawRoundedRect(ctx, 84, 292, W - 168, 56, 18);
    ctx.fill();
    ctx.fillStyle = statusFg;
    ctx.font = "900 25px Arial, sans-serif";
    ctx.fillText(statusTitle, W / 2, 329);

    // Logos Équipes (Domicile à gauche, Extérieur à droite)
    const leftX = 240;
    const rightX = W - 240;
    const badgeY = 382;
    const badgeSize = 156;

    if (homeImg) {
      ctx.drawImage(homeImg, leftX - badgeSize / 2, badgeY, badgeSize, badgeSize);
    }
    if (awayImg) {
      ctx.drawImage(awayImg, rightX - badgeSize / 2, badgeY, badgeSize, badgeSize);
    }

    // Centre : Score ou Horaire + VS
    ctx.textAlign = "center";
    if (m.status === "live" || m.status === "finished") {
      ctx.fillStyle = "#0F172A";
      drawRoundedRect(ctx, W / 2 - 165, 396, 330, 114, 24);
      ctx.fill();

      ctx.fillStyle = m.status === "live" ? "#F97316" : "#FFFFFF";
      ctx.font = "900 68px Arial, sans-serif";
      ctx.fillText(`${m.sh} - ${m.sa}`, W / 2, 476);
    } else if (m.status === "postponed" || m.status === "forfeit") {
      ctx.fillStyle = statusFg;
      ctx.font = "900 36px Arial, sans-serif";
      ctx.fillText(m.status === "postponed" ? "REPORTÉ" : "FORFAIT", W / 2, 466);
    } else {
      ctx.fillStyle = "#EA580C";
      ctx.font = "900 54px Arial, sans-serif";
      ctx.fillText("VS", W / 2, 452);
      ctx.fillStyle = "#1E3A8A";
      ctx.font = "900 32px Arial, sans-serif";
      ctx.fillText(m.time || "", W / 2, 496);
    }

    // Noms des équipes (sur 2 lignes max)
    ctx.font = "900 26px Arial, sans-serif";
    ctx.fillStyle = homeUs ? "#EA580C" : "#0F172A";
    const homeLines = wrapCanvasLines(ctx, m.home, 360, 2);
    homeLines.forEach((line, idx) => {
      ctx.fillText(line, leftX, 586 + idx * 34);
    });

    ctx.fillStyle = isLSBSC(m.away) ? "#EA580C" : "#0F172A";
    const awayLines = wrapCanvasLines(ctx, m.away, 360, 2);
    awayLines.forEach((line, idx) => {
      ctx.fillText(line, rightX, 586 + idx * 34);
    });

    // Détail par quart-temps si disponible
    if (typeof hasRecordedQuarterStats === "function" && hasRecordedQuarterStats(m)) {
      const qs = ensureQuarterStats(m);
      const qtLine = `QT1 ${qs.QT1.ph}-${qs.QT1.pa}  •  QT2 ${qs.QT2.ph}-${qs.QT2.pa}  •  QT3 ${qs.QT3.ph}-${qs.QT3.pa}  •  QT4 ${qs.QT4.ph}-${qs.QT4.pa}`;
      ctx.fillStyle = "#EFF6FF";
      drawRoundedRect(ctx, 110, 668, W - 220, 44, 14);
      ctx.fill();
      ctx.fillStyle = "#1E3A8A";
      ctx.font = "800 21px Arial, sans-serif";
      ctx.fillText(qtLine, W / 2, 697);
    } else {
      ctx.fillStyle = "#64748B";
      ctx.font = "800 22px Arial, sans-serif";
      ctx.fillText(`${m.wkLabel || ""}`, W / 2, 696);
    }

    // 5. Bloc Infos Pratiques (Date, Salle) sans adresse exacte
    const info = getMatchVenueInfo(m);
    ctx.fillStyle = "rgba(255, 255, 255, 0.12)";
    drawRoundedRect(ctx, 56, 766, W - 112, 168, 26);
    ctx.strokeStyle = "rgba(147, 197, 253, 0.45)";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fill();

    ctx.fillStyle = "#FFFFFF";
    ctx.font = "800 26px Arial, sans-serif";
    ctx.fillText(`📅 ${m.date} à ${m.time}   •   🏟️ ${info.salle}`, W / 2, 822);

    if (info.precision) {
      ctx.fillStyle = "#FDE68A";
      ctx.font = "700 22px Arial, sans-serif";
      ctx.fillText(`📌 ${info.precision}`, W / 2, 864);
      ctx.fillStyle = "#93C5FD";
      ctx.font = "700 21px Arial, sans-serif";
      ctx.fillText("📲 Suivez le direct & l'itinéraire GPS sur l'appli LSBSC", W / 2, 906);
    } else {
      ctx.fillStyle = "#93C5FD";
      ctx.font = "800 23px Arial, sans-serif";
      ctx.fillText("📲 Suivez le direct & l'itinéraire GPS sur l'appli LSBSC", W / 2, 874);
    }

    // 6. Pied de carte
    ctx.fillStyle = "#F59E0B";
    ctx.font = "900 22px Arial, sans-serif";
    ctx.fillText("ALLEZ LES LIONS DU LSBSC ! 🦁🏀", W / 2, 992);

    return canvas;
  }

  function canvasToPngBlob(canvas) {
    return new Promise((resolve, reject) => {
      try {
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject(new Error("toBlob null"));
        }, "image/png");
      } catch (e) {
        reject(e);
      }
    });
  }

  window.shareMatchAsImage = async function(matchId) {
    const m = state.matches.find(x => x.id === matchId) || state.matches.find(x => x.id === state.selectedMatchId);
    if (!m) return;

    const btn = document.getElementById("btnShareImageTile");
    const origHtml = btn ? btn.innerHTML : "";
    if (btn) {
      btn.innerHTML = `<span class="share-tile-ico">⏳</span><span>Création de l'image...</span>`;
    }

    try {
      const canvas = await renderMatchShareCardCanvas(m);
      const blob = await canvasToPngBlob(canvas);
      const safeCat = (m.cat || "LSBSC").replace(/[^a-zA-Z0-9_-]/g, "");
      const fileName = `LSBSC-${safeCat}-match-${m.id}.png`;
      const file = new File([blob], fileName, { type: "image/png" });
      const payload = buildMatchSharePayload(m);

      // Partage natif avec fichier image (ouvre directement WhatsApp / Messagerie sur téléphone)
      if (navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
        await navigator.share({
          files: [file],
          title: payload.subject,
          text: `${m.home} vs ${m.away} (${m.date} à ${m.time}) — Direct & GPS : ${payload.appUrl}`
        });
        if (btn) btn.innerHTML = origHtml;
        return;
      }

      // Secours PC / navigateur sans partage de fichiers : téléchargement automatique du PNG
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 4000);

      if (btn) {
        btn.innerHTML = `<span class="share-tile-ico">✅</span><span>Image PNG téléchargée !</span>`;
        setTimeout(() => { if (btn) btn.innerHTML = origHtml; }, 2200);
      }
    } catch (err) {
      if (btn) btn.innerHTML = origHtml;
      if (err && err.name === "AbortError") return;
      alert("Impossible de générer l'image sur ce navigateur.");
    }
  };

  window.downloadMatchShareImage = async function(matchId) {
    const m = state.matches.find(x => x.id === matchId) || state.matches.find(x => x.id === state.selectedMatchId);
    if (!m) return;
    try {
      const canvas = await renderMatchShareCardCanvas(m);
      const blob = await canvasToPngBlob(canvas);
      const safeCat = (m.cat || "LSBSC").replace(/[^a-zA-Z0-9_-]/g, "");
      const fileName = `LSBSC-${safeCat}-match-${m.id}.png`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    } catch (e) {
      alert("Erreur lors du téléchargement de l'image.");
    }
  };

  // Enrichir l'onglet Partage avec l'aperçu de la carte image + bouton "Partager en Image (WhatsApp)" + "Télécharger Image"
  const _prevRenderSelectedMatchShareTabV34 = renderSelectedMatchShareTab;
  renderSelectedMatchShareTab = function() {
    _prevRenderSelectedMatchShareTabV34();
    const shareWrap = document.getElementById("sbShareTabWrap");
    if (!shareWrap) return;
    const current = state.matches.find(m => m.id === state.selectedMatchId) || state.matches[0];
    if (!current) return;

    const tilesGrid = shareWrap.querySelector(".share-tiles-grid");
    if (tilesGrid && !document.getElementById("btnShareImageTile")) {
      tilesGrid.insertAdjacentHTML(
        "afterbegin",
        `
        <button type="button" id="btnShareImageTile" class="share-tile-btn" style="background:linear-gradient(135deg,#16A34A,#15803D);color:#FFFFFF;grid-column:1 / -1;" onclick="shareMatchAsImage(${current.id})">
          <span class="share-tile-ico">🖼️</span>
          <span>Partager en Image PNG (WhatsApp / Réseaux)</span>
        </button>
        <button type="button" class="share-tile-btn" style="background:#0F172A;color:#FCD34D;" onclick="downloadMatchShareImage(${current.id})">
          <span class="share-tile-ico">⬇️</span>
          <span>Télécharger l'Image</span>
        </button>
        `
      );
    }
  };
})();


/* ================= EXTENSION V36 : FICHES MATCHS PDF (DONNÉES JOUEUSES & RATIOS) RÉSERVÉES ADMIN & COACHS ================= */
(function() {
  const PDF_MATCH_REPORTS = {
    3: {
      matchRef: "Rencontre N° 6110 • DFU18 Poule D",
      dateLabel: "12/09/26 à 18:30 • LILLE",
      arbitres: "BORIGHEM C • DUFAY P",
      homeTeam: "LILLE-EST BASKET-1",
      awayTeam: "LILLE SUD BASKET-BALL SPORTING CLUB",
      lsbscSide: "away",
      finalScore: { home: 66, away: 21 },
      halves: {
        home: { h1: 29, h2: 37, ot: 0, total: 66, foulsH1: 11, foulsH2: 5, foulsTot: 16 },
        away: { h1: 11, h2: 10, ot: 0, total: 21, foulsH1: 12, foulsH2: 6, foulsTot: 18 }
      },
      ratios: {
        home: { maxLead: 45, maxRun: 15, benchPts: 28, ties: 0, leadTime: "39:30" },
        away: { maxLead: 0, maxRun: 4, benchPts: 7, ties: 0, leadTime: "00:00" }
      },
      players: {
        home: [
          { num: "4",  name: "GARATE LERGA, Eider", starter: false, min: "34:06", pts: 11, fg: 4, p3: 0, p2in: 4, p2out: 0, ft: 3, fouls: 1 },
          { num: "5",  name: "Defoe, Annaelle", starter: true,  min: "34:28", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 1 },
          { num: "6",  name: "Medahi, Hind", starter: false, min: "33:46", pts: 7,  fg: 3, p3: 0, p2in: 3, p2out: 0, ft: 1, fouls: 3 },
          { num: "7",  name: "Idrissi, Inaya", starter: false, min: "32:16", pts: 4,  fg: 2, p3: 0, p2in: 1, p2out: 1, ft: 0, fouls: 1 },
          { num: "8",  name: "Tandji, Assil", starter: true,  min: "33:27", pts: 5,  fg: 1, p3: 1, p2in: 0, p2out: 0, ft: 2, fouls: 3 },
          { num: "9",  name: "Nempont, Jeanne", starter: true,  min: "36:48", pts: 10, fg: 4, p3: 0, p2in: 4, p2out: 0, ft: 2, fouls: 1 },
          { num: "10", name: "DENIS, Sofia", starter: false, min: "35:36", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 3 },
          { num: "12", name: "NAELS, Erine", starter: false, min: "34:35", pts: 4,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 0, fouls: 0 },
          { num: "13", name: "Tchako Touabou Kadji, Axelle", starter: true, min: "35:17", pts: 19, fg: 9, p3: 0, p2in: 9, p2out: 0, ft: 1, fouls: 2 },
          { num: "14", name: "GARATE LERGA, Amets", starter: true,  min: "34:57", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 1 }
        ],
        away: [
          { num: "4",  name: "AIT MOHA, Chaima", starter: false, min: "36:51", pts: 2, fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 0 },
          { num: "5",  name: "Fouad, Zéïna", starter: true,  min: "37:09", pts: 5, fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 1, fouls: 0 },
          { num: "7",  name: "Keita, Marieme", starter: false, min: "33:21", pts: 2, fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 1 },
          { num: "8",  name: "AOLAD AISSA, Maissa", starter: true,  min: "39:32", pts: 2, fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 2 },
          { num: "9",  name: "MESSO FOIRESTIER, Melodie", starter: true,  min: "34:58", pts: 0, fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 },
          { num: "10", name: "VENDEVILLE, Samia", starter: false, min: "34:05", pts: 3, fg: 1, p3: 1, p2in: 0, p2out: 0, ft: 0, fouls: 2 },
          { num: "11", name: "Pognon-sabir, Lila", starter: true,  min: "35:42", pts: 2, fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 3 },
          { num: "12", name: "LOUAIL, Nour", starter: false, min: "29:31", pts: 0, fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 },
          { num: "14", name: "OUCHEN, Israh", starter: true,  min: "32:12", pts: 5, fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 3, fouls: 4 },
          { num: "15", name: "KOLAI, Tasnime", starter: false, min: "31:54", pts: 0, fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 4 }
        ]
      }
    },
    7: {
      matchRef: "Rencontre N° 6132 • DFU18 Poule D",
      dateLabel: "19/09/26 à 18:30 • LILLE",
      arbitres: "JAUMOUILLE L • EN-NABBADI N",
      homeTeam: "LILLE SUD BASKET-BALL SPORTING CLUB",
      awayTeam: "WATTRELOS BC",
      lsbscSide: "home",
      finalScore: { home: 55, away: 44 },
      halves: {
        home: { h1: 29, h2: 26, ot: 0, total: 55, foulsH1: 12, foulsH2: 18, foulsTot: 30 },
        away: { h1: 9,  h2: 35, ot: 0, total: 44, foulsH1: 9,  foulsH2: 9,  foulsTot: 18 }
      },
      ratios: {
        home: { maxLead: 22, maxRun: 11, benchPts: 13, ties: 0, leadTime: "14:51" },
        away: { maxLead: 0,  maxRun: 10, benchPts: 3,  ties: 0, leadTime: "00:00" }
      },
      players: {
        home: [
          { num: "4",  name: "ABOU CHAAYA, Sila", starter: false, min: "13:39", pts: 2,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 2, fouls: 0 },
          { num: "5",  name: "Fouad, Zéïna", starter: true,  min: "20:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 5 },
          { num: "7",  name: "Keita, Marieme", starter: false, min: "19:50", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 },
          { num: "8",  name: "AOLAD AISSA, Maissa", starter: true,  min: "29:11", pts: 14, fg: 4, p3: 2, p2in: 2, p2out: 0, ft: 4, fouls: 2 },
          { num: "9",  name: "MESSO FOIRESTIER, Melodie", starter: false, min: "18:03", pts: 7,  fg: 3, p3: 1, p2in: 1, p2out: 1, ft: 0, fouls: 5 },
          { num: "10", name: "VENDEVILLE, Samia", starter: true,  min: "31:17", pts: 11, fg: 4, p3: 2, p2in: 2, p2out: 0, ft: 1, fouls: 3 },
          { num: "11", name: "Pognon-sabir, Lila", starter: false, min: "18:34", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 4 },
          { num: "12", name: "LOUAIL, Nour", starter: false, min: "07:37", pts: 2,  fg: 1, p3: 0, p2in: 0, p2out: 1, ft: 0, fouls: 2 },
          { num: "14", name: "OUCHEN, Israh", starter: true,  min: "30:11", pts: 13, fg: 6, p3: 1, p2in: 5, p2out: 0, ft: 0, fouls: 4 },
          { num: "15", name: "KOLAI, Tasnime", starter: true,  min: "23:00", pts: 2,  fg: 1, p3: 0, p2in: 0, p2out: 1, ft: 0, fouls: 4 }
        ],
        away: [
          { num: "4",  name: "BAYART, Selene", starter: false, min: "11:09", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 2 },
          { num: "6",  name: "LECLERCQ, Zelie", starter: true,  min: "22:13", pts: 1,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 1, fouls: 4 },
          { num: "7",  name: "SKENDER, Lilya", starter: true,  min: "28:59", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 4 },
          { num: "8",  name: "RENAUX, Zélie", starter: true,  min: "37:59", pts: 28, fg: 9, p3: 1, p2in: 7, p2out: 1, ft: 9, fouls: 1 },
          { num: "11", name: "PREVOST, Jannah", starter: false, min: "18:58", pts: 3,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 1, fouls: 4 },
          { num: "13", name: "ADAM, Emma", starter: true,  min: "34:35", pts: 8,  fg: 3, p3: 0, p2in: 3, p2out: 0, ft: 2, fouls: 1 },
          { num: "15", name: "CUDEAUX, Leane", starter: false, min: "19:12", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "23", name: "BARBENSON, Mya", starter: true,  min: "27:04", pts: 4,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 0, fouls: 2 }
        ]
      }
    },
    15: {
      matchRef: "Rencontre N° 6154 • DFU18 Poule D",
      dateLabel: "26/09/26 à 18:30 • WAMBRECHIES",
      arbitres: "HUCKEN A • WAMBRE M",
      homeTeam: "WAMBRECHIES J",
      awayTeam: "LILLE SUD BASKET-BALL SPORTING CLUB",
      lsbscSide: "away",
      finalScore: { home: 40, away: 32 },
      halves: {
        home: { h1: 20, h2: 20, ot: 0, total: 40, foulsH1: 6, foulsH2: 14, foulsTot: 20 },
        away: { h1: 14, h2: 18, ot: 0, total: 32, foulsH1: 7, foulsH2: 7,  foulsTot: 14 }
      },
      ratios: {
        home: { maxLead: 12, maxRun: 6, benchPts: 15, ties: 1, leadTime: "40:00" },
        away: { maxLead: 0,  maxRun: 5, benchPts: 2,  ties: 1, leadTime: "00:00" }
      },
      players: {
        home: [
          { num: "4",  name: "BROUCQSAULT, Marine", starter: true,  min: "09:45", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 4 },
          { num: "5",  name: "DE PONTON D AMECOURT, Ellie", starter: true, min: "02:12", pts: 0, fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 },
          { num: "6",  name: "COUSTENOBLE, Jeanne", starter: false, min: "00:00", pts: 0, fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "7",  name: "BILLARD-GUILLOT, Amarante", starter: true, min: "10:00", pts: 9, fg: 4, p3: 0, p2in: 3, p2out: 1, ft: 1, fouls: 4 },
          { num: "8",  name: "PLEUX, Jade", starter: false, min: "07:48", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "9",  name: "REYNS, Laly", starter: false, min: "00:15", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 4 },
          { num: "10", name: "LEGRAND, Juline", starter: false, min: "07:33", pts: 3,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 1, fouls: 1 },
          { num: "11", name: "LECOUTRE, Chloe", starter: true,  min: "02:27", pts: 6,  fg: 3, p3: 0, p2in: 3, p2out: 0, ft: 0, fouls: 2 },
          { num: "12", name: "HENSGEN, Lise", starter: true,  min: "02:12", pts: 8,  fg: 4, p3: 0, p2in: 3, p2out: 1, ft: 0, fouls: 4 },
          { num: "13", name: "Levant, Lola", starter: false, min: "07:48", pts: 10, fg: 5, p3: 0, p2in: 5, p2out: 0, ft: 0, fouls: 0 }
        ],
        away: [
          { num: "4",  name: "ABOU CHAAYA, Sila", starter: false, min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 0 },
          { num: "5",  name: "Fouad, Zéïna", starter: true,  min: "02:27", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 1 },
          { num: "7",  name: "Keita, Marieme", starter: false, min: "07:33", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 },
          { num: "8",  name: "AOLAD AISSA, Maissa", starter: true,  min: "02:12", pts: 5,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 1, fouls: 4 },
          { num: "9",  name: "MESSO FOIRESTIER, Melodie", starter: true,  min: "02:12", pts: 5,  fg: 2, p3: 1, p2in: 1, p2out: 0, ft: 0, fouls: 1 },
          { num: "10", name: "VENDEVILLE, Samia", starter: false, min: "07:48", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 3 },
          { num: "11", name: "Pognon-sabir, Lila", starter: false, min: "07:48", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "12", name: "AIT MOHA, Chaima", starter: false, min: "07:48", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 },
          { num: "14", name: "OUCHEN, Israh", starter: true,  min: "10:00", pts: 14, fg: 6, p3: 0, p2in: 6, p2out: 0, ft: 2, fouls: 1 },
          { num: "15", name: "KOLAI, Tasnime", starter: true,  min: "02:12", pts: 4,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 0, fouls: 2 }
        ]
      }
    },
    22: {
      matchRef: "Rencontre N° 6174 • DFU18 Poule D",
      dateLabel: "03/10/26 à 17:00 • LILLE",
      arbitres: "EN-NABBADI N • RICHARD M",
      homeTeam: "LILLE SUD BASKET-BALL SPORTING CLUB",
      awayTeam: "MARCQ EN BAROEUL ASJ",
      lsbscSide: "home",
      finalScore: { home: 37, away: 70 },
      halves: {
        home: { h1: 16, h2: 21, ot: 0, total: 37, foulsH1: 11, foulsH2: 13, foulsTot: 24 },
        away: { h1: 33, h2: 37, ot: 0, total: 70, foulsH1: 15, foulsH2: 6,  foulsTot: 21 }
      },
      ratios: {
        home: { maxLead: 0,  maxRun: 6,  benchPts: 10, ties: 0, leadTime: "00:00" },
        away: { maxLead: 34, maxRun: 12, benchPts: 24, ties: 0, leadTime: "40:00" }
      },
      players: {
        home: [
          { num: "4",  name: "AIT MOHA, Chaima", starter: false, min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 0 },
          { num: "5",  name: "Fouad, Zéïna", starter: true,  min: "00:00", pts: 8,  fg: 4, p3: 0, p2in: 3, p2out: 1, ft: 0, fouls: 4 },
          { num: "7",  name: "Keita, Marieme", starter: false, min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 0 },
          { num: "8",  name: "AOLAD AISSA, Maissa", starter: true,  min: "00:00", pts: 11, fg: 3, p3: 1, p2in: 2, p2out: 0, ft: 4, fouls: 4 },
          { num: "9",  name: "MESSO FOIRESTIER, Melodie", starter: true,  min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 1 },
          { num: "10", name: "VENDEVILLE, Samia", starter: false, min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 3 },
          { num: "11", name: "Pognon-sabir, Lila", starter: false, min: "00:00", pts: 4,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 0, fouls: 3 },
          { num: "12", name: "KOLAI, Tasnime", starter: true,  min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 5 },
          { num: "14", name: "OUCHEN, Israh", starter: true,  min: "00:00", pts: 4,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 0, fouls: 3 },
          { num: "15", name: "ABOU CHAAYA, Sila", starter: false, min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 1 }
        ],
        away: [
          { num: "6",  name: "COULIER, Jade", starter: false, min: "00:00", pts: 7,  fg: 3, p3: 0, p2in: 3, p2out: 0, ft: 1, fouls: 0 },
          { num: "9",  name: "WIKRZAK LECOCQ, Rosalie", starter: false, min: "00:00", pts: 2, fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 2, fouls: 3 },
          { num: "11", name: "LEGRAND, Anaelle", starter: true,  min: "00:00", pts: 7,  fg: 3, p3: 0, p2in: 3, p2out: 0, ft: 1, fouls: 3 },
          { num: "13", name: "VANBESIEN, Lily", starter: false, min: "00:00", pts: 8,  fg: 4, p3: 0, p2in: 3, p2out: 1, ft: 0, fouls: 4 },
          { num: "14", name: "VASSEUR, Hanaë", starter: true,  min: "00:00", pts: 6,  fg: 3, p3: 0, p2in: 3, p2out: 0, ft: 0, fouls: 3 },
          { num: "19", name: "HEYDARZADEH TAHERI, Dayana", starter: true, min: "00:00", pts: 10, fg: 5, p3: 0, p2in: 5, p2out: 0, ft: 0, fouls: 3 },
          { num: "22", name: "PECHON, Lilas", starter: false, min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 1 },
          { num: "23", name: "VERMEERSCH, Kaelia", starter: true,  min: "00:00", pts: 11, fg: 5, p3: 1, p2in: 3, p2out: 1, ft: 0, fouls: 2 },
          { num: "24", name: "RENARD, Lilou", starter: true,  min: "00:00", pts: 12, fg: 5, p3: 0, p2in: 5, p2out: 0, ft: 2, fouls: 2 },
          { num: "34", name: "COMMEYNE, Naomi", starter: false, min: "00:00", pts: 5,  fg: 2, p3: 0, p2in: 1, p2out: 1, ft: 1, fouls: 0 }
        ]
      }
    },
    32: {
      matchRef: "Rencontre N° 6195 • DFU18 Poule D",
      dateLabel: "10/10/26 à 18:30 • LILLE",
      arbitres: "DECOTTIGNIES • NUTTENS R • LEMAITRE N",
      homeTeam: "LILLE SUD BASKET-BALL SPORTING CLUB",
      awayTeam: "LOOSSOIS BASKET CLUB",
      lsbscSide: "home",
      finalScore: { home: 61, away: 23 },
      halves: {
        home: { h1: 24, h2: 37, ot: 0, total: 61, foulsH1: 8, foulsH2: 5, foulsTot: 13 },
        away: { h1: 12, h2: 11, ot: 0, total: 23, foulsH1: 5, foulsH2: 8, foulsTot: 13 }
      },
      ratios: {
        home: { maxLead: 38, maxRun: 16, benchPts: 28, ties: 1, leadTime: "40:00" },
        away: { maxLead: 2,  maxRun: 4,  benchPts: 3,  ties: 1, leadTime: "00:00" }
      },
      players: {
        home: [
          { num: "4",  name: "ABOU CHAAYA, Sila", starter: false, min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "5",  name: "Fouad, Zéïna", starter: true,  min: "00:00", pts: 5,  fg: 2, p3: 0, p2in: 2, p2out: 0, ft: 1, fouls: 3 },
          { num: "7",  name: "Keita, Marieme", starter: false, min: "00:00", pts: 1,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 1, fouls: 2 },
          { num: "8",  name: "AOLAD AISSA, Maissa", starter: true,  min: "00:00", pts: 11, fg: 4, p3: 2, p2in: 1, p2out: 1, ft: 1, fouls: 2 },
          { num: "9",  name: "MESSO FOIRESTIER, Melodie", starter: false, min: "00:00", pts: 7,  fg: 3, p3: 1, p2in: 2, p2out: 0, ft: 0, fouls: 1 },
          { num: "10", name: "VENDEVILLE, Samia", starter: true,  min: "00:00", pts: 9,  fg: 4, p3: 1, p2in: 3, p2out: 0, ft: 0, fouls: 1 },
          { num: "11", name: "KOLAI, Tasnime", starter: true,  min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 2 },
          { num: "12", name: "LOUAIL, Nour", starter: false, min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "14", name: "OUCHEN, Israh", starter: false, min: "00:00", pts: 20, fg: 8, p3: 2, p2in: 4, p2out: 2, ft: 2, fouls: 2 },
          { num: "15", name: "AIT MOHA, Chaima", starter: true,  min: "00:00", pts: 8,  fg: 4, p3: 0, p2in: 4, p2out: 0, ft: 0, fouls: 0 }
        ],
        away: [
          { num: "1",  name: "Zahraoui, Noha", starter: true,  min: "00:00", pts: 2,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 0, fouls: 4 },
          { num: "2",  name: "ANTONIOL, Josephine", starter: false, min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 },
          { num: "3",  name: "DONGO, Noémie", starter: true,  min: "00:00", pts: 11, fg: 5, p3: 0, p2in: 4, p2out: 1, ft: 1, fouls: 4 },
          { num: "4",  name: "PAMART, Rosalie", starter: true,  min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 4 },
          { num: "5",  name: "NIANGANE, Médina", starter: true,  min: "00:00", pts: 3,  fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 1, fouls: 1 },
          { num: "6",  name: "AKAKPO, Maëlle", starter: true,  min: "00:00", pts: 4,  fg: 2, p3: 0, p2in: 1, p2out: 1, ft: 0, fouls: 0 },
          { num: "7",  name: "POIGNANT DE GUBERNATIS, Soléane", starter: false, min: "00:00", pts: 3, fg: 1, p3: 0, p2in: 1, p2out: 0, ft: 1, fouls: 0 },
          { num: "8",  name: "QUESTIER, Ines", starter: false, min: "00:00", pts: 0,  fg: 0, p3: 0, p2in: 0, p2out: 0, ft: 0, fouls: 0 }
        ]
      }
    }
  };

  window.getPdfMatchReport = function(matchId) {
    return PDF_MATCH_REPORTS[Number(matchId)] || null;
  };

  function syncCoachTabVisibility() {
    const tabBtn = document.getElementById("btnSbTabCoachPdf");
    const coachWrap = document.getElementById("sbCoachPdfTabWrap");
    const unlocked = Boolean(state.staffUnlocked);

    if (tabBtn) {
      tabBtn.style.display = unlocked ? "inline-flex" : "none";
    }
    if (!unlocked) {
      if (coachWrap) coachWrap.style.display = "none";
      if (state.selectedMatchViewTab === "coach_pdf") {
        state.selectedMatchViewTab = "match";
        const arenaWrap = document.getElementById("sbArenaMainWrap");
        const btnMatch = document.getElementById("btnSbTabMatch");
        if (arenaWrap) arenaWrap.style.display = "flex";
        if (btnMatch) btnMatch.classList.add("active");
        if (tabBtn) tabBtn.classList.remove("active");
      }
    }
  }

  function renderPlayerRows(list) {
    return (list || []).map(p => `
      <tr class="${p.starter ? "starter-row" : ""}">
        <td><strong>#${p.num}</strong></td>
        <td class="p-name">${p.name}</td>
        <td>${p.min && p.min !== "00:00" ? p.min : "-"}</td>
        <td><strong>${p.pts}</strong></td>
        <td>${p.fg}</td>
        <td>${p.p3}</td>
        <td>${p.p2in}</td>
        <td>${p.p2out}</td>
        <td>${p.ft}</td>
        <td class="${p.fouls >= 5 ? "qt-foul-bonus" : ""}">${p.fouls}</td>
      </tr>
    `).join("");
  }

  function renderCoachPdfTab() {
    const coachWrap = document.getElementById("sbCoachPdfTabWrap");
    if (!coachWrap) return;

    if (!state.staffUnlocked) {
      coachWrap.style.display = "none";
      return;
    }

    const current = state.matches.find(m => m.id === state.selectedMatchId) || state.matches[0];
    const report = current ? getPdfMatchReport(current.id) : null;
    const roleLabel = state.activeStaffName ? `${state.activeStaffName}` : "Staff / Coach";

    if (!report) {
      coachWrap.innerHTML = `
        <div class="coach-stats-banner">
          <div>
            <h4>📋 Feuille de Match & Stats Coach (${current ? current.cat : ""})</h4>
            <p>Accès réservé Admin & Coachs • Connecté : ${roleLabel}</p>
          </div>
          <span class="coach-lock-pill">🔐 Privé Coach / Admin</span>
        </div>
        <div class="qt-box-card">
          <div style="font-size:0.84rem;font-weight:800;color:#475569;text-align:center;padding:12px;">
            Aucune feuille de match PDF importée pour cette rencontre pour le moment.<br>
            <span style="font-size:0.76rem;color:#64748B;">Transmettez le PDF de la rencontre pour l'ajouter à cette fiche.</span>
          </div>
        </div>
      `;
      return;
    }

    const lsbscIsHome = report.lsbscSide === "home";
    const oppSide = lsbscIsHome ? "away" : "home";
    const rLsbsc = report.ratios[report.lsbscSide];
    const rOpp = report.ratios[oppSide];
    const hLsbsc = report.halves[report.lsbscSide];
    const hOpp = report.halves[oppSide];
    const oppTeamName = lsbscIsHome ? report.awayTeam : report.homeTeam;
    const lsbscLocTag = lsbscIsHome ? "Domicile" : "Extérieur";
    const oppLocTag = lsbscIsHome ? "Visiteurs" : "Locaux";

    coachWrap.innerHTML = `
      <div class="coach-stats-banner">
        <div>
          <h4>📋 ${report.matchRef} — Analyse PDF</h4>
          <p>${report.dateLabel} • Arbitres : ${report.arbitres} • Vue : ${roleLabel}</p>
        </div>
        <span class="coach-lock-pill">🔐 Réservé Admin & Coachs</span>
      </div>

      <div class="qt-box-card">
        <div class="qt-box-header">
          <strong>📈 Mi-Temps & Ratios (${report.homeTeam} ${report.finalScore.home} - ${report.finalScore.away} ${report.awayTeam})</strong>
        </div>
        <div class="coach-ratios-grid">
          <div class="coach-ratio-tile">
            <span>Mi-temps LSBSC (${lsbscLocTag})</span>
            <strong>1re MT : ${hLsbsc.h1} • 2e MT : ${hLsbsc.h2}</strong>
          </div>
          <div class="coach-ratio-tile">
            <span>Avantage max LSBSC</span>
            <strong>+${rLsbsc.maxLead} pts (${rLsbsc.leadTime})</strong>
          </div>
          <div class="coach-ratio-tile">
            <span>Série / Banc LSBSC</span>
            <strong>Série ${rLsbsc.maxRun} • Banc ${rLsbsc.benchPts} pts</strong>
          </div>
          <div class="coach-ratio-tile">
            <span>Mi-temps Adversaire</span>
            <strong>1re MT : ${hOpp.h1} • 2e MT : ${hOpp.h2}</strong>
          </div>
          <div class="coach-ratio-tile">
            <span>Avantage max Adversaire</span>
            <strong>+${rOpp.maxLead} pts (${rOpp.leadTime})</strong>
          </div>
          <div class="coach-ratio-tile">
            <span>Série / Banc Adversaire</span>
            <strong>Série ${rOpp.maxRun} • Banc ${rOpp.benchPts} pts</strong>
          </div>
        </div>
      </div>

      <div class="qt-box-card" style="border-left-color:#EA580C;">
        <div class="qt-box-header">
          <strong style="color:#9A3412;">🦁 Joueuses LSBSC (${lsbscLocTag}) — Total : ${hLsbsc.total} pts • ${hLsbsc.foulsTot} fautes (1re MT: ${hLsbsc.foulsH1}, 2e MT: ${hLsbsc.foulsH2})</strong>
        </div>
        <div class="qt-table-scroll">
          <table class="coach-players-table">
            <thead>
              <tr>
                <th>N°</th>
                <th style="text-align:left;">Joueuse</th>
                <th>Tps</th>
                <th>Pts</th>
                <th>Tirs</th>
                <th>3pts</th>
                <th>2Int</th>
                <th>2Ext</th>
                <th>LF</th>
                <th>Ftes</th>
              </tr>
            </thead>
            <tbody>${renderPlayerRows(report.players[report.lsbscSide])}</tbody>
          </table>
        </div>
      </div>

      <div class="qt-box-card">
        <div class="qt-box-header">
          <strong>🏀 Joueuses Adverses — ${oppTeamName} (${oppLocTag}) — Total : ${hOpp.total} pts • ${hOpp.foulsTot} fautes</strong>
        </div>
        <div class="qt-table-scroll">
          <table class="coach-players-table">
            <thead>
              <tr>
                <th>N°</th>
                <th style="text-align:left;">Joueuse</th>
                <th>Tps</th>
                <th>Pts</th>
                <th>Tirs</th>
                <th>3pts</th>
                <th>2Int</th>
                <th>2Ext</th>
                <th>LF</th>
                <th>Ftes</th>
              </tr>
            </thead>
            <tbody>${renderPlayerRows(report.players[oppSide])}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  window.switchSelectedMatchTab = function(tabName) {
    if (tabName === "coach_pdf" && !state.staffUnlocked) {
      if (typeof requestPinAccess === "function") requestPinAccess("staff");
      return;
    }
    const validTab = ["match", "stats", "share", "coach_pdf"].includes(tabName) ? tabName : "match";
    state.selectedMatchViewTab = validTab;

    const btnMatch = document.getElementById("btnSbTabMatch");
    const btnStats = document.getElementById("btnSbTabStats");
    const btnShare = document.getElementById("btnSbTabShare");
    const btnCoach = document.getElementById("btnSbTabCoachPdf");
    const arenaWrap = document.getElementById("sbArenaMainWrap");
    const statsWrap = document.getElementById("sbStatsTabWrap");
    const shareWrap = document.getElementById("sbShareTabWrap");
    const coachWrap = document.getElementById("sbCoachPdfTabWrap");

    if (btnMatch) btnMatch.classList.toggle("active", validTab === "match");
    if (btnStats) btnStats.classList.toggle("active", validTab === "stats");
    if (btnShare) btnShare.classList.toggle("active", validTab === "share");
    if (btnCoach) btnCoach.classList.toggle("active", validTab === "coach_pdf");

    if (arenaWrap) arenaWrap.style.display = validTab === "match" ? "flex" : "none";
    if (statsWrap) {
      statsWrap.style.display = validTab === "stats" ? "flex" : "none";
      if (validTab === "stats" && typeof renderSelectedMatchStatsTab === "function") renderSelectedMatchStatsTab();
    }
    if (shareWrap) {
      shareWrap.style.display = validTab === "share" ? "flex" : "none";
      if (validTab === "share" && typeof renderSelectedMatchShareTab === "function") renderSelectedMatchShareTab();
    }
    if (coachWrap) {
      coachWrap.style.display = (validTab === "coach_pdf" && state.staffUnlocked) ? "flex" : "none";
      if (validTab === "coach_pdf" && state.staffUnlocked) renderCoachPdfTab();
    }
  };

  const _prevRenderRightV36 = renderRightColumn;
  renderRightColumn = function() {
    _prevRenderRightV36();
    syncCoachTabVisibility();
    if (state.selectedMatchViewTab === "coach_pdf" && state.staffUnlocked) {
      const arenaWrap = document.getElementById("sbArenaMainWrap");
      const statsWrap = document.getElementById("sbStatsTabWrap");
      const shareWrap = document.getElementById("sbShareTabWrap");
      const coachWrap = document.getElementById("sbCoachPdfTabWrap");
      if (arenaWrap) arenaWrap.style.display = "none";
      if (statsWrap) statsWrap.style.display = "none";
      if (shareWrap) shareWrap.style.display = "none";
      if (coachWrap) {
        coachWrap.style.display = "flex";
        renderCoachPdfTab();
      }
    }
  };

  document.addEventListener("DOMContentLoaded", () => {
    syncCoachTabVisibility();
  });
})();


/* ================= EXTENSION V41 : LECTURE FIABLE DE /imported_stats.json SUR TOUS LES APPAREILS + AGRÉGATION PAR NOM ================= */
(function() {
  const STORAGE_KEY_PDF_STATS = "lsbsc_imported_pdf_stats_v1";

  const sspState = {
    isOpen: false,
    team: "ALL",
    viewMode: "season", // 'season' | 'match'
    selectedMatchId: null,
    importedReports: {},
    lastCloudStatsSyncAt: 0
  };

  function normalizePlayerIdentity(rawName) {
    const base = String(rawName || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!base) return "joueuse";
    const parts = base.split(" ").filter(Boolean).sort();
    return parts.join("_");
  }

  function getFirebaseStatsNodeUrl() {
    const rawUrl = (typeof state !== "undefined" && state.syncUrl)
      ? String(state.syncUrl).trim()
      : (typeof DEFAULT_CLOUD_SYNC_URL !== "undefined" ? String(DEFAULT_CLOUD_SYNC_URL).trim() : "");
    if (!rawUrl) return "";

    try {
      const u = new URL(rawUrl);
      const parts = u.pathname.split("/").filter(Boolean);
      if (parts.length > 0 && parts[parts.length - 1].endsWith(".json")) {
        parts.pop();
      }
      parts.push("imported_stats.json");
      u.pathname = "/" + parts.join("/");
      return u.toString();
    } catch (e) {
      return rawUrl.replace(/\.json(\?.*)?$/, "/imported_stats.json$1");
    }
  }

  window.getImportedStatsMap = function() {
    return sspState.importedReports || {};
  };

  function loadImportedReports() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_PDF_STATS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          sspState.importedReports = parsed;
        }
      }
    } catch (e) {}
  }

  function saveImportedReports() {
    try {
      localStorage.setItem(STORAGE_KEY_PDF_STATS, JSON.stringify(sspState.importedReports));
    } catch (e) {}
  }

  function showImportFeedback(msg, isError = false) {
    const box = document.getElementById("sspImportFeedback");
    if (!box) return;
    box.style.display = "block";
    box.style.background = isError ? "#FEE2E2" : "#DCFCE7";
    box.style.borderColor = isError ? "#EF4444" : "#22C55E";
    box.style.color = isError ? "#991B1B" : "#14532D";
    box.textContent = msg;
  }

  // Envoie uniquement /imported_stats.json vers Firebase
  window.pushImportedStatsToCloud = async function(silent = false) {
    const statsUrl = getFirebaseStatsNodeUrl();
    if (!statsUrl) {
      if (!silent) showImportFeedback("⚠️ Aucune URL Firebase configurée dans Réglages (⚙️).", true);
      return false;
    }

    const now = Date.now();
    const statsPayload = {
      importedPdfReports: sspState.importedReports || {},
      updatedAt: now
    };

    try {
      const res = await fetch(statsUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(statsPayload)
      });
      if (!res.ok) {
        const errTxt = await res.text().catch(() => "");
        if (!silent) {
          showImportFeedback(`❌ Firebase a refusé l'écriture (${res.status}) : ${errTxt.slice(0, 120)}`, true);
        }
        return false;
      }

      sspState.lastCloudStatsSyncAt = now;
      if (!silent) {
        showImportFeedback(`☁️ Statistiques envoyées sur Firebase (${Object.keys(sspState.importedReports || {}).length} fiche(s)) !`);
      }
      return true;
    } catch (err) {
      if (!silent) {
        showImportFeedback("❌ Erreur réseau lors de l'envoi vers Firebase.", true);
      }
      return false;
    }
  };

  // Récupère /imported_stats.json depuis Firebase sur les autres appareils (même sans updatedAt ou avec timestamp plus récent)
  window.pullImportedStatsFromCloud = async function(forceRender = false) {
    const statsUrl = getFirebaseStatsNodeUrl();
    if (!statsUrl) return;

    try {
      const sep = statsUrl.includes("?") ? "&" : "?";
      const fetchUrl = `${statsUrl}${sep}_t=${Date.now()}`;
      const res = await fetch(fetchUrl, { headers: { "Accept": "application/json" }, cache: "no-store" });
      if (!res.ok) return;
      const cloudData = await res.json();
      if (!cloudData || typeof cloudData !== "object") return;

      const cloudReports = cloudData.importedPdfReports || (!cloudData.updatedAt ? cloudData : null);
      if (cloudReports && typeof cloudReports === "object") {
        const hasCloudEntries = Object.keys(cloudReports).length > 0;
        if (hasCloudEntries) {
          const merged = Object.assign({}, sspState.importedReports, cloudReports);
          const changed = JSON.stringify(merged) !== JSON.stringify(sspState.importedReports);
          if (changed) {
            sspState.importedReports = merged;
            saveImportedReports();
            if (forceRender && sspState.isOpen) {
              renderSeasonStatsPage();
            }
          }
        }
      }
    } catch (e) {}
  };

  const _prevGetPdfReport = window.getPdfMatchReport;
  window.getPdfMatchReport = function(matchId) {
    const idNum = Number(matchId);
    if (sspState.importedReports && sspState.importedReports[idNum]) {
      return sspState.importedReports[idNum];
    }
    return typeof _prevGetPdfReport === "function" ? _prevGetPdfReport(idNum) : null;
  };

  const _origPollCloudV41 = window.pollCloudSync;
  window.pollCloudSync = async function() {
    if (typeof _origPollCloudV41 === "function") {
      await _origPollCloudV41();
    }
    await window.pullImportedStatsFromCloud(true);
  };

  function syncPrivateStatsButtonVisibility() {
    const btn = document.getElementById("btnOpenSeasonStatsPage");
    const unlocked = Boolean(state.staffUnlocked);
    if (btn) {
      btn.style.display = unlocked ? "inline-flex" : "none";
    }
    if (!unlocked && sspState.isOpen) {
      window.closeSeasonStatsPage();
    }
  }

  function getLsbscScoreForMatch(m) {
    const homeIsUs = isLSBSC(m.home);
    const awayIsUs = isLSBSC(m.away);
    if (homeIsUs) return { us: Number(m.sh) || 0, opp: Number(m.sa) || 0, loc: "Domicile" };
    if (awayIsUs) return { us: Number(m.sa) || 0, opp: Number(m.sh) || 0, loc: "Extérieur" };
    return { us: Number(m.sh) || 0, opp: Number(m.sa) || 0, loc: "Club" };
  }

  function getTeamSeasonSummary(catCode) {
    const matches = (state.matches || []).filter(m => catCode === "ALL" || m.cat === catCode);
    const played = matches.filter(m => m.status === "finished" || m.status === "forfeit");
    const upcoming = matches.filter(m => m.status === "upcoming" || m.status === "live" || m.status === "postponed");

    let wins = 0, losses = 0, draws = 0, ptsFor = 0, ptsAgainst = 0, pdfCount = 0;
    const playerAgg = new Map();

    matches.forEach(m => {
      const rep = window.getPdfMatchReport(m.id);
      if (rep) pdfCount++;

      if (m.status === "finished" || m.status === "forfeit") {
        const sc = getLsbscScoreForMatch(m);
        ptsFor += sc.us;
        ptsAgainst += sc.opp;
        const out = computeMatchOutcome(m);
        if (out === "win") wins++;
        else if (out === "loss") losses++;
        else if (out === "draw") draws++;
      }

      if (rep && rep.players) {
        const sideKey = rep.lsbscSide === "home" ? "home" : "away";
        const plist = rep.players[sideKey] || [];
        plist.forEach(p => {
          const rawName = String(p.name || "Joueuse").trim();
          const identityKey = normalizePlayerIdentity(rawName);
          const numVal = String(p.num || "").replace(/^#/, "").trim();

          const cur = playerAgg.get(identityKey) || {
            name: rawName,
            numsSet: new Set(),
            games: 0,
            pts: 0,
            fg: 0,
            p3: 0,
            ft: 0,
            fouls: 0
          };
          if (numVal) cur.numsSet.add("#" + numVal);
          cur.games += 1;
          cur.pts += Number(p.pts) || 0;
          cur.fg += Number(p.fg) || 0;
          cur.p3 += Number(p.p3) || 0;
          cur.ft += Number(p.ft) || 0;
          cur.fouls += Number(p.fouls) || 0;
          playerAgg.set(identityKey, cur);
        });
      }
    });

    const gp = played.length;
    const avgFor = gp > 0 ? (ptsFor / gp).toFixed(1) : "0.0";
    const avgAgainst = gp > 0 ? (ptsAgainst / gp).toFixed(1) : "0.0";
    const diff = ptsFor - ptsAgainst;

    const topPlayers = Array.from(playerAgg.values())
      .map(p => ({
        name: p.name,
        numsLabel: Array.from(p.numsSet).join(", ") || "-",
        games: p.games,
        pts: p.pts,
        fg: p.fg,
        p3: p.p3,
        ft: p.ft,
        fouls: p.fouls
      }))
      .sort((a, b) => b.pts - a.pts);

    return {
      cat: catCode,
      totalMatches: matches.length,
      playedCount: gp,
      upcomingCount: upcoming.length,
      wins,
      losses,
      draws,
      ptsFor,
      ptsAgainst,
      avgFor,
      avgAgainst,
      diff,
      pdfCount,
      matches,
      topPlayers
    };
  }

  function populateMatchSelector() {
    const sel = document.getElementById("sspMatchSelect");
    if (!sel) return;
    const list = (state.matches || []).filter(m => sspState.team === "ALL" || m.cat === sspState.team);
    if (list.length === 0) {
      sel.innerHTML = `<option value="">Aucun match disponible</option>`;
      sspState.selectedMatchId = null;
      return;
    }
    if (!list.some(m => String(m.id) === String(sspState.selectedMatchId))) {
      sspState.selectedMatchId = list[0].id;
    }
    sel.innerHTML = list.map(m => {
      const hasPdf = window.getPdfMatchReport(m.id) ? " [PDF]" : "";
      const scoreTxt = (m.status === "finished" || m.status === "live") ? ` (${m.sh}-${m.sa})` : ` (${m.time})`;
      return `<option value="${m.id}" ${String(m.id) === String(sspState.selectedMatchId) ? "selected" : ""}>${m.date} • ${m.cat} • ${m.home} vs ${m.away}${scoreTxt}${hasPdf}</option>`;
    }).join("");
  }

  function renderSeasonSummaryView() {
    const contentEl = document.getElementById("sspDynamicContent");
    if (!contentEl) return;

    const sum = getTeamSeasonSummary(sspState.team);
    const teamTitle = sspState.team === "ALL" ? "Toutes les équipes LSBSC" : `Équipe ${sspState.team}`;

    const matchRowsHtml = sum.matches.map(m => {
      const sc = getLsbscScoreForMatch(m);
      const out = computeMatchOutcome(m);
      let resBadge = "🕒 À venir";
      if (m.status === "live") resBadge = "🔴 En direct";
      else if (m.status === "postponed") resBadge = "📅 Reporté";
      else if (m.status === "forfeit") resBadge = "🚫 Forfait";
      else if (m.status === "finished") {
        resBadge = out === "win" ? "✅ Victoire" : (out === "loss" ? "❌ Défaite" : "🤝 Nul");
      }
      const rep = window.getPdfMatchReport(m.id);
      return `
        <tr>
          <td>${m.date}</td>
          <td><strong>${m.cat}</strong></td>
          <td class="left">${m.home} vs ${m.away}</td>
          <td>${sc.loc}</td>
          <td><strong>${m.status === "upcoming" ? m.time : `${m.sh} - ${m.sa}`}</strong></td>
          <td>${resBadge}</td>
          <td>${rep ? `<span style="color:#15803D;font-weight:900;">✓ ${rep.matchRef || "PDF"}</span>` : `<span style="color:#94A3B8;">—</span>`}</td>
          <td>
            <button type="button" class="ssp-btn-open-match" onclick="openSingleMatchInStatsPage(${m.id})">Voir stats</button>
          </td>
        </tr>
      `;
    }).join("");

    const playersHtml = sum.topPlayers.length > 0 ? `
      <div class="ssp-panel">
        <div class="ssp-panel-title">
          <h3>🏅 Cumul Joueuses LSBSC par Nom (tous numéros confondus) — ${teamTitle}</h3>
          <span style="font-size:0.76rem;font-weight:800;color:#475569;">${sum.pdfCount} feuille(s) analysée(s)</span>
        </div>
        <div class="ssp-table-wrap">
          <table class="ssp-table">
            <thead>
              <tr>
                <th style="text-align:left;">Joueuse</th>
                <th>N° portés</th>
                <th>Matchs PDF</th>
                <th>Pts</th>
                <th>Moy. Pts</th>
                <th>Tirs</th>
                <th>3pts</th>
                <th>LF</th>
                <th>Fautes</th>
              </tr>
            </thead>
            <tbody>
              ${sum.topPlayers.map(p => `
                <tr>
                  <td class="left">${p.name}</td>
                  <td><span style="font-size:0.74rem;color:#475569;">${p.numsLabel}</span></td>
                  <td>${p.games}</td>
                  <td><strong>${p.pts}</strong></td>
                  <td>${p.games > 0 ? (p.pts / p.games).toFixed(1) : "0.0"}</td>
                  <td>${p.fg}</td>
                  <td>${p.p3}</td>
                  <td>${p.ft}</td>
                  <td>${p.fouls}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
    ` : "";

    contentEl.innerHTML = `
      <div class="ssp-kpi-row">
        <div class="ssp-kpi-card">
          <span>Bilan (${teamTitle})</span>
          <strong>${sum.wins}V - ${sum.losses}D${sum.draws ? ` - ${sum.draws}N` : ""}</strong>
          <small>${sum.playedCount} joué(s) / ${sum.totalMatches} programmé(s)</small>
        </div>
        <div class="ssp-kpi-card orange">
          <span>Points Marqués LSBSC</span>
          <strong>${sum.ptsFor} pts</strong>
          <small>Moyenne : ${sum.avgFor} pts / match</small>
        </div>
        <div class="ssp-kpi-card">
          <span>Points Encaissés</span>
          <strong>${sum.ptsAgainst} pts</strong>
          <small>Moyenne : ${sum.avgAgainst} pts / match</small>
        </div>
        <div class="ssp-kpi-card green">
          <span>Différentiel</span>
          <strong>${sum.diff >= 0 ? `+${sum.diff}` : sum.diff}</strong>
          <small>Écart global saison</small>
        </div>
        <div class="ssp-kpi-card gold">
          <span>Feuilles Stats PDF</span>
          <strong>${sum.pdfCount}</strong>
          <small>Disponibles en détail</small>
        </div>
      </div>

      ${playersHtml}

      <div class="ssp-panel">
        <div class="ssp-panel-title">
          <h3>📅 Tous les matchs (${teamTitle}) — Sélection rapide des stats par match</h3>
        </div>
        <div class="ssp-table-wrap">
          <table class="ssp-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Cat.</th>
                <th style="text-align:left;">Rencontre</th>
                <th>Lieu</th>
                <th>Score / Heure</th>
                <th>Statut</th>
                <th>Feuille PDF</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>${matchRowsHtml}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  function renderMatchDetailInSeasonPage() {
    const contentEl = document.getElementById("sspDynamicContent");
    if (!contentEl) return;

    const m = (state.matches || []).find(x => String(x.id) === String(sspState.selectedMatchId));
    if (!m) {
      contentEl.innerHTML = `<div class="ssp-panel"><p style="font-weight:800;color:#475569;">Sélectionnez un match dans la liste ci-dessus.</p></div>`;
      return;
    }

    const rep = window.getPdfMatchReport(m.id);
    const hasQt = typeof hasRecordedQuarterStats === "function" && hasRecordedQuarterStats(m);
    const qs = typeof ensureQuarterStats === "function" ? ensureQuarterStats(m) : null;

    const qtBlockHtml = (hasQt && qs) ? `
      <div class="ssp-panel">
        <div class="ssp-panel-title">
          <h3>⏱️ Points & Fautes par Quart-Temps (Table Direct)</h3>
        </div>
        <div class="ssp-table-wrap">
          <table class="ssp-table">
            <thead>
              <tr>
                <th style="text-align:left;">Ligne</th>
                <th>QT1</th>
                <th>QT2</th>
                <th>QT3</th>
                <th>QT4</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="left">Pts ${m.home}</td>
                <td>${qs.QT1.ph}</td>
                <td>${qs.QT2.ph}</td>
                <td>${qs.QT3.ph}</td>
                <td>${qs.QT4.ph}</td>
                <td><strong>${m.sh}</strong></td>
              </tr>
              <tr>
                <td class="left">Pts ${m.away}</td>
                <td>${qs.QT1.pa}</td>
                <td>${qs.QT2.pa}</td>
                <td>${qs.QT3.pa}</td>
                <td>${qs.QT4.pa}</td>
                <td><strong>${m.sa}</strong></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    ` : "";

    let pdfBlockHtml = "";
    if (rep) {
      const lsbscIsHome = rep.lsbscSide === "home";
      const oppSide = lsbscIsHome ? "away" : "home";
      const lsbscPlayers = (rep.players && rep.players[rep.lsbscSide]) || [];
      const oppPlayers = (rep.players && rep.players[oppSide]) || [];

      const renderRows = (arr) => arr.map(p => `
        <tr class="${p.starter ? "starter-row" : ""}">
          <td class="left">${p.name}</td>
          <td><strong>#${p.num}</strong></td>
          <td>${p.min && p.min !== "00:00" ? p.min : "-"}</td>
          <td><strong>${p.pts}</strong></td>
          <td>${p.fg}</td>
          <td>${p.p3}</td>
          <td>${p.p2in}</td>
          <td>${p.p2out}</td>
          <td>${p.ft}</td>
          <td>${p.fouls}</td>
        </tr>
      `).join("");

      pdfBlockHtml = `
        <div class="ssp-panel">
          <div class="ssp-panel-title">
            <h3>📋 ${rep.matchRef || "Feuille de match"} — ${rep.dateLabel || m.date}</h3>
            <span style="font-size:0.78rem;font-weight:800;color:#1E3A8A;">Score : ${rep.finalScore ? `${rep.finalScore.home} - ${rep.finalScore.away}` : `${m.sh} - ${m.sa}`}</span>
          </div>

          <h4 style="font-size:0.86rem;font-weight:900;color:#9A3412;margin-top:4px;">🦁 Joueuses LSBSC</h4>
          <div class="ssp-table-wrap">
            <table class="ssp-table">
              <thead>
                <tr>
                  <th style="text-align:left;">Joueuse</th>
                  <th>N° Match</th>
                  <th>Tps</th>
                  <th>Pts</th>
                  <th>Tirs</th>
                  <th>3pts</th>
                  <th>2Int</th>
                  <th>2Ext</th>
                  <th>LF</th>
                  <th>Ftes</th>
                </tr>
              </thead>
              <tbody>${renderRows(lsbscPlayers)}</tbody>
            </table>
          </div>

          <h4 style="font-size:0.86rem;font-weight:900;color:#1E3A8A;margin-top:10px;">🏀 Joueuses Adverses</h4>
          <div class="ssp-table-wrap">
            <table class="ssp-table">
              <thead>
                <tr>
                  <th style="text-align:left;">Joueuse</th>
                  <th>N° Match</th>
                  <th>Tps</th>
                  <th>Pts</th>
                  <th>Tirs</th>
                  <th>3pts</th>
                  <th>2Int</th>
                  <th>2Ext</th>
                  <th>LF</th>
                  <th>Ftes</th>
                </tr>
              </thead>
              <tbody>${renderRows(oppPlayers)}</tbody>
            </table>
          </div>
        </div>
      `;
    } else {
      pdfBlockHtml = `
        <div class="ssp-panel">
          <p style="font-size:0.86rem;font-weight:800;color:#475569;text-align:center;padding:10px;">
            Aucune feuille de match détaillée enregistrée pour ce match (${m.date} • ${m.home} vs ${m.away} • Score : ${m.sh} - ${m.sa}).<br>
            <span style="font-size:0.76rem;color:#64748B;">Vous pouvez importer un fichier JSON ou CSV de statistiques via le bouton « ⬆️ Importer Stats » en haut à droite.</span>
          </p>
        </div>
      `;
    }

    contentEl.innerHTML = `
      <div class="ssp-panel" style="border-left:6px solid #EA580C;">
        <div class="ssp-panel-title">
          <h3>🏀 ${m.cat} • ${m.home} vs ${m.away}</h3>
          <span style="font-size:0.84rem;font-weight:900;color:#15803D;">${m.date} à ${m.time} • Score : ${m.sh} - ${m.sa}</span>
        </div>
      </div>
      ${qtBlockHtml}
      ${pdfBlockHtml}
    `;
  }

  function renderSeasonStatsPage() {
    if (!sspState.isOpen) return;
    populateMatchSelector();
    if (sspState.viewMode === "match") {
      renderMatchDetailInSeasonPage();
    } else {
      renderSeasonSummaryView();
    }
  }

  window.openSeasonStatsPage = function() {
    if (!state.staffUnlocked) {
      if (typeof requestPinAccess === "function") requestPinAccess("staff");
      return;
    }
    sspState.isOpen = true;
    const pageEl = document.getElementById("seasonStatsPageOverlay");
    if (pageEl) {
      pageEl.style.display = "flex";
      pageEl.setAttribute("aria-hidden", "false");
    }
    renderSeasonStatsPage();
    window.pullImportedStatsFromCloud(true);
  };

  window.closeSeasonStatsPage = function() {
    sspState.isOpen = false;
    const pageEl = document.getElementById("seasonStatsPageOverlay");
    if (pageEl) {
      pageEl.style.display = "none";
      pageEl.setAttribute("aria-hidden", "true");
    }
  };

  window.onSspTeamChange = function(val) {
    sspState.team = val || "ALL";
    renderSeasonStatsPage();
  };

  window.setSspViewMode = function(mode) {
    sspState.viewMode = mode === "match" ? "match" : "season";
    const bSeason = document.getElementById("sspModeBtnSeason");
    const bMatch = document.getElementById("sspModeBtnMatch");
    const matchSelWrap = document.getElementById("sspMatchSelectorWrap");

    if (bSeason) bSeason.classList.toggle("active", sspState.viewMode === "season");
    if (bMatch) bMatch.classList.toggle("active", sspState.viewMode === "match");
    if (matchSelWrap) matchSelWrap.style.display = sspState.viewMode === "match" ? "flex" : "none";

    renderSeasonStatsPage();
  };

  window.onSspMatchChange = function(matchIdStr) {
    sspState.selectedMatchId = Number(matchIdStr) || matchIdStr;
    renderSeasonStatsPage();
  };

  window.openSingleMatchInStatsPage = function(matchId) {
    sspState.selectedMatchId = Number(matchId) || matchId;
    window.setSspViewMode("match");
  };

  window.exportSeasonStatsJson = function() {
    const payload = {
      club: "LSBSC",
      exportedAt: new Date().toISOString(),
      teamFilter: sspState.team,
      summary: getTeamSeasonSummary(sspState.team),
      importedPdfReports: sspState.importedReports
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `lsbsc-stats-${sspState.team.toLowerCase()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    showImportFeedback(`✅ Export JSON téléchargé (lsbsc-stats-${sspState.team.toLowerCase()}.json).`);
  };

  function parseCsvStatsText(csvText) {
    const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    if (lines.length < 2) return 0;
    const sep = lines[0].includes(";") ? ";" : ",";
    const headers = lines[0].split(sep).map(h => h.trim().toLowerCase());
    const idxMatchId = headers.findIndex(h => h === "match_id" || h === "id");
    const idxNum = headers.findIndex(h => h === "num" || h === "maillot");
    const idxName = headers.findIndex(h => h === "name" || h === "nom" || h === "joueuse");
    const idxPts = headers.findIndex(h => h === "pts" || h === "points");
    const idxFouls = headers.findIndex(h => h === "fouls" || h === "ftes" || h === "fautes");

    let count = 0;
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(sep).map(c => c.trim());
      const mid = idxMatchId !== -1 ? Number(cols[idxMatchId]) : Number(sspState.selectedMatchId);
      if (!mid) continue;
      const mObj = (state.matches || []).find(x => Number(x.id) === mid);
      if (!mObj) continue;

      if (!sspState.importedReports[mid]) {
        sspState.importedReports[mid] = {
          matchRef: `Import CSV • Match #${mid}`,
          dateLabel: mObj.date || "",
          arbitres: "Import CSV",
          homeTeam: mObj.home || "",
          awayTeam: mObj.away || "",
          lsbscSide: isLSBSC(mObj.home) ? "home" : "away",
          finalScore: { home: Number(mObj.sh) || 0, away: Number(mObj.sa) || 0 },
          halves: {
            home: { h1: 0, h2: 0, ot: 0, total: Number(mObj.sh) || 0, foulsH1: 0, foulsH2: 0, foulsTot: 0 },
            away: { h1: 0, h2: 0, ot: 0, total: Number(mObj.sa) || 0, foulsH1: 0, foulsH2: 0, foulsTot: 0 }
          },
          ratios: {
            home: { maxLead: 0, maxRun: 0, benchPts: 0, ties: 0, leadTime: "00:00" },
            away: { maxLead: 0, maxRun: 0, benchPts: 0, ties: 0, leadTime: "00:00" }
          },
          players: { home: [], away: [] }
        };
      }

      const sideKey = sspState.importedReports[mid].lsbscSide === "home" ? "home" : "away";
      sspState.importedReports[mid].players[sideKey].push({
        num: idxNum !== -1 ? cols[idxNum] : "",
        name: idxName !== -1 ? cols[idxName] : `Joueuse ${i}`,
        starter: false,
        min: "-",
        pts: idxPts !== -1 ? (Number(cols[idxPts]) || 0) : 0,
        fg: 0,
        p3: 0,
        p2in: 0,
        p2out: 0,
        ft: 0,
        fouls: idxFouls !== -1 ? (Number(cols[idxFouls]) || 0) : 0
      });
      count++;
    }
    return count;
  }

  window.handleSeasonStatsFileImport = function(ev) {
    const file = ev.target.files && ev.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      const txt = String(e.target.result || "");
      try {
        if (file.name.toLowerCase().endsWith(".json") || txt.trim().startsWith("{")) {
          const parsed = JSON.parse(txt);
          const reportsMap = parsed.importedPdfReports || parsed.reports || parsed;
          let added = 0;
          if (reportsMap && typeof reportsMap === "object") {
            Object.entries(reportsMap).forEach(([k, v]) => {
              const numId = Number(k);
              if (numId && v && typeof v === "object") {
                sspState.importedReports[numId] = v;
                added++;
              }
            });
          }
          saveImportedReports();
          renderSeasonStatsPage();
          const synced = await window.pushImportedStatsToCloud(true);
          showImportFeedback(
            synced
              ? `✅ Import JSON réussi (${added} fiche(s)) et envoyé sur Firebase (/imported_stats.json) !`
              : `✅ Import JSON réussi (${added} fiche(s)) en local — vérifiez les règles Firebase pour la synchro cloud.`
          );
        } else {
          const addedRows = parseCsvStatsText(txt);
          saveImportedReports();
          renderSeasonStatsPage();
          const synced = await window.pushImportedStatsToCloud(true);
          showImportFeedback(
            synced
              ? `✅ Import CSV réussi (${addedRows} ligne(s)) et envoyé sur Firebase (/imported_stats.json) !`
              : `✅ Import CSV réussi (${addedRows} ligne(s)) en local — vérifiez les règles Firebase pour la synchro cloud.`
          );
        }
      } catch (err) {
        showImportFeedback("❌ Fichier invalide : vérifiez le format JSON ou CSV.", true);
      }
      ev.target.value = "";
    };
    reader.readAsText(file, "utf-8");
  };

  const _prevRenderAllV41 = renderAll;
  renderAll = function() {
    _prevRenderAllV41();
    syncPrivateStatsButtonVisibility();
    if (sspState.isOpen) {
      renderSeasonStatsPage();
    }
  };

  document.addEventListener("DOMContentLoaded", () => {
    loadImportedReports();
    syncPrivateStatsButtonVisibility();
    window.pullImportedStatsFromCloud(false);
    setInterval(() => {
      if (!document.hidden) window.pullImportedStatsFromCloud(true);
    }, 6000);
  });
})();

/* ================= EXTENSION V42 : ONGLET / ESPACE COACH COMPLET (MULTI-ÉQUIPES, PIN COACH, FICHES & COMMENTAIRES MATCHS) ================= */
(function() {
  const DEFAULT_COACH_PROFILES = [
    { id: "coach_1", name: "Coach U11F / U13F", pin: "2011", teams: ["U11F", "U13F"] },
    { id: "coach_2", name: "Coach U15F / U18F", pin: "2015", teams: ["U15F", "U18F"] },
    { id: "coach_3", name: "Coach U15M / U18M", pin: "2018", teams: ["U15M", "U18M"] },
    { id: "coach_4", name: "Coach Seniors (SM1 / SM2)", pin: "2026", teams: ["SM1", "SM2"] },
    { id: "coach_5", name: "Coach U9 Mini-Poussins", pin: "2009", teams: ["U9"] }
  ];

  state.coachProfiles = JSON.parse(JSON.stringify(DEFAULT_COACH_PROFILES));
  state.coachUnlocked = false;
  state.activeCoachId = null;
  state.activeCoachName = "";
  state.coachSelectedTeam = "";
  state.coachSubTab = "overview"; // 'overview' | 'roster' | 'stats' | 'comments'
  state.coachIsOpen = false;
  state.matchComments = {}; // { [matchId]: [ { id, author, text, createdAt } ] }
  state.teamRostersCustom = {}; // { [cat]: [ { name, num, poste, note } ] }

  function loadCoachLocalData() {
    try {
      const saved = localStorage.getItem("lsbsc_state_v4");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.coachProfiles) && parsed.coachProfiles.length > 0) {
          state.coachProfiles = parsed.coachProfiles;
        }
        if (parsed.matchComments && typeof parsed.matchComments === "object") {
          state.matchComments = parsed.matchComments;
        }
        if (parsed.teamRostersCustom && typeof parsed.teamRostersCustom === "object") {
          state.teamRostersCustom = parsed.teamRostersCustom;
        }
      }
    } catch (e) {}
  }
  loadCoachLocalData();

  function normalizePlayerNameKey(rawName) {
    const base = String(rawName || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!base) return "joueur";
    return base.split(" ").filter(Boolean).sort().join("_");
  }

  function getActiveCoachProfile() {
    if (state.isAdminUser || state.activeCoachId === "admin") {
      return {
        id: "admin",
        name: "Admin / Responsable Technique",
        pin: state.pinMaster || "9694",
        teams: LSBSC_TEAMS_CATALOG.map(t => t.cat)
      };
    }
    return (state.coachProfiles || []).find(c => c.id === state.activeCoachId) || null;
  }

  function getCoachAllowedTeams() {
    const prof = getActiveCoachProfile();
    if (!prof) return [];
    const validCats = LSBSC_TEAMS_CATALOG.map(t => t.cat);
    const list = (prof.teams || []).filter(c => validCats.includes(c));
    return list.length > 0 ? list : validCats;
  }

  persistLocalOnly = function() {
    try {
      localStorage.setItem("lsbsc_state_v4", JSON.stringify({
        matches: state.matches,
        tickerText: state.tickerText,
        clubAssets: state.clubAssets,
        buvetteMenuText: state.buvetteMenuText,
        clubInfosText: state.clubInfosText,
        tvDurations: state.tvDurations,
        trustedPins: state.trustedPins,
        coachProfiles: state.coachProfiles,
        matchComments: state.matchComments,
        teamRostersCustom: state.teamRostersCustom,
        updatedAt: state.lastUpdatedAt
      }));
    } catch (e) {}
  };

  saveState = function(pushCloud = true) {
    const now = Date.now();
    state.lastUpdatedAt = now;
    const payload = {
      matches: state.matches,
      tickerText: state.tickerText,
      clubAssets: state.clubAssets,
      buvetteMenuText: state.buvetteMenuText,
      clubInfosText: state.clubInfosText,
      tvDurations: state.tvDurations,
      trustedPins: state.trustedPins,
      coachProfiles: state.coachProfiles,
      matchComments: state.matchComments,
      teamRostersCustom: state.teamRostersCustom,
      updatedAt: now
    };
    try {
      localStorage.setItem("lsbsc_state_v4", JSON.stringify(payload));
    } catch (e) {}
    if (bcChannel) {
      try { bcChannel.postMessage(payload); } catch (e) {}
    }
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (pushCloud && targetUrl) {
      fetch(targetUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload)
      }).then(() => {
        const syncEl = document.getElementById("syncStatusBadge");
        if (syncEl) syncEl.textContent = "● Direct Synchronisé";
      }).catch(() => {});
    }
  };

  pollCloudSync = async function() {
    if (cloudPolling || document.hidden) return;
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (!targetUrl) return;
    cloudPolling = true;
    try {
      const light = cloudLightUrl(targetUrl);
      if (light) {
        const r = await fetch(light);
        if (!r.ok) return;
        const ts = await r.json();
        if (typeof ts !== "number" || ts <= state.lastUpdatedAt) return;
      }
      const res = await fetch(targetUrl, { headers: { "Accept": "application/json" } });
      if (!res.ok) return;
      const data = await res.json();
      if (data && Array.isArray(data.matches) && data.updatedAt && data.updatedAt > state.lastUpdatedAt) {
        state.lastUpdatedAt = data.updatedAt;
        state.matches = overlaySchedule(data.matches);
        if (data.tickerText) state.tickerText = data.tickerText;
        if (data.buvetteMenuText) state.buvetteMenuText = data.buvetteMenuText;
        if (data.clubInfosText) state.clubInfosText = data.clubInfosText;
        if (data.tvDurations) state.tvDurations = Object.assign(state.tvDurations, data.tvDurations);
        if (Array.isArray(data.trustedPins)) state.trustedPins = data.trustedPins;
        if (Array.isArray(data.coachProfiles) && data.coachProfiles.length > 0) state.coachProfiles = data.coachProfiles;
        if (data.matchComments && typeof data.matchComments === "object") state.matchComments = data.matchComments;
        if (data.teamRostersCustom && typeof data.teamRostersCustom === "object") state.teamRostersCustom = data.teamRostersCustom;
        if (data.clubAssets) state.clubAssets = Object.assign(state.clubAssets, data.clubAssets);
        persistLocalOnly();
        renderAll();
        if (state.coachIsOpen) renderCoachSpace();
      }
    } catch (e) {
    } finally {
      cloudPolling = false;
    }
  };

  const _prevRequestPinAccessV42 = window.requestPinAccess;
  window.requestPinAccess = function(target) {
    if (target === "coach") {
      if (state.coachUnlocked || state.isAdminUser) {
        if (state.isAdminUser && !state.coachUnlocked) {
          state.coachUnlocked = true;
          state.activeCoachId = "admin";
          state.activeCoachName = "Admin";
        }
        window.openCoachSpace();
        return;
      }
      state.pinTarget = "coach";
      state.pinBuffer = "";
      const titleEl = document.getElementById("pinModalTitle");
      if (titleEl) titleEl.textContent = "📋 Accès Espace Coach — Saisissez votre PIN";
      const box = document.getElementById("pinDisplayBox");
      if (box) box.textContent = "";
      const modal = document.getElementById("pinModal");
      if (modal) modal.classList.add("open");
      return;
    }
    _prevRequestPinAccessV42(target);
  };

  const _prevPressPinDigitV42 = window.pressPinDigit;
  window.pressPinDigit = function(d) {
    if (state.pinTarget === "coach") {
      if (d === "C") {
        state.pinBuffer = "";
      } else if (d === "OK") {
        verifyCoachPin();
        return;
      } else if (state.pinBuffer.length < 6) {
        state.pinBuffer += String(d);
      }
      const box = document.getElementById("pinDisplayBox");
      if (box) box.textContent = "•".repeat(state.pinBuffer.length);

      if (state.pinBuffer.length >= 4) {
        const code = state.pinBuffer;
        const isMaster = code === (state.pinMaster || "9694");
        const isCoach = (state.coachProfiles || []).some(c => String(c.pin).trim() === code);
        if (isMaster || isCoach || state.pinBuffer.length === 4) {
          setTimeout(verifyCoachPin, 120);
        }
      }
      return;
    }
    _prevPressPinDigitV42(d);
  };

  function verifyCoachPin() {
    const code = (state.pinBuffer || "").trim();
    if (!code) return;

    if (code === (state.pinMaster || "9694")) {
      state.coachUnlocked = true;
      state.isAdminUser = true;
      state.staffUnlocked = true;
      state.activeCoachId = "admin";
      state.activeCoachName = "Admin";
      state.activeStaffName = "Admin";
      document.getElementById("pinModal").classList.remove("open");
      renderAll();
      window.openCoachSpace();
      return;
    }

    const coachMatch = (state.coachProfiles || []).find(c => String(c.pin).trim() === code);
    if (coachMatch) {
      state.coachUnlocked = true;
      state.activeCoachId = coachMatch.id;
      state.activeCoachName = coachMatch.name || "Coach";
      document.getElementById("pinModal").classList.remove("open");
      renderAll();
      window.openCoachSpace();
      return;
    }

    const box = document.getElementById("pinDisplayBox");
    if (box) {
      box.style.borderColor = "#DC2626";
      box.textContent = "CODE PIN INCONNU";
      state.pinBuffer = "";
      setTimeout(() => {
        box.style.borderColor = "#CBD5E1";
        box.textContent = "";
      }, 900);
    }
  }

  window.openCoachSpace = function() {
    if (!state.coachUnlocked && !state.isAdminUser) {
      window.requestPinAccess("coach");
      return;
    }
    const allowed = getCoachAllowedTeams();
    if (!state.coachSelectedTeam || !allowed.includes(state.coachSelectedTeam)) {
      state.coachSelectedTeam = allowed[0] || "U13F";
    }
    state.coachIsOpen = true;
    const ov = document.getElementById("coachSpaceOverlay");
    if (ov) {
      ov.style.display = "flex";
      ov.setAttribute("aria-hidden", "false");
    }
    if (typeof window.pullImportedStatsFromCloud === "function") {
      window.pullImportedStatsFromCloud(false);
    }
    renderCoachSpace();
  };

  window.closeCoachSpace = function() {
    state.coachIsOpen = false;
    const ov = document.getElementById("coachSpaceOverlay");
    if (ov) {
      ov.style.display = "none";
      ov.setAttribute("aria-hidden", "true");
    }
  };

  window.logoutCoachSession = function() {
    state.coachUnlocked = false;
    state.activeCoachId = null;
    state.activeCoachName = "";
    window.closeCoachSpace();
    renderAll();
  };

  window.toggleCoachTeamAssignBox = function() {
    const panel = document.getElementById("coachTeamAssignPanel");
    if (!panel) return;
    const willOpen = panel.style.display === "none";
    panel.style.display = willOpen ? "flex" : "none";
    if (willOpen) renderCoachSelfTeamsCheckboxes();
  };

  function renderCoachSelfTeamsCheckboxes() {
    const grid = document.getElementById("coachSelfTeamsGrid");
    if (!grid) return;
    const allowed = getCoachAllowedTeams();
    grid.innerHTML = LSBSC_TEAMS_CATALOG.map(t => {
      const checked = allowed.includes(t.cat);
      return `
        <label class="coach-team-chk-pill ${checked ? "checked" : ""}">
          <input type="checkbox" ${checked ? "checked" : ""} onchange="toggleCoachAssignedTeam('${t.cat}', this.checked)">
          <span><strong>${t.cat}</strong> — ${t.short}</span>
        </label>
      `;
    }).join("");
  }

  window.toggleCoachAssignedTeam = function(catCode, isChecked) {
    const prof = getActiveCoachProfile();
    if (!prof) return;
    if (prof.id === "admin") {
      if (isChecked) state.coachSelectedTeam = catCode;
      renderCoachSelfTeamsCheckboxes();
      renderCoachSpace();
      return;
    }
    let nextTeams = Array.isArray(prof.teams) ? [...prof.teams] : [];
    if (isChecked && !nextTeams.includes(catCode)) {
      nextTeams.push(catCode);
    } else if (!isChecked) {
      if (nextTeams.length <= 1) {
        alert("Un coach doit rester associé à au moins une équipe.");
        renderCoachSelfTeamsCheckboxes();
        return;
      }
      nextTeams = nextTeams.filter(x => x !== catCode);
    }
    prof.teams = nextTeams;
    if (!nextTeams.includes(state.coachSelectedTeam)) {
      state.coachSelectedTeam = nextTeams[0];
    }
    saveState(true);
    renderCoachSelfTeamsCheckboxes();
    renderCoachSpace();
  };

  window.selectCoachTeamTab = function(catCode) {
    state.coachSelectedTeam = catCode;
    renderCoachSpace();
  };

  window.setCoachSubTab = function(subTab) {
    state.coachSubTab = subTab;
    ["overview", "roster", "stats", "comments"].forEach(k => {
      const btn = document.getElementById("coachSubTab" + k.charAt(0).toUpperCase() + k.slice(1));
      if (btn) btn.classList.toggle("active", k === subTab);
    });
    renderCoachDynamicContent();
  };

  function getTeamAggregatedPlayers(catCode) {
    const teamMatches = (state.matches || []).filter(m => m.cat === catCode);
    const reportsMap = typeof window.getImportedStatsMap === "function" ? window.getImportedStatsMap() : {};
    const agg = new Map();

    teamMatches.forEach(m => {
      const rep = reportsMap[m.id] || (typeof window.getPdfMatchReport === "function" ? window.getPdfMatchReport(m.id) : null);
      if (!rep || !rep.players) return;
      const sideKey = rep.lsbscSide === "home" ? "home" : "away";
      const list = rep.players[sideKey] || [];
      list.forEach(p => {
        const rawName = String(p.name || "Joueur").trim();
        const key = normalizePlayerNameKey(rawName);
        const numStr = String(p.num || "").replace(/^#/, "").trim();
        const cur = agg.get(key) || {
          key,
          name: rawName,
          nums: new Set(),
          games: 0,
          starts: 0,
          pts: 0,
          fg: 0,
          p3: 0,
          p2in: 0,
          p2out: 0,
          ft: 0,
          fouls: 0
        };
        if (numStr) cur.nums.add("#" + numStr);
        cur.games += 1;
        if (p.starter) cur.starts += 1;
        cur.pts += Number(p.pts) || 0;
        cur.fg += Number(p.fg) || 0;
        cur.p3 += Number(p.p3) || 0;
        cur.p2in += Number(p.p2in) || 0;
        cur.p2out += Number(p.p2out) || 0;
        cur.ft += Number(p.ft) || 0;
        cur.fouls += Number(p.fouls) || 0;
        agg.set(key, cur);
      });
    });

    const customList = (state.teamRostersCustom && state.teamRostersCustom[catCode]) || [];
    customList.forEach(cp => {
      const key = normalizePlayerNameKey(cp.name);
      if (!agg.has(key)) {
        agg.set(key, {
          key,
          name: cp.name,
          nums: cp.num ? new Set(["#" + String(cp.num).replace(/^#/, "")]) : new Set(),
          games: 0,
          starts: 0,
          pts: 0,
          fg: 0,
          p3: 0,
          p2in: 0,
          p2out: 0,
          ft: 0,
          fouls: 0,
          poste: cp.poste || "",
          note: cp.note || ""
        });
      } else {
        const existing = agg.get(key);
        if (cp.num) existing.nums.add("#" + String(cp.num).replace(/^#/, ""));
        if (cp.poste) existing.poste = cp.poste;
        if (cp.note) existing.note = cp.note;
      }
    });

    return Array.from(agg.values())
      .map(p => ({
        ...p,
        numsLabel: Array.from(p.nums).join(", ") || "-"
      }))
      .sort((a, b) => b.pts - a.pts || a.name.localeCompare(b.name));
  }

  window.addCoachRosterPlayer = function(catCode) {
    const nameEl = document.getElementById("inpCoachPlayerName");
    const numEl = document.getElementById("inpCoachPlayerNum");
    const posteEl = document.getElementById("inpCoachPlayerPoste");
    const noteEl = document.getElementById("inpCoachPlayerNote");

    const name = nameEl ? nameEl.value.trim() : "";
    if (!name) {
      alert("Veuillez saisir le nom et prénom du joueur / de la joueuse.");
      return;
    }
    if (!state.teamRostersCustom[catCode]) state.teamRostersCustom[catCode] = [];
    state.teamRostersCustom[catCode].push({
      name,
      num: numEl ? numEl.value.trim() : "",
      poste: posteEl ? posteEl.value.trim() : "",
      note: noteEl ? noteEl.value.trim() : ""
    });
    saveState(true);
    renderCoachDynamicContent();
  };

  window.addCoachMatchComment = function(matchId) {
    const inp = document.getElementById(`inpCoachComment_${matchId}`);
    const txt = inp ? inp.value.trim() : "";
    if (!txt) return;

    if (!Array.isArray(state.matchComments[matchId])) {
      state.matchComments[matchId] = [];
    }
    const now = new Date();
    const dateStr = now.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) + " à " +
                    now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

    state.matchComments[matchId].push({
      id: "c_" + Date.now(),
      author: state.activeCoachName || "Coach",
      text: txt,
      createdAt: dateStr
    });

    saveState(true);
    renderCoachDynamicContent();
  };

  window.deleteCoachMatchComment = function(matchId, commentId) {
    if (!Array.isArray(state.matchComments[matchId])) return;
    state.matchComments[matchId] = state.matchComments[matchId].filter(c => c.id !== commentId);
    saveState(true);
    renderCoachDynamicContent();
  };

  function renderCoachSpace() {
    const titleEl = document.getElementById("coachSpaceHeaderTitle");
    const subEl = document.getElementById("coachSpaceHeaderSub");
    const tabsEl = document.getElementById("coachAssignedTabs");
    const allowed = getCoachAllowedTeams();

    if (titleEl) {
      titleEl.textContent = `📋 Espace ${state.activeCoachName || "Coach"} — Revue Complète`;
    }
    if (subEl) {
      subEl.textContent = `${allowed.length} équipe(s) associée(s) : ${allowed.join(" • ")}`;
    }

    if (tabsEl) {
      tabsEl.innerHTML = allowed.map(cat => {
        const info = LSBSC_TEAMS_CATALOG.find(x => x.cat === cat);
        const active = cat === state.coachSelectedTeam;
        return `
          <button type="button" class="coach-team-tab-btn ${active ? "active" : ""}" onclick="selectCoachTeamTab('${cat}')">
            <span>🏀 ${cat}</span>
            <span style="font-size:0.74rem;opacity:0.9;">(${info ? info.short : cat})</span>
          </button>
        `;
      }).join("");
    }

    renderCoachDynamicContent();
  }

  function renderCoachDynamicContent() {
    const container = document.getElementById("coachDynamicContainer");
    if (!container) return;

    const cat = state.coachSelectedTeam || "U13F";
    const teamInfo = LSBSC_TEAMS_CATALOG.find(x => x.cat === cat) || { cat, short: cat, fullName: cat };
    const teamMatches = (state.matches || []).filter(m => m.cat === cat);
    const reportsMap = typeof window.getImportedStatsMap === "function" ? window.getImportedStatsMap() : {};

    let wins = 0, losses = 0, draws = 0, ptsFor = 0, ptsAgainst = 0, pdfCount = 0;
    teamMatches.forEach(m => {
      if (reportsMap[m.id]) pdfCount++;
      if (m.status === "finished" || m.status === "forfeit") {
        const homeUs = isLSBSC(m.home);
        ptsFor += homeUs ? (Number(m.sh) || 0) : (Number(m.sa) || 0);
        ptsAgainst += homeUs ? (Number(m.sa) || 0) : (Number(m.sh) || 0);
        const out = computeMatchOutcome(m);
        if (out === "win") wins++;
        else if (out === "loss") losses++;
        else if (out === "draw") draws++;
      }
    });

    const playersList = getTeamAggregatedPlayers(cat);

    if (state.coachSubTab === "roster") {
      container.innerHTML = `
        <div class="ssp-panel" style="border-left:6px solid #1E3A8A;">
          <div class="ssp-panel-title">
            <h3>👥 Fiche d'Équipe — ${teamInfo.fullName} (${cat})</h3>
            <span style="font-size:0.78rem;font-weight:900;color:#0369A1;">${playersList.length} joueur(s) / joueuse(s) recensé(e)s</span>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;background:#F8FAFC;padding:10px;border-radius:10px;border:1px solid #CBD5E1;">
            <input id="inpCoachPlayerName" type="text" placeholder="Nom Prénom (ex: DUPONT, Emma)" style="flex:2;min-width:170px;padding:7px 10px;border-radius:8px;border:1.5px solid #94A3B8;font-size:0.82rem;font-weight:700;">
            <input id="inpCoachPlayerNum" type="text" placeholder="N° Maillot" style="width:95px;padding:7px 10px;border-radius:8px;border:1.5px solid #94A3B8;font-size:0.82rem;font-weight:700;">
            <input id="inpCoachPlayerPoste" type="text" placeholder="Poste / Rôle (ex: Meneur)" style="flex:1;min-width:130px;padding:7px 10px;border-radius:8px;border:1.5px solid #94A3B8;font-size:0.82rem;font-weight:700;">
            <input id="inpCoachPlayerNote" type="text" placeholder="Note coach (ex: Capitaine)" style="flex:1;min-width:140px;padding:7px 10px;border-radius:8px;border:1.5px solid #94A3B8;font-size:0.82rem;font-weight:700;">
            <button type="button" class="btn-action-sm btn-save-score" onclick="addCoachRosterPlayer('${cat}')">➕ Ajouter à la fiche</button>
          </div>

          <div class="coach-roster-grid">
            ${playersList.length > 0 ? playersList.map(p => `
              <div class="coach-player-card">
                <div class="coach-player-card-head">
                  <span class="coach-player-name">${p.name}</span>
                  <span class="coach-player-nums">${p.numsLabel}</span>
                </div>
                ${p.poste || p.note ? `<div style="font-size:0.74rem;font-weight:800;color:#EA580C;">${[p.poste, p.note].filter(Boolean).join(" • ")}</div>` : ""}
                <div class="coach-player-metrics">
                  <span>🏀 ${p.games} match(s)</span>
                  <span>⭐ ${p.pts} pts (${p.games > 0 ? (p.pts / p.games).toFixed(1) : "0.0"}/m)</span>
                  <span>🎯 ${p.fg} tirs (${p.p3}×3pts)</span>
                  <span>⚠️ ${p.fouls} ftes</span>
                </div>
              </div>
            `).join("") : `<p style="font-weight:800;color:#64748B;">Aucun joueur enregistré pour le moment. Importez une feuille de match FFBB ou ajoutez un joueur ci-dessus.</p>`}
          </div>
        </div>
      `;
      return;
    }

    if (state.coachSubTab === "stats") {
      const reportsWithMatch = teamMatches.filter(m => reportsMap[m.id]);
      container.innerHTML = `
        <div class="ssp-panel">
          <div class="ssp-panel-title">
            <h3>🏅 Tableau Statistique Complet — ${teamInfo.fullName} (${pdfCount} feuille(s) FFBB)</h3>
            ${state.isAdminUser ? `<button type="button" class="btn-action-sm" style="background:#EA580C;color:#FFF;" onclick="closeCoachSpace();openSeasonStatsPage();">⬆️ Importer / Exporter JSON</button>` : ""}
          </div>
          <div class="ssp-table-wrap">
            <table class="ssp-table">
              <thead>
                <tr>
                  <th style="text-align:left;">Joueuse / Joueur</th>
                  <th>N° portés</th>
                  <th>Matchs</th>
                  <th>5 Dép.</th>
                  <th>Pts</th>
                  <th>Moy.</th>
                  <th>Tirs</th>
                  <th>3pts</th>
                  <th>2Int</th>
                  <th>2Ext</th>
                  <th>LF</th>
                  <th>Fautes</th>
                </tr>
              </thead>
              <tbody>
                ${playersList.length > 0 ? playersList.map(p => `
                  <tr>
                    <td class="left">${p.name}</td>
                    <td>${p.numsLabel}</td>
                    <td>${p.games}</td>
                    <td>${p.starts}</td>
                    <td><strong>${p.pts}</strong></td>
                    <td>${p.games > 0 ? (p.pts / p.games).toFixed(1) : "0.0"}</td>
                    <td>${p.fg}</td>
                    <td>${p.p3}</td>
                    <td>${p.p2in}</td>
                    <td>${p.p2out}</td>
                    <td>${p.ft}</td>
                    <td>${p.fouls}</td>
                  </tr>
                `).join("") : `<tr><td colspan="12" style="padding:16px;color:#64748B;">Aucune feuille statistique importée pour ${cat}.</td></tr>`}
              </tbody>
            </table>
          </div>
        </div>

        ${reportsWithMatch.map(m => {
          const rep = reportsMap[m.id];
          const sideKey = rep.lsbscSide === "home" ? "home" : "away";
          const plist = (rep.players && rep.players[sideKey]) || [];
          return `
            <div class="ssp-panel" style="border-left:5px solid #EA580C;">
              <div class="ssp-panel-title">
                <h3>📋 ${m.date} • ${m.home} (${m.sh}) vs ${m.away} (${m.sa}) — ${rep.matchRef || ""}</h3>
                <span style="font-size:0.76rem;font-weight:800;color:#475569;">Arbitres : ${rep.arbitres || "-"}</span>
              </div>
              <div class="ssp-table-wrap">
                <table class="ssp-table">
                  <thead>
                    <tr>
                      <th style="text-align:left;">Joueur / Joueuse</th>
                      <th>N°</th>
                      <th>5 Dép.</th>
                      <th>Tps</th>
                      <th>Pts</th>
                      <th>Tirs</th>
                      <th>3pts</th>
                      <th>2Int</th>
                      <th>2Ext</th>
                      <th>LF</th>
                      <th>Ftes</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${plist.map(pl => `
                      <tr>
                        <td class="left">${pl.name}</td>
                        <td><strong>#${pl.num}</strong></td>
                        <td>${pl.starter ? "⭐" : "-"}</td>
                        <td>${pl.min || "-"}</td>
                        <td><strong>${pl.pts}</strong></td>
                        <td>${pl.fg}</td>
                        <td>${pl.p3}</td>
                        <td>${pl.p2in}</td>
                        <td>${pl.p2out}</td>
                        <td>${pl.ft}</td>
                        <td>${pl.fouls}</td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>
            </div>
          `;
        }).join("")}
      `;
      return;
    }

    if (state.coachSubTab === "comments") {
      container.innerHTML = `
        <div class="ssp-panel" style="border-left:6px solid #0284C7;">
          <div class="ssp-panel-title">
            <h3>💬 Commentaires & Notes Techniques des Coachs — ${teamInfo.fullName}</h3>
            <span style="font-size:0.76rem;font-weight:800;color:#0369A1;">Synchronisé entre coachs</span>
          </div>
          ${teamMatches.map(m => {
            const comments = Array.isArray(state.matchComments[m.id]) ? state.matchComments[m.id] : [];
            const scoreLbl = m.status === "upcoming" ? `🕒 ${m.time}` : `${m.sh} - ${m.sa}`;
            return `
              <div class="coach-comment-card">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                  <div>
                    <strong style="font-size:0.9rem;color:#0F172A;">${m.date} • ${m.home} vs ${m.away}</strong>
                    <span style="margin-left:8px;background:#EFF6FF;color:#1E3A8A;padding:2px 8px;border-radius:6px;font-size:0.76rem;font-weight:900;">${scoreLbl}</span>
                  </div>
                  <span style="font-size:0.74rem;font-weight:800;color:#64748B;">${comments.length} commentaire(s)</span>
                </div>

                ${comments.length > 0 ? `
                  <div style="display:flex;flex-direction:column;gap:6px;">
                    ${comments.map(c => `
                      <div class="coach-comment-item">
                        <div class="coach-comment-meta">
                          <span>👤 ${c.author} • ${c.createdAt}</span>
                          <button type="button" style="background:none;border:none;color:#DC2626;cursor:pointer;font-weight:900;" onclick="deleteCoachMatchComment(${m.id}, '${c.id}')" title="Supprimer">🗑️</button>
                        </div>
                        <div style="color:#1E293B;font-weight:700;white-space:pre-wrap;">${c.text}</div>
                      </div>
                    `).join("")}
                  </div>
                ` : ""}

                <div class="coach-comment-form">
                  <input type="text" id="inpCoachComment_${m.id}" class="coach-comment-input" placeholder="Ajouter un commentaire sur ce match (consignes, points forts, axes de travail...)" onkeydown="if(event.key==='Enter') addCoachMatchComment(${m.id})">
                  <button type="button" class="btn-action-sm btn-save-score" onclick="addCoachMatchComment(${m.id})">💬 Publier</button>
                </div>
              </div>
            `;
          }).join("")}
        </div>
      `;
      return;
    }

    const matchRows = teamMatches.map(m => {
      const homeUs = isLSBSC(m.home);
      const out = computeMatchOutcome(m);
      const rep = reportsMap[m.id];
      const comments = Array.isArray(state.matchComments[m.id]) ? state.matchComments[m.id] : [];
      const info = getMatchVenueInfo(m);

      let badge = "🕒 À venir";
      if (m.status === "live") badge = "🔴 En direct";
      else if (m.status === "postponed") badge = "📅 Reporté";
      else if (m.status === "forfeit") badge = "🚫 Forfait";
      else if (m.status === "finished") badge = out === "win" ? "✅ Victoire" : (out === "loss" ? "❌ Défaite" : "🤝 Nul");

      return `
        <tr>
          <td>${m.date}</td>
          <td>${homeUs ? "🏠 Dom." : "🚌 Ext."}</td>
          <td class="left">${m.home} vs ${m.away}</td>
          <td><strong>${m.status === "upcoming" ? m.time : `${m.sh} - ${m.sa}`}</strong></td>
          <td>${badge}</td>
          <td>${rep ? `<span style="color:#15803D;font-weight:900;">✓ Feuille FFBB</span>` : `<span style="color:#94A3B8;">—</span>`}</td>
          <td><a href="${info.gpsUrl}" target="_blank" rel="noopener" style="color:#1D4ED8;font-weight:800;text-decoration:none;">📍 ${info.salle}</a></td>
          <td>
            <button type="button" class="ssp-btn-open-match" style="background:#0284C7;" onclick="setCoachSubTab('comments')">
              💬 ${comments.length}
            </button>
          </td>
        </tr>
      `;
    }).join("");

    container.innerHTML = `
      <div class="ssp-kpi-row">
        <div class="ssp-kpi-card">
          <span>Bilan ${teamInfo.short}</span>
          <strong>${wins}V - ${losses}D${draws ? ` - ${draws}N` : ""}</strong>
          <small>${teamMatches.length} match(s) au calendrier</small>
        </div>
        <div class="ssp-kpi-card orange">
          <span>Points Marqués</span>
          <strong>${ptsFor} pts</strong>
          <small>Moy. : ${(wins + losses + draws) > 0 ? (ptsFor / (wins + losses + draws)).toFixed(1) : "0.0"} pts/match</small>
        </div>
        <div class="ssp-kpi-card">
          <span>Points Encaissés</span>
          <strong>${ptsAgainst} pts</strong>
          <small>Différentiel : ${ptsFor - ptsAgainst >= 0 ? "+" : ""}${ptsFor - ptsAgainst}</small>
        </div>
        <div class="ssp-kpi-card green">
          <span>Effectif & Feuilles</span>
          <strong>${playersList.length} joueurs</strong>
          <small>${pdfCount} feuille(s) FFBB importée(s)</small>
        </div>
      </div>

      <div class="ssp-panel">
        <div class="ssp-panel-title">
          <h3>📅 Calendrier Complet, Scores & Suivi — ${teamInfo.fullName}</h3>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <button type="button" class="btn-action-sm" style="background:#1E3A8A;color:#FFF;" onclick="setCoachSubTab('roster')">👥 Fiche Équipe</button>
            <button type="button" class="btn-action-sm" style="background:#EA580C;color:#FFF;" onclick="setCoachSubTab('stats')">🏅 Stats Joueurs</button>
            <button type="button" class="btn-action-sm" style="background:#0284C7;color:#FFF;" onclick="setCoachSubTab('comments')">💬 Commentaires</button>
          </div>
        </div>
        <div class="ssp-table-wrap">
          <table class="ssp-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Lieu</th>
                <th style="text-align:left;">Rencontre</th>
                <th>Score / Heure</th>
                <th>Résultat</th>
                <th>Stats FFBB</th>
                <th>Salle / GPS</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>${matchRows}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  function renderCoachPinsAdminManager() {
    const listEl = document.getElementById("coachPinsListContainer");
    const chkEl = document.getElementById("newCoachTeamsCheckboxes");

    if (chkEl && !chkEl.dataset.initialized) {
      chkEl.dataset.initialized = "1";
      chkEl.innerHTML = LSBSC_TEAMS_CATALOG.map(t => `
        <label style="display:inline-flex;align-items:center;gap:4px;background:#FFFFFF;border:1px solid #7DD3FC;padding:4px 8px;border-radius:6px;font-size:0.75rem;font-weight:800;color:#0369A1;cursor:pointer;">
          <input type="checkbox" class="chk-new-coach-team" value="${t.cat}">
          <span>${t.cat}</span>
        </label>
      `).join("");
    }

    if (!listEl) return;
    listEl.innerHTML = (state.coachProfiles || []).map((c, idx) => `
      <div style="background:#FFFFFF;border:1.5px solid #BAE6FD;border-radius:10px;padding:8px 10px;display:flex;flex-direction:column;gap:6px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;">
          <input type="text" value="${(c.name || "").replace(/"/g, "&quot;")}" onchange="updateCoachProfileField(${idx}, 'name', this.value)" style="flex:1;min-width:150px;padding:5px 8px;border:1px solid #CBD5E1;border-radius:6px;font-size:0.82rem;font-weight:800;">
          <div style="display:flex;align-items:center;gap:6px;">
            <span style="font-size:0.74rem;font-weight:800;color:#0369A1;">PIN :</span>
            <input type="text" inputmode="numeric" maxlength="6" value="${(c.pin || "").replace(/"/g, "&quot;")}" onchange="updateCoachProfileField(${idx}, 'pin', this.value)" style="width:76px;padding:5px 6px;border:1.5px solid #0284C7;border-radius:6px;font-size:0.84rem;font-weight:900;text-align:center;">
            <button type="button" class="btn-action-sm" style="background:#FEE2E2;color:#B91C1C;padding:5px 8px;" onclick="removeCoachProfileUser(${idx})">🗑️</button>
          </div>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:5px;">
          ${LSBSC_TEAMS_CATALOG.map(t => {
            const has = (c.teams || []).includes(t.cat);
            return `
              <label style="display:inline-flex;align-items:center;gap:3px;padding:3px 7px;border-radius:6px;font-size:0.72rem;font-weight:800;cursor:pointer;border:1px solid ${has ? "#0284C7" : "#CBD5E1"};background:${has ? "#E0F2FE" : "#F8FAFC"};color:${has ? "#0369A1" : "#64748B"};">
                <input type="checkbox" ${has ? "checked" : ""} onchange="toggleAdminCoachTeam(${idx}, '${t.cat}', this.checked)">
                <span>${t.cat}</span>
              </label>
            `;
          }).join("")}
        </div>
      </div>
    `).join("");
  }

  window.updateCoachProfileField = function(idx, field, val) {
    if (!state.coachProfiles || !state.coachProfiles[idx]) return;
    const clean = (val || "").trim();
    if (!clean) return;
    if (field === "pin" && !/^\d{4,6}$/.test(clean)) {
      alert("Le code PIN du coach doit contenir 4 à 6 chiffres.");
      renderCoachPinsAdminManager();
      return;
    }
    state.coachProfiles[idx][field] = clean;
    saveState(true);
    renderCoachPinsAdminManager();
  };

  window.toggleAdminCoachTeam = function(idx, catCode, checked) {
    const c = state.coachProfiles && state.coachProfiles[idx];
    if (!c) return;
    let teams = Array.isArray(c.teams) ? [...c.teams] : [];
    if (checked && !teams.includes(catCode)) teams.push(catCode);
    else if (!checked) {
      if (teams.length <= 1) {
        alert("Chaque coach doit avoir au moins une équipe.");
        renderCoachPinsAdminManager();
        return;
      }
      teams = teams.filter(x => x !== catCode);
    }
    c.teams = teams;
    saveState(true);
    renderCoachPinsAdminManager();
  };

  window.addCoachPinUser = function() {
    const nameEl = document.getElementById("inpNewCoachName");
    const pinEl = document.getElementById("inpNewCoachPin");
    const name = nameEl ? nameEl.value.trim() : "";
    const pin = pinEl ? pinEl.value.trim() : "";
    const selectedTeams = Array.from(document.querySelectorAll(".chk-new-coach-team:checked")).map(el => el.value);

    if (!name) {
      alert("Veuillez saisir le nom du coach.");
      return;
    }
    if (!/^\d{4,6}$/.test(pin)) {
      alert("Veuillez saisir un code PIN de 4 à 6 chiffres.");
      return;
    }
    if (selectedTeams.length === 0) {
      alert("Veuillez sélectionner au moins une équipe pour ce coach.");
      return;
    }
    state.coachProfiles.push({
      id: "coach_" + Date.now(),
      name,
      pin,
      teams: selectedTeams
    });
    if (nameEl) nameEl.value = "";
    if (pinEl) pinEl.value = "";
    document.querySelectorAll(".chk-new-coach-team").forEach(el => { el.checked = false; });
    saveState(true);
    renderCoachPinsAdminManager();
  };

  window.removeCoachProfileUser = function(idx) {
    if (!state.coachProfiles || !state.coachProfiles[idx]) return;
    if (confirm(`Supprimer l'accès Coach « ${state.coachProfiles[idx].name} » ?`)) {
      state.coachProfiles.splice(idx, 1);
      saveState(true);
      renderCoachPinsAdminManager();
    }
  };

  const _prevOpenCloudModalV42 = window.openCloudModal;
  window.openCloudModal = function() {
    _prevOpenCloudModalV42();
    renderCoachPinsAdminManager();
  };

  const _prevRenderHeaderV42 = renderHeaderAndTicker;
  renderHeaderAndTicker = function() {
    _prevRenderHeaderV42();
    const btnCoach = document.getElementById("btnCoachToggle");
    if (btnCoach) {
      if (state.coachUnlocked) {
        btnCoach.classList.add("unlocked");
        btnCoach.innerHTML = `📋 ${state.activeCoachName || "Espace Coach"}`;
      } else {
        btnCoach.classList.remove("unlocked");
        btnCoach.innerHTML = "📋 Espace Coach";
      }
    }
  };

  const _prevRenderAllV42 = renderAll;
  renderAll = function() {
    _prevRenderAllV42();
    if (state.coachIsOpen) renderCoachSpace();
  };
})();

/* ================= EXTENSION V43 : MODIFICATION DU CODE PIN ADMIN (4 À 6 CHIFFRES) ================= */
(function() {
  const PIN_REGEX_4_6 = /^\d{4,6}$/;

  function loadMasterPinFromStorage() {
    try {
      const saved = localStorage.getItem("lsbsc_state_v4");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.pinMaster && PIN_REGEX_4_6.test(String(parsed.pinMaster).trim())) {
          state.pinMaster = String(parsed.pinMaster).trim();
          state.pinLogos = state.pinMaster;
          state.pinStaff = state.pinMaster;
        }
      }
    } catch (e) {}
  }
  loadMasterPinFromStorage();

  function refreshAdminPinBadgeUI() {
    const curPin = PIN_REGEX_4_6.test(String(state.pinMaster || "").trim())
      ? String(state.pinMaster).trim()
      : "9694";
    const badge = document.getElementById("lblCurrentAdminPinBadge");
    if (badge) badge.textContent = `Code Admin Maître : ${curPin}`;
    const inp = document.getElementById("inpMasterAdminPin");
    if (inp && document.activeElement !== inp) inp.value = curPin;
  }

  window.saveMasterAdminPin = function() {
    const inp = document.getElementById("inpMasterAdminPin");
    const raw = inp ? String(inp.value || "").trim() : "";
    if (!PIN_REGEX_4_6.test(raw)) {
      alert("Le code PIN Admin doit contenir uniquement entre 4 et 6 chiffres (ex : 9694, 59000 ou 123456).");
      if (inp) inp.focus();
      return;
    }

    // Éviter d'écraser un code déjà attribué à une personne de confiance ou un coach
    const conflictTrusted = (state.trustedPins || []).some(u => String(u.pin || "").trim() === raw);
    const conflictCoach = (state.coachProfiles || []).some(c => String(c.pin || "").trim() === raw);
    if (conflictTrusted || conflictCoach) {
      alert("Ce code PIN est déjà utilisé par un membre du staff ou un coach. Choisissez un autre code.");
      if (inp) inp.focus();
      return;
    }

    state.pinMaster = raw;
    state.pinLogos = raw;
    state.pinStaff = raw;
    refreshAdminPinBadgeUI();
    if (typeof saveState === "function") saveState(true);
    alert(`✅ Code PIN Admin mis à jour (${raw.length} chiffres) !`);
  };

  // Persistance locale & cloud incluant pinMaster
  const _prevPersistV43 = typeof persistLocalOnly === "function" ? persistLocalOnly : null;
  persistLocalOnly = function() {
    if (_prevPersistV43) _prevPersistV43();
    try {
      const raw = localStorage.getItem("lsbsc_state_v4");
      const obj = raw ? JSON.parse(raw) : {};
      obj.pinMaster = state.pinMaster;
      localStorage.setItem("lsbsc_state_v4", JSON.stringify(obj));
    } catch (e) {}
  };

  const _prevSaveStateV43 = typeof saveState === "function" ? saveState : null;
  saveState = function(pushCloud = true) {
    const now = Date.now();
    state.lastUpdatedAt = now;
    const payload = {
      matches: state.matches,
      tickerText: state.tickerText,
      clubAssets: state.clubAssets,
      buvetteMenuText: state.buvetteMenuText,
      clubInfosText: state.clubInfosText,
      tvDurations: state.tvDurations,
      trustedPins: state.trustedPins,
      coachProfiles: state.coachProfiles,
      matchComments: state.matchComments,
      teamRostersCustom: state.teamRostersCustom,
      pinMaster: state.pinMaster,
      updatedAt: now
    };
    try {
      localStorage.setItem("lsbsc_state_v4", JSON.stringify(payload));
    } catch (e) {}
    if (bcChannel) {
      try { bcChannel.postMessage(payload); } catch (e) {}
    }
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (pushCloud && targetUrl) {
      fetch(targetUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload)
      }).then(() => {
        const syncEl = document.getElementById("syncStatusBadge");
        if (syncEl) syncEl.textContent = "● Direct Synchronisé";
      }).catch(() => {});
    }
  };

  // Synchronisation cloud : récupérer pinMaster si mis à jour depuis un autre appareil
  const _origPollCloudV43 = pollCloudSync;
  pollCloudSync = async function() {
    if (cloudPolling || document.hidden) return;
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (!targetUrl) return;
    cloudPolling = true;
    try {
      const light = cloudLightUrl(targetUrl);
      if (light) {
        const r = await fetch(light);
        if (!r.ok) return;
        const ts = await r.json();
        if (typeof ts !== "number" || ts <= state.lastUpdatedAt) return;
      }
      const res = await fetch(targetUrl, { headers: { "Accept": "application/json" } });
      if (!res.ok) return;
      const data = await res.json();
      if (data && Array.isArray(data.matches) && data.updatedAt && data.updatedAt > state.lastUpdatedAt) {
        if (data.pinMaster && PIN_REGEX_4_6.test(String(data.pinMaster).trim())) {
          state.pinMaster = String(data.pinMaster).trim();
          state.pinLogos = state.pinMaster;
          state.pinStaff = state.pinMaster;
        }
      }
    } catch (e) {}
    cloudPolling = false;
    if (_origPollCloudV43) await _origPollCloudV43();
    refreshAdminPinBadgeUI();
  };

  // Sur le clavier PIN : permettre jusqu'à 6 chiffres et valider automatiquement si la saisie correspond au pinMaster (4 à 6 chiffres) ou appui sur OK
  window.pressPinDigit = function(d) {
    if (d === "C") {
      state.pinBuffer = "";
    } else if (d === "OK") {
      if (state.pinTarget === "coach") {
        // Déclenche la vérification coach via le gestionnaire existant
        const ev = new CustomEvent("lsbsc:verifyCoachPin");
        document.dispatchEvent(ev);
      }
      if (state.pinBuffer === state.pinMaster) {
        state.staffUnlocked = true;
        state.isAdminUser = true;
        state.activeStaffName = "Admin";
        state.activeCoachId = "admin";
        state.activeCoachName = "Admin";
        document.getElementById("pinModal").classList.remove("open");
        renderAll();
        if (state.pinTarget === "logos") {
          state.logosUnlocked = true;
          openLogosManagerModal();
        } else if (state.pinTarget === "settings") {
          openCloudModal();
        } else if (state.pinTarget === "coach" && typeof window.openCoachSpace === "function") {
          window.openCoachSpace();
        } else if (state.displayMode === "mobile") {
          switchMobileTab("live");
        }
        return;
      }
      if (state.pinTarget !== "coach" && typeof verifyMultiUserPinCode === "function") {
        verifyMultiUserPinCode();
      } else {
        const box = document.getElementById("pinDisplayBox");
        if (box) {
          box.style.borderColor = "#DC2626";
          box.textContent = "CODE ERRONÉ";
          state.pinBuffer = "";
          setTimeout(() => {
            box.style.borderColor = "#CBD5E1";
            box.textContent = "";
          }, 900);
        }
      }
      return;
    } else if (state.pinBuffer.length < 6) {
      state.pinBuffer += String(d);
    }

    const box = document.getElementById("pinDisplayBox");
    if (box) box.textContent = "•".repeat(state.pinBuffer.length);

    // Si la bufferisation atteint exactement le code PIN Admin maître (4, 5 ou 6 chiffres), valider immédiatement
    if (state.pinBuffer === state.pinMaster) {
      setTimeout(() => {
        if (state.pinBuffer === state.pinMaster) {
          state.staffUnlocked = true;
          state.isAdminUser = true;
          state.activeStaffName = "Admin";
          state.activeCoachId = "admin";
          state.activeCoachName = "Admin";
          document.getElementById("pinModal").classList.remove("open");
          renderAll();
          if (state.pinTarget === "logos") {
            state.logosUnlocked = true;
            openLogosManagerModal();
          } else if (state.pinTarget === "settings") {
            openCloudModal();
          } else if (state.pinTarget === "coach" && typeof window.openCoachSpace === "function") {
            window.openCoachSpace();
          } else if (state.displayMode === "mobile") {
            switchMobileTab("live");
          }
        }
      }, 120);
      return;
    }

    // Pour les codes PIN secondaires (coach / personnes de confiance), valider à 4 chiffres si non admin
    if (state.pinBuffer.length === 4 && state.pinMaster.length === 4) {
      if (state.pinTarget === "coach") {
        setTimeout(() => {
          // Vérification via le même chemin que l'extension V42
          const code = state.pinBuffer;
          const cMatch = (state.coachProfiles || []).find(c => String(c.pin).trim() === code);
          if (cMatch) {
            state.coachUnlocked = true;
            state.activeCoachId = cMatch.id;
            state.activeCoachName = cMatch.name || "Coach";
            document.getElementById("pinModal").classList.remove("open");
            renderAll();
            if (typeof window.openCoachSpace === "function") window.openCoachSpace();
          } else if (box) {
            box.style.borderColor = "#DC2626";
            box.textContent = "CODE PIN INCONNU";
            state.pinBuffer = "";
            setTimeout(() => {
              box.style.borderColor = "#CBD5E1";
              box.textContent = "";
            }, 900);
          }
        }, 120);
      } else if (typeof verifyMultiUserPinCode === "function") {
        setTimeout(verifyMultiUserPinCode, 120);
      }
    }
  };

  const _prevOpenCloudV43 = window.openCloudModal;
  window.openCloudModal = function() {
    if (_prevOpenCloudV43) _prevOpenCloudV43();
    refreshAdminPinBadgeUI();
  };

  const _prevSaveCloudV43 = window.saveCloudAndTicker;
  window.saveCloudAndTicker = function() {
    const inp = document.getElementById("inpMasterAdminPin");
    const raw = inp ? String(inp.value || "").trim() : "";
    if (raw && PIN_REGEX_4_6.test(raw)) {
      state.pinMaster = raw;
      state.pinLogos = raw;
      state.pinStaff = raw;
    }
    if (_prevSaveCloudV43) _prevSaveCloudV43();
    refreshAdminPinBadgeUI();
  };

  document.addEventListener("DOMContentLoaded", () => {
    loadMasterPinFromStorage();
    refreshAdminPinBadgeUI();
  });
})();

/* ================= EXTENSION V44 : PIN ADMIN MASQUÉ & VÉRIFICATION DE L'ANCIEN CODE POUR CHANGEMENT ================= */
(function() {
  const PIN_RX = /^\d{4,6}$/;

  function getCurrentAdminPin() {
    const p = String(state.pinMaster || "").trim();
    return PIN_RX.test(p) ? p : "9694";
  }

  function refreshMaskedAdminPinUI() {
    const cur = getCurrentAdminPin();
    const badge = document.getElementById("lblCurrentAdminPinBadge");
    if (badge) {
      badge.textContent = `Code Admin Maître : ${"•".repeat(cur.length)}`;
    }
    const oldInp = document.getElementById("inpOldMasterAdminPin");
    const newInp = document.getElementById("inpMasterAdminPin");
    if (oldInp && document.activeElement !== oldInp) oldInp.value = "";
    if (newInp && document.activeElement !== newInp) newInp.value = "";
  }

  window.saveMasterAdminPin = function() {
    const curPin = getCurrentAdminPin();
    const oldInp = document.getElementById("inpOldMasterAdminPin");
    const newInp = document.getElementById("inpMasterAdminPin");

    const oldVal = oldInp ? String(oldInp.value || "").trim() : "";
    const newVal = newInp ? String(newInp.value || "").trim() : "";

    if (!oldVal || oldVal !== curPin) {
      alert("🔒 Sécurité : l'ancien code PIN Admin saisi est incorrect.");
      if (oldInp) {
        oldInp.value = "";
        oldInp.focus();
      }
      return;
    }

    if (!PIN_RX.test(newVal)) {
      alert("Le nouveau code PIN Admin doit contenir uniquement entre 4 et 6 chiffres.");
      if (newInp) newInp.focus();
      return;
    }

    if (newVal === curPin) {
      alert("Le nouveau code PIN doit être différent de l'ancien.");
      if (newInp) newInp.focus();
      return;
    }

    const conflictTrusted = (state.trustedPins || []).some(u => String(u.pin || "").trim() === newVal);
    const conflictCoach = (state.coachProfiles || []).some(c => String(c.pin || "").trim() === newVal);
    if (conflictTrusted || conflictCoach) {
      alert("Ce code PIN est déjà utilisé par un membre du staff ou un coach.");
      if (newInp) newInp.focus();
      return;
    }

    state.pinMaster = newVal;
    state.pinLogos = newVal;
    state.pinStaff = newVal;
    if (typeof saveState === "function") saveState(true);
    refreshMaskedAdminPinUI();
    alert(`✅ Code PIN Admin modifié avec succès (${newVal.length} chiffres) !`);
  };

  // Empêcher saveCloudAndTicker d'écraser le PIN sans vérification de l'ancien code
  const _prevSaveCloudV44 = window.saveCloudAndTicker;
  window.saveCloudAndTicker = function() {
    const oldInp = document.getElementById("inpOldMasterAdminPin");
    const newInp = document.getElementById("inpMasterAdminPin");
    const oldVal = oldInp ? String(oldInp.value || "").trim() : "";
    const newVal = newInp ? String(newInp.value || "").trim() : "";

    if (newVal.length > 0) {
      window.saveMasterAdminPin();
      // Recharger les champs pour éviter que _prevSaveCloudV44 ne relise inpMasterAdminPin
      if (newInp) newInp.value = "";
      if (oldInp) oldInp.value = "";
    }
    if (_prevSaveCloudV44) _prevSaveCloudV44();
    refreshMaskedAdminPinUI();
  };

  const _prevOpenCloudV44 = window.openCloudModal;
  window.openCloudModal = function() {
    if (_prevOpenCloudV44) _prevOpenCloudV44();
    refreshMaskedAdminPinUI();
  };

  document.addEventListener("DOMContentLoaded", () => {
    refreshMaskedAdminPinUI();
  });
})();


/* ================= EXTENSION V45 : INTÉGRATION E-MARQUE TOURNOI & FEUILLE DE MARQUE + SYNCHRO FIREBASE ================= */
(function() {
  const EMARK_STORAGE_KEY = "lsbsc_emark_tournament_v1";
  const EMARK_PHT = ["", "Phase 1 · Matchs de poule", "Phase 2 · Matchs à élimination croisés", "Phase 3 · Finale et petites finales"];
  const EMARK_PH = {
    s0: ["1er poule A", "2e poule B"],
    s1: ["1er poule B", "2e poule A"],
    k0: ["3e poule A", "4e poule B"],
    k1: ["3e poule B", "4e poule A"],
    q5: ["3e poule A", "3e poule B"],
    f:  ["Vainqueur demi 1", "Vainqueur demi 2"],
    c:  ["Perdant demi 1", "Perdant demi 2"],
    k5: ["Vainqueur 5–8 n°1", "Vainqueur 5–8 n°2"],
    k7: ["Perdant 5–8 n°1", "Perdant 5–8 n°2"]
  };
  const EMARK_LAB = {
    "1": "+1 point", "2": "+2 points", "3": "+3 points",
    P: "Faute personnelle", T: "Faute technique", U: "Faute antisportive", D: "Faute disqualifiante",
    TO: "Temps mort", C: "Faute technique entraîneur", B: "Faute technique banc"
  };

  function mkDefaultPlayers() {
    return Array.from({ length: 10 }, (_, i) => ({ n: String(i + 4), name: "" }));
  }

  function mkDefaultMatchSheet() {
    return {
      info: { num: "", date: "", salle: "ANTOINE BLONDIN A 790M2", arb1: "", arb2: "", marq: "" },
      teams: [
        { name: "Équipe A", coach: "", players: mkDefaultPlayers(), on: [] },
        { name: "Équipe B", coach: "", players: mkDefaultPlayers(), on: [] }
      ],
      period: 1,
      ms: 600000,
      t0: Date.now(),
      run: false,
      pos: null,
      tm: null,
      log: []
    };
  }

  function mkDefaultTournament() {
    return {
      n: 8,
      courts: 2,
      dur: 20,
      start: "09:00",
      org: "Lille Sud Basketball Sporting Club",
      names: Array.from({ length: 8 }, (_, i) => "Équipe " + (i + 1)),
      sc: {}
    };
  }

  function sanitizeTournamentObj(raw) {
    const base = mkDefaultTournament();
    const src = (raw && typeof raw === "object") ? raw : {};
    const n = Math.max(4, Math.min(8, Number(src.n) || 8));
    const courts = (Number(src.courts) === 1) ? 1 : 2;
    const dur = Math.max(5, Number(src.dur) || 20);
    const start = (typeof src.start === "string" && /^\d{1,2}:\d{2}$/.test(src.start)) ? src.start : "09:00";
    const org = (typeof src.org === "string") ? src.org : base.org;
    const rawNames = Array.isArray(src.names) ? src.names : [];
    const names = Array.from({ length: 8 }, (_, i) => {
      const v = rawNames[i];
      return (typeof v === "string" && v.trim()) ? v : ("Équipe " + (i + 1));
    });
    const sc = (src.sc && typeof src.sc === "object") ? src.sc : {};
    return { n, courts, dur, start, org, names, sc };
  }

  function sanitizeMatchObj(raw) {
    const base = mkDefaultMatchSheet();
    const src = (raw && typeof raw === "object") ? raw : {};
    const teams = [0, 1].map(idx => {
      const tSrc = (Array.isArray(src.teams) && src.teams[idx]) ? src.teams[idx] : {};
      const players = Array.isArray(tSrc.players) && tSrc.players.length
        ? tSrc.players.map((p, j) => ({ n: String((p && p.n) ?? (j + 4)), name: String((p && p.name) || "") }))
        : mkDefaultPlayers();
      return {
        name: String(tSrc.name || (idx ? "Équipe B" : "Équipe A")),
        coach: String(tSrc.coach || ""),
        players,
        on: Array.isArray(tSrc.on) ? tSrc.on : []
      };
    });
    return {
      info: Object.assign({}, base.info, (src.info && typeof src.info === "object") ? src.info : {}),
      teams,
      period: Number(src.period) || 1,
      ms: (src.ms == null) ? 600000 : Number(src.ms),
      t0: Number(src.t0) || Date.now(),
      run: Boolean(src.run),
      pos: (src.pos === 0 || src.pos === 1) ? src.pos : null,
      tm: (src.tm != null) ? src.tm : null,
      log: Array.isArray(src.log) ? src.log : []
    };
  }

  state.emark = {
    isOpen: false,
    view: "tournoi",
    updatedAt: 0,
    tn: mkDefaultTournament(),
    match: mkDefaultMatchSheet(),
    savedTeams: {}
  };

  function loadEmarkLocal() {
    try {
      const raw = localStorage.getItem(EMARK_STORAGE_KEY);
      if (raw) {
        const p = JSON.parse(raw);
        if (p && typeof p === "object") {
          state.emark.tn = sanitizeTournamentObj(p.tn);
          state.emark.match = sanitizeMatchObj(p.match);
          state.emark.savedTeams = (p.savedTeams && typeof p.savedTeams === "object") ? p.savedTeams : {};
          state.emark.updatedAt = Number(p.updatedAt) || 0;
        }
      }
    } catch (e) {
      state.emark.tn = mkDefaultTournament();
      state.emark.match = mkDefaultMatchSheet();
    }
  }
  loadEmarkLocal();

  function getEmarkFirebaseUrl() {
    const targetUrl = state.syncUrl || DEFAULT_CLOUD_SYNC_URL;
    if (!targetUrl) return null;
    if (/\.json(\?.*)?$/.test(targetUrl)) {
      return targetUrl.replace(/\.json(\?.*)?$/, (m, q) => "/emarkTournament.json" + (q || ""));
    }
    return targetUrl.replace(/\/+$/, "") + "/emarkTournament.json";
  }

  function pushEmarkToFirebase() {
    const emarkNodeUrl = getEmarkFirebaseUrl();
    if (!emarkNodeUrl) return;
    fetch(emarkNodeUrl, {
      method: "PUT",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({
        tn: state.emark.tn,
        match: state.emark.match,
        savedTeams: state.emark.savedTeams,
        updatedAt: state.emark.updatedAt
      })
    }).then(() => {
      const lbl = document.getElementById("emarkSyncStatusLbl");
      if (lbl) lbl.textContent = "● Synchronisé Firebase (" + new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) + ")";
    }).catch(() => {});
  }

  function saveEmarkState(pushCloud = true) {
    state.emark.updatedAt = Date.now();
    try {
      localStorage.setItem(EMARK_STORAGE_KEY, JSON.stringify({
        tn: state.emark.tn,
        match: state.emark.match,
        savedTeams: state.emark.savedTeams,
        updatedAt: state.emark.updatedAt
      }));
    } catch (e) {}
    if (pushCloud) pushEmarkToFirebase();
  }

  async function pullEmarkFromFirebase() {
    const emarkNodeUrl = getEmarkFirebaseUrl();
    if (!emarkNodeUrl) return;
    try {
      const res = await fetch(emarkNodeUrl, { headers: { "Accept": "application/json" } });
      if (!res.ok) return;
      const data = await res.json();
      if (data && typeof data === "object" && data.tn && data.match && (Number(data.updatedAt) || 0) > (Number(state.emark.updatedAt) || 0)) {
        state.emark.tn = sanitizeTournamentObj(data.tn);
        state.emark.match = sanitizeMatchObj(data.match);
        if (data.savedTeams && typeof data.savedTeams === "object") {
          state.emark.savedTeams = Object.assign(state.emark.savedTeams || {}, data.savedTeams);
        }
        state.emark.updatedAt = Number(data.updatedAt) || Date.now();
        try {
          localStorage.setItem(EMARK_STORAGE_KEY, JSON.stringify({
            tn: state.emark.tn,
            match: state.emark.match,
            savedTeams: state.emark.savedTeams,
            updatedAt: state.emark.updatedAt
          }));
        } catch (e) {}
        if (state.emark.isOpen) renderEmarkAll();
      }
    } catch (e) {}
  }

  const emarkEsc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const emarkPl = p => p < 5 ? "Q" + p : "Prol." + (p - 4);
  const emarkGrp = p => p <= 2 ? 0 : p <= 4 ? 1 : p - 3;
  const emarkMaxTO = g => g == 0 ? 2 : g == 1 ? 3 : 1;
  const emarkRem = () => {
    const S = state.emark.match;
    const m = S.ms == null ? 600000 : S.ms;
    return S.run ? Math.max(0, m - (Date.now() - S.t0)) : m;
  };
  const emarkFmt = s => s == null ? "" : Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
  const emarkStop = () => {
    const S = state.emark.match;
    if (S.run) { S.ms = emarkRem(); S.run = false; }
  };
  const emarkPush = o => {
    const S = state.emark.match;
    o.per = S.period;
    o.c = Math.ceil(emarkRem() / 1000);
    S.log.push(o);
  };
  const emarkCoachOut = c => c.filter(x => x == "C").length >= 2 || c.length >= 3;
  const emarkIsOut = f => {
    const n = k => f.filter(x => x == k).length;
    return f.length >= 5 || n("D") > 0 || n("U") >= 2 || n("T") >= 2 || (n("U") > 0 && n("T") > 0);
  };
  const emarkTt = m => String(Math.floor(m / 60) % 24).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");

  function emarkCalc() {
    const S = state.emark.match;
    const T = S.teams.map(t => ({ s: 0, pts: t.players.map(() => 0), fl: t.players.map(() => []), tf: {}, to: {}, cf: [] }));
    const L = [];
    (S.log || []).forEach(e => {
      const t = T[e.t];
      if (!t) return;
      if ("123".includes(e.k) && e.k.length == 1) {
        const v = +e.k;
        t.s += v;
        if (e.p >= 0 && t.pts[e.p] != null) t.pts[e.p] += v;
      } else if (e.k == "TO") {
        const g = emarkGrp(e.per);
        t.to[g] = (t.to[g] || 0) + 1;
      } else if (e.k == "C" || e.k == "B") {
        t.cf.push(e.k);
      } else {
        if (e.p >= 0 && t.fl[e.p]) t.fl[e.p].push(e.k);
        if (e.k != "T") t.tf[e.per] = (t.tf[e.per] || 0) + 1;
      }
      L.push({ e, a: T[0].s, b: T[1].s });
    });
    return { T, L };
  }

  function emarkRr(ids) {
    const a = ids.slice(), Rd = [];
    if (a.length % 2) a.push(-1);
    const k = a.length;
    for (let r = 0; r < k - 1; r++) {
      const m = [];
      for (let i = 0; i < k / 2; i++) {
        const x = a[i], y = a[k - 1 - i];
        if (x >= 0 && y >= 0) m.push([x, y]);
      }
      Rd.push(m);
      a.splice(1, 0, a.pop());
    }
    return Rd;
  }

  function emarkPlan() {
    const TN = state.emark.tn;
    const n = Math.max(4, Math.min(8, Number(TN.n) || 8));
    const courts = Math.max(1, Number(TN.courts) || 2);
    const ids = [...Array(n).keys()], h = Math.ceil(n / 2);
    const G = [ids.slice(0, h), ids.slice(h)];
    const rds = G.map(emarkRr), M = [], mx = Math.max(1, ...rds.map(r => r.length));
    for (let r = 0; r < mx; r++) {
      rds.forEach((rd, g) => (rd[r] || []).forEach(p => M.push({ id: "g" + p[0] + "-" + p[1], a: p[0], b: p[1], g, ph: 1, lab: "Poule " + "AB"[g] })));
    }
    const slots = [], left = M.slice();
    let prev = [];
    let guard = 0;
    while (left.length && guard++ < 100) {
      const s = [], used = new Set();
      for (const pass of [0, 1]) {
        for (let i = 0; i < left.length && s.length < courts; ) {
          const m = left[i];
          if (!used.has(m.a) && !used.has(m.b) && (pass || (!prev.includes(m.a) && !prev.includes(m.b)))) {
            s.push(m);
            used.add(m.a);
            used.add(m.b);
            left.splice(i, 1);
          } else i++;
        }
      }
      if (!s.length && left.length) {
        s.push(left.shift());
      }
      slots.push(s);
      prev = [...used];
    }
    const ch = a => { for (let i = 0; i < a.length; i += courts) slots.push(a.slice(i, i + courts)); };
    const big = G[0].length > 3 && G[1].length > 3, mid = !big && G[0].length > 2 && G[1].length > 2;
    ch([{ id: "s0", ph: 2, lab: "Demi-finale 1" }, { id: "s1", ph: 2, lab: "Demi-finale 2" }, ...(big ? [{ id: "k0", ph: 2, lab: "Places 5–8 · match 1" }, { id: "k1", ph: 2, lab: "Places 5–8 · match 2" }] : mid ? [{ id: "q5", ph: 2, lab: "5e place" }] : [])]);
    ch([...(big ? [{ id: "k7", ph: 3, lab: "7e place" }, { id: "k5", ph: 3, lab: "5e place" }] : []), { id: "c", ph: 3, lab: "3e place" }, { id: "f", ph: 3, lab: "Finale" }]);
    return { G, slots, M };
  }

  function emarkStand(P, gi) {
    const TN = state.emark.tn;
    const r = P.G[gi].map(t => ({ t, j: 0, v: 0, pf: 0, pa: 0 }));
    P.M.filter(m => m.g == gi).forEach(m => {
      const s = TN.sc[m.id];
      if (!s || s[0] == null || s[1] == null || s[0] === "" || s[1] === "") return;
      const x = r.find(o => o.t == m.a), y = r.find(o => o.t == m.b);
      if (!x || !y) return;
      x.j++; y.j++; x.pf += +s[0]; x.pa += +s[1]; y.pf += +s[1]; y.pa += +s[0];
      (+s[0] > +s[1] ? x : y).v++;
    });
    r.forEach(o => { o.pts = o.v * 2 + (o.j - o.v); });
    return r.sort((p, q) => q.pts - p.pts || (q.pf - q.pa) - (p.pf - p.pa) || q.pf - p.pf || p.t - q.t);
  }

  window.openTournamentEmarkSpace = function() {
    state.emark.isOpen = true;
    const ov = document.getElementById("emarkTournamentOverlay");
    if (ov) {
      ov.style.display = "flex";
      ov.setAttribute("aria-hidden", "false");
    }
    window.setEmarkView(state.emark.view || "tournoi");
    pullEmarkFromFirebase();
  };

  window.closeTournamentEmarkSpace = function() {
    state.emark.isOpen = false;
    const ov = document.getElementById("emarkTournamentOverlay");
    if (ov) {
      ov.style.display = "none";
      ov.setAttribute("aria-hidden", "true");
    }
  };

  window.setEmarkView = function(viewName) {
    state.emark.view = ["tournoi", "match", "public", "results"].includes(viewName) ? viewName : "tournoi";
    ["tournoi", "match", "public", "results"].forEach(v => {
      const btn = document.getElementById("btnEmarkView" + v.charAt(0).toUpperCase() + v.slice(1));
      if (btn) btn.classList.toggle("active", v === state.emark.view);
    });
    const pubEl = document.getElementById("emarkPublicScreen");
    const bodyEl = document.getElementById("emarkMainScrollBody");
    const vT = document.getElementById("emarkTournoiView");
    const vM = document.getElementById("emarkMatchView");
    const vR = document.getElementById("emarkResultsView");

    if (state.emark.view === "public") {
      if (pubEl) pubEl.style.display = "grid";
      if (bodyEl) bodyEl.style.display = "none";
    } else {
      if (pubEl) pubEl.style.display = "none";
      if (bodyEl) bodyEl.style.display = "block";
      if (vT) vT.style.display = state.emark.view === "tournoi" ? "flex" : "none";
      if (vM) vM.style.display = state.emark.view === "match" ? "flex" : "none";
      if (vR) vR.style.display = state.emark.view === "results" ? "flex" : "none";
    }
    renderEmarkAll();
  };

  function renderEmarkAll() {
    const tournoiEl = document.getElementById("emarkTournoiView");
    const matchEl = document.getElementById("emarkMatchView");
    const resEl = document.getElementById("emarkResultsView");
    const pubEl = document.getElementById("emarkPublicScreen");

    try {
      if (!state.emark || !state.emark.tn || !state.emark.match) {
        state.emark = {
          isOpen: true,
          view: "tournoi",
          updatedAt: 0,
          tn: mkDefaultTournament(),
          match: mkDefaultMatchSheet(),
          savedTeams: {}
        };
      }
      state.emark.tn = sanitizeTournamentObj(state.emark.tn);
      state.emark.match = sanitizeMatchObj(state.emark.match);

      const { T, L } = emarkCalc();
      const S = state.emark.match;
      const TN = state.emark.tn;
      S.teams.forEach(t => { t.on = t.on || []; });

      if (pubEl && state.emark.view === "public") {
        const g = emarkGrp(S.period);
        const tTxt = emarkFmt(Math.ceil(emarkRem() / 1000));
        const sideHtml = idx => {
          const d = T[idx], tf = d.tf[S.period] || 0;
          return `<div>
            <div style="font-size:2rem;font-weight:900;color:${idx ? "#FF86A3" : "#7AA5FF"};">${emarkEsc(S.teams[idx].name)}</div>
            <div style="font-size:6.5rem;font-weight:900;line-height:1;color:#FBBF24;">${d.s}</div>
            <div style="margin-top:8px;">Fautes : ${tf}${tf >= 5 ? " · BONUS" : ""}</div>
            <div>Temps morts restants : ${emarkMaxTO(g) - (d.to[g] || 0)}</div>
          </div>`;
        };
        pubEl.innerHTML = sideHtml(0) + `
          <div>
            <div style="font-size:1.4rem;color:#94A3B8;">${emarkPl(S.period)}</div>
            <div id="emarkPubClock" style="font-size:4.5rem;font-weight:900;color:#FBBF24;">${tTxt}</div>
            <div style="font-size:1.1rem;color:#38BDF8;">${S.pos == null ? "" : (S.pos ? "▶ " : "◀ ") + emarkEsc(S.teams[S.pos].name)}</div>
            <button type="button" class="emark-nav-btn" style="margin-top:16px;" onclick="setEmarkView('match')">Quitter l'écran public</button>
          </div>
        ` + sideHtml(1);
      }

      const P = emarkPlan();
      const nm = i => emarkEsc(TN.names[i] || ("Équipe " + (i + 1)));
      const pd = id => { const s = TN.sc[id]; return !!s && s[0] != null && s[1] != null && s[0] !== "" && s[1] !== ""; };
      const st = P.G.map((g, gi) => emarkStand(P, gi));
      const ok = P.G.every((g, gi) => P.M.filter(m => m.g == gi).every(m => pd(m.id)));
      const [hh, mi] = String(TN.start || "09:00").split(":");
      const t0 = (+hh || 0) * 60 + (+mi || 0);
      const allM = P.slots.flat();
      const ref = {};
      if (ok) {
        const q = (g, k) => st[g][k] && st[g][k].t;
        ref.s0 = [q(0, 0), q(1, 1)];
        ref.s1 = [q(1, 0), q(0, 1)];
        if (P.G[0].length > 3 && P.G[1].length > 3) { ref.k0 = [q(0, 2), q(1, 3)]; ref.k1 = [q(1, 2), q(0, 3)]; }
        else if (P.G[0].length > 2 && P.G[1].length > 2) ref.q5 = [q(0, 2), q(1, 2)];
      }
      const wl = id => { const s = TN.sc[id], r = ref[id]; return r && pd(id) ? (+s[0] > +s[1] ? r : [r[1], r[0]]) : null; };
      const a0 = wl("s0"), a1 = wl("s1"), b0 = wl("k0"), b1 = wl("k1");
      if (a0 && a1) { ref.f = [a0[0], a1[0]]; ref.c = [a0[1], a1[1]]; }
      if (b0 && b1) { ref.k5 = [b0[0], b1[0]]; ref.k7 = [b0[1], b1[1]]; }

      let fin = null;
      if (allM.filter(m => m.ph > 1).every(m => pd(m.id))) {
        fin = [];
        ["f", "c", "k5", "k7", "q5"].forEach(id => { const w = wl(id); if (w) fin.push(...w); });
        for (let k = 2; k < 8; k++) st.forEach(g => { if (g[k] && !fin.includes(g[k].t)) fin.push(g[k].t); });
      }

      let lastPh = 0;
      const slotsHtml = P.slots.map((s, si) => {
        const hd = s[0].ph != lastPh ? `<h4 style="margin:12px 0 6px;color:#1E3A8A;font-weight:900;">${EMARK_PHT[lastPh = s[0].ph]}</h4>` : "";
        const cards = s.map((m, ci) => {
          const r = ref[m.id] || [], a = m.ph == 1 ? m.a : r[0], b = m.ph == 1 ? m.b : r[1];
          const sc = TN.sc[m.id] || [], w = pd(m.id) ? (+sc[0] > +sc[1] ? 0 : 1) : -1;
          const nn = (i, k) => i != null ? nm(i) : EMARK_PH[m.id][k];
          const cls = m.ph == 1 ? "g" + "AB"[m.g] : m.id == "f" ? "fin" : "ko";
          return `<div class="emark-mc ${cls}">
            <div style="display:flex;justify-content:space-between;font-size:0.74rem;font-weight:800;color:#64748B;">
              <span>Salle ${ci + 1}</span><span>${m.lab}</span>
            </div>
            <div class="emark-mb">
              <span class="tA ${w == 0 ? "w" : ""}">${nn(a, 0)}</span>
              <input type="number" min="0" value="${sc[0] ?? ""}" onchange="emarkUpdateMatchScore('${m.id}', 0, this.value)">
              <span>–</span>
              <input type="number" min="0" value="${sc[1] ?? ""}" onchange="emarkUpdateMatchScore('${m.id}', 1, this.value)">
              <span class="${w == 1 ? "w" : ""}">${nn(b, 1)}</span>
            </div>
            ${a != null && b != null ? `<button type="button" class="btn-action-sm" style="background:#EFF6FF;color:#1E3A8A;width:100%;" onclick="emarkOpenMatchFromTournament('${m.id}', ${a}, ${b})">📋 Ouvrir la feuille de marque</button>` : ""}
          </div>`;
        }).join("");
        return `${hd}<div class="emark-slot"><div class="emark-slot-tm">${emarkTt(t0 + si * TN.dur)}</div><div class="emark-slot-matches">${cards}</div></div>`;
      }).join("");

      const namesGrid = g => P.G[g].map(i => `
        <label style="display:flex;align-items:center;gap:6px;margin:4px 0;font-weight:800;">
          <span style="background:#1E3A8A;color:#FFF;border-radius:999px;width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;font-size:0.75rem;">${i + 1}</span>
          <input value="${emarkEsc(TN.names[i])}" onchange="emarkUpdateTeamName(${i}, this.value)" style="flex:1;padding:5px 8px;border:1px solid #CBD5E1;border-radius:7px;font-weight:800;">
        </label>
      `).join("");

      const standingsTabs = st.map((r, gi) => `
        <div class="emark-poule-card ${"AB"[gi]}">
          <h4 style="margin:0 0 6px;font-weight:900;">Poule ${"AB"[gi]}</h4>
          <table>
            <tr><th>Équipe</th><th>J</th><th>V</th><th>+/-</th><th>Pts</th></tr>
            ${r.map((o, k) => `<tr class="${k < 2 ? "q" : ""}"><td style="color:#0F172A;">${k + 1}. ${nm(o.t)}</td><td style="color:#0F172A;">${o.j}</td><td style="color:#0F172A;">${o.v}</td><td style="color:#0F172A;">${o.pf - o.pa}</td><td style="color:#0F172A;"><b>${o.pts}</b></td></tr>`).join("")}
          </table>
        </div>
      `).join("");

      if (tournoiEl) {
        tournoiEl.innerHTML = `
          <div class="emark-card">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
              <strong style="font-size:1rem;color:#1E3A8A;">⚙️ Paramètres du Tournoi (Synchronisé Firebase)</strong>
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                ${fin ? `<button type="button" class="btn-action-sm btn-save-score" onclick="setEmarkView('results')">🏆 Voir Page Résultats</button>` : ""}
                <button type="button" class="btn-action-sm" style="background:#FEE2E2;color:#B91C1C;" onclick="emarkResetTournament()">🔄 Réinitialiser tournoi</button>
              </div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;font-size:0.84rem;font-weight:800;">
              <label>Équipes :
                <select onchange="emarkUpdateTnCfg('n', +this.value)">
                  ${[4, 5, 6, 7, 8].map(k => `<option value="${k}" ${k == Math.max(4, TN.n) ? "selected" : ""}>${k}</option>`).join("")}
                </select>
              </label>
              <label>Organisateur : <input value="${emarkEsc(TN.org || "")}" onchange="emarkUpdateTnCfg('org', this.value)" style="width:210px;"></label>
              <label>Terrains :
                <button type="button" class="btn-action-sm ${TN.courts == 1 ? "btn-save-score" : ""}" onclick="emarkUpdateTnCfg('courts', 1)">1</button>
                <button type="button" class="btn-action-sm ${TN.courts == 2 ? "btn-save-score" : ""}" onclick="emarkUpdateTnCfg('courts', 2)">2</button>
              </label>
              <label>Début : <input type="time" value="${emarkEsc(TN.start || "09:00")}" onchange="emarkUpdateTnCfg('start', this.value)"></label>
              <label>Durée (min) : <input type="number" min="5" value="${TN.dur || 20}" onchange="emarkUpdateTnCfg('dur', Math.max(5, +this.value || 20))" style="width:65px;"></label>
            </div>
            <p style="margin-top:8px;font-size:0.78rem;color:#475569;font-weight:700;">
              ${allM.length} matchs · ${P.slots.length} créneaux · fin prévue à ${emarkTt(t0 + P.slots.length * TN.dur)}. Victoire = 2 pts, défaite = 1 pt.
            </p>
          </div>

          <div class="emark-grid-2">
            <div class="emark-poule-card A"><h4 style="margin:0 0 6px;color:#1D4ED8;font-weight:900;">Poule A</h4>${namesGrid(0)}</div>
            <div class="emark-poule-card B"><h4 style="margin:0 0 6px;color:#BE123C;font-weight:900;">Poule B</h4>${namesGrid(1)}</div>
          </div>

          <div class="emark-card">
            <h4 style="margin:0 0 6px;font-weight:900;color:#0F172A;">📅 Programme de la journée</h4>
            ${slotsHtml}
          </div>

          <div class="emark-grid-2">${standingsTabs}</div>
        `;
      }

      if (matchEl) {
        const periodsHtml = [1, 2, 3, 4, 5, 6].map(p =>
          `<button type="button" class="btn-action-sm ${S.period == p ? "btn-set-live" : ""}" onclick="emarkSetPeriod(${p})">${emarkPl(p)}</button>`
        ).join("");

        const savedTeamKeys = Object.keys(state.emark.savedTeams || {});
        const teamsCardsHtml = S.teams.map((tm, i) => {
          const d = T[i], g = emarkGrp(S.period), used = d.to[g] || 0, mx = emarkMaxTO(g), tf = d.tf[S.period] || 0;
          const playerRows = tm.players.map((p, j) => {
            const f = d.fl[j] || [], out = emarkIsOut(f);
            const evBtn = (k, l) => `<button type="button" class="btn-action-sm" style="padding:4px 7px;" ${out ? "disabled" : ""} onclick="emarkPlayerEvent(${i}, ${j}, '${k}')">${l}</button>`;
            return `<div style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding:6px 4px;border-top:1px solid #E2E8F0;${out ? "background:#FEE2E2;border-radius:6px;" : ""}">
              <strong style="min-width:28px;color:#1E3A8A;">#${emarkEsc(p.n)}</strong>
              <input value="${emarkEsc(p.name)}" placeholder="Nom joueur/joueuse" onchange="emarkUpdatePlayerName(${i}, ${j}, this.value)" style="flex:1;min-width:120px;padding:4px 7px;border:1px solid #CBD5E1;border-radius:6px;font-weight:700;">
              <span style="font-weight:900;min-width:36px;text-align:right;">${d.pts[j]} pt</span>
              <span style="font-size:0.75rem;font-weight:800;color:#991B1B;">Ftes: ${f.join("") || "—"}</span>
              <div style="display:flex;gap:3px;flex-wrap:wrap;width:100%;">
                ${evBtn("1", "+1")}${evBtn("2", "+2")}${evBtn("3", "+3")}
                ${evBtn("P", "P")}${evBtn("T", "T")}${evBtn("U", "U")}${evBtn("D", "D")}
              </div>
            </div>`;
          }).join("");

          return `<div class="emark-poule-card ${i ? "B" : "A"}">
            <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
              <input value="${emarkEsc(tm.name)}" onchange="emarkUpdateMatchTeamField(${i}, 'name', this.value)" style="flex:1;font-weight:900;font-size:1rem;padding:6px 8px;border:1.5px solid #94A3B8;border-radius:8px;">
              <button type="button" class="btn-action-sm btn-save-score" onclick="emarkSaveRoster(${i})" title="Mémoriser l'effectif dans Firebase">💾 Mémoriser</button>
              <select onchange="emarkLoadRoster(${i}, this.value)" style="max-width:130px;font-weight:800;">
                <option value="">Charger…</option>
                ${savedTeamKeys.map(k => `<option value="${emarkEsc(k)}">${emarkEsc(k)}</option>`).join("")}
              </select>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;font-size:0.8rem;font-weight:800;margin-bottom:8px;">
              <span>Coach : <input value="${emarkEsc(tm.coach || "")}" onchange="emarkUpdateMatchTeamField(${i}, 'coach', this.value)" style="width:130px;"></span>
              <button type="button" class="btn-action-sm" style="background:#EFF6FF;color:#1E3A8A;" ${used >= mx ? "disabled" : ""} onclick="emarkTimeout(${i})">Temps mort (${mx - used}/${mx})</button>
              <span>Fautes ${emarkPl(S.period)} : <b>${tf}</b>${tf >= 5 ? " · BONUS" : ""}</span>
              <button type="button" class="btn-action-sm" style="background:#FEF3C7;color:#92400E;" onclick="emarkCoachFoul(${i}, 'C')">+C</button>
              <button type="button" class="btn-action-sm" style="background:#FEF3C7;color:#92400E;" onclick="emarkCoachFoul(${i}, 'B')">+B</button>
              <span>${(d.cf || []).join(" ")}${emarkCoachOut(d.cf || []) ? " · exclu" : ""}</span>
            </div>
            ${playerRows}
          </div>`;
        }).join("");

        matchEl.innerHTML = `
          <div class="emark-card">
            <div class="emark-sb">
              <span class="tn">${emarkEsc(S.teams[0].name)}</span>
              <span class="n">${T[0].s}</span>
              <span style="font-size:1.5rem;font-weight:900;color:#FBBF24;">–</span>
              <span class="n">${T[1].s}</span>
              <span class="tn">${emarkEsc(S.teams[1].name)}</span>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:center;align-items:center;margin-top:10px;">
              ${periodsHtml}
              <span id="emarkClockDisplay" style="font-size:1.4rem;font-weight:900;color:#1E3A8A;margin:0 6px;font-variant-numeric:tabular-nums;">${emarkFmt(Math.ceil(emarkRem() / 1000))}</span>
              <button type="button" class="btn-action-sm btn-save-score" onclick="emarkToggleClock()">${S.run ? "⏸ Arrêter" : "▶ Démarrer"}</button>
              <button type="button" class="btn-action-sm" style="background:#E2E8F0;color:#0F172A;" onclick="emarkTogglePoss()">Poss : ${S.pos == null ? "—" : emarkEsc(S.teams[S.pos].name)}</button>
              <button type="button" class="btn-action-sm" style="background:#FEE2E2;color:#991B1B;" onclick="emarkUndo()">↩ Annuler</button>
              <button type="button" class="btn-action-sm btn-reset-up" onclick="emarkResetMatch()">Nouveau match</button>
              ${S.tm != null ? `<button type="button" class="btn-action-sm btn-set-live" onclick="emarkValidateTournamentScore()">✅ Valider au tournoi</button>` : ""}
            </div>
          </div>

          <div class="emark-grid-2">${teamsCardsHtml}</div>

          <div class="emark-card">
            <h4 style="margin:0 0 6px;font-weight:900;">📜 Déroulement du match (${L.length} action(s))</h4>
            <div style="max-height:190px;overflow-y:auto;font-size:0.82rem;">
              ${L.length ? L.slice().reverse().map(({ e, a, b }) => {
                const tm = S.teams[e.t], p = e.p >= 0 ? tm.players[e.p] : null;
                return `<div style="padding:4px 0;border-top:1px solid #E2E8F0;display:flex;gap:10px;">
                  <strong style="min-width:56px;color:#1E3A8A;">${a} – ${b}</strong>
                  <span>${emarkPl(e.per)} ${emarkFmt(e.c)} · ${emarkEsc(tm.name)}${p ? " · #" + emarkEsc(p.n) + " " + emarkEsc(p.name) : ""} · <b>${EMARK_LAB[e.k] || e.k}</b></span>
                </div>`;
              }).join("") : `<p style="color:#64748B;font-weight:700;">Aucune action enregistrée.</p>`}
            </div>
          </div>
        `;
      }

      if (resEl && state.emark.view === "results") {
        if (!fin) {
          resEl.innerHTML = `<div class="emark-card" style="text-align:center;padding:24px;">
            <h3 style="margin:0 0 6px;color:#1E3A8A;">🏆 Résultats & Podium du Tournoi</h3>
            <p style="font-weight:700;color:#475569;">Complétez les scores des poules et des phases finales dans l'onglet « 🏆 Tournoi & Poules » pour afficher le classement final.</p>
          </div>`;
        } else {
          resEl.innerHTML = `<div class="emark-card" style="text-align:center;">
            <div style="font-size:0.82rem;font-weight:900;color:#EA580C;text-transform:uppercase;">🏆 Tournoi de basket</div>
            <h3 style="margin:4px 0;font-size:1.8rem;font-weight:900;color:#0F172A;">Résultats & Classement Final</h3>
            <p style="color:#64748B;font-weight:700;">${emarkEsc(TN.org || "LSBSC")}</p>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0;">
              <div style="background:#F8FAFC;border:1.5px solid #CBD5E1;border-radius:10px;padding:12px;">🥈<br><strong>${nm(fin[1])}</strong></div>
              <div style="background:#FEF3C7;border:2px solid #D97706;border-radius:10px;padding:14px;">🥇<br><strong>${nm(fin[0])}</strong></div>
              <div style="background:#F8FAFC;border:1.5px solid #CBD5E1;border-radius:10px;padding:12px;">🥉<br><strong>${nm(fin[2])}</strong></div>
            </div>
            <ol style="text-align:left;max-width:420px;margin:0 auto;padding-left:22px;font-weight:800;">
              ${fin.map(i => `<li style="padding:4px 0;">${nm(i)} <span style="color:#64748B;font-size:0.78rem;">(Poule ${P.G[0].includes(i) ? "A" : "B"})</span></li>`).join("")}
            </ol>
          </div>`;
        }
      }
    } catch (err) {
      if (tournoiEl) {
        tournoiEl.innerHTML = `<div class="emark-card" style="color:#991B1B;background:#FEF2F2;border-color:#FCA5A5;">
          <strong>⚠️ Affichage de secours du tournoi</strong>
          <p style="font-size:0.82rem;">${emarkEsc(err && err.message ? err.message : String(err))}</p>
          <button type="button" class="btn-action-sm btn-save-score" onclick="emarkResetTournament()">Réinitialiser les données du tournoi</button>
        </div>`;
      }
    }
  }

  window.emarkUpdateTnCfg = function(key, val) {
    state.emark.tn[key] = val;
    state.emark.tn = sanitizeTournamentObj(state.emark.tn);
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkUpdateTeamName = function(idx, val) {
    state.emark.tn.names[idx] = val;
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkUpdateMatchScore = function(matchId, sideIdx, rawVal) {
    const s = state.emark.tn.sc[matchId] || [null, null];
    s[sideIdx] = rawVal === "" ? null : Math.max(0, parseInt(rawVal, 10) || 0);
    state.emark.tn.sc[matchId] = s;
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkResetTournament = function() {
    if (!confirm("Réinitialiser le tournoi et effacer les scores du tournoi ?")) return;
    state.emark.tn = mkDefaultTournament();
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkOpenMatchFromTournament = function(matchId, idxA, idxB) {
    const TN = state.emark.tn;
    const fresh = mkDefaultMatchSheet();
    [idxA, idxB].forEach((ti, k) => {
      const nme = TN.names[ti] || ("Équipe " + (ti + 1));
      fresh.teams[k].name = nme;
      const sv = state.emark.savedTeams && state.emark.savedTeams[nme];
      if (sv) {
        fresh.teams[k].coach = sv.coach || "";
        fresh.teams[k].players = (sv.players || mkDefaultPlayers()).map(q => ({ ...q }));
      }
    });
    fresh.tm = matchId;
    state.emark.match = fresh;
    saveEmarkState(true);
    window.setEmarkView("match");
  };

  window.emarkValidateTournamentScore = function() {
    const S = state.emark.match;
    if (S.tm == null) return;
    const { T } = emarkCalc();
    if (T[0].s == T[1].s) {
      alert("Égalité : jouez la prolongation avant de valider le score au tournoi.");
      return;
    }
    state.emark.tn.sc[S.tm] = [T[0].s, T[1].s];
    saveEmarkState(true);
    window.setEmarkView("tournoi");
  };

  window.emarkSetPeriod = function(p) {
    emarkStop();
    state.emark.match.period = p;
    state.emark.match.ms = p <= 4 ? 600000 : 300000;
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkToggleClock = function() {
    const S = state.emark.match;
    if (S.run) {
      emarkStop();
    } else {
      S.ms = emarkRem();
      S.t0 = Date.now();
      S.run = true;
    }
    saveEmarkState(false);
    renderEmarkAll();
  };

  window.emarkTogglePoss = function() {
    const S = state.emark.match;
    S.pos = S.pos == null ? 0 : 1 - S.pos;
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkUndo = function() {
    state.emark.match.log.pop();
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkResetMatch = function() {
    if (!confirm("Démarrer une nouvelle feuille de marque ?")) return;
    state.emark.match = mkDefaultMatchSheet();
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkPlayerEvent = function(tIdx, pIdx, k) {
    emarkPush({ t: tIdx, p: pIdx, k });
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkTimeout = function(tIdx) {
    emarkStop();
    emarkPush({ t: tIdx, p: -1, k: "TO" });
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkCoachFoul = function(tIdx, k) {
    emarkPush({ t: tIdx, p: -1, k });
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkUpdateMatchTeamField = function(tIdx, field, val) {
    state.emark.match.teams[tIdx][field] = val;
    saveEmarkState(true);
    renderEmarkAll();
  };

  window.emarkUpdatePlayerName = function(tIdx, pIdx, val) {
    state.emark.match.teams[tIdx].players[pIdx].name = val;
    saveEmarkState(true);
  };

  window.emarkSaveRoster = function(tIdx) {
    const tm = state.emark.match.teams[tIdx];
    if (!tm || !tm.name) return;
    state.emark.savedTeams[tm.name] = {
      coach: tm.coach || "",
      players: (tm.players || []).map(p => ({ ...p }))
    };
    saveEmarkState(true);
    alert(`Effectif « ${tm.name} » mémorisé dans Firebase !`);
    renderEmarkAll();
  };

  window.emarkLoadRoster = function(tIdx, name) {
    if (!name || !state.emark.savedTeams || !state.emark.savedTeams[name]) return;
    const sv = state.emark.savedTeams[name];
    state.emark.match.teams[tIdx].name = name;
    state.emark.match.teams[tIdx].coach = sv.coach || "";
    state.emark.match.teams[tIdx].players = (sv.players || mkDefaultPlayers()).map(p => ({ ...p }));
    saveEmarkState(true);
    renderEmarkAll();
  };

  setInterval(() => {
    if (!state.emark || !state.emark.isOpen) return;
    const S = state.emark.match;
    if (S.run && emarkRem() <= 0) {
      S.ms = 0;
      S.run = false;
      saveEmarkState(true);
      renderEmarkAll();
      return;
    }
    const tStr = emarkFmt(Math.ceil(emarkRem() / 1000));
    const el1 = document.getElementById("emarkClockDisplay");
    const el2 = document.getElementById("emarkPubClock");
    if (el1) el1.textContent = tStr;
    if (el2) el2.textContent = tStr;
  }, 250);

  setInterval(() => {
    if (state.emark && state.emark.isOpen && !document.hidden) {
      pullEmarkFromFirebase();
    }
  }, 6000);
})();
